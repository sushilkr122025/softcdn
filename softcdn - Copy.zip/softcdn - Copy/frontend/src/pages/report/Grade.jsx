import React, { useEffect, useState } from 'react'
import MultiServices from '../../api/MultiServices'

function Grade() {
  const [formData, setFormData] = useState({
    grade: '',
    markstart: '',
    markend: '',
  })
  //https://github.com/piyush-eon/react-form-validation-tutorial/blob/master/src/components/form-with-yup.jsx
  //https://www.bezkoder.com/react-node-express-mongodb-mern-stack/
  //https://githubcode.com/react-node-app-github/
  //https://www.bezkoder.com/react-spring-boot-crud/

  const handleInput = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: [e.target.value] }))
  }

  const [gradeList, setGradeList] = useState([])
  const handleGradeList = async () => {
    const res = await MultiServices.GradeList()
    console.log(res)

    setGradeList(res)
  }

  useEffect(() => {
    handleGradeList()
  }, [])

  const handelsubmit = async (e) => {
    e.preventDefault()
    try {
      await MultiServices.GradeAdd(formData)
      setFormData({
        grade: '',
        markstart: '',
        markend: '',
      })
      handleGradeList()
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="container">
      <div className="row pb-4 mb-4">
        <div className="col-md-4 offset-4">
          <h4>Set Grading</h4>
          <form onSubmit={handelsubmit}>
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Grade</th>
                  <th>From</th>
                  <th>-</th>
                  <th>To</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <input
                      type="text"
                      name="grade"
                      value={formData.grade}
                      onChange={handleInput}
                      className="form-control"
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name="markstart"
                      value={formData.markstart}
                      onChange={handleInput}
                      className="form-control"
                    />
                  </td>
                  <td>-</td>
                  <td>
                    <input
                      type="text"
                      name="markend"
                      value={formData.markend}
                      onChange={handleInput}
                      className="form-control"
                    />
                  </td>
                </tr>
              </tbody>
            </table>

            <div className=" text-center p-2">
              <input type="submit" value="Submit" className="btn btn-primary" />
            </div>
          </form>
        </div>
      </div>
      <div className="row">
        <div className="col-md-4 offset-4">
          <h4>Grades</h4>
          {gradeList.length > 0 && (
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>-</th>
                  <th>Grade</th>
                  <th>From</th>
                  <th>To</th>
                </tr>
              </thead>
              <tbody>
                {gradeList.map((item, key) => {
                  return (
                    <tr key={key}>
                      <td>{key + 1}</td>
                      <td>{item.grade}</td>
                      <td>{item.markstart}</td>
                      <td>{item.markend}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

export default Grade
