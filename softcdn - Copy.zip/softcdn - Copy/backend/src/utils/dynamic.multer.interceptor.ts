import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  mixin,
  Type,
} from '@nestjs/common';
import { FileInterceptor, FileFieldsInterceptor } from '@nestjs/platform-express';
import { generateMulterConfig } from '../services/multer.config.service';
import { StorageEngine } from 'multer';

export function DynamicMulterInterceptor(
  folderPathCallback: (req: any) => string,
  fields: { name: string; maxCount: number }[]
  //  fieldName: string = 'files',
  // maxCount: number = 10
): Type<NestInterceptor> {
  @Injectable()
  class MixinInterceptor implements NestInterceptor {
    async intercept(context: ExecutionContext, next: CallHandler) {
      const ctx = context.switchToHttp();
      const request = ctx.getRequest();

      const folderName = folderPathCallback(request);
      // const multerOptions = generateMulterConfig(folderName);
      const multerOptions: {
        storage: StorageEngine;
        limits?: { files: number };
      } = generateMulterConfig(folderName);

      const totalFilesLimit = fields.reduce((acc, f) => acc + f.maxCount, 0);
      multerOptions.limits = { files: totalFilesLimit };

      // const InterceptorClass = FileInterceptor(fields, multerOptions);
      // const interceptorInstance = new InterceptorClass();
      const InterceptorClass = FileFieldsInterceptor(fields, multerOptions);
      const interceptorInstance = new InterceptorClass();

      return interceptorInstance.intercept(context, next);
    }
  }

  return mixin(MixinInterceptor);
}
