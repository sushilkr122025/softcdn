export class ExamWithQuestionsDto {
  questionpaper: {
    examName: string;
    className: number;
    subject: string;
    marks: number;
    examDate: string;
    tenantId: string;
  };
  questions: {
    tId: number;
    subject: string;
    class: string;
    subdomain: string;
    quesType: string;
    correctAns: string;
    marks: number;
    sectionNo: number;
  }[];
}
