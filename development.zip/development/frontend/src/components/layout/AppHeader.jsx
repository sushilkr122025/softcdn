import React, { useState } from 'react';
import useAuth from '../../context/AuthContext';
import logo from '../../assets/images/logo.png';
import userimg from '../../assets/images/user/user.jpg';
import off from '../../assets/images/off.svg';
import { FaPowerOff } from "react-icons/fa";
import ThemeToggle from './ThemeToggle';
import NotificationBell from '../NotificationBell';
import { MdOutlineArrowBackIosNew, MdOutlineArrowForwardIos } from "react-icons/md";

const AppHeader = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();
  const [isopen, setIsOpen] = useState(true)
  return (
    <header className="d-flex justify-content-between align-items-center py-2 shadow-sm appheaderbg fixed-top z-3">
      <div className='d-flex justify-content-between align-items-center gap-5'>
        <img src={logo} alt="logo" width={100} className='img-fluid ' />
        <div onClick={toggleSidebar}>
          <button className='btn btn-toggle p-1' onClick={() => setIsOpen(!isopen)} >{isopen ? (<MdOutlineArrowBackIosNew size={23} />) : (<MdOutlineArrowForwardIos size={23} />)}</button>
        </div>
      </div>
      <div className='d-flex justify-content-around align-items-center gap-3 me-1'>
        <ThemeToggle />
        <NotificationBell />
        <div className="dropdown">
          <button className="logoutbtn custombtn" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
            <img src={off} alt="logout" width={27} title='Logout' />
          </button>
          <div className="dropdown-menu mt-3 rounded shadow p-2">
            <div className='p-2 d-flex flex-column align-items-center'>
              <img src={userimg} className="Avatar-img rounded p-1" alt="profile" />
              <p className='mb-0 text-secondary-400'>{user.name}</p>
              <p className='mb-0 text-grey-400 p-1'>{user.designation}</p>
              <div className='bg-light d-flex p-1'>
                {/* <a className="text-grey-400 border-end px-3 text-nowrap" href='/logout'>Forget ?</a> */}
                <button className="btn btn-secondary py-0 d-flex align-items-center" onClick={logout}><FaPowerOff className='me-1' />Logout</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
export default AppHeader;
