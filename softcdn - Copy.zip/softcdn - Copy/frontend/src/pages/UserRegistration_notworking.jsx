import React, { useEffect, useState } from 'react'
import './Userrejistrationcss.css'
import apiClient from '../api/apiService'

const UserRegistration = () => {
  // const navigator = useNavigate();
  const [formData, setFormData] = useState([])
  const [errors, setErrors] = useState({})
  const [userData, setUserData] = useState()

  const [stateOptions, setStateOptions] = useState([])
  const [districtOptions, setDistrictOptions] = useState([])

  // const [data, setData] = useState(false);

  const parameters = new URLSearchParams(window.location.search)
  const updateId = parameters.get('id')

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const validateForm = () => {
    const errors = {}
    // Example validation rules, you can customize as needed
    if (!formData.Name) {
      errors.Name = 'Name is required'
    }
    if (!formData.Gender) {
      errors.Gender = 'Gender is required'
    }
    if (!formData.Education) {
      errors.Education = 'Education is required'
    }
    if (!formData.Experience) {
      errors.Experience = 'Experience is required'
    }
    if (!formData.ContactNumber) {
      errors.ContactNumber = 'Contact number is required'
    }
    if (!formData.EmailID) {
      errors.EmailID = 'Email is required'
    }
    if (!formData.Address) {
      errors.Address = 'Address is required'
    }
    if (!formData.Password) {
      errors.Password = 'Password is required'
    }
    if (!formData.Status) {
      errors.Status = 'Status is required'
    }
    if (!formData.Role) {
      errors.Role = 'Role is required'
    }
    return errors
  }

  const handleState = async (val) => {
    await apiClient
      .post('/district', { stateId: val })
      .then((response) => {
        setDistrictOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }

  useEffect(() => {
    const fetchState = async () => {
      try {
        const response = await apiClient.get('/store/states')
        setStateOptions(response.data)
      } catch (error) {
        console.log(error.message)
      }
    }
    fetchState()

    if (updateId) {
      const fetchData = async () => {
        await apiClient
          .post('/userById', { id: updateId })
          .then((response) => {
            handleState(response.data[0].state)
            setUserData(response.data[0])
            console.log(response.data[0])
          })
          .catch((error) => console.log(error.message))
      }
      fetchData()
    }
  }, [])

  const onSubmitHandler = async (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)

    console.log(payload)

    const validationErrors = validateForm()
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors)
      return
    }

    try {
      console.log('Submitting form with payload:', payload);
      
      const response = await apiClient.post('/user', payload)
      console.log(response)
      console.log(response.data)
      // navigator('/dashboard')
    } catch (error) {
      console.error(error.response)
    }
  }

  const formatDate = (date) => {
    const d = new Date(date)
    const year = d.getFullYear()
    const month = (d.getMonth() + 1).toString().padStart(2, '0')
    const day = d.getDate().toString().padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  if (updateId && !userData) {
    return <div>Loading ...</div>
  }
  return (
    <>
      <div className="container">
        <nav className="mt-5">
          <div className="nav nav-tabs border-0" id="nav-tab" role="tablist">
            <button className="nav-link me-2 lq-red-color active">Teacher Registration</button>
          </div>
        </nav>
        <div className="tab-content bg-white px-5 py-4" id="nav-tabContent">
          <div className="tab-pane fade show active">
            <div className="App">
              <div className="container-fluid">
                <form className="forms red" onSubmit={onSubmitHandler}>
                  <div className="row mb-3">
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="text"
                          name="Name"
                          id="Name"
                          className="form-control "
                          placeholder="User Name"
                          onChange={handleInputChange}
                          defaultValue={userData?.name}
                        />
                        <label htmlFor="Name" className="floatinginput">
                          Name
                        </label>
                        {errors.Name && <span className="error ">{errors.Name}</span>}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="Gender"
                          name="Gender"
                          className="form-select"
                          onChange={handleInputChange}
                          defaultValue={userData?.gender}
                        >
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="female">Female</option>
                          <option value="May not Prefer">May Not Prefer</option>
                        </select>
                        <label htmlFor="Gender" className=" floatinginput required">
                          Gender
                        </label>
                        {errors.Gender && <span className="error">{errors.Gender}</span>}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="date"
                          name="DateOfBirth"
                          id="DateOfBirth"
                          className="form-control"
                          placeholder="Enter the Date Of Birth"
                          defaultValue={formatDate(userData?.DOB)}
                        />
                        <label htmlFor="DateOfBirth" className=" floatinginput required">
                          Date of Birth
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="date"
                          name="DateOfJoining"
                          id="DateOfJoining"
                          className="form-control"
                          placeholder="Enter the Date Of Joining"
                          defaultValue={formatDate(userData?.DOJ)}
                        />
                        <label htmlFor="DateOfJoining" className=" floatinginput required">
                          Date of Joining
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="Education"
                          name="Education"
                          className="form-select"
                          defaultValue={userData?.education}
                        >
                          <option value="">Select Education</option>
                          <option value="B Ed">B Ed</option>
                          <option value="Diploma">Diploma</option>
                          <option value="B.tech">B.tech</option>
                        </select>
                        {errors.Education && <span className="error">{errors.Education}</span>}
                        <label htmlFor="Education" className=" floatinginput required">
                          Education
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="Experience"
                          name="Experience"
                          className="form-select"
                          defaultValue={userData?.experience}
                        >
                          <option value="">Select Experience</option>
                          <option value="0-1">0-1</option>
                          <option value="1-5">1-5</option>
                          <option value="5-10">5-10</option>
                          <option value="10-30">10-30</option>
                          <option value="30 or more">30 or more</option>
                        </select>
                        {errors.Experience && <span className="error ">{errors.Experience}</span>}
                        <label htmlFor="Experience" className=" floatinginput required">
                          Experience
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="text"
                          name="ContactNumber"
                          id="ContactNumber"
                          className="form-control"
                          placeholder="Enter the Contact Number"
                          defaultValue={userData?.contactNo}
                        />
                        {errors.ContactNumber && (
                          <span className="error ">{errors.ContactNumber}</span>
                        )}
                        <label htmlFor="ContactNumber" className=" floatinginput required">
                          Contact Number
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="text"
                          name="AlternativeContactNumber"
                          id="AlternativeContactNumber"
                          className="form-control"
                          placeholder="Enter the Alternative Contact Number"
                          defaultValue={userData?.altContactNo}
                        />
                        <label htmlFor="AlternativeContactNumber" className="floatinginput">
                          Alternative Contact Number
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="email"
                          name="EmailID"
                          id="EmailID"
                          className="form-control"
                          placeholder="Enter the Email ID"
                          defaultValue={userData?.email}
                        />
                        {errors.EmailID && <span className="error ">{errors.EmailID}</span>}
                        <label htmlFor="EmailID" className="floatinginput required">
                          Email ID
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="text"
                          name="Address"
                          id="Address"
                          className="form-control"
                          placeholder="Enter the Address"
                          defaultValue={userData?.address}
                        />
                        {errors.Address && <span className="error ">{errors.Address}</span>}
                        <label htmlFor="Address" className="floatinginput required">
                          Address
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="State"
                          name="State"
                          className="form-select"
                          defaultValue={userData?.state}
                          onChange={(e) => handleState(e.target.value)}
                        >
                          <option value="">Select State</option>
                          {stateOptions.map((e) => (
                            <option key={e.Id} value={e.Id}>
                              {e.stateNConsti}
                            </option>
                          ))}
                        </select>
                        {errors.State && <span className="error">{errors.State}</span>}
                        <label htmlFor="State" className="floatinginput">
                          State
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="District"
                          name="District"
                          className="form-select"
                          defaultValue={userData?.district}
                        >
                          <option value="">Select District</option>
                          {districtOptions.map((e, i) => (
                            <option key={i} value={e.Id}>
                              {e.stateNConsti}
                            </option>
                          ))}
                        </select>
                        {errors.District && <span className="error">{errors.District}</span>}
                        <label htmlFor="District" className="floatinginput">
                          District
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <input
                          type="password"
                          name="Password"
                          id="Password"
                          className="form-control"
                          placeholder="Enter the Password"
                        />
                        {errors.Password && <span className="error ">{errors.Password}</span>}
                        <label htmlFor="Password" className="floatinginput required">
                          Password
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          id="Status"
                          name="Status"
                          className="form-select"
                          defaultValue={userData?.status}
                        >
                          <option value="">Select Status</option>
                          <option value="Permanent">Permanent</option>
                          <option value="Part Time">Part Time</option>
                          <option value="Internship">Internship</option>
                          <option value="Bond based">Bond based</option>
                        </select>
                        {errors.Status && <span className="error">{errors.Status}</span>}
                        <label htmlFor="Status" className="floatinginput required">
                          Employment Type
                        </label>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <div className="form-floating">
                        <select
                          name="role"
                          className="form-select"
                          defaultValue={userData?.role}
                          required
                        >
                          <option value="">Select Role Level</option>
                          <option value="Admin">Admin</option>
                          <option value="Teacher">Teacher</option>
                          <option value="co-ordinator">co-ordinator</option>
                        </select>
                        {errors.Role && <span className="error">{errors.Role}</span>}
                        <label htmlFor="Role" className="floatinginput required">
                          Role
                        </label>
                      </div>
                    </div>
                    <div className="col-12 text-center">
                      <button className="shadow-lg rounded p-2 lq-red-color border-0" type="submit">
                        SUBMIT
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
export default UserRegistration
