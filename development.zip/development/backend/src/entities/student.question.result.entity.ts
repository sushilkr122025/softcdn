import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('studentquestionresult')
export class StudentQuestionResult {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: 50 })
  paperid!: string;

  @Column({ type: 'varchar', length: 50 })
  studentid!: string;

  @Column({ type: 'varchar', length: 50 })
  class!: string;

  @Column({ type: 'varchar', length: 50 })
  section!: string;

  @Column()
  qid!: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  subject!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  subdomain!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  skill!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  questionType!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  studentAnswer!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  correctAnswer!: string;

  @Column({ type: 'float' })
  score!: number;

  @Column({ type: 'float' })
  maxScore!: number;

  @Column({ type: 'int', nullable: false })
  sequence!: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  createdate!: Date;
}
