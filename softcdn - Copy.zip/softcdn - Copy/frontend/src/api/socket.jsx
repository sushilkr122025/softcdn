import { io } from "socket.io-client";

const API_BASE_URL = import.meta.env.VITE_APIHOST;

const socketClient = io(API_BASE_URL, {
  withCredentials: true,
  transports: ["websocket"], // force websocket (optional, better performance)
});

export default socketClient;