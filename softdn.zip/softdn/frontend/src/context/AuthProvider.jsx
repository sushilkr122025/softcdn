import React, { useState, useEffect } from 'react'
// import { loginUser } from '../api/authService'
import apiClient from '../api/apiService'
import { Auth } from './AuthContext'
import { io } from "socket.io-client";
import { getLocal, setLocal, clearAll } from '../utils/storage'
const API_BASE_URL = import.meta.env.VITE_APIHOST;
function AuthProvider({ children }) {
  const [user, setUser] = useState()
  const [loading, setLoading] = useState(true)
  const [isAuth, setIsAuth] = useState(false)
  const [socket, setSocket] = useState(null);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const logged = getLocal()

    const verify = async () => {
      try {
        if (logged) {
          const response = await apiClient.get('/auth/verify')
          const data = response.data          
          setUser(data)
          setIsAuth(true)
          setLoading(false)
          setLocal(true)
        } else {
          setIsAuth(false)
          clearAll()
          setLoading(false)
        }
      } catch (error) {
        setIsAuth(false)
        clearAll()
        setUser(null)
        console.log(error)
      } finally {
        setLoading(false)
      }
    }
    verify()
    apiClient.get("/notifications/unread").then((res) => {
      setNotifications(res.data);
    });

    if (!user) return;

    const encrypteddate = user?.id ;//user?._date;

    const socketInstance = io(API_BASE_URL, {
        withCredentials: true,
        transports: ["websocket"], 
        auth: {userId: encrypteddate }
    });
    socketInstance.on("connect", () => {
      console.log(" Connected:", socketInstance .id);
    });

    socketInstance.on("connect_error", (err) => {
      console.error("Connect error:", err.message);
    });

    setSocket(socketInstance);

    // listen for new ones
    socketInstance.on("notification", (data) => {
      setNotifications((prev) => [data, ...prev]);
    });

    return () => {
      socketInstance.disconnect();
    };
  }, [])

  const markAsRead = async (id) => {
    await apiClient.post(`/notifications/read/${id}`);
    setNotifications((prev) =>
      prev.filter((n) => n.id !== id)
    );
  };

  // const login = async (email, password) => {
  //   try {
  //     const res = await loginUser(email, password)

  //     if (res.Status === 'Success') {
  //       setUser({
  //         id: res.id,
  //         name: res.name,
  //         role: res.role,
  //         rights: res.rights,
  //       })
  //       setIsAuth(true)
  //       localStorage.setItem('logged', true)
  //       return true
  //     }
  //   } catch (error) {
  //     console.log(error)
  //   } finally {
  //     setLoading(false)
  //   }
  // }

  const logout = () => {
    clearAll()
    setIsAuth(false)
    setUser(null)
  }

  const values = {
    user,
    setUser,
    // login,
    logout,
    isAuth,
    setIsAuth,
    loading,
    notifications,
    setNotifications,
    markAsRead,
    socket
  }

  return <Auth.Provider value={values}>{children}</Auth.Provider>
}

export default AuthProvider
