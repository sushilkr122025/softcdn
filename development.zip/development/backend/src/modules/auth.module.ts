import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthController } from '../controllers/auth.controller';
import { Login } from '../entities/login.entity';
import { AuthService } from '../services/auth.service';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtStrategy } from '../auth/jwt.strategy';
import { PassportModule } from '@nestjs/passport';
import { LoginActivity } from '../entities/login.activity';
import { UserAgentService } from '../services/user-agent.service';
import { EncryptionService } from '../services/encryption.service';
import { UserPermission } from '../entities/user.permissions.entity';
import { StringValue } from 'ms';
import { SchoolSetting } from '../entities/school.setting.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Login,
      LoginActivity,
      UserPermission,
      SchoolSetting,
    ]),
    ConfigModule,
    PassportModule.register({ defaultStrategy: 'jwt' }),

    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const secret = configService.get<string>('JWT_SECRET');
        const expiresIn = configService.get<string>('JWT_EXPIRES_IN');

        return {
          secret: secret ?? 'defaultSecret', // fallback to avoid undefined
          signOptions: {
            expiresIn: (expiresIn ?? '1h') as StringValue,
          },
        };
      },
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService, UserAgentService, JwtStrategy, EncryptionService],
})
export class AuthModule {}
