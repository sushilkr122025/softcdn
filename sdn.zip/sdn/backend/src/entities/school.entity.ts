import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('schools')
export class School {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100, nullable: true })
  board: string;

  @Column({ length: 20, nullable: true })
  code: string; // school unique code / id

  @Column({ unique: true, length: 50, nullable: true })
  tenantid: string; //tenent id / school auto genereted id by system

  @Column({ length: 150, nullable: true })
  name: string;

  @Column({ length: 100, nullable: true })
  logo: string;

  @Column({ length: 200, nullable: true })
  address: string;

  @Column({ length: 50, nullable: true })
  city: string;

  @Column({ length: 50, nullable: true })
  state: string;

  @Column({ length: 10, nullable: true })
  pincode: string;

  @Column({ length: 15, nullable: true })
  contact: string;

  @Column({ length: 100, nullable: true })
  website: string;

  @Column({ type: 'int', nullable: true, default: 0 })
  adminlic: number;

  @Column({ type: 'int', nullable: true, default: 0 })
  teacherlic: number;

  @Column({ type: 'int', nullable: true, default: 0 })
  studentlic: number;

  @Column({ length: 50, nullable: true })
  subscription: string;

  @Column({ length: 50, nullable: true })
  descriptive: string; // for internal validation that hold value of all license

  @Column({ length: 10, nullable: true, default: 'ACTIVE' })
  status: string;

  @Column({ length: 5, default: 'I' })
  dmltype: string;

  @CreateDateColumn({ type: 'datetime', precision: 6 })
  createdate: Date;

  @UpdateDateColumn({ type: 'datetime', precision: 6 })
  updatedate: Date;
}
