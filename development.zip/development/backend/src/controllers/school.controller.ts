/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Inject,
  NotFoundException,
  Param,
  Post,
  Query,
  Req,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { SchoolService } from '../services/school.service';
import { Questions } from '../entities/questions.entity';
import { Request } from 'express';
import { ExamWithQuestionsDto } from '../dto/exam.questions.dto';
import { DynamicMulterInterceptor } from '../utils/dynamic.multer.interceptor';
import { CanvasImage } from '../entities/canvasimage.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { LoggerService } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

@UseGuards(JwtAuthGuard)
@Controller('school')
export class SchoolController {
  constructor(
    private readonly schoolService: SchoolService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: LoggerService
  ) {}
  // old makePaper
  @Post('makePaper')
  async makePaper(@Body() data: any, @Req() req: Request): Promise<any> {
    const token = req['company'] as string;
    const tableName = data.table;

    if (!tableName) {
      throw new BadRequestException('Table name is required');
    }

    switch (tableName) {
      case 'questions':
        return await this.schoolService.getQuestion(data);

      case 'questionpaper':
        return await this.schoolService.getPaper(data);

      default:
        throw new BadRequestException('Invalid table name');
    }
  }

  @Post('getPaperById')
  async makePaperById(@Body() data: any, @Req() req: Request): Promise<any> {
    const token = req['company'] as string;
    const questionpaper = await this.schoolService.getPaperById(data);
    return questionpaper;
  }

  @Post('getpaper')
  async getPaper(@Body() data: any): Promise<any> {
    const paper = await this.schoolService.getQuestionPaper(data);
    return paper;
  }

  @Post('anskey')
  async setAnsKeyManual(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const result = await this.schoolService.setAnsKeyManual(data, tenantId);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('createcontext')
  async createContext(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const contextData = {
      ...data.params,
      tenantid: tenantId,
    };
    const result = await this.schoolService.createContext(contextData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Get('getcontext')
  async getContextByShortUuid(
    @Query('id') shortuuid: any,
    @Req() req: Request
  ): Promise<any> {
    const tenantId = req['company'] as string;
    const data = {
      shortuuid: shortuuid,
      tenantid: tenantId,
    };
    const result = await this.schoolService.getContextByShortUuid(data);
    if (!result) throw new Error('Question context');
    return result;
  }

  @Post('createquestions') //old route 'questions'
  async saveQuestion(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';

    const questionData = {
      ...data,
      tenantid: tenantId,
      folderName: folderName,
    };
    const result = await this.schoolService.saveQuestion(questionData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('question') // new route for to iniate questions for make history
  async createQuestion(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';

    const questionData = {
      ...data,
      tenantid: tenantId,
      folderName: folderName,
    };
    const result = await this.schoolService.createQuestion(questionData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('markscheme')
  async createQuestionMarkingScheme(@Body() data: any): Promise<any> {
    const result = await this.schoolService.createMarkingHistory(data);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('actionPerform')
  async questionForPaneling(
    @Body() data: any,
    @Req() req: Request
  ): Promise<string> {
    const tenantId = req['company'] as string;
    const result = await this.schoolService.actionPerform(data, tenantId);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Get('panelItems')
  async getPanels(@Req() req: Request): Promise<any> {
    const userId = (req.user as { id: number }).id;
    const panelList = await this.schoolService.getPanels(userId);
    return {
      success: true,
      data: panelList,
      meta: {
        found: !!panelList,
        total: panelList.length,
      },
    };
  }

  @Get('panelhistory/:id')
  async getPanelItemById(@Param('id') id: number) {
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getPanelHistoryById(id);
    if (!question) {
      return 'Question not found';
    }
    return question;
  }

  @Get('getquestions')
  async getQuestion(@Query('id') id: number) {
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getQuestionById(id);
    if (!question) {
      throw new Error('Question not found');
    }
    return question;
  }

  @Get('cordsQues')
  async getQuestionByUser(@Query('id') id: number) {
    console.log('id', id);
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getQuestionByUser(id);
    if (!question) {
      throw new Error('Section creation failed');
    }
    return question;
  }

  @Get('gallery')
  async getGallery() {
    const gallery = await this.schoolService.getGallery();
    if (!gallery) {
      throw new Error('Section creation failed');
    }
    return gallery;
  }
  @Post('galleryImage')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req) => req['schoolname'] || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async createGallery(
    @UploadedFiles()
    files: {
      image?: Express.Multer.File[];
    },
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    const tenantId = req['company'] as string;
    // console.log('tenantId controller', tenantId); // files is an array of Express.Multer.File
    console.log(data);

    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];
    console.log(allFiles);

    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    const gallerydata = {
      ...data,
      tenantId: tenantId,
      folderName: folderName,
    };
    const gallery = await this.schoolService.createGallery(
      allFiles,
      gallerydata
    );
    if (!gallery) {
      throw new Error('Gallery creation failed');
    }
    return Promise.resolve('Gallery created successfully');
  }

  @Post('canvas')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req) => req['schoolname'] || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async createCanvasImage(
    @UploadedFiles()
    files: {
      image?: Express.Multer.File[];
    },
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    // console.log(data);
    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];
    // console.log(allFiles);
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string)?.toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';

    const canvasdata = {
      ...data,
      tenantId: tenantId,
      folderName: folderName,
      allFiles,
    };

    const canvasImage = await this.schoolService.createCanvasImage(canvasdata);

    return { message: 'Canvas image created successfully', canvasImage };
  }

  @Post('quesPaper')
  async saveQuestionPaper(
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    // console.log('data controller', data);
    const tenantId = req['company'] as string;
    try {
      const result = await this.schoolService.saveQuestionPaper(data, tenantId);
      return result;
    } catch (error) {
      console.error('Error saving question paper:', error);
      throw new Error('Failed to save question paper');
    }
  }

  @Get('userquestions')
  async getUserQuestions(@Req() req: Request) {
    const useid = (req.user as any)?.id;
    const questions = await this.schoolService.getUserQuestions(useid);
    if (!questions) {
      throw new NotFoundException('Question not found');
    }
    return questions;
  }

  @Post('uploadImage')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req) => req['schoolname'] || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async uploadQuestionImage(
    @UploadedFiles()
    files: {
      image?: Express.Multer.File[];
    },
    @Req() req: Request
  ): Promise<any> {
    const tenantId = req['company'] as string;

    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];

    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    const gallerydata = {
      tenantId: tenantId,
      folderName: folderName,
    };
    const gallery = await this.schoolService.uploadImg(allFiles, gallerydata);
    if (!gallery) {
      throw new Error('Image upload failed');
    }
    return {
      success: true,
      gallery,
    };
  }

  @Post('deleteImage')
  async deleteImage(@Body() body: { images: string[] }, @Req() req: Request) {
    const school = req['schoolname'] as string;
    const tenantId = school.toLowerCase();
    for (const img of body.images) {
      if (!img || typeof img !== 'string') continue;

      const fileName = path.basename(img);
      if (!fileName) continue;

      const filePath = path.join(
        process.cwd(),
        '../uploads/assets/' + tenantId,
        fileName
      );

      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
    return { success: true };
  }
}
