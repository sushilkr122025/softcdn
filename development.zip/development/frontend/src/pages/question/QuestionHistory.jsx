import { useEffect, useRef, useState } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Link, useNavigate } from 'react-router-dom';
import queServices from '../../api/QuestionServices';
import ShowMessage from '../../components/ShowMessage'
import { Popover, OverlayTrigger } from 'react-bootstrap';
import { BsThreeDotsVertical } from "react-icons/bs";
import { FaCheckCircle, FaTimesCircle, FaUsers, FaExchangeAlt, FaFileAlt, FaTrash, FaRegCommentDots, FaBookmark } from "react-icons/fa";

const QuestionHistory = () => {
  const reviewReff = useRef('');
  const deleteReff = useRef('');
  const actionReff = useRef('');
  const navigator = useNavigate();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [statusCount, setStatusCount] = useState({});
  const qTypeConvert = { multipleChoice: 'Multiple Choice', trueFalse: 'True/False', oneWord: 'One Word', CR: 'Written Response', fillups: 'Fill in the Blanks', match: 'Match the Following' };

  const statusLabels = {
    APPROVED: {
      label: "Approved",
      icon: <FaCheckCircle size={20} />,
      colorClass: "status-approved-color",
    },
    REJECTED: {
      label: "Rejected",
      icon: <FaTimesCircle size={20} />,
      colorClass: "status-rejected-color",
    },
    PANELING: {
      label: "In-Review",
      icon: <FaRegCommentDots size={20} />,
      colorClass: "status-paneling-color",
    },
    READYPANELING: {
      label: "Ready for paneling",
      icon: <FaUsers size={20} />,
      colorClass: "status-readypaneling-color",
    },
    TRANSFERRED: {
      label: "Transferred",
      icon: <FaExchangeAlt size={20} />,
      colorClass: "status-transferred-color",
    },
    DRAFT: {
      label: "Draft",
      icon: <FaBookmark size={20} />,
      colorClass: "status-draft-color",
    },
    DELETED: {
      label: "Deleted",
      icon: <FaTrash size={20} />,
      colorClass: "status-deleted-color",
    },
    MSCMREQUIRE: {
      label: "Marking Scheme Missing",
      icon: <FaFileAlt size={20} />,
      colorClass: "status-mscmrequire-color",
    },
  };

  const fetchData = async () => {
    try {
      const result = await queServices.getUserQuestions();
      console.log(result);

      const formattedData = (result || []).map((item, index) => ({
        ...item,
        srNo: index + 1,
      }));
      const counts = (result || []).reduce((acc, item) => {
        const status = item.status || "UNKNOWN";
        acc[status] = (acc[status] || 0) + 1;
        return acc;
      }, {});


      setData(formattedData);
      setStatusCount(counts);
    } catch (error) {
      console.error("Error fetching questions:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleMessageAction = (action) => {
    const reffAction = actionReff.current;
    if (action === "confirm") {
      if (reffAction === 'Review') {
        sendReview(reviewReff.current);
      }
      else if (reffAction === 'Delete') {
        senddeleteQuestion(deleteReff.current);
      }
    }

    if (action === "close") {
      setShowMsg(false);
    }

  };

  const sendReview = async (e) => {
    reviewReff.current = e;
    const result = await queServices.actionPerform({ action: 'REVIEW', qid: e });
    if (result) {
      fetchData();
    }
  }
  const sendToReview = async (e) => {
    actionReff.current = 'Review';
    setTextConfirm('Confirm')
    setTextClose('Cancel')
    setRedirect('/question/history')
    setMsgType('modal');
    setMessage("Send Question for review")
    setBtnClose(true)
    setBtnConfirm(true)
    setShowMsg(true);
    reviewReff.current = e;
  }

  const senddeleteQuestion = async (e) => {
    const result = await queServices.actionPerform({ action: 'DELETE', qid: e })
    if (result) {
      fetchData();
    }
  }
  const deleteQuestion = async (e) => {
    actionReff.current = 'Delete';
    setTextConfirm('Yes')
    setTextClose('Cancel')
    setRedirect('/question/history')
    setMsgType('modal');
    setMessage("Are you sure to delete Question?")
    setBtnClose(true)
    setBtnConfirm(true)
    setShowMsg(true);
    deleteReff.current = e;
  }

  const columns = [
    {
      field: 'srNo',
      headerName: 'SR No',
      sortable: false,
      filterable: false,

    },
    {
      field: 'id',
      headerName: 'Que. Id',
    },
    {
      field: 'question',
      headerName: 'Question',
      flex: 1,
      renderCell: (params) => (
        <div
          className='text-wrap'
          dangerouslySetInnerHTML={{ __html: params.row.question }}
        />
      ),
    },
    {
      field: 'subject',
      headerName: 'Subject',
      renderCell: (params) => (
        params.row.subject
      ),
    },
    {
      field: 'class',
      headerName: 'Class',
      renderCell: (params) => (
        params.row.class
      ),
    },
    {
      field: 'quesType',
      headerName: 'Type',
      renderCell: (params) => (
        qTypeConvert[params.row.quesType]
      ),
    },
    {
      field: 'createdAt',
      headerName: 'Date',
      valueFormatter: (params) => {
        const date = new Date(params);
        if (isNaN(date)) return '';
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear().toString().slice(-2);
        return `${day}-${month}-${year}`;
      },
    },
    {
      field: 'status',
      headerName: 'Status',
      renderCell: (params) => {
        const item = params.row;
        if (item.status === 'TRANSFERRED') {
          return <span className="badge status-transferred-color">Transferred</span>;
        }

        else if (item.status === 'REJECTED') {
          return <span className="badge status-rejected-color">Rejected</span>;
        }

        else if (item.status === 'MSCMREQUIRE') {
          return (
            <span className='badge status-mscmrequire-color'>Mark Scheme Missing</span>
          );
        }
        else if (item.status === 'DRAFT') {
          return (
            <span className='badge status-draft-color'>IN-DRAFT</span>
          );
        }
        else if (item.status === 'PANELING') {
          return (
            <span className="badge status-paneling-color">IN-Review</span>
          );
        }
        else if (item.status === 'REVISING') {
          return (
            <span className="badge bg-secondary">Revise</span>
          );
        }
        else if (item.status === 'READYPANELING') {
          return (
            <span className='badge status-readypaneling-color'>Ready</span>
          );
        }
        else if (item.status === 'DELETED') {
          return (
            <span className="badge status-deleted-color">Deleted</span>
          );
        }
        else {
          return (
            <span>{item.status}</span>
          );
        }
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      renderCell: (params) => {
        const item = params.row;
        if (["TRANSFERRED", "PANELING", "REJECTED", "DELETED"].includes(item.status)) {
          return "";
        }
        const popover = (
          <Popover id={`popover-${item.id}`} className="custom-shadow border-0">
            <Popover.Body className="p-0">
              <ul className="list-unstyled mb-0 p-2" style={{ minWidth: "160px" }}>
                <li> <Link to={`/questionGeneration/${item.id}`} className="dropdown-item py-2 px-3"> Update</Link></li>
                <li><div className="dropdown-item py-2 px-3 cursor-pointer" onClick={() => sendToReview(item.id)}>Send to Review</div></li>
                {item.status === "MSCMREQUIRE" && (
                  <li><Link to={`/question/mkscheme/${item.id}`} className="dropdown-item py-2 px-3">Mark Scheme Missing</Link> </li>
                )}
                <li><div className="dropdown-item py-2 px-3 cursor-pointer" onClick={() => deleteQuestion(item.id)} > Delete</div></li>
              </ul>
            </Popover.Body>
          </Popover>
        );
        return (
          <OverlayTrigger trigger="click" placement="left" rootClose overlay={popover}>
            <button type="button" className="btn btn-sm border-0 p-0"><BsThreeDotsVertical className='btnclr pointer' size={20} /></button>
          </OverlayTrigger>
        );
      }
    },
  ];

  return (
    <>
      <div className="p-lg-4 mt-2">
        <div className="container-fluid">
          <div className="row h-80vh">
            <div className="col-12 p-lg-2 py-2">
              <div className="row align-items-center">
                <div className="col-12">
                  <h5 className='mb-0 fw-bold pagetitle mb-4'>Your Questions</h5>
                </div>
                <div className="col-12">
                  <div className="d-flex flex-wrap gap-3 mb-3">
                    {Object.entries(statusCount).map(([key, value]) => {
                      const statusInfo = statusLabels[key] || {};
                      const iconColorClass = statusInfo.colorClass || "status-default-color";
                      return (
                        <div key={key} className="d-flex align-items-center justify-content-between border bg-white ps-1 pe-1 py-1 status-card">
                          <div className="d-flex align-items-center">
                            <div className={`d-flex align-items-center justify-content-center rounded-2 me-2 status-icon-box ${iconColorClass}`}> {statusInfo.icon}</div>
                            <span className="fw-medium textcolor status-label">{statusInfo.label || key}</span>
                          </div>
                          <span className="fw-bold status-count px-1">{value}</span>
                        </div>
                      )
                    })}
                  </div>
                  {data &&
                    <div className='w-100 h-67vh'>
                      <DataGrid
                        className="custom-data-grid"
                        rows={data}
                        columns={columns}
                        loading={loading}
                        getRowId={(row) => row.id}
                        disableRowSelectionOnClick
                        pageSizeOptions={[25, 50, 100]}
                        initialState={{
                          pagination: {
                            paginationModel: { pageSize: 25, page: 0 },
                          },
                        }}
                        getRowHeight={() => 60}
                        columnHeaderHeight={50}
                      />
                    </div>
                  }
                  {!data && <p>Data Not found</p>}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose}
        onAction={handleMessageAction}
        textConfirm={textConfirm}
        textClose={textClose}
        onClose={() => setShowMsg(false)}
        onConfirm={() => {
          setShowMsg(false);
          navigator(redirect);
        }}
      />
    </>
  );
};

export default QuestionHistory;