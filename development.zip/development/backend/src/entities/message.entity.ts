import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'messages' })
export class Message {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'int', nullable: true })
  qId!: number;

  @Column({ type: 'int', nullable: true })
  userId!: number;

  @Column({ type: 'varchar', length: '1200', nullable: true })
  message!: string;

  @Column({ nullable: true }) // Autoincrement id of the message being replied to
  replyToId?: string;

  @Column({ nullable: true })
  msgType?: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt!: Date;

  @Column({ type: 'varchar', length: '50', nullable: true })
  tenantid!: string;

  @Column({ type: 'int', nullable: true }) // ques Version number to track mssage history
  quesVersion!: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;
}
