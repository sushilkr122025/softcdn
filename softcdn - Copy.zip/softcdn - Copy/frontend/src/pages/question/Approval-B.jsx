import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Modal, Button } from 'react-bootstrap'
import { CiEdit } from 'react-icons/ci'
import { MdDelete } from 'react-icons/md'
import { IoMdAdd } from 'react-icons/io'
import apiClient from '../../api/apiService'

const HighlightPage = () => {
  const { id } = useParams()
  const navigator = useNavigate()
  const [showApproveModal, setShowApproveModal] = useState(false)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [comments, setComments] = useState([])
  const [commentId, setCommentId] = useState(1)
  const [editingComment, setEditingComment] = useState(null)
  const [editedCommentText, setEditedCommentText] = useState('')
  const [selectedTextForComment, setSelectedTextForComment] = useState('')
  const [selectedHighlightId, setSelectedHighlightId] = useState(null)
  const [showCommentModal, setShowCommentModal] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedItem, setSelectedItem] = useState(null)

  useEffect(() => {
    // Fetch data from the server based on the id parameter
    apiClient
      .get(`/questions/${id}`) // Updated URL with parameter
      .then((response) => {
        setSelectedItem(response.data)
        setIsLoading(false)
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
        setIsLoading(false)
      })
  }, [id])

  const getRandomLightColor = () => {
    const letters = '89ABCDEF'
    let color = '#'
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * letters.length)]
    }
    return color
  }

  const handleHighlight = () => {
    const selectedText = window.getSelection().toString()

    if (selectedText !== '') {
      // Save the selected text and its highlight ID
      setSelectedTextForComment(selectedText)
      setSelectedHighlightId(commentId)
      setShowCommentModal(true)
      // document.getElementById('commentText').focus();
    }
  }

  const handleEditComment = (commentId) => {
    const commentToEdit = comments.find((comment) => comment.id === commentId)

    if (commentToEdit) {
      setEditingComment(commentToEdit)
      setEditedCommentText(commentToEdit.text)
    }
  }

  const handleDeleteComment = (commentId) => {
    const updatedComments = comments.filter((comment) => comment.id !== commentId)
    setComments(updatedComments)

    const highlightIdToDelete = comments.find((comment) => comment.id === commentId)?.highlightId

    if (highlightIdToDelete !== null && highlightIdToDelete !== undefined) {
      const spansToRemove = document.querySelectorAll(
        `.highlighted-text[data-highlight-id="${highlightIdToDelete}"]`
      )

      spansToRemove.forEach((span) => {
        const originalText = document.createTextNode(span.textContent)
        span.parentNode.replaceChild(originalText, span)
      })

      if (highlightIdToDelete === selectedHighlightId) {
        // setSelectedText("");
        setSelectedHighlightId(null)
      }
    }
  }

  const handleSaveEditedComment = () => {
    if (editingComment) {
      editingComment.text = editedCommentText
      setEditingComment(null)
      setEditedCommentText('')
      // console.log('Edited Comment:', editingComment);
    }
  }

  const openApproveModal = () => {
    setShowApproveModal(true)
  }

  const closeApproveModal = () => {
    setShowApproveModal(false)
  }

  const openRejectModal = () => {
    setShowRejectModal(true)
  }

  const closeRejectModal = () => {
    setShowRejectModal(false)
  }

  const handleApprovePage = () => {
    // console.log('Page Approved');
    navigator('/userQuestions?status=approved')
  }

  const handleRejectPage = () => {
    // console.log('Page Rejected');
    navigator('/userQuestions?status=rejected')
  }

  const handleSaveComment = () => {
    const highlightColor = getRandomLightColor()
    const highlightId = selectedHighlightId // Use the selectedHighlightId

    const span = document.createElement('span')
    span.className = 'highlighted-text'
    span.style.backgroundColor = highlightColor
    span.textContent = selectedTextForComment // Use selectedTextForComment
    span.setAttribute('data-highlight-id', highlightId)
    console.log(span)

    span.addEventListener('mouseenter', () => {
      const associatedComment = comments.find((comment) => comment.highlightId === highlightId)
      if (associatedComment) {
        console.log(`Comment: %c${associatedComment.text}`, `background-color: ${highlightColor}`)
      }
    })

    const selection = window.getSelection()
    const range = selection.getRangeAt(0)
    range.deleteContents()
    range.insertNode(span)

    const newComment = {
      id: commentId,
      text: editedCommentText,
      highlightId,
      highlightColor,
    }

    setComments((prevComments) => [...prevComments, newComment])
    setCommentId(commentId + 1)

    setSelectedTextForComment('') // Clear selectedTextForComment
    setSelectedHighlightId(null) // Clear selectedHighlightId

    setShowCommentModal(false)
  }

  return (
    <div className={`container mt-4 ${showCommentModal ? 'pointer-events-none' : ''}`}>
      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <div className="container mt-4">
          <div className="row">
            <div className="col-md-8">
              {selectedItem && (
                <div style={{}}>
                  <h1>Approval Process</h1>
                  <p>
                    Subject: <span onMouseUp={handleHighlight}>{selectedItem.subject}</span>
                  </p>
                  <p>
                    Class Level: <span onMouseUp={handleHighlight}>{selectedItem.class}</span>
                  </p>
                  <p>
                    Difficulty: <span onMouseUp={handleHighlight}>{selectedItem.difficulty}</span>
                  </p>
                  <p>
                    Learning Objective:{' '}
                    <span onMouseUp={handleHighlight}>{selectedItem.learnObj}</span>
                  </p>
                  <p>
                    competency: <span onMouseUp={handleHighlight}>{selectedItem.competency}</span>
                  </p>
                  <p>
                    concept: <span onMouseUp={handleHighlight}>{selectedItem.concept}</span>
                  </p>
                  <p>
                    learningOutcome:{' '}
                    <span onMouseUp={handleHighlight}>{selectedItem.learningOutcome}</span>
                  </p>
                  <p>
                    Type: <span onMouseUp={handleHighlight}>{selectedItem.quesType}</span>
                  </p>
                  <p>
                    Question: <span onMouseUp={handleHighlight}>{selectedItem.question}</span>
                  </p>
                  {/* Render other item details here */}
                </div>
              )}
            </div>

            <div className="col-md-4">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Comments</h5>
                  <ul className="list-group">
                    {comments.map((comment) => (
                      <li
                        key={comment.id}
                        className="list-group-item"
                        style={{ backgroundColor: comment.highlightColor }}
                      >
                        {editingComment?.id === comment.id ? (
                          <div>
                            <textarea
                              style={{
                                width: '100%',
                                minHeight: '100px',
                                resize: 'none',
                                overflow: 'hidden',
                              }}
                              id="editedCommentText"
                              value={editedCommentText}
                              onChange={(e) => {
                                setEditedCommentText(e.target.value)
                              }}
                            />
                            <button
                              className="btn btn-success mt-2"
                              type="button"
                              onClick={handleSaveEditedComment}
                            >
                              Save
                            </button>
                          </div>
                        ) : (
                          <div>
                            <p className="fw-bold pe-2">Commenter`s Name:</p>
                            <br />
                            <p className="fw-bold pe-2">Parent:</p>
                            <br />
                            <p className="fw-bold pe-2">Text Highlighted:</p>
                            <br />
                            <p>
                              <span className="fw-bold pe-2">Comment:</span>
                              {comment.text}
                            </p>
                            <div className="text-end">
                              <button
                                className="btn bg-primary-subtle btn-sm ms-2"
                                type="button"
                                onClick={() => handleEditComment(comment.id)}
                              >
                                <CiEdit />
                              </button>
                              <button
                                className="btn btn-danger btn-sm ms-2"
                                type="button"
                                onClick={() => handleDeleteComment(comment.id)}
                              >
                                <MdDelete />
                              </button>
                              <button
                                className="btn btn-light btn-sm ms-2"
                                type="button"
                                onClick={() => handleDeleteComment(comment.id)}
                              >
                                <IoMdAdd />
                              </button>
                            </div>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                  <br />
                  <button
                    className="btn btn-primary btn-sm ms-2 text-end"
                    type="button"
                  >
                    Add General Comment
                  </button>
                </div>
              </div>
            </div>
          </div>

          <button className="btn btn-success me-2" type="button" onClick={openApproveModal}>
            Approve
          </button>
          <button className="btn btn-danger" type="button" onClick={openRejectModal}>
            Reject
          </button>

          <Modal show={showApproveModal} onHide={closeApproveModal}>
            <Modal.Header closeButton>
              <Modal.Title>Approve Page</Modal.Title>
            </Modal.Header>
            <Modal.Body>Are you sure you want to approve this page?</Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={closeApproveModal}>
                Cancel
              </Button>
              <Button variant="success" onClick={handleApprovePage}>
                Yes, Approve
              </Button>
            </Modal.Footer>
          </Modal>

          <Modal show={showRejectModal} onHide={closeRejectModal}>
            <Modal.Header closeButton>
              <Modal.Title>Reject Page</Modal.Title>
            </Modal.Header>
            <Modal.Body>Are you sure you want to reject this page?</Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={closeRejectModal}>
                Cancel
              </Button>
              <Button variant="danger" onClick={handleRejectPage}>
                Yes, Reject
              </Button>
            </Modal.Footer>
          </Modal>

          <Modal
            show={showCommentModal}
            onHide={() => setShowCommentModal(false)}
            backdrop="static"
            keyboard={false}
          >
            <Modal.Header closeButton>
              <Modal.Title>Comment</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <textarea
                style={{ width: '100%', minHeight: '100px', resize: 'none', overflow: 'hidden' }}
                value={editedCommentText}
                id="commentText"
                className="form-control"
                onChange={(e) => setEditedCommentText(e.target.value)}
                placeholder="Enter your comment..."
              />
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowCommentModal(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleSaveComment}>
                Save Comment
              </Button>
            </Modal.Footer>
          </Modal>
        </div>
      )}
    </div>
  )
}

export default HighlightPage
