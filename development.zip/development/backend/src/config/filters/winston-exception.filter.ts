import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';

@Catch()
export class WinstonExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('Exception');

  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const req = ctx.getRequest();
    const res = ctx.getResponse();

    const status =
      exception instanceof HttpException
        ? exception.getStatus()
        : HttpStatus.INTERNAL_SERVER_ERROR;

    const message =
      exception instanceof HttpException
        ? exception.getResponse()
        : 'Internal server error';

    this.logger.error(exception.message || 'Unhandled exception', {
      context: {
        path: req?.url,
        method: req?.method,
        status,
      },
      stack: exception.stack,
    });

    res.status(status).json({
      statusCode: status,
      message:
        typeof message === 'string'
          ? message
          : (message as any)?.message || 'Something went wrong',
    });
  }
}
