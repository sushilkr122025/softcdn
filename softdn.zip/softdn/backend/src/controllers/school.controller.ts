/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  Body,
  Controller,
  Get,
  Inject,
  Param,
  Post,
  Query,
  Req,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { SchoolService } from '../services/school.service';
import { Questions } from '../entities/questions.entity';
import { Request } from 'express';
import { ExamWithQuestionsDto } from '../dto/exam.questions.dto';
import { DynamicMulterInterceptor } from '../utils/dynamic.multer.interceptor';
import { CanvasImage } from '../entities/canvasimage.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { LoggerService } from '@nestjs/common';

@UseGuards(JwtAuthGuard)
@Controller('school')
export class SchoolController {
  constructor(
    private readonly schoolService: SchoolService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: LoggerService
  ) {}

  @Post('makePaper')
  async makePaper(@Body() data: any, @Req() req: Request): Promise<any> {
    this.logger.log('school-controller: No data provided in the request body');
    const token = req['company'] as string;
    const tableName = data.table;
    if (tableName == 'questions') {
      const questionData = data as Questions;
      const question = await this.schoolService.getQuestion(questionData);
      return question;
    } else if (tableName == 'questionpaper') {
      const questionpaper = await this.schoolService.getQuestionPaper(data);
      return questionpaper;
    } else {
      throw new Error('Invalid table name');
    }
  }

  @Post('anskey')
  async setAnsKeyManual(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const result = await this.schoolService.setAnsKeyManual(data, tenantId);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('createcontext')
  async createContext(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const contextData = {
      ...data.params,
      tenantid: tenantId,
    };
    // console.log('contextData', contextData);
    const result = await this.schoolService.createContext(contextData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Get('getcontext')
  async getContextByShortUuid(
    @Query('id') shortuuid: string,
    @Req() req: Request
  ): Promise<any> {
    const tenantId = req['company'] as string;
    const data = {
      shortuuid: shortuuid,
      tenantid: tenantId,
    };
    const result = await this.schoolService.getContextByShortUuid(data);
    if (!result) throw new Error('Question context');
    return result;
  }

  @Post('createquestions') //old route 'questions'
  async saveQuestion(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const questionData = {
      ...data,
      tenantid: tenantId,
      folderName: folderName,
    };
    // console.log('questionData controller', questionData);
    const result = await this.schoolService.saveQuestion(questionData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Post('questions') // new route for to iniate questions for make history
  async createQuestion(@Body() data: any, @Req() req: Request): Promise<any> {
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const questionData = {
      ...data,
      tenantid: tenantId,
      folderName: folderName,
    };
    // console.log('questionData controller', questionData);
    const result = await this.schoolService.createQuestion(questionData);
    if (!result) throw new Error('Invalid table name');
    return result;
  }

  @Get('panelItems')
  async getPanels(@Req() req: Request): Promise<any> {
    const userId = (req.user as { id: number }).id;
    const panelList = await this.schoolService.getPanels(userId);
    if (!panelList) {
      throw new Error('No panels found');
    }
    return panelList;
  }

  @Get('panelid/:id')
  async getPanelItemById(@Param('id') id: number) {
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getQuestionByUserId(id);
    if (!question) {
      throw new Error('Question not found');
    }
    return question;
  }

  @Get('getquestions')
  async getQuestion(@Query('id') id: number) {
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getQuestionById(id);
    if (!question) {
      throw new Error('Question not found');
    }
    return question;
  }

  @Get('cordsQues')
  async getQuestionByUser(@Query('id') id: number) {
    console.log('id', id);
    if (!id) {
      throw new Error('Invalid ID');
    }
    const question = await this.schoolService.getQuestionByUser(id);
    if (!question) {
      throw new Error('Section creation failed');
    }
    return question;
  }

  @Get('gallery')
  async getGallery() {
    const gallery = await this.schoolService.getGallery();
    if (!gallery) {
      throw new Error('Section creation failed');
    }
    return gallery;
  }
  @Post('galleryImage')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req) => req['schoolname'] || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async createGallery(
    @UploadedFiles()
    files: {
      image?: Express.Multer.File[];
    },
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    const tenantId = req['company'] as string;
    // console.log('tenantId controller', tenantId); // files is an array of Express.Multer.File
    console.log(data);

    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];
    console.log(allFiles);

    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    const gallerydata = {
      ...data,
      tenantId: tenantId,
      folderName: folderName,
    };
    const gallery = await this.schoolService.createGallery(
      allFiles,
      gallerydata
    );
    if (!gallery) {
      throw new Error('Gallery creation failed');
    }
    return Promise.resolve('Gallery created successfully');
  }

  @Post('canvas')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req) => req['schoolname'] || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async createCanvasImage(
    @UploadedFiles()
    files: {
      image?: Express.Multer.File[];
    },
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    // console.log(data);
    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];
    // console.log(allFiles);
    const tenantId = req['company'] as string;
    const folderName =
      (req['schoolname'] as string)?.toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';

    const canvasdata = {
      ...data,
      tenantId: tenantId,
      folderName: folderName,
      allFiles,
    };

    const canvasImage = await this.schoolService.createCanvasImage(canvasdata);

    return { message: 'Canvas image created successfully', canvasImage };
  }
}
