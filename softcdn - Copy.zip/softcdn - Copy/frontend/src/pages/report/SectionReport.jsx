import React, { useEffect, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Bar, getElementAtEvent } from 'react-chartjs-2'
import Modal from 'react-bootstrap/Modal'
import ChartDataLabels from 'chartjs-plugin-datalabels'
import MultiServices from '../../api/MultiServices'
import Color from '../gallery/Color'
import '../report/Reportadmin.css'

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

// Register the components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

const SectionReport = () => {
  const [sparams] = useSearchParams()
  let paperid = sparams.get('paperid')
  let cla = sparams.get('class')
  let clsection = sparams.get('section')
  const [result, setResult] = useState([])
  const [avgdata, setAvgData] = useState([])
  const perarr = []
  const chartRef = useRef()
  const chartdata = []

  const [qid, setQid] = useState([])
  const [totalarray, setTotalarray] = useState([])
  const [totalperc, setTotalperc] = useState([])
  const [subDomain, setSubDomain] = useState([])

  const scrollContainerRef = useRef(null)
  const tableRef = useRef(null)
  const [windowWidth, setWindowWidth] = useState(window.outerWidth)
  const [showLeftArrow, setShowLeftArrow] = useState(false)
  const [showRightArrow, setShowRightArrow] = useState(false)
  const [countgrade, setCountgrade] = useState()
  const [percentile, setPercentile] = useState([])
  let keysArray

  const sortObjectKeys = (obj) => {
    const sortedKeys = Object.keys(obj).sort((a, b) => {
      return parseFloat(a) - parseFloat(b)
    })

    const sortedObj = {}
    sortedKeys.forEach((key) => {
      sortedObj[key] = obj[key]
    })
    return sortedObj
  }

  const fetchdata = async () => {
    try {
      const respons = await MultiServices.GetResultList({
        params: {
          paperid: paperid,
          class: cla,
          section: clsection,
        },
      })
      // console.log(respons)

      setResult(respons.result)
      setQid(respons.qid)
      setAvgData(respons.avg)
      setSubDomain(respons.subDomain)
      setCountgrade(respons.countgrade)
      setPercentile(respons.percentile)
    } catch (error) {}
  }

  useEffect(() => {
    fetchdata()
  }, [])

  {
    result.length > 0 &&
      result.forEach((ques, index) => {
        perarr.push(ques.studentpercentage)
      })
  }
  let dlable = []
  let dcount = []
  let davg = []
  let [qdata, setQdata] = useState()
  const [showInnerModal, setShowInnerModal] = useState(false)

  const handleCloseInnerModal = () => setShowInnerModal(false)

  const handlequestionClick = async (e) => {
    try {
      const response = await MultiServices.GetAverage({
        params: {
          paperid: paperid,
          qid: e,
          class: cla,
          section: clsection,
        },
      })      
      dlable = []
      dcount = []      
      if (response) {        
        Object.keys(response).map((key, i) => {          
          if (key.toUpperCase() == clsection.toUpperCase()) {            
            setQdata(response[key])
            setShowInnerModal(true)
          }
        })        
        let copt1 = 0
        let copt2 = 0
        let copt3 = 0
        let copt4 = 0

        for (let [key, val] of Object.entries(response)) {
          // console.log(key, val)
          if (key != clsection.toUpperCase()) {
            val.map((item) => {
              if (item.uanswer == 'opt1') {
                copt1 = copt1 + item.count
              }
              if (item.uanswer == 'opt2') {
                copt2 = copt2 + item.count
              }
              if (item.uanswer == 'opt3') {
                copt3 = copt3 + item.count
              }
              if (item.uanswer == 'opt4') {
                copt4 = copt4 + item.count
              }
            })
          }
        }
        let tarray = []
        tarray.push(copt1)
        tarray.push(copt2)
        tarray.push(copt3)
        tarray.push(copt4)       
        setTotalarray(tarray)

        let totlecount = copt1 + copt2 + copt3 + copt4
        let perc1 = parseFloat((copt1 / totlecount) * 100)
          .toFixed(2)
          .replace(/[.,]00$/, '')
        let perc2 = parseFloat((copt2 / totlecount) * 100)
          .toFixed(2)
          .replace(/[.,]00$/, '')
        let perc3 = parseFloat((copt3 / totlecount) * 100)
          .toFixed(2)
          .replace(/[.,]00$/, '')
        let perc4 = parseFloat((copt4 / totlecount) * 100)
          .toFixed(2)
          .replace(/[.,]00$/, '')
        let tperc = []
        tperc.push(perc1)
        tperc.push(perc2)
        tperc.push(perc3)
        tperc.push(perc4)
        setTotalperc(tperc)
        // console.log(totalarray)
        // console.log(totalperc)
      }
    } catch (err) {
      console.log(err.message)
    }
  }

  {
    qdata &&
      qdata.map((item) => {        
        dlable.push(item.uanswer)
        davg.push(item.tval)
      })
  }

  const graphclickinner = (event) => {
    let datasetIndex = getElementAtEvent(chartRef.current, event)
    if (datasetIndex.length > 0) {
      let index = datasetIndex[0].index
      handlequestionClick(qid[index])
    }
  }

  const letterToNumber = {
    a: 0,
    b: 1,
    c: 2,
    d: 3,
    e: 4,
  }

  const getNumber = (letter) => {
    return letterToNumber[letter]
  }

  const choptions = {
    plugins: {
      legend: {
        display: false,
        labels: {
          padding: 10,
        },
      },
      title: {
        display: false,
        text: 'Comparison Chart By Question', // Chart title
        // color: '#343a40',
        font: {
          weight: 'bold',
          size: 24,
        },
      },
      tooltip: {
        enabled: true,
      },
      datalabels: {
        font: {
          weight: 'bold',
          size: 13,
          family: 'arial',
        },
        display: true,
        //color: "black",
        //formatter: Math.round,
        anchor: 'end',
        offset: -20,
        align: 'start',
      },
      afterUpdate: function (chart) {
        // Add padding to the top of the chart area
        chart.layout.padding.top = 20 // Adjust this value as needed
      },
    },
    layout: {
      padding: {
        top: 20, // Add space at the top
        bottom: 0,
        left: 0,
        right: 0,
      },
    },
    // scales: {
    //   x: {
    //     type: 'category',
    //     title: {
    //         display: true,
    //         text: "Question Number's", // Name of x-axis
    //         font: {
    //           size: 24
    //         },
    //     },
    //     beginAtZero: true
    // },
    // xTopPadding: {
    //   // Fake x-axis for padding
    //   position: 'top',
    //   labels: [''],
    //   grid: {
    //     drawOnChartArea: false,
    //     drawTicks: true,
    //     ticksWidth: 0,
    //     ticksLength: 0, // Increase ticksLength to increase the "padding"
    //   },
    // },
    //   y: {
    //     title: {
    //       display: true,
    //       text: '% Correct', // Name of y-axis
    //       font: {
    //         size: 24
    //       }
    //   },
    //     beginAtZero: true,
    //   }
    // }
  }

  const choptionsinner = {
    layout: {
      padding: {
        top: 0, // Adjust the top padding here
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: true,
      },
      datalabels: {
        font: {
          weight: 'bold',
          size: 13,
          family: 'arial',
        },
        display: true,
        color: 'black',
        //formatter: Math.round,
        anchor: 'end',
        offset: -20,
        align: 'start',
      },
      afterUpdate: function (chart) {
        chart.layout.padding.top = 40 // Adjust this value as needed
      },
    },
    legend: {
      display: false,
    },
    //   scales: {
    //     x: {
    //       type: 'category',
    //         title: {
    //         display: true,
    //         text: 'Options', // Name of y-axis
    //         font: {
    //           size: 16
    //         }
    //       }
    //     },
    //     y: {
    //           title: {
    //           display: true,
    //           text: 'Percentage', // Name of y-axis
    //           font: {
    //             size: 16
    //           }
    //         },
    //         beginAtZero: true,
    //         grace: '5%',
    //     }
    // }
  }
  let colindex = getNumber(clsection)
  let indata
  if (avgdata.length > 0) {
    indata = {
      data: avgdata,
      backgroundColor: Color.bgColor[colindex],
    }
    chartdata.push(indata)
  }

  const setSelectedType = async (e) => {
    console.log(e)
    if (e != 'all') {
      try {
        const respons = await MultiServices.GetResultList({
          params: {
            paperid: paperid,
            class: cla,
            section: clsection,
            subdomain: e,
          },
        })
        setResult(respons.result)
        setQid(respons.qid)
        setAvgData(respons.avg)
        setCountgrade(respons.countgrade)
        setPercentile(respons.percentile)
      } catch (err) {
        console.log(err.message)
      }
    } else {
      fetchdata()
    }
  }

  const handleScrollLeft = () => {
    scrollContainerRef.current.scrollBy({
      left: -250,
      behavior: 'smooth',
    })
  }

  const handleScrollRight = () => {
    scrollContainerRef.current.scrollBy({
      left: 250,
      behavior: 'smooth',
    })
  }

  const getPercentile = (definedKey) => {
    // console.log(percentile)
    const entries = Object.entries(percentile)
    const sortedEntries = entries.sort((a, b) => parseFloat(a[0]) - parseFloat(b[0]))
    let posindex = sortedEntries.findIndex(([key]) => key === definedKey)
    let val = sortedEntries[posindex][1]
    // if((posindex+1) == sortedEntries.length){
    //   posindex = posindex
    //   // console.log('1 - a ' + definedKey)
    // }else{
    //   // console.log('2 - b ' + definedKey)
    //   posindex = parseFloat(posindex+1)
    // }
    const total = sortedEntries.slice(0, posindex).reduce((total, [, value]) => total + value, 0)

    let tile = total + parseFloat(0.5 * val) //parseFloat(result.length - total)
    //tile = tile + (parseFloat(0.5 * val))
    tile = parseFloat(tile / result.length) * 100
    tile = parseFloat(tile)
      .toFixed(2)
      .replace(/[.,]00$/, '')
    return tile
  }

  return (
    <div className="container-fluid">
      {chartdata && (
        <div className="row my-3 mx-2 border bg-white rounded rounded-4 pb-4">
          <div className="col-md-12 py-3 ">
            <div className="col-12 h5 text-end"> Comparison Chart By Question</div>
            <Bar
              datasetIdKey="id"
              data={{
                labels: qid,
                datasets: chartdata,
              }}
              plugins={[ChartDataLabels]}
              options={choptions}
              ref={chartRef}
              onClick={graphclickinner}
            />
          </div>
        </div>
      )}
      <div className="row">
        {subDomain && subDomain.length > 1 && (
          <div className="col-md-2 pb-4 d-flex align-items-center">
            <div className="form-floating w-100">
              <select
                className="form-select inputfield"
                id="floatingSelect"
                aria-label="Floating label select example"
                onChange={(e) => setSelectedType(e.target.value)}
              >
                <option value="all">All</option>
                {subDomain.map((item, index) => {
                  return (
                    <option key={index} value={item}>
                      {item}
                    </option>
                  )
                })}
              </select>
              <label>Select Sub domain</label>
            </div>
          </div>
        )}
        {countgrade && (
          <div className="col-md-10 pb-4 text-end">
            <span className="fw-bold">Student Grade Score</span>
            {Object.entries(countgrade).map(([key, value], index) => (
              <button
                type="button"
                className={`btn ms-2 ${key === 'E' ? 'btn-danger' : key === 'D' ? 'btn-warning' : 'btn-primary'} `}
                key={index}
              >
                {key} : {value}
              </button>
            ))}
          </div>
        )}
      </div>
      {result.length > 0 && (
        <div className="row">
          <div className="col-md-12">
            <section className="arrowcontainer">
              {showLeftArrow && ''}
              <button id="left-arrowbtn" className="arrow-btn" onClick={handleScrollLeft}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-arrow-left-circle-fill"
                  viewBox="0 0 16 16"
                >
                  <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0m3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5z" />
                </svg>
              </button>

              {showRightArrow && ''}

              <button className="arrow-btn" onClick={handleScrollRight}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-arrow-right-circle-fill"
                  viewBox="0 0 16 16"
                >
                  <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0M4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5z" />
                </svg>
              </button>
            </section>
            <div className="table-responsive scrollbar" ref={scrollContainerRef}>
              <table className="rangedta table-bordered table-hover table-sm table-striped" ref={tableRef}>
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Name</th>
                    {qid.map((ques, index) => {
                      return (
                        <th key={index}>
                          <span
                            onClick={(e) => handlequestionClick(e.currentTarget.textContent)}
                            className="cursor"
                          >
                            {ques}
                          </span>
                        </th>
                      )
                    })}
                    <th>%</th>
                    <th>Grade</th>
                    <th>Percentile</th>
                  </tr>
                </thead>
                <tbody>
                  {result.map((item, index) => {
                    let quesdata = item.questiondata
                    let quesarray = quesdata
                    return (
                      <tr
                        key={index}
                        className={`${item.studentgrade == 'E' ? 'fail' : item.studentgrade == 'D' ? 'warning' : ''} `}
                      >
                        <td>{item.rollno}</td>
                        <td>{item.studentname}</td>
                        {quesarray.map((qitem, qindex) => {
                          let qarray = qitem.data
                          return (
                            <td
                              key={qindex}
                              className={`text-${qarray == 1 ? 'success fw-bolder text-center' : 'danger fw-bolder text-center'} `}
                            >
                              {qarray == 1 ? <>&#x2713;</> : <>&#x292B;</>}
                            </td>
                          )
                        })}
                        <td>{item.studentpercentage}</td>
                        <td>{item.studentgrade}</td>
                        <td>
                          {item.studentgrade != 'E' ? getPercentile(item.studentpercentage) : ''}
                        </td>
                        <td>
                          <Link
                            to={`/reportcard?studentid=${item.id}`}
                            target="_blank"
                            className="btn btm-sm btn-primary"
                          >
                            View
                          </Link>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <Modal size="lg" show={showInnerModal} onHide={handleCloseInnerModal}>
        <Modal.Header className="justify-content-between">
          <Modal.Title className="h5">Question No: {qdata && qdata[0].qid} </Modal.Title>{' '}
          <span className="fw-bold text-danger">Variation: &plusmn; 0.01</span>
        </Modal.Header>
        <Modal.Body>
          {qdata && (
            <>
              <div className="row align-items-center">
                <div className="col-md-6">
                  <Bar
                    datasetIdKey="id"
                    data={{
                      labels: dlable,
                      datasets: [
                        {
                          id: 1,
                          label: '',
                          backgroundColor: Color.bgColor,
                          borderColor: Color.boColor,
                          data: davg,
                        },
                      ],
                    }}
                    plugins={[ChartDataLabels]}
                    options={choptionsinner}
                  />
                </div>
                <div className="col-md-6">
                  <table className="rangedta table-sm table-bordered table-hover table-striped mt-0">
                    <thead>
                      <tr>
                        <th>Option</th>
                        <th>Count</th>
                        <th>Avg %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {qdata.map((item, index) => (
                        <tr
                          key={index}
                          className={item.canswer == item.uanswer ? 'table-success' : ''}
                        >
                          <td>
                            {item.uanswer}{' '}
                            {item.canswer == item.uanswer ? (
                              <>
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="20"
                                  height="20"
                                  fill="currentColor"
                                  className="bi bi-check-circle-fill"
                                  viewBox="0 0 16 16"
                                >
                                  <path
                                    d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"
                                    fill="green"
                                  />
                                </svg>
                              </>
                            ) : (
                              ''
                            )}
                          </td>
                          <td>{item.count}</td>
                          <td>{item.tval}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="accordion py-3" id="Moredata">
                <div className="accordion-item">
                  <h2 className="accordion-header">
                    <button
                      className="accordion-button collapsed py-2"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseTwo"
                      aria-expanded="false"
                      aria-controls="collapseTwo"
                    >
                      Show Student of other Section
                    </button>
                  </h2>
                </div>
                <div
                  id="collapseTwo"
                  className="accordion-collapse collapse"
                  data-bs-parent="#Moredata"
                >
                  <div className="accordion-body border p-0 pt-3">
                    <div className="row align-items-center">
                      <div className="col-md-6">
                        <Bar
                          data={{
                            labels: dlable,
                            datasets: [
                              {
                                id: 1,
                                label: '',
                                backgroundColor: Color.bgColor,
                                borderColor: Color.boColor,
                                data: totalperc,
                              },
                            ],
                          }}
                          plugins={[ChartDataLabels]}
                          options={choptionsinner}
                        />
                      </div>
                      <div className="col-md-6">
                        <table className="rangedta table-bordered table-hover table-striped mt-0">
                          <thead>
                            <tr>
                              <th>Option</th>
                              <th>Count</th>
                              <th>Avg %</th>
                            </tr>
                          </thead>
                          <tbody>
                            {qdata.map((item, index) => (
                              <tr
                                key={`row${index}`}
                                className={item.canswer == item.uanswer ? 'table-success' : ''}
                              >
                                <td>
                                  {item.uanswer}{' '}
                                  {item.canswer == item.uanswer ? (
                                    <>
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="20"
                                        height="20"
                                        fill="currentColor"
                                        className="bi bi-check-circle-fill"
                                        viewBox="0 0 16 16"
                                      >
                                        <path
                                          d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0m-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"
                                          fill="green"
                                        />
                                      </svg>
                                    </>
                                  ) : (
                                    ''
                                  )}
                                </td>
                                <td>{totalarray[index]}</td>
                                <td>{totalperc[index]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </Modal.Body>
      </Modal>
    </div>
  )
}

export default SectionReport
