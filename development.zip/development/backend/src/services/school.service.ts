/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { Inject, Injectable, LoggerService, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { School } from '../entities/school.entity';
import { Questions } from '../entities/questions.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { DataSource } from 'typeorm';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { Subject } from '../entities/subject.entity';
import { Gallery } from '../entities/gallery.entity';
import { CanvasImage } from '../entities/canvasimage.entity';
import { QuestionContext } from '../entities/question.context.entity';
import { NotificationGateway } from 'src/gateway/notification.gateway';
import { QuestionsHistory } from '../entities/questions.history.entity';
import { QuestionRule } from '../entities/question.rule.entity';
import { QuestionsMarkingSchemeHistory } from '../entities/question.markscheme.history.entity';
import { QuestionsMarkingScheme } from '../entities/question.markscheme.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

@Injectable()
export class SchoolService {
  constructor(
    private readonly notificationGateway: NotificationGateway,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: LoggerService,
    @InjectRepository(School)
    private schoolRepository: Repository<School>,
    @InjectRepository(Questions)
    private questionRepository: Repository<Questions>,
    @InjectRepository(Gallery)
    private galleryRepository: Repository<Gallery>,
    @InjectRepository(CanvasImage)
    private canvasRepository: Repository<CanvasImage>,
    @InjectRepository(QuestionContext)
    private questionContextRepository: Repository<QuestionContext>,
    @InjectRepository(QuestionsHistory)
    private questionHistoryRepository: Repository<QuestionsHistory>,
    @InjectRepository(QuestionsMarkingSchemeHistory)
    private questionsMScHistory: Repository<QuestionsMarkingSchemeHistory>,
    @InjectRepository(QuestionRule)
    private questionRuleRepository: Repository<QuestionRule>,
    @InjectRepository(QuestionPaper)
    private readonly questionPaperRepository: Repository<QuestionPaper>,
    @InjectRepository(ExamQuestion)
    private readonly examQuestionRepository: Repository<ExamQuestion>,
    private dataSource: DataSource
  ) {}
  findById(id: number): Promise<School | null> {
    return this.schoolRepository.findOne({ where: { id } });
  }
  async getQuestion(data: any): Promise<any> {
    // Pagination
    const page = Number(data.page) || 1;
    const limit = Math.min(Number(data.limit) || 10, 50); // max 50
    const skip = (page - 1) * limit;

    // Sorting
    const sortBy = data.sortBy || 'contextid';
    const order =
      (data.order || 'ASC').toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    // Allowed columns (VERY IMPORTANT)
    const allowedColumns = [
      'id',
      'subject',
      'class',
      'subDomain',
      'difficulty',
      'quesType',
      'chapter',
      'status',
      'competency',
      'cg',
      'marks',
      'contextid',
      'contextstatus',
      'createdBy',
    ];

    // Base Query
    const qb = this.questionRepository
      .createQueryBuilder('question')
      .leftJoin(QuestionContext, 'context', 'context.id = question.contextid')
      .leftJoin(Subject, 'sub', 'sub.id = question.subDomain')
      .leftJoin('curriculumgoal', 'child', 'child.id = question.competency')
      .leftJoin('curriculumgoal', 'parent', 'parent.id = question.cg')
      .select([
        'question.id as id',
        'question.customid as customId',
        'question.subject as subject',
        'question.class as class',
        'sub.subject as subDomain',
        'question.difficulty as difficulty',
        'question.quesType as quesType',
        'question.question as question',
        'question.correctAns as correctAns',
        'question.optA as optA',
        'question.optB as optB',
        'question.optC as optC',
        'question.optD as optD',
        'question.optAimg as optAimg',
        'question.optBimg as optBimg',
        'question.optCimg as optCimg',
        'question.optDimg as optDimg',
        'question.image as image',
        'question.contextid as contextId',
        'question.createdBy as createdBy',
        'question.marks as marks',
        'question.chapter as chapter',
        'question.status as status',
        'question.cg as cg',
        'question.competency as competency',
        'question.contextstatus AS contextstatus',
        'context.context AS context',
      ])
      .addSelect(['child.cgNo AS competencyText', 'parent.cgNo AS cgText']);

    // Clone filters
    const filters = { ...data };

    // remove non-column fields
    delete filters.table;
    delete filters.page;
    delete filters.limit;
    delete filters.sortBy;
    delete filters.order;

    // Default condition
    qb.where('question.createdBy = :createdBy', { createdBy: 'bank' });
    qb.andWhere("question.dmlType = 'I'");

    // Dynamic WHERE (filters)
    Object.entries(filters).forEach(([key, value]) => {
      if (!allowedColumns.includes(key)) return;
      if (value === undefined || value === null || value === '') return;

      if (Array.isArray(value)) {
        qb.andWhere(`question.${key} IN (:...${key})`, {
          [key]: value,
        });
      } else {
        qb.andWhere(`question.${key} = :${key}`, {
          [key]: value,
        });
      }
    });

    // Sorting
    if (allowedColumns.includes(sortBy)) {
      qb.orderBy(`question.${sortBy}`, order as 'ASC' | 'DESC');
    } else {
      qb.orderBy('question.id', 'ASC');
    }

    // Pagination
    // qb.skip(skip).take(limit);
    qb.offset(skip).limit(limit);

    // Get data
    const dataResult = await qb.getRawMany();

    // Get total count (IMPORTANT: separate query for accuracy)
    const countQb = this.questionRepository
      .createQueryBuilder('question')
      .where('question.createdBy = :createdBy', { createdBy: 'bank' });

    // apply same filters to count query
    Object.entries(filters).forEach(([key, value]) => {
      if (!allowedColumns.includes(key)) return;
      if (value === undefined || value === null || value === '') return;

      if (Array.isArray(value)) {
        countQb.andWhere(`question.${key} IN (:...${key})`, {
          [key]: value,
        });
      } else {
        countQb.andWhere(`question.${key} = :${key}`, {
          [key]: value,
        });
      }
    });

    const total = await countQb.getCount();

    return {
      data: dataResult,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getPaper(formData: any): Promise<any[]> {
    const query = this.dataSource
      .createQueryBuilder()
      .select([
        'qp.id AS id',
        'qp.subject AS subject',
        'qp.subjectName AS subjectName',
        'qp.class AS class',
        'qp.examDate AS examDate',
        'eq.paperId AS paperId',
        'COUNT(eq.questionId) AS totalQuestion',
      ])
      .from(QuestionPaper, 'qp')
      .innerJoin(ExamQuestion, 'eq', 'qp.id = eq.paperId')
      .where('qp.subject = :subject', { subject: formData.subject })
      .andWhere('qp.class = :class', { class: formData.class });

    if (formData.data) {
      query.andWhere('qp.createdFrom = :createdFrom', {
        createdFrom: formData.data,
      });
    }
    query.groupBy('eq.paperId');
    return await query.getRawMany();
  }

  async getPaperById(formData: any): Promise<any> {
    const query = this.dataSource
      .createQueryBuilder()
      .select([
        'qp.id AS id',
        'qp.subject AS subject',
        'qp.class AS class',
        'qp.examDate AS examDate',
        'eq.paperId AS paperId',
      ])
      .from(QuestionPaper, 'qp')
      .leftJoin(ExamQuestion, 'eq', 'qp.id = eq.paperId')
      .where('qp.id = :id', { id: formData.id });
    // console.log(query.getSql());
    // console.log(query.getParameters());
    return await query.getRawOne();
  }

  async getQuestionPaper(formData: any): Promise<any> {
    const ids =
      formData.reqType === 'paper' ? formData.paperId : formData.paperId;
    const selectFields = [
      // Question fields
      'qu.id AS id',
      'qu.question AS question',
      'qu.optA AS optA',
      'qu.optB AS optB',
      'qu.optC AS optC',
      'qu.optD AS optD',
      'qu.optAimg AS optAimg',
      'qu.quesType AS quesType',
      'qu.correctAns AS correctAns',
      // Mark Scheme fields
      'qs.id AS markSchemeId',
      'qs.markingScheme AS markingScheme',
      // Context fields
      'qc.id AS contextId',
      'qc.context AS context',
    ];
    if (formData.reqType === 'paper') {
      selectFields.push(
        // ExamQuestion fields
        'eq.questionId AS questionId',
        'eq.paperId AS paperId',
        'eq.sequence AS sequence',
        'eq.marks AS marks',
        'eq.section AS section',
        'eq.connector AS connector',
        'eq.isSub AS isSub',
        'eq.subOf AS subOf',
        'eq.ui AS ui',
        'eq.queslabel AS queslabel',
        'eq.contextLabel AS contextLabel',
        'eq.contextTitle AS contextTitle',
        'eq.contextSubTitle AS contextSubTitle'
      );
    } else {
      selectFields.push('qu.marks AS marks');
    }
    const db = this.dataSource
      .createQueryBuilder()
      .select(selectFields)
      .from(Questions, 'qu')
      .leftJoin(QuestionsMarkingScheme, 'qs', 'qs.qId = qu.id')
      .leftJoin(QuestionContext, 'qc', 'qc.id = qu.contextid');
    if (formData.reqType === 'paper') {
      db.innerJoin(ExamQuestion, 'eq', 'qu.id = eq.questionId');
      db.where('eq.paperId = :paperId', { paperId: formData.paperId });
      db.orderBy('eq.sequence', 'ASC');
      // console.log('equal statment ids', ids);
    } else {
      // console.log('in statment ids', ids, ids.length);
      db.where('qu.id IN (:...ids)', { ids });
    }

    const questions = await db.getRawMany();
    let response: any = { questions };
    if (formData.reqType === 'paper') {
      const generalDetails = await this.questionPaperRepository
        .createQueryBuilder('qp')
        .select([
          'qp.id AS id',
          'qp.examCode AS examCode',
          'qp.name AS name',
          'qp.class AS class',
          'qp.subject AS subject',
          'qp.subjectName AS subjectName',
          'qp.section AS section',
          'qp.maxMarks AS maxMarks',
          'qp.totalTime AS totalTime',
          'qp.generalInstruction AS generalInstruction',
          'qp.examDate AS examDate',
          'qp.session AS session',
          'qp.sectionsData AS sectionsData',
        ])
        .where('qp.id = :paperId', { paperId: formData.paperId })
        .getRawOne();

      response = { generalDetails, questions };
    }
    return response;
  }

  async getQuestionPaperOld(formData: any): Promise<any> {
    const query = this.dataSource
      .createQueryBuilder()
      .select([
        'eq.questionId AS questionId',
        'eq.paperId AS paperId',
        'eq.sequence AS sequence',
        'eq.marks AS marks',
        'eq.section AS section',
        'eq.connector AS connector',
        'eq.isSub AS isSub',
        'eq.subOf AS subOf',
        'eq.ui AS ui',
        'qu.id AS id',
        'qu.question AS question',
        'qu.optA AS optA',
        'qu.optB AS optB',
        'qu.optC AS optC',
        'qu.optD AS optD',
        'qu.optAimg AS optAimg',
        'qu.quesType AS quesType',
        'qu.correctAns AS correctAns',
      ])
      .from(Questions, 'qu')
      .innerJoin(ExamQuestion, 'eq', 'qu.id = eq.questionId')
      .where('eq.paperId = :paperId', { paperId: formData.paperId })
      .orderBy('eq.sequence', 'ASC');
    const questions = await query.getRawMany();
    const generalDetails = await this.questionPaperRepository
      .createQueryBuilder('qp')
      .select([
        'qp.id AS id',
        'qp.examCode AS examCode',
        'qp.name AS name',
        'qp.class AS class',
        'qp.subject AS subject',
        'qp.subjectName AS subjectName',
        'qp.section AS section',
        'qp.maxMarks AS maxMarks',
        'qp.totalTime AS totalTime',
        'qp.generalInstruction AS generalInstruction',
        'qp.examDate AS examDate',
        'qp.session AS session',
        'qp.sectionsData AS sectionsData',
      ])
      .where('qp.id = :paperId', { paperId: formData.paperId })
      .getRawOne();
    return { generalDetails, questions };
  }

  async setAnsKeyManual(data: any, tenantId: string): Promise<any> {
    return this.dataSource.transaction(async (manager) => {
      const paperData = data.questionpaper;
      const questionPaper = manager.create(QuestionPaper, {
        name: paperData.examName,
        class: paperData.className,
        subject: paperData.subject,
        maxMarks: paperData.marks,
        createdFrom: 'manual',
        examDate: paperData.examDate,
        tenantid: tenantId,
      });
      const savedPaper = await manager.save(questionPaper);
      savedPaper.examCode = `EX${savedPaper.id}-${savedPaper.class}-${savedPaper.subject}`;
      await manager.save(savedPaper);
      const questions = data.questions.map((q) =>
        manager.create(Questions, {
          tId: q.tId,
          subject: q.subject,
          class: q.class,
          subDomain: q.subdomain,
          quesType: q.quesType,
          correctAns: q.correctAns,
          createdBy: 'manual',
          tenantid: tenantId,
        })
      );
      const savedQuestions = await manager.save(questions);
      const examQuestions = savedQuestions.map((question, i) =>
        manager.create(ExamQuestion, {
          paperId: savedPaper.id,
          questionId: question.id,
          sequence: i + 1,
          marks: data.questions[i].marks,
          sectionNo: data.questions[i].sectionNo,
          paperFrom: 'manual',
        })
      );
      await manager.save(examQuestions);
      return { message: 'Saved all data with transaction' };
    });
  }

  async createContext(data: any): Promise<string> {
    const context = this.questionContextRepository.create({
      subject: data?.subject,
      tId: data.tId,
      class: data.class,
      topicName: data.topicName,
      contextstatus: data.contextstatus,
      context: data.context,
      tenantid: data.tenantid,
    });
    const result = await this.questionContextRepository.save(context);
    if (!result) {
      throw new NotFoundException('Context creation failed');
    }
    return result?.shortUuid;
  }

  async getContextByShortUuid(data: any): Promise<any> {
    // console.log('data', data);
    const isNumericId = /^\d+$/.test(data.shortuuid);
    const column = isNumericId === false ? 'shortUuid' : 'id';
    const value =
      typeof data.shortuuid === 'string'
        ? data.shortuuid
        : parseInt(data.shortuuid);
    const result = await this.questionContextRepository.findOneBy({
      // shortUuid: data.shortuuid,
      [column]: value,
      tenantid: data.tenantid,
      dmlType: 'I',
    });
    if (!result) {
      throw new NotFoundException('Question Context not found');
    }
    return {
      id: result.id,
      shortuuid: result.shortUuid,
      subject: result.subject,
      class: result.class,
      context: result.context,
      topicName: result.topicName,
      contextstatus: result.contextstatus,
    };
  }

  async saveQuestion(q: any): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }

        const trackerRepo = manager.getRepository(QuestionIdTracker);
        const questionRepo = manager.getRepository(Questions);
        const subjectRepo = manager.getRepository(Subject);

        const getsubject = await subjectRepo.findOne({
          where: { id: q.subject },
        });

        if (!getsubject) {
          throw new NotFoundException('Subject not found');
        }
        let shortsubject = getsubject.subject.substring(0, 2).toUpperCase();
        if (getsubject.subject === 'Social Science') {
          shortsubject = 'SS';
        }

        const cgtext = q.cgtext;
        const competencytext = q.competencytext;

        const year = new Date().getFullYear();
        const subject = q.subject;
        const className = q.std;
        const tenantId = q.tenantid;

        let tracker = await trackerRepo.findOne({
          where: {
            tenantId,
            subject,
            class: className,
            year,
            cg: q.cg,
            competency: q.competency,
          },
        });

        if (!tracker) {
          tracker = trackerRepo.create({
            tenantId,
            subject,
            class: className,
            cg: q.cg,
            competency: q.competency,
            year,
            currentCounter: 1,
          });
        } else {
          tracker.currentCounter += 1;
        }

        const paddedCounter = String(tracker.currentCounter).padStart(4, '0');
        const customId = `${year} ${shortsubject} G${className} ${cgtext} ${competencytext} #${paddedCounter}`;

        await trackerRepo.save(tracker);

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          contextid: q.contextid,
          contextstatus: q.contextstatus,
          subject,
          class: className,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          tenantid: tenantId,
          createdBy: 'bank',
          customId,
          // file paths could go here
        };
        // const newQuestion = questionRepo.create(Qdata);
        // await this.notificationService.sendToUser(tenantId, userId, {
        //     type: 'ORDER_PLACED',
        //     message: `Your order #${orderData.id} has been placed successfully.`,
        //   });
        return await questionRepo.upsert(Qdata, ['id']);
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async createQuestion(q: any): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }
        let version = 0;
        const existing = await this.questionHistoryRepository.findOneBy({
          id: q.editId,
        });
        // console.log('existing.status', existing?.status, 'q.status', q.status);
        if (
          existing &&
          q.editId &&
          q.status !== 'DRAFT' &&
          existing.status !== 'DRAFT'
        ) {
          const { id: _, ...copy } = existing;
          copy.trailId = existing.id;
          copy.status = 'QRHISTORY';
          // copy.approverId = ``;
          const inserted = await this.questionHistoryRepository.save(copy);
          version = inserted.revision;
        }

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          contextid: q.contextid,
          tenantid: q.tenantid,
          contextstatus: q.contextstatus,
          subject: q.subject,
          class: q.std,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg || null,
          competency: q.competency || null,
          bloomTaxonomy: q.bloomTaxonomy || null,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          revision: 1 + version,
          marks: q.marks,
          trailId: 0,
          createdBy: 'bank',
          descriptors: q.descriptors,
          ...(q.status === 'DRAFT' && { status: 'DRAFT' }),
          ...(q.status === 'SUBMITTED' && { status: 'MSCMREQUIRE' }),
        };
        const result = await this.questionHistoryRepository.upsert(Qdata, [
          'id',
        ]);
        if (!result) {
          throw new NotFoundException('Failed to create question history');
        }
        // Qdata['historyId'] = result.identifiers[0]?.id;
        if (q.status !== 'DRAFT') {
          const qid = result.identifiers[0]?.id;
          const getApprovalIds = await this.questionRuleRepository.findOneBy({
            userId: q.user,
            subjectId: String(q.subject),
            classId: String(q.std),
            dmlType: 'I',
          });
          if (getApprovalIds && getApprovalIds.teachersId) {
            const setapprovers = await this.questionHistoryRepository.findOneBy(
              {
                id: qid,
              }
            );
            if (setapprovers) {
              const apid = getApprovalIds.teachersId
                .split(',')
                .map(Number)
                .filter((num) => num !== setapprovers.tId)
                .join(',');
              setapprovers.approverId = apid;
              await this.questionHistoryRepository.save(setapprovers);
            }
          }
          if (
            ['multipleChoice', 'trueFalse', 'oneWord'].includes(
              q.quesType as string
            )
          ) {
            const markingScheme = [
              {
                level: 'NA',
                descriptiors: q.corrAns,
                guidelines: '',
                marks: q.marks,
              },
            ];
            // adfadf
            const msdata = {
              qid: result.identifiers[0]?.id,
              expectedFromat: '',
              markScheme: markingScheme,
              revision: 1 + version,
            };
            // your logic here

            await this.createMarkingHistory(msdata);
          }

          return {
            id: qid,
            message: 'Question saved successfully',
          };
        } else {
          return {
            id: result.identifiers[0]?.id,
            message: 'Question saved as draft successfully',
          };
        }
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async createMarkingHistory(data: any): Promise<any> {
    const markingSchemeHistory = this.questionsMScHistory.create({
      qId: data.qid,
      expectedFromat: data.expectedFormat,
      markingScheme: data.markScheme,
      revision: data.revision,
    });
    const result = await this.questionsMScHistory.save(markingSchemeHistory);
    if (!result) {
      throw new NotFoundException('Marking Scheme history creation failed');
    }
    const upquest = await this.questionHistoryRepository.findOneBy({
      id: data.qid,
    });
    if (upquest) {
      upquest.status = 'READYPANELING';
      await this.questionHistoryRepository.save(upquest);
    }
    return `Marking Scheme history created with ID: ${result.id}`;
  }

  async actionPerform(data: any, tenantId: string): Promise<string> {
    const upquest = await this.questionHistoryRepository.findOneBy({
      id: data.qid,
    });
    if (upquest) {
      if (data.action === 'REVIEW') {
        upquest.status = 'PANELING';
      } else if (data.action === 'DELETE') {
        upquest.status = 'DELETED';
      }
      await this.questionHistoryRepository.save(upquest);
      if (data.action === 'REVIEW') {
        const approverIdArray = upquest.approverId
          .split(',')
          .map((id) => parseInt(id));
        for (const approverId of approverIdArray) {
          await this.notificationGateway.sendToUser(
            tenantId,
            approverId,
            `New Question is available  for paneling.`
          );
        }
      }
    }
    const res =
      data.action == 'REVIEW' ? 'sent to paneling' : 'Question Deleted';
    return res;
  }

  async getPanels(userId: number): Promise<any[]> {
    const query = `
    SELECT 
      q.id AS id, q.question AS question, q.createdAt AS createdAt, q.tId as tId, q.revision AS revision, q.class AS class, q.quesType as quesType, sub.subject AS subject,
      l.id AS userId, l.name AS name
    FROM questionshistory q
    LEFT JOIN login l ON l.id = q.tId
    LEFT JOIN subject AS sub ON sub.id = q.subject
    WHERE q.tId = ? AND q.trailId = 0 AND q.status = 'PANELING'

    UNION

    SELECT 
      q.id AS id, q.question AS question, q.createdAt AS createdAt, q.tId as tId, q.revision AS revision, q.class AS class, q.quesType as quesType, sub.subject AS subject,
      l.id AS userId, l.name AS name
    FROM questionshistory q
    LEFT JOIN login l ON l.id = q.tId
    LEFT JOIN subject AS sub ON sub.id = q.subject
    WHERE FIND_IN_SET(?, q.approverId) > 0 AND q.trailId = 0 AND q.status = 'PANELING'
  `;

    const panels = await this.dataSource.query(query, [userId, userId]);

    return panels || [];
  }

  async getQuestionByUser(approverId: number): Promise<Questions[]> {
    const question = (await this.questionRepository.query(
      `SELECT * FROM questions WHERE FIND_IN_SET(?, approverId) > 0`,
      [approverId]
    )) as Questions[];
    if (!question || question.length === 0) {
      throw new NotFoundException('Question not found');
    }
    return question;
  }

  async getGallery(): Promise<Gallery[]> {
    const gallery = await this.galleryRepository.find();
    if (!gallery) {
      throw new NotFoundException('Question not found');
    }
    return gallery;
  }

  async createGallery(
    files: Express.Multer.File[],
    galleryData: any
  ): Promise<any> {
    const fileDetails = files?.length
      ? files.map((file) => ({
          fileName: file.filename,
          filePath: `/${galleryData.folderName}/${file.filename}`,
        }))
      : [];

    const gallery = this.galleryRepository.create({
      ...galleryData,
      imageURL: fileDetails[0]?.filePath || undefined,
    });
    // console.log(gallery);
    const res = await this.galleryRepository.save(gallery);
    // console.log(res);
    return res;
  }

  async createCanvasImage(data: any): Promise<any> {
    const create = await this.canvasRepository.insert(data);
    if (create) {
      // console.log('create', create);
      const gallerydata: any = {
        userId: data.user,
        tenantId: data.tenantId,
        canvasId: create.identifiers[0]?.id,
        name: data.name,
        keyword: data.keyword,
        description: data.description,
        visibility: data.visibility,
        source: data.source,
        imageURL: `/${data.folderName}/${data.allFiles[0].filename}`,
      };
      // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
      const gallery = this.galleryRepository.create(gallerydata);
      // console.log(gallery);
      const res = await this.galleryRepository.save(gallery);

      // console.log('canvasImage', res);
      return res;
    } else {
      throw new NotFoundException('Canvas image creation failed');
    }
  }

  async getQuestionById(id: number): Promise<QuestionsHistory> {

    const query = this.questionHistoryRepository
      .createQueryBuilder('q')
      // .leftJoin('subject', 'sub', 'sub.id = q.subject')
      // // .leftJoin('subject', 'subdomain', 'subdomain.id = q.subDomain')
      // .leftJoin('curriculumgoal', 'child', 'child.id = q.competency')
      // .leftJoin('curriculumgoal', 'parent', 'parent.id = q.cg')
      // .leftJoinAndSelect(
      //   'questionmarkschemehistory',
      //   'qm',
      //   '(qm.qId = q.id OR qm.qId = q.trailId) AND qm.revision = q.revision'
      // )
      .select([
        'q.id AS id',
        'q.class As class',
        'q.quesType AS quesType',
        'q.optA AS optA',
        'q.optB AS optB',
        'q.optC AS optC',
        'q.optD AS optD',
        'q.correctAns AS correctAns',
        'q.optAimg AS optAimg',
        'q.optBimg AS optBimg',
        'q.optCimg AS optCimg',
        'q.optDimg AS optDimg',
        'q.question AS question',
        'q.revision AS revision',
        'q.difficulty AS difficulty',
        'q.tId AS tId',
        'q.createdAt AS createdAt',
        'q.approverId AS approverId',
        'q.marks AS marks',
        'q.trailId AS trailId',
        'q.contextid AS contextid',
        'q.contextstatus AS contextstatus',
        'q.status AS status',
        'q.subject as subject',
        'q.subDomain as subDomain',
        'q.competency as competency',
        'q.cg AS cg',
        'q.descriptors AS descriptors',
        'q.bloomTaxonomy AS bloomTaxonomy',
        'q.chapter AS chapter',
      ])
      .where('q.id = :id ', { id });
    // console.log(query.getSql());
    const questions = await query.getRawOne();
    if (!questions || questions.length === 0) {
      throw new NotFoundException('Question not found');
    }
    return questions;
  }

  async getPanelHistoryById(id: number): Promise<QuestionsHistory[]> {
    // const questions = await this.questionHistoryRepository.find({
    //   where: [{ id: id }, { trailId: id }],
    // });
    const query = this.questionHistoryRepository
      .createQueryBuilder('q')
      .leftJoin('subject', 'sub', 'sub.id = q.subject')
      .leftJoin('curriculumgoal', 'child', 'child.id = q.competency')
      .leftJoin('curriculumgoal', 'parent', 'parent.id = q.cg')
      .leftJoinAndSelect(
        'questionmarkschemehistory',
        'qm',
        '(qm.qId = q.id OR qm.qId = q.trailId) AND qm.revision = q.revision'
      )
      .select([
        'q.id AS id',
        'q.class As class',
        'q.quesType AS quesType',
        'q.optA AS optA',
        'q.optB AS optB',
        'q.optC AS optC',
        'q.optD AS optD',
        'q.correctAns AS correctAns',
        'q.optAimg AS optAimg',
        'q.optBimg AS optBimg',
        'q.optCimg AS optCimg',
        'q.optDimg AS optDimg',
        'q.question AS question',
        'q.revision AS revision',
        'q.difficulty AS difficulty',
        'q.tId AS tId',
        'q.createdAt AS createdAt',
        'q.approverId AS approverId',
        'q.marks AS marks',
        'q.trailId AS trailId',
        'q.contextid AS contextid',
        'q.status AS status',
        'qm.id AS markingSchemeHistoryId',
        'qm.markingScheme AS markingScheme',
        'sub.subject as subject',
        'child.cgNo AS competency',
        'parent.cgNo AS cg',
      ])
      .where('q.status = :status AND q.id = :id OR q.trailId = :id', {
        id,
        status: 'PANELING',
      });
    // console.log(query.getSql());
    const questions = await query.getRawMany();
    if (!questions || questions.length === 0) {
      throw new NotFoundException('Question history not found');
    }
    return questions;
  }

  async saveQuestionPaper(data: any, tenantId: string): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        const paper = data.generalDetails;
        const questionPaper = manager.create(QuestionPaper, {
          examCode: paper.examCode,
          name: paper.name,
          class: paper.class,
          subject: paper.subject,
          subjectName: paper.subjectName,
          section: paper.section,
          maxMarks: paper.maxMarks,
          totalTime: paper.totalTime,
          createdFrom: 'bank',
          generalInstruction: paper.generalInstruction,
          examDate: paper.examDate,
          session: paper.session,
          sectionsData: paper.sectionsData,
          tenantid: tenantId,
        });
        const savedPaper = await manager.insert(QuestionPaper, questionPaper);
        const paperId: number = savedPaper.identifiers[0].id;

        const questions: ExamQuestion[] = data.questions.map((q: any) => ({
          paperId, // parent reference
          questionId: q.questionId,
          sequence: q.sequence,
          marks: q.marks,
          connector: q.connector,
          isSection: q.isSection,
          isSub: q.isSub,
          section: q.section,
          ui: q.ui,
          subOf: q.subOf,
          queslabel: q.queslabel,
        }));

        await manager.insert(ExamQuestion, questions);

        return paperId;
      });
    } catch (error) {
      this.logger.log(`Paper saving Error: ${error}`);
      console.error('Error saving question paper:', error);
      throw new Error('Failed to save question paper');
    }
  }

  async getUserQuestions(userId: number): Promise<QuestionsHistory[]> {
    const questions = await this.questionHistoryRepository
      .createQueryBuilder('q')
      .leftJoin('subject', 'sub', 'sub.id = q.subject')
      .where('q.tId = :userId', { userId })
      .andWhere('q.dmlType = "I"')
      .andWhere('q.status IN (:...status)', {
        status: [
          'DRAFT',
          'REVISING',
          'READYPANELING',
          'REJECTED',
          'DELETED',
          'MSCMREQUIRE',
          'PANELING',
          'TRANSFERRED',
        ],
      })
      .select([
        'q.id as id',
        'q.question as question',
        'q.createdAt as createdAt',
        'q.status as status',
        'q.class as class',
        'q.quesType as quesType',
        'sub.subject as subject',
      ])
      .orderBy('q.createdAt', 'DESC')
      .getRawMany();

    if (questions.length === 0) {
      throw new NotFoundException('Questions not found');
    }
    // console.log('questions', questions);
    return questions;
  }

  async uploadImg(
    files: Express.Multer.File[],
    galleryData: any
  ): Promise<any> {
    const fileDetails = files?.length
      ? files.map((file) => ({
          fileName: file.filename,
          filePath: `/${galleryData.folderName}/${file.filename}`,
        }))
      : [];
    return fileDetails;
  }
}
