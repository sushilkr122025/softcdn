import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('lookupschool')
export class LookupSchool {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true, nullable: true, length: 50 })
  getlocation: string;

  @Column({ nullable: true, length: 50 })
  returnlocation: string;

  @Column({ default: 0 })
  viewcount: number;

  @Column({ length: 5, default: 'I' })
  dmltype: string;

  @Column({ length: 10, nullable: true, default: 'ACTIVE' })
  status: string;

  @CreateDateColumn({ type: 'datetime', precision: 6 })
  createdate: Date;
}
