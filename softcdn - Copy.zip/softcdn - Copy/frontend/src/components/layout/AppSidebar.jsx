import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Settings, ChevronRight } from 'lucide-react';
import teacher from '../../assets/images/teachers.svg';
import student from '../../assets/images/student.svg';
import report from '../../assets/images/report.svg';
import bank from '../../assets/images/bank.svg';
import dashboard from '../../assets/images/dashboard.svg';
import { IoIosCloseCircleOutline } from 'react-icons/io';
import './Sidebar.css';

const Sidebar = ({ isCollapsed, collapseFully, setCollapseFully }) => {
  const [activeItem, setActiveItem] = useState('');
  const [openMenu, setOpenMenu] = useState({});
  const sidebarRef = useRef(null);
  const [popoutMenu, setPopoutMenu] = useState(null);
  const [popoutVisible, setPopoutVisible] = useState(null);

  const handleGroupClick = (menuName) => {
    if (isCollapsed) {
      if (popoutMenu === menuName) {
        setPopoutVisible(null);
        setTimeout(() => setPopoutMenu(null), 900);
      } else {
        setPopoutMenu(menuName);
        setPopoutVisible(menuName);
      }
    } else {
      setOpenMenu({
        [menuName]: !openMenu[menuName],
      });
      setPopoutMenu(null);
      setPopoutVisible(null);
    }
  };


  const getItemStyle = (itemName) => ({
    backgroundColor: activeItem === itemName ? 'var(--bs-primary)' : 'transparent',
    color: activeItem === itemName ? '#000' : 'inherit',
  });

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target) && popoutMenu) {
        setPopoutMenu(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [popoutMenu]);

  useEffect(() => {
    if (isCollapsed) {
      setOpenMenu((prev) => ({
        teachers: prev.teachers,
        students: prev.students,
        questionBank: prev.questionBank,
        report: prev.report,
      }));
    }
  }, [isCollapsed]);

  const handleSubmenuClick = (itemName) => {
    setActiveItem(itemName);
    if (isCollapsed) {
      setPopoutMenu(null);
      setPopoutVisible(null);
    }
    if (window.innerWidth < 768) {
      setCollapseFully(true);
    }
  };

  return (
    <div
      id='sidefix'
      ref={sidebarRef}
      className={`sidebar-container ${collapseFully
        ? "sidebar-hidden"
        : isCollapsed
          ? "sidebar-collapsed"
          : "sidebar-default new"
        }`}
    >
      <div className="sidebarLogo d-flex justify-content-center">
        <span className="fs-5 fw-bold text-white">LearnIQ</span>
        <button className="btn d-flex align-items-center close-btn"
          onClick={() => {
            setCollapseFully(true);
            setOpenMenu({});       // Close all open menus
            setPopoutMenu(null);   // Remove popout
            setPopoutVisible(null);// Hide popout animation
          }}
        >
          <IoIosCloseCircleOutline size={30} />
        </button>
      </div>
      <ul className="nav flex-column px-4 gap-1 pt-5">
        <li className="nav-item mb-3 ">
          <Link
            to="/dashboard"
            className="nav-link justify-content-start"
            onClick={() => {
              handleSubmenuClick("dashboard")
            }}

            style={{
              flexDirection: isCollapsed ? "column" : "row",
              gap: "0.6rem",
              cursor: "pointer"
            }}
          >
            <img
              src={dashboard}
              alt="students"
              style={{ width: "22px" }} />
            {isCollapsed ? (
              <span >Dashboard</span>
            ) : (
              <span>Dashboard</span>
            )}
          </Link>
        </li>
        <li className="nav-item mb-3">
          <div
            className="nav-link"
            onClick={() => handleGroupClick("teachers")}
            style={{
              flexDirection: isCollapsed ? "column" : "row",
              cursor: "pointer"
            }}
          >
            <div
              className="nav-sublink"
              style={{
                flexDirection: isCollapsed ? "column" : "row",
              }}
            >
              <img
                src={teacher}// Replace with your icon path
                alt="students"
                style={{ width: "25px" }} />
              {/* <BookUser size={20} /> */}
              <span>Teachers</span>
            </div>

            {isCollapsed ? null : (
              <span
                className={`arrow-icon ${openMenu.teachers || popoutMenu === "teachers" ? "open" : ""}`}>
                <ChevronRight size={18} />
              </span>
            )}
          </div>

          <div
            className={
              isCollapsed
                ? popoutVisible === "teachers"
                  ? "popout-slide-in"
                  : popoutMenu === "teachers" && popoutVisible !== "teachers"
                    ? "popout-slide-out"
                    : ""
                : ""
            }

            style={{
              maxHeight: !isCollapsed && openMenu.teachers ? "500px" : "0",
              overflow: "hidden",
              transition: "max-height 0.45s ease-in-out",
              ...(isCollapsed && popoutMenu === "teachers" && {
                position: 'fixed',
                top: '268px',
                left: '9rem',
                minWidth: '200px',
                backgroundColor: 'var(--bs-body-color)',
                borderRadius: '0 0.375rem 0.375rem 0.375rem',
                zIndex: 1000,
                maxHeight: 'none',
                overflow: 'visible',
              }),
            }}

          >

            <ul className="nav flex-column submenu" >
              <li className="nav-item rounded ms-0" style={getItemStyle("allTeachers")}>
                <Link
                  to="/users"
                  className="nav-link"
                  onClick={() => handleSubmenuClick("AllTeacher")}
                >
                  <span><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "teachers" ? "All Teachers" : (!isCollapsed && "All User")}</span>
                </Link>

              </li>
            </ul>
          </div>
        </li>
        <li className="nav-item mb-3">
          <div
            className="nav-link text-white d-flex justify-content-between align-items-center"
            onClick={() => handleGroupClick("students")}
            style={{
              flexDirection: isCollapsed ? "column" : "row",
              cursor: "pointer"
            }}
          >
            <div
              className="nav-sublink"
              style={{
                flexDirection: isCollapsed ? "column" : "row",
              }}
            >
              <img
                src={student}// Replace with your icon path
                alt="students"
                style={{ width: "25px" }} />
              <span>Students</span>
            </div>

            {isCollapsed ? <></> : (
              <span className={`arrow-icon ${openMenu.students || popoutMenu === "students" ? "open" : ""}`}>
                <ChevronRight size={18} />
              </span>
            )}
          </div>

          <div
            className={
              isCollapsed
                ? popoutVisible === "students"
                  ? "popout-slide-in"
                  : popoutMenu === "students" && popoutVisible !== "students"
                    ? "popout-slide-out"
                    : ""
                : ""
            }
            style={{
              maxHeight: !isCollapsed && openMenu.students ? "500px" : "0",
              overflow: "hidden",
              transition: "max-height 0.45s ease-in-out",
              ...(isCollapsed && popoutMenu === "students" && {
                position: 'fixed',
                top: '356px',
                left: '9rem',
                minWidth: '200px',
                backgroundColor: 'var(--bs-body-color)',
                borderRadius: '0 0.375rem 0.375rem 0.375rem',
                zIndex: 1000,
                maxHeight: 'none',
                overflow: 'visible',
              }),
            }}
          >
            <ul className="nav flex-column submenu" >
              <li className="nav-item rounded" style={getItemStyle("allStudents")}>
                <Link
                  to="/student"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("AllStudent");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                    handleSubmenuClick("AllStudent");
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "students" ? "All Students" : (!isCollapsed && "All Students")}</span>
                </Link>
              </li>
            </ul>
          </div>

        </li>
        <li className="nav-item mb-3">
          <div
            className="nav-link text-white d-flex justify-content-between align-items-center"
            onClick={() => handleGroupClick("questionBank")}
            style={{
              flexDirection: isCollapsed ? "column" : "row",
              textAlign: isCollapsed ? "center" : "left",
              cursor: "pointer"
            }}
          >
            <div
              className="nav-sublink"
              style={{
                flexDirection: isCollapsed ? "column" : "row",
              }}
            >
              <img
                src={bank}
                alt="students"
                style={{ width: "20px" }} />
              <span>Question Bank</span>
            </div>
            {isCollapsed ? <></> : (
              <span className={`arrow-icon ${openMenu.questionBank || popoutMenu === "questionBank" ? "open" : ""}`}>
                <ChevronRight size={18} />
              </span>
            )}
          </div>

          <div
            className={
              isCollapsed
                ? popoutVisible === "questionBank"
                  ? "popout-slide-in"
                  : popoutMenu === "questionBank" && popoutVisible !== "questionBank"
                    ? "popout-slide-out"
                    : ""
                : ""
            }
            style={{
              maxHeight: !isCollapsed && openMenu.questionBank ? "500px" : "0",
              overflow: "hidden",
              transition: "max-height 0.45s ease-in-out",
              ...(isCollapsed && popoutMenu === "questionBank" && {
                position: 'fixed',
                top: '444px',
                left: '9rem',
                minWidth: '200px',
                backgroundColor: 'var(--bs-body-color)',
                borderRadius: '0 0.375rem 0.375rem 0.375rem',
                zIndex: 1000,
                maxHeight: 'none',
                overflow: 'visible',
              }),
            }}
          >
            <ul className="nav flex-column submenu p-0 " >
              <li className="nav-item" style={getItemStyle("allQuestions")}>
                <Link
                  to="/question"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("AllQuestion");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                    handleSubmenuClick("allQuestions");
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "questionBank" ? "All Questions" : (!isCollapsed && "All questions")}</span>
                </Link>
              </li>

              <li className="nav-item rounded" style={getItemStyle("createQuestion")}>
                <Link
                  to="/questionGeneration"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("createQuestion");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                    handleSubmenuClick("createQuestion");

                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "questionBank" ? "Create Question" : (!isCollapsed && "Create a question")}</span>
                </Link>
              </li>

              <li className="nav-item rounded" style={getItemStyle("checkApproval")}>
                <Link
                  to="/question-bank/approval"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("checkApproval");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                    handleSubmenuClick("checkApproval");
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "questionBank" ? "Check Approval" : (!isCollapsed && "Check approval")}</span>
                </Link>
              </li>

              <li className="nav-item rounded" style={getItemStyle("createQuestionPaper")}>
                <Link
                  to="/question-bank/paper"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("createQuestionPaper");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                    handleSubmenuClick("createQuestionPaper");

                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "questionBank" ? "Create Question Paper" : (!isCollapsed && "Create question paper")}</span>
                </Link>
              </li>
            </ul>
          </div>

        </li>
        <li className="nav-item mb-3">
          <div
            className="nav-link text-white d-flex justify-content-between align-items-center"
            onClick={() => handleGroupClick("report")}
            style={{
              flexDirection: isCollapsed ? "column" : "row",
              cursor: "pointer"
            }}
          >
            <div
              className="nav-sublink"
              style={{
                flexDirection: isCollapsed ? "column" : "row",
              }}
            >
              <img
                src={report}
                alt="students"
                style={{ width: "22px" }} />
              <span>Report</span>
            </div>
            {isCollapsed ? <></> : (
              <span className={`arrow-icon ${openMenu.report || popoutMenu === "report" ? "open" : ""}`}>
                <ChevronRight size={18} />
              </span>
            )}
          </div>

          <div
            className={
              isCollapsed
                ? popoutVisible === "report"
                  ? "popout-slide-in"
                  : popoutMenu === "report" && popoutVisible !== "report"
                    ? "popout-slide-out"
                    : ""
                : ""
            }
            style={{
              maxHeight: !isCollapsed && openMenu.report ? "500px" : "0",
              overflow: "hidden",
              transition: "max-height 0.45s ease-in-out",
              ...(isCollapsed && popoutMenu === "report" && {
                position: 'fixed',
                top: '556px',
                left: '9rem',
                minWidth: '200px',
                backgroundColor: 'var(--bs-body-color)',
                borderRadius: '0 0.375rem 0.375rem 0.375rem',
                zIndex: 1000,
                maxHeight: 'none',
                overflow: 'visible',
              }),
            }}
          >
            <ul className="nav flex-column submenu" >
              <li className="nav-item rounded" >
                <Link
                  to="/report/student"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("studentReport");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "report" ? "Student Report" : (!isCollapsed && "Student Report")}</span>
                </Link>
              </li>

              <li className="nav-item rounded" style={getItemStyle("teacherReport")}>
                <Link
                  to="/report/teacher"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("teacherReport");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "report" ? "Teacher Report" : (!isCollapsed && "Teacher Report")}</span>
                </Link>
              </li>

              <li className="nav-item rounded" style={getItemStyle("managementReport")}>
                <Link
                  to="/reportadmin"
                  className="nav-link text-white d-flex align-items-center"
                  onClick={() => {
                    setActiveItem("managementReport");
                    if (isCollapsed) {
                      setPopoutVisible(null);
                      setTimeout(() => setPopoutMenu(null), 900);
                    }
                  }}
                >
                  <span ><ChevronRight size={15} /></span>
                  <span>{isCollapsed && popoutMenu === "report" ? "Management Report" : (!isCollapsed && "Management Report")}</span>
                </Link>
              </li>
            </ul>
          </div>

        </li>
        <li className="nav-item mb-3">
          <Link
            to="/settings"
            className="nav-link justify-content-start"
            onClick={() => {
              setActiveItem("settings");
              setOpenMenu({});
            }}
            style={{
              flexDirection: isCollapsed ? "column" : "row",
              gap: "0.6rem",
            }}
          >
            <Settings size={20} />
            {isCollapsed ? (
              <span>Settings</span>
            ) : (
              <span>Settings</span>
            )}
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
