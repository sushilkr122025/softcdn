import { useEffect, useState, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'
import './Question.css'
// import Toolbar from 'src/components/toolbar/Toolbar'
import { Modal, Button } from 'react-bootstrap'
import apiClient from '../../api/apiService'
import { classToStage } from '../../utils/util'
import useAuth from '../../context/AuthContext'
import { BiImageAdd } from 'react-icons/bi';
import { FaImage } from 'react-icons/fa6';
import MultiServices from '../../api/MultiServices'
import { useNavigate } from 'react-router-dom'
import SimpleToast from '../../components/Toast';
// import DOMPurify from 'dompurify';
import JoditEditor from 'jodit-react';
import 'jodit/es2021/jodit.min.css';
import { e } from 'mathjs'

function QuestionGeneration() {
  const apiUrl = import.meta.env.VITE_HOST;
  const [sparams] = useSearchParams();
  const joeditor = useRef(null);
  const joditconfig = {
    readonly: false, // all options from https://xdsoft.net/jodit/docs/
    toolbarSticky: false,
    toolbarAdaptive: false,
    height: 250,

    buttons: [
      'bold',
      'italic',
      'underline',
      'strikethrough',
      '|',
      'ul',
      'ol',
      '|',
      'outdent',
      'indent',
      'table',
      '|',
      'font',
      'fontsize',
      'brush',
      'paragraph',
      '|',
      'align',
      '|',
      'image',
      '|',
      'undo',
      'redo',
      '|',
      'hr',
      'eraser',
      'copyformat',
      // '|', 'fullsize', 'preview'
    ],
  };

  const { user } = useAuth();
  const navigator = useNavigate()

  // Metadata State
  const [std, setStd] = useState('');
  const [subject, setSubject] = useState('');
  const [subDomain, setSubDomain] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [cg, setCg] = useState('');
  const [competency, setCompetency] = useState('');

  const [cgtext, setCgtext] = useState('');
  const [competencytext, setCompetencytext] = useState('');

  // api Data options
  const [classData, setClassData] = useState([]);
  const [subjectData, setSubjectData] = useState([]);
  const [subDomainData, setSubDomainData] = useState([]);
  const [cgData, setCgData] = useState([]);
  const [competencyData, setCompetencyData] = useState([]);

  const [optionImages, setOptionImages] = useState({});
  const [activeOption, setActiveOption] = useState(null);

  const [show, setShow] = useState(false);
  const [preview, setPreview] = useState(false);

  const [images, setImages] = useState([]);

  const [question, setQuestion] = useState('');

  const [QuesType, setQuesType] = useState('');
  const [Options, setOptions] = useState(['', '', '', '']);
  // const [SelectedImages, setSelectedImages] = useState([])
  const [errors, setErrors] = useState({});
  const [chapter, setChapter] = useState('');

  const [showToast, setShowToast] = useState(false);

  // const [formData, setFormData] = useState([]);

  useEffect(() => {
    apiClient.get('/store/classes').then((res) => setClassData(res.data)).catch((err) => console.error('Class fetch error', err));
    apiClient.get('/store/subject').then((res) => setSubjectData(res.data)).catch((err) => console.error('Subject fetch error', err));

    async function fetchImages() {
      const response = await MultiServices.getImages()      
      setImages(response)
    }    
    fetchImages();
  }, []);

    useEffect(() => {
      setCg('');
      setCompetency('');
      setCgData([]);
      setCompetencyData([]);

      if (std && subject) {
        const stage = classToStage[std];
        apiClient
          .get('/store/cg', { params: { stage, subject } })
          .then((res) => setCgData(res.data))
          .catch((err) => console.error('CG fetch error', err));
      }
    }, [std, subject]);

    useEffect(() => {
      setSubDomain('');
      setSubDomainData([]);

      if (subject) {
        apiClient
          .get('/store/subDomain', { params: { subject } })
          .then((res) => setSubDomainData(res.data))
          .catch((err) => console.error('Subdomain fetch error', err));
      }
    }, [subject]);

    useEffect(() => {
      setCompetency('');
      setCompetencyData([]);

      if (cg) {
        apiClient
          .get('/store/competency', { params: { id: cg } })
          .then((res) => setCompetencyData(res.data))
          .catch((err) => console.error('Competency fetch error', err));
      }
    }, [cg]);

  const handleClose = () => {
    setShow(false);
    setPreview(false);
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const payload = Object.fromEntries(formData);
    
    payload['tId'] = user.id;
    payload['cg'] = cg;
    payload['competency'] = competency;
    payload['question'] = question;
    payload['class'] = std;
    payload['subject'] = subject
    payload['subDomain'] = subDomain;
    payload['difficulty'] = difficulty;
    payload['cgtext'] = cgtext;
    payload['competencytext'] = competencytext;
    payload['questionType'] = QuesType;
    payload['chapter'] = chapter;
    payload["image"] = optionImages['quesImg'] || '' ;
    // payload['options'] = 
    // payload['optionImages'] = selectedImages
    console.log(payload);

    const validateForm = (formData) => {
      console.log(formData);

      const errors = {};

      if (!formData.subject) {
        errors.subject = 'Subject is required';
      }
      if (!formData.class) {
        errors.class = 'Class is required';
      }
      if (!formData.subDomain && subDomainData.length > 0) {
        errors.subDomain = 'Sub Domain is required';
      }
      if (!formData.cg) {
        errors.cg = 'Curriculum Goal is required';
      }
      if (!formData.competency) {
        errors.competency = 'Competency is required';
      }
      if (!formData.difficulty) {
        errors.difficulty = 'Difficulty is required';
      }
      if (!formData.questionType) {
        errors.questionType = 'Type is required';
      }
      if (formData.questionType === 'oneWord' && formData.corrAns.trim().split(' ').length > 1) {
        errors.correctAnswer = 'Please enter only one word';
      }
      if (formData.questionType === 'oneWord' && !formData.corrAns) {
        errors.correctAnswer = 'Please enter one word';
      }
      if (formData.questionType === 'trueFalse' && !formData.corrAns) {
        errors.correctAnswer = 'Please select either true or false';
      }
      if (formData.questionType === 'multipleChoice' && !formData.corrAns) {
        errors.correctAnswer = 'Please select any one option';
      }
      // Add more validation rules for other fields
      return errors;
    };

    const validationErrors = validateForm(payload);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      console.log(validationErrors);
      return;
    }

    // payload['canvas'] = localStorage.getItem('canvasState')

    try {
      const response = await apiClient.post('/school/questions', payload);
      if (response) {      
        setShowToast(true);
        // navigator('/questionGeneration');
      }
    } catch (error) {
      console.error(error);
    }
  };

    const fetchQuestion = async () => {
      try {
        const response = await apiClient.get(`/school/questions/${sparams.get('id')}`);
        if (response.data) {
          setStd(response.data.class);
          setSubject(response.data.subject);
          setSubDomain(response.data.subDomain);
          setDifficulty(response.data.difficulty);
          setCg(response.data.cg);
          setCompetency(response.data.competency);
          setCgtext(response.data.cgtext);
          setCompetencytext(response.data.competencytext);
          setQuestion(response.data.question);
          setQuesType(response.data.questionType);
          setChapter(response.data.chapter);

          const options = response.data.options || [];
          if (options.length < 4) {
            for (let i = options.length; i < 4; i++) {
              options.push('');
            }
          }
          setOptions(options);

          const images = response.data.optionImages || {};
          setOptionImages(images);

        } 
      } catch (error) {
        console.error(error);
      }
    }
    const getquestion =  sparams.get('id');
    if (getquestion) {
      console.log(getquestion);
      fetchQuestion();
    }

  return (
    <>
      <div className="container-fluid" id="question-section">
        <div className="row my-3">
          <div className="col">
            <select id="class" name="class" className="form-select" onChange={(e) => setStd(e.target.value)}>
              <option value="">Class</option>
              {classData.map((classes) => (
                <option key={classes.id} value={classes.class}>
                  {classes.class}
                </option>
              ))}
            </select>
            {errors.class && <span className="error ">{errors.class}</span>}
          </div>
          <div className="col">
            <select id="subject" name="subject" className="form-select" onChange={(e) => setSubject(e.target.value)}>
              <option value="">Subject</option>
              {subjectData.map((subject) => (
                <option key={subject.id} value={subject.id}>
                  {subject.subject}
                </option>
              ))}
            </select>
            {errors.subject && <span className="error">{errors.subject}</span>}
          </div>
          <div className="col">
            <select id="subDomain" name="subDomain" className="form-select" onChange={(e) => setSubDomain(e.target.value)} disabled={!subDomainData.length}>
              <option value="">Sub Domain</option>
              {subDomainData.map((subDomain) => (
                <option key={subDomain.id} value={subDomain.id}>
                  {subDomain.subject}
                </option>
              ))}
            </select>
            {errors.subDomain && <span className="error">{errors.subDomain}</span>}
          </div>
          <div className="col">
            <select id="difficulty" name="difficulty" className="form-select" onChange={(e) => setDifficulty(e.target.value)}>
              <option value="">Difficulty</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
            {errors.difficulty && <span className="error">{errors.difficulty}</span>}
          </div>
          <div className="col">
            <select
              className="form-select"
              id="cg"
              name="cg"
              value={cg}
              disabled={!cgData.length}
              onChange={(e) => {
                setCg(e.target.value);
                setCgtext(e.target.options[e.target.selectedIndex].text);
              }}
            >
              <option value="">Curriculum Goal</option>
              {cgData.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.cgNo}
                </option>
              ))}
            </select>
            {errors.cg && <div className="error">{errors.cg}</div>}
          </div>
          <div className="col">
            <select
              className="form-select"
              id="competency"
              name="competency"
              value={competency}
              disabled={!competencyData.length}
              onChange={(e) => {
                setCompetency(e.target.value);
                setCompetencytext(e.target.options[e.target.selectedIndex].text);
              }}
            >
              <option value="">Competency</option>
              {competencyData.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.cgNo}
                </option>
              ))}
            </select>
            {errors.competency && <div className="error">{errors.competency}</div>}
          </div>
          <div className="col">
            <select className="form-select" name="questionType" id="questionType" onChange={(e) => setQuesType(e.target.value)}>
              <option value="">Select Question Type</option>
              <option value="multipleChoice">Multiple Choice</option>
              <option value="trueFalse">True/False</option>
              <option value="oneWord">One Word</option>
              <option value="CR">Written Response</option>
              <option value="fillups">Fill in the Blanks</option>
              <option value="match">Match the Following</option>
            </select>
            {errors.questionType && <div className="error">{errors.questionType}</div>}
          </div>
        </div>
        <div className="row">
          <div className="col-md-10 py-4">
            <JoditEditor ref={joeditor} value={question} config={joditconfig} onBlur={(content) => setQuestion(content)} />
          </div>
          <div className="col-md-2 py-4 d-flex flex-column justify-content-between align-items-center">
            <button
              className="btn w-100 h-100 p-0"
              style={{ border: '1px dashed #000' }}
              onClick={() => {
                setActiveOption(`quesImg`);
                setShow(true);
              }}
            >
              {!optionImages['quesImg'] && <BiImageAdd />}
              {optionImages['quesImg'] && <img src={`${apiUrl}/assets${optionImages['quesImg']['src']}`} alt={optionImages['quesImg']['label']} className="image-preview m-0 w-100 h-100" />}
            </button>
            {optionImages.quesImg && <div className="py-2">{optionImages.quesImg.label}</div>}
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 p-4 bg-white shadow-sm">
            <form className="form" onSubmit={onSubmitHandler} encType="multipart/form-data">
              <div className="row mb-3">
                <div className="col-md-4 offset-md-4">
                  {QuesType === 'oneWord' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="textQuesAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <input
                            id="corrAns"
                            name="corrAns"
                            className="form-control"
                            type="text"
                            // value={CorrectAns}
                            // onChange={(e) => setCorrectAnswer(e.target.value)}
                            placeholder="Enter the Correct Answer"
                          />
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {QuesType === 'trueFalse' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="trueFalseAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select id="corrAns" name="corrAns" className="form-select">
                            <option value="">Select Correct Answer</option>
                            <option value="true">True</option>
                            <option value="false">false</option>
                          </select>
                          {errors.correctAnswer && <div className="error-message">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {QuesType === 'multipleChoice' && (
                    <>
                      <div className="row">
                        {Options.map((opt, index) => {
                          const key = `opt${index + 1}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <div className="col-md-12 mb-3" key={index}>
                              <label htmlFor={key} className="form-label">
                                Option {index + 1}
                              </label>
                              <div className="d-flex">
                                <input
                                  className="form-control form-control-sm me-3"
                                  name={key}
                                  id={key}
                                  type="text"
                                  onChange={(e) => {
                                    const newOptions = [...Options];
                                    newOptions[index] = e.target.value;
                                    setOptions(newOptions);
                                  }}
                                />
                                <input type="hidden" name={imgKey} id={imgKey} value={imgObj ? JSON.stringify(imgObj) : ''} />
                                <button
                                  className="btn"
                                  style={{ border: '1px dashed #000' }}
                                  onClick={() => {
                                    setShow(true);
                                    setActiveOption(`opt${index + 1}img`);
                                  }}
                                >
                                  <BiImageAdd />
                                </button>
                                {imgObj && (
                                  <>
                                    <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview ms-2" />
                                    <span className="ms-2">{imgObj.label}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="row pt-2">
                        <div className="col-md-12 mb-3">
                          <label className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select className="form-select form-rows" name="corrAns" id="corrAns">
                            <option value="">Select Correct Answer</option>
                            <option value="optA">Option 1</option>
                            <option value="optB">Option 2</option>
                            <option value="optC">Option 3</option>
                            <option value="optD">Option 4</option>
                          </select>
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  <div className="row mb-3">
                    <div className="col-12">
                      <label htmlFor="chapter" className="mb-2">
                        Chapter
                      </label>
                      <input type="text" name="chapter" id="chapter" className="form-control" onInput={e => setChapter(e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>
              <Modal show={show} onHide={handleClose} backdrop="static" size="xl">
                <Modal.Header closeButton>
                  <Modal.Title>Gallery</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="row">
                    {images.map((e, i) => {
                      return (
                        <div key={i} className="col-4">
                          <div
                            className="image-container"
                            onClick={() => {
                              setOptionImages((prev) => ({ ...prev, [activeOption]: { src: e.imageURL, label: e.name } }));
                              setShow(false);
                            }}
                          >
                            <div className="d-flex justify-content-between w-100">
                              <div className="img-head px-3">
                                <div className=" d-flex align-items-center">
                                  <FaImage className="text-danger me-3" /> {e.name}
                                </div>
                              </div>
                              <div className="img-foot">
                                <div className="keyword">{e.keyword}</div>
                                <div className="keyword description" title="description">
                                  {e.description}
                                </div>
                              </div>
                            </div>
                            <div className="img">
                              <img src={`${apiUrl}/assets${e.imageURL}`} alt={e.name} className="img-fluid" />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                  <Button variant="primary">Save Changes</Button>
                </Modal.Footer>
              </Modal>

              <div className="text-center mt-3">
                <button className="btn btn-ghost me-3" type="button">
                  panel
                </button>
                <button className="btn btn-grey me-3" type="button" onClick={() => setPreview(true)}>
                  preview
                </button>
                <button className="btn btn-primary" type="submit">
                  save
                </button>
              </div>
            </form>
            <Modal show={preview} onHide={handleClose} backdrop="static" size="md">
              <Modal.Header closeButton>
                <Modal.Title>Preview Question</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <div dangerouslySetInnerHTML={{ __html: question}}></div>
                <div className="row mb-4">
                  <div className="col-8 offset-2">
                    <div className="row">
                      {QuesType === 'multipleChoice' &&
                        Options.map((e, index) => {
                          const key = `opt${index + 1}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <div className="col-md-6 my-3 text-center" key={index}>
                              <span>
                                {index + 1}. &nbsp;{e}
                              </span>
                              {imgObj && <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview me-2" />}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </Modal.Body>
            </Modal>
          </div>
        </div>
        <SimpleToast show={showToast} message="Question saved successfully !" variant="success" onClose={() => setShowToast(false)} />
      </div>
    </>
  );
}
export default QuestionGeneration
