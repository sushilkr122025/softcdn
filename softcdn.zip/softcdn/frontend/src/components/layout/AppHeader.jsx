import React from 'react'
import { NavLink } from 'react-router-dom'
import Logo from '../../assets/images/logo.png'
import AppHeaderDropdown from './AppHeaderDropdown'
import { PiToggleRightLight, PiToggleLeftLight } from "react-icons/pi";
import { RiMenu2Line, RiMenu3Fill, RiMenuFill } from "react-icons/ri";
import { CiPower } from "react-icons/ci";
import { PiBellLight } from "react-icons/pi";

const AppHeader = ({ isCollapsed, setIsCollapsed, setCollapseFully, collapseFully }) => {
  // const [searchTerm, setSearchTerm] = useState('')

  // const handleSearch = () => {
  //   console.log('Searching for:', searchTerm)
  // }

  return (
    // <header className="sticky-top py-1 bg-white">
    //   <div className="container-fluid">
    //     <div className="row align-items-center">
    //       <div className="col-md-2 col-3">
    //         <NavLink to="/dashboard">
    //           <img src={Logo} alt="classroom" className="img-fluid" width={50} />
    //         </NavLink>
    //       </div>
    //       <div className="col-md-8 col-5 ">
    //         <input
    //           type="text"
    //           className="form-control border-0 d-md-inline d-md-flex p-2"
    //           style={{ backgroundColor: '#E9EBF8', width: '100%', borderRadius: '15px' }}
    //           placeholder="Search"
    //           value={searchTerm}
    //           onChange={(e) => setSearchTerm(e.target.value)}
    //         />
    //         {/* <FaSearch
    //           className="d-none"
    //           onClick={handleSearch}
    //           style={{
    //             cursor: 'pointer',
    //             position: 'absolute',
    //             right: '360px',
    //             top: '50%',
    //             transform: 'translateY(-50%)',
    //           }}
    //         /> */}
    //       </div>
    //       <div className="col-md-2 col-4 justify-content-end d-flex align-items-center">
    //         <div className="justify-content-center me-2">
    //           <FaBell className="me-md-3 me-2 text-secondary" style={{ fontSize: '18px' }} />
    //           <FaCog className="me-md-2 text-secondary" style={{ fontSize: '18px' }} />
    //         </div>
    //         <div>
    //           <AppHeaderDropdown />
    //         </div>
    //       </div>
    //     </div>
    //   </div>
    // </header>
    <header className="d-flex justify-content-between align-items-center">
      <div className='d-flex justify-content-between align-items-center'>
        <button
          className="btn btn-primary ms-4 d-none d-md-block"
          onClick={() => {
            if (!isCollapsed && !collapseFully) {
              setIsCollapsed(true)
            } else if (isCollapsed && !collapseFully) {
              setCollapseFully(true)
            } else {
              setCollapseFully(false);
              setIsCollapsed(false);
            }
          }}
        >
          {collapseFully ? (
            <RiMenu2Line />
          ) : (isCollapsed ?
            <RiMenuFill />
            : <RiMenu3Fill />

          )}
        </button>
        <button
          className="btn btn-primary d-block d-md-none"
          onClick={() => {
            if (!isCollapsed && !collapseFully) {
              setIsCollapsed(true);
            } else {
              setCollapseFully(false);
            }
          }}
        >
          {collapseFully ? (
            <RiMenu2Line />
          ) : (isCollapsed ?
            <RiMenuFill />
            : <RiMenu3Fill />

          )}
        </button>
        <input
          type="text"
          className="form-control d-none d-lg-block ms-5"
          placeholder="Search"
          style={{ width: "40rem" }}
        />
      </div>
      <div className='d-flex justify-content-around align-items-center'>
        <button className="px-4 bg-white border-0 text-grey-400" title='Notification'><PiBellLight style={{fontSize: "25px"}} /></button>
        <button className="px-4 bg-white border-0 border-start rounded-0 text-grey-400" title='Logout'><CiPower style={{fontSize: "25px"}} /></button>
      </div>

    </header>
  );
};

export default AppHeader
