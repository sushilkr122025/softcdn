import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import AuthService from '../api/authService'
import useAuth from '../context/AuthContext'

const Logout = () => {
  const navigate = useNavigate()
  const { logout, setUser  } = useAuth()

  const handleLogout = async () => {
    try {
      await AuthService.logoutUser()      
    } catch (error) {
      console.error('Logout API failed:', error)
    }finally {
      await logout()
      setUser(null)
      navigate('/login')
    } 
  }
  
    handleLogout()


  return;
}

export default Logout
