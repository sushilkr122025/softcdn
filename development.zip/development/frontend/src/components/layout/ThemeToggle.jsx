import { useTheme } from "./ThemeContext";
import { IoIosColorPalette } from "react-icons/io";
import { IoSunnyOutline } from "react-icons/io5";
const themes = [
  { name: "blue", label: " Blue" },
  { name: "teal", label: " Teal blue" },
  { name: "purple", label: " Purple" },
];

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="dropdown">
      <button
       className="custombtn" type="button" data-bs-toggle="dropdown" aria-expanded="false" 
       title="Theme"
      >
        <IoSunnyOutline  size={23}/>
      </button>
      <ul className="dropdown-menu p-2">
        {themes.map((t) => (
          <li key={t.name}>
            <button
              className={`dropdown-item my-1 ${theme === t.name ? "active" : ""}`}
              onClick={() => setTheme(t.name)}
            >
              {t.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ThemeToggle;
