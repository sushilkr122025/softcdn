import { Injectable } from '@nestjs/common';
import { Message } from '../entities/message.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { CommonService } from './common.service';

@Injectable()
export class MessageService {
  constructor(
    @InjectRepository(Message)
    private repoMessage: Repository<Message>,
    private readonly commonService: CommonService
  ) {}

  async createMessage(data: Partial<Message>): Promise<any> {
    const message = this.repoMessage.create(data);
    const res = await this.repoMessage.save(message);
    const id = res.id;
    if (data.msgType == 'APPROVE') {
      const findApproved: { count: number } | undefined = await this.repoMessage
        .createQueryBuilder('m')
        .where('m.msgType = :msgType', { msgType: 'APPROVE' })
        .andWhere('m.qId = :qId', { qId: data.qId })
        .andWhere('m.quesVersion = :quesVersion', {
          quesVersion: data.quesVersion,
        })
        .select('COUNT(DISTINCT m.userId)', 'count')
        .getRawOne();
      if (findApproved && findApproved.count > 1) {
        await this.commonService.transferQuestion(data.qId!, data.tenantid!);
      }
    } else if (data.msgType == 'REJECT') {
      const findApproved: { count: number } | undefined = await this.repoMessage
        .createQueryBuilder('m')
        .where('m.msgType = :msgType', { msgType: 'REJECT' })
        .andWhere('m.qId = :qId', { qId: data.qId })
        .andWhere('m.quesVersion = :quesVersion', {
          quesVersion: data.quesVersion,
        })
        .select('COUNT(DISTINCT m.userId)', 'count')
        .getRawOne();
      if (findApproved && findApproved.count > 1) {
        await this.commonService.rejectQuestion(data.qId!);
      }
    } else if (data.msgType == 'REVISE') {
      const findApproved: { count: number } | undefined = await this.repoMessage
        .createQueryBuilder('m')
        .where('m.msgType = :msgType', { msgType: 'REVISE' })
        .andWhere('m.qId = :qId', { qId: data.qId })
        .andWhere('m.quesVersion = :quesVersion', {
          quesVersion: data.quesVersion,
        })
        .select('COUNT(DISTINCT m.userId)', 'count')
        .getRawOne();
      if (findApproved && findApproved.count > 1) {
        await this.commonService.reviseQuestion(data.qId!);
      }
    }
    const response:
      | {
          id: number;
          qId: number;
          message: string;
          createdAt: Date;
          userId: number;
          name: string;
        }
      | undefined = await this.repoMessage
      .createQueryBuilder('message')
      .leftJoin('login', 'login', 'login.id = message.userId')
      .select([
        'message.id AS id',
        'message.qId AS qId',
        'message.message AS message',
        'message.createdAt AS createdAt',
        'message.userId AS userId',
        'login.name AS name',
      ])
      .andWhere('message.id = :id', { id: id })
      .getRawOne();
    // console.log('Created message response:', response);
    return response;
  }

  async getMessages(tenantId: string, qId: string): Promise<any[]> {
    return this.repoMessage
      .createQueryBuilder('message')
      .leftJoin('login', 'login', 'login.id = message.userId')
      .select([
        'message.id AS id',
        'message.qId AS qId',
        'message.message AS message',
        'message.createdAt AS createdAt',
        'message.userId AS userId',
        'login.name AS name',
      ])
      .where('message.tenantid = :tenantId', { tenantId })
      .andWhere('message.qId = :qId', { qId: Number(qId) })
      .andWhere('message.dmlType = :dmlType', { dmlType: 'I' })
      .orderBy('message.id', 'ASC')
      .getRawMany();
  }
}
