import React from 'react'
import { useForm } from 'react-hook-form'
import { Container, Row, Col, Button, Card, Form } from 'react-bootstrap'

function School() {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm()

  const onSubmit = (data) => {
    console.log('Submitting the data', data)
  }

  const states = [
    'Andhra Pradesh',
    'Arunachal Pradesh',
    'Assam',
    'Bihar',
    'Chhattisgarh',
    'Delhi',
    'Goa',
    'Gujarat',
    'Haryana',
    'Himachal Pradesh',
    'Jharkhand',
    'Karnataka',
    'Kerala',
    'Madhya Pradesh',
    'Maharashtra',
    'Manipur',
    'Meghalaya',
    'Mizoram',
    'Nagaland',
    'Odisha',
    'Punjab',
    'Rajasthan',
    'Sikkim',
    'Tamil Nadu',
    'Telangana',
    'Tripura',
    'Uttar Pradesh',
    'Uttarakhand',
    'West Bengal',
  ]

  const bourd = ['CBSE', 'ICSE']

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8} lg={8}>
          <Card className="shadow-lg p-4">
            <Card.Body className="text-center">
              <h2 className="mb-4 text-primary">School Registration Form</h2>
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Row className="mb-3">
                  <Col md={6}>
                    <Form.Group controlId="ID" className="text-start">
                      <Form.Label>School ID</Form.Label>
                      <Form.Control
                        size="sm"
                        type="text"
                        placeholder="12345"
                        readOnly
                        value="12345"
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group controlId="schoolname" className="text-start">
                      <Form.Label>School Name</Form.Label>
                      <Form.Control
                        size="sm"
                        type="text"
                        placeholder="School Name"
                        {...register('schoolName', {
                          required: 'School Name is required',
                          pattern: {
                            value: /^[A-Za-z\s]+$/,
                            message: 'Only alphabetic characters are allowed',
                          },
                        })}
                      />
                      {errors.schoolName && (
                        <p className="text-danger">{errors.schoolName.message}</p>
                      )}
                    </Form.Group>
                  </Col>
                </Row>

                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Group controlId="contactNo" className="text-start">
                      <Form.Label>Contact Number</Form.Label>
                      <Form.Control
                        type="text"
                        size="sm"
                        maxLength="10"
                        placeholder="Contact No."
                        {...register('contactNo', {
                          required: 'Contact Number is required',
                          pattern: {
                            value: /^[0-9]{10}$/,
                            message: 'Contact Number must be 10 digits',
                          },
                        })}
                      />
                      {errors.contactNo && (
                        <p className="text-danger">{errors.contactNo.message}</p>
                      )}
                    </Form.Group>
                  </Col>

                  <Col md={6}>
                    <Form.Group controlId="address" className="text-start">
                      <Form.Label> Address</Form.Label>
                      <Form.Control
                        type="text"
                        size="sm"
                        placeholder="Address"
                        {...register('address', { required: 'Address is required' })}
                      />
                      {errors.address && <p className="text-danger">{errors.address.message}</p>}
                      <Form.Text className="text-muted">
                        We'll never share your address with anyone else.
                      </Form.Text>
                    </Form.Group>
                  </Col>
                </Row>

                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Group controlId="city" className="text-start">
                      <Form.Label>City</Form.Label>
                      <Form.Control
                        type="text"
                        size="sm"
                        placeholder="City"
                        {...register('city', { required: 'City is required' })}
                      />
                      {errors.city && <p className="text-danger">{errors.city.message}</p>}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="state" className="text-start">
                      <Form.Label>State</Form.Label>
                      <Form.Control
                        as="select"
                        size="sm"
                        {...register('state', { required: 'State is required' })}
                      >
                        <option value="">Select State</option>
                        {states.map((state, index) => (
                          <option key={index} value={state}>
                            {state}
                          </option>
                        ))}
                      </Form.Control>
                      {errors.state && <p className="text-danger">{errors.state.message}</p>}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="pincode" className="text-start">
                      <Form.Label>Pincode</Form.Label>
                      <Form.Control
                        type="text"
                        size="sm"
                        placeholder="Pincode"
                        maxLength="6"
                        {...register('pincode', {
                          required: 'Pincode is required',
                          pattern: {
                            value: /^[0-9]{6}$/,
                            message: 'Pincode must be 6 digits',
                          },
                        })}
                      />
                      {errors.pincode && <p className="text-danger">{errors.pincode.message}</p>}
                    </Form.Group>
                  </Col>
                </Row>

                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Group controlId="schoolLogo" className="text-start">
                      <Form.Label>School Logo</Form.Label>
                      <Form.Control
                        size="sm"
                        type="file"
                        accept="image/*"
                        {...register('profilePicture', {
                          required: 'Profile picture is required',
                          validate: {
                            fileSize: (value) =>
                              value[0]?.size <= 5000000 || 'File size should be less than 5MB',
                            fileType: (value) =>
                              ['image/jpeg', 'image/png', 'image/gif'].includes(value[0]?.type) ||
                              'Only JPEG, PNG, or GIF files are allowed',
                          },
                        })}
                      />
                      {errors.profilePicture && (
                        <p className="text-danger">{errors.profilePicture.message}</p>
                      )}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="website" className="text-start">
                      <Form.Label>Website</Form.Label>
                      <Form.Control
                        type="text"
                        size="sm"
                        placeholder="https://example.com"
                        {...register('website', {
                          required: 'Website is required',
                          pattern: {
                            value: /^([\w-]+\.){1,2}[a-zA-Z]{2,}(\S*)?$/,
                            message:
                              "Enter a valid URL with at least 2 characters after the last '.' and maximum 2 '.'",
                          },
                        })}
                      />
                      {errors.website && <p className="text-danger">{errors.website.message}</p>}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="noOfAdmins" className="text-start">
                      <Form.Label>Number of Admins</Form.Label>
                      <Form.Control
                        type="number"
                        size="sm"
                        placeholder="Number of Admins"
                        {...register('noOfAdmins', {
                          required: 'This field is required',
                          min: {
                            value: 1,
                            message: 'At least one admin is required',
                          },
                        })}
                      />
                      {errors.noOfAdmins && (
                        <p className="text-danger">{errors.noOfAdmins.message}</p>
                      )}
                    </Form.Group>
                  </Col>
                </Row>

                {/* Adding Number of Teachers & Students */}
                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Group controlId="noOfTeachers" className="text-start">
                      <Form.Label>Number of Teachers</Form.Label>
                      <Form.Control
                        type="number"
                        size="sm"
                        placeholder="Number of Teachers"
                        {...register('noOfTeachers', {
                          required: 'This field is required',
                          min: {
                            value: 1,
                            message: 'At least one teacher is required',
                          },
                        })}
                      />
                      {errors.noOfTeachers && (
                        <p className="text-danger">{errors.noOfTeachers.message}</p>
                      )}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="noOfStudents" className="text-start">
                      <Form.Label>Number of Students</Form.Label>
                      <Form.Control
                        type="number"
                        size="sm"
                        placeholder="Number of Students"
                        {...register('noOfStudents', {
                          required: 'This field is required',
                          min: {
                            value: 1,
                            message: 'At least one student is required',
                          },
                        })}
                      />
                      {errors.noOfStudents && (
                        <p className="text-danger">{errors.noOfStudents.message}</p>
                      )}
                    </Form.Group>
                  </Col>

                  <Col md={4}>
                    <Form.Group controlId="bourd" className="text-start">
                      <Form.Label>Education Bourd</Form.Label>
                      <Form.Control
                        as="select"
                        size="sm"
                        {...register('bourd', { required: 'bourd is required' })}
                      >
                        <option value="">Select bourd</option>
                        {bourd.map((bourd, index) => (
                          <option key={index} value={bourd}>
                            {bourd}
                          </option>
                        ))}
                      </Form.Control>
                      {errors.bourd && <p className="text-danger">{errors.bourd.message}</p>}
                    </Form.Group>
                  </Col>
                </Row>

                <Button
                  variant="primary"
                  size="lg"
                  className="mt-3"
                  disabled={isSubmitting}
                  value={isSubmitting ? 'Submitting' : 'Submit'}
                  type="submit"
                >
                  Get Started
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default School
