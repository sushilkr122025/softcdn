import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'userPermissions' })
export class UserPermission {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;

  @Column()
  subject: number;

  @Column({ length: 20 })
  class: string;

  @Column({ length: 20 })
  permission: string;

  @Column({ length: 15 })
  action: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;
}
