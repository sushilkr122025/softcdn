import apiClient from './apiService'
class QuestionServices {
  createContext = async (data) => {
    try {
      const response = await apiClient.post("/school/createcontext", data);
      return {
        status: response.status,
        data: response.data,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  createQuestion = async (data) => {
    try {
      const response = await apiClient.post("/school/question", data);
      return {
        status: response.status,
        data: response.data,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  createMarkScheme = async (data) => {
    try {
      const response = await apiClient.post("/school/markscheme", data);
      return {
        status: response.status,
        data: response.data,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  getContextByShortUuid = async (data) => {
    try {
      const response = await apiClient.get(`school/getcontext/`, data);
      return {
        status: response.status,
        data: response.data,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  getPanelItems = async () => {
    try {
      const response = await apiClient.get(`/school/panelItems`);
      return response.data;
    } catch (error) {
      console.log(error);
    }
  };

  getPanelHistoryById = async (data) => {
    try {
      const response = await apiClient.get(`/school/panelhistory/${data}`);
      return response.data;
    } catch (error) {
      console.log(error);
    }
  };

  getQuestionById = async (id) => {
    try {
      const response = await apiClient.get(`/school/getquestions/`, id);
      return response.data;
    } catch (error) {
      console.log(error);
    }
  };
  getUserQuestions = async () => {
    try {
      const response = await apiClient.get('/school/userquestions')     
      return response.data
    } catch (error) {
      console.log(error);
    }
  };

  saveQuestionPaper = async (data) => {
    try {
      const response = await apiClient.post("/school/quesPaper", data);
      return response.data;
    } catch (error) {
      console.log(error);
    }
  };

  GetQuestionPaper = async (data) => {
    try {
      const response = await apiClient.post("/school/getpaper/", data);

      return response.data;
    } catch (error) {
      console.log(error);
      // setError(error.response.data.errtext);
    }
  };

  GetStudentByClass = async (fdata) => {
    try {
      const response = await apiClient.get("/report/studentByClass", {
        params: fdata,
      });
      return response.data;
    } catch (error) {
      console.log(error);
      // setError(error.response.data.errtext);
    }
  };
  GetQuestionData = async (fdata) => {
    try {
      const response = await apiClient.get("/report/questionData", fdata);
      return response.data;
    } catch (error) {
      console.log(error);
      // setError(error.response.data.errtext);
    }
  };

  studentAnswered = async (data) => {
    try {
      const response = await apiClient.get("/report/studentAnswered/", {
        params: data,
      });
      return {
        status: response.status,
        statusCode: response.data?.statusCode,
        message: response.data?.message,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  CheckStudentAnswered = async (data) => {
    try {
      const response = await apiClient.post(
        "/report/studentAnsweredCheck/",
        data,
      );
      return {
        status: response.status,
        data: response.data,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };
  SaveStudentAnswer = async (data) => {
    try {
      const response = await apiClient.post("/report/saveAnswer/", data);
      return {
        status: response.status,
        statusCode: response.data?.statusCode,
        message: response.data?.message,
      };
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message:
          error.response?.data?.message.message || "Something went wrong",
      };
    }
  };

  CreateResult = async (fdata) => {
    try {
      const response = await apiClient.get("/report/createresult", {
        params: fdata,
      });
      // console.log("response.data");
      return response.data;
    } catch (error) {
      console.log("response.data");
      console.log(error);
    }
  };

  getPaperById = async (fdata) => {
    try {
      const response = await apiClient.post("/school/getPaperById", fdata);
      return response.data;
    } catch (error) {
      console.log(error);
    }
  }

  actionPerform = async (fdata) => {
    try {
      const response = await apiClient.post('/school/actionPerform', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  uploadImg = async (fdata) => {
    try {
      const response = await apiClient.post('/school/uploadImage', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  questionFromBank = async (fdata) => {
    try {
      const response = await apiClient.post('/school/makePaper', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
}
export default new QuestionServices()