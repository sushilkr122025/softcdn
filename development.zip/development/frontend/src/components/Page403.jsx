// src/pages/Forbidden.jsx
const Forbidden = () => {
  const styles = {
    container: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      height: "90vh",
      textAlign: "center",
      backgroundColor: "#f8f9fa",
      color: "#333",
    },
    code: {
      fontSize: "8rem",
      fontWeight: "bold",
      color: "#ff4d4f",
      margin: 0,
    },
    message: {
      fontSize: "1.5rem",
      marginBottom: "1rem",
    },
    link: {
      display: "inline-block",
      marginTop: "1rem",
      padding: "0.6rem 1.2rem",
      backgroundColor: "#007bff",
      color: "white",
      textDecoration: "none",
      borderRadius: "6px",
      transition: "background-color 0.3s",
    },
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.code}>403</h1>
      <p style={styles.message}>You don't have permission to access this page.</p>
    </div>
  );
};

export default Forbidden;
