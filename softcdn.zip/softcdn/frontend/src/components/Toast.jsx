import { useEffect, useState } from 'react';
import { Toast, ToastContainer } from 'react-bootstrap';

function SimpleToast({ show, message, variant = 'primary', autohide = true, delay = 3000, position = 'top-center', onClose }) {
  const [visible, setVisible] = useState(show);

  useEffect(() => {
    setVisible(show);
  }, [show]);

  return (
    <ToastContainer position={position} className="p-3">
      <Toast
        onClose={() => {
          setVisible(false);
          onClose?.();
        }}
        show={visible}
        delay={delay}
        autohide={autohide}
        bg={variant}
      >
        <Toast.Body className="text-white">{message}</Toast.Body>
      </Toast>
    </ToastContainer>
  );
}

export default SimpleToast;
