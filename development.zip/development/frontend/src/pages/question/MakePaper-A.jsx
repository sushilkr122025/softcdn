import React, { useState, useRef, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import ShowMessage from "../../components/ShowMessage";
import apiClient from "../../api/apiService";
import usePermission from "../../hooks/usePermission";
import CustomDropdown from "../../components/layout/CustomDropdown";

const UserQuestions = () => {
  const MAX_SECTIONS = 10;
  const navigate = useNavigate();
  const location = useLocation();
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [sectionCount, setSectionCount] = useState(0);
  const [wasValidated, setWasValidated] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState([]);
  const [permissionData, setPermissionData] = useState();
  const { canRead, readScope } = usePermission("BANK");
  const [SubjectData, setSubjectData] = useState([]);
  const [sectionMarks, setSectionMarks] = useState();
  const [classData, setClassData] = useState([]);
  const [allowedSubjects, setAllowedSubjects] = useState([]);
  const [allowedClasses, setAllowedClasses] = useState([]);
  const [filter, setFilter] = useState({});
  const [openKey, setOpenKey] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    subjectId: "",
    subjectName: "",
    classId: "",
    class: "",
    session: "",
    year: "",
    totalTime: "01:00",
    section: sectionCount,
    maxMarks: '',
    generalInstruction: "1. Answer to this paper must be written on the answer script provided separately.\n2. All subsections of each question must be answered in the correct order.\n3. You are not allowed to write during the first 15 minutes. This time is to be spent in reading the question paper.\n4. The time given at the head of this paper is the time allowed for writing the answers.\n5. Please do not write anything on your question paper except your name and roll number.\n6. The intended marks for questions or parts of questions are given in brackets [ ].\n7. This paper consists of three parts, Section A and Section B and Section C.\n8. Answer all questions in all the sections.\n9. Internal choices have been provided in two questions of Section B and two questions of Section C.",
    sectionsData: [],
  });
  const [showAlert, setShowAlert] = useState(false);
  const formRef = useRef(null);
  const repeatTimersRef = useRef(new Map());
  const formDataRef = useRef(formData);

  useEffect(() => {
    formDataRef.current = formData;
  }, [formData]);

  const defaultSection = (index) => ({
    id: index + 1,
    questionType: "",
    marksPerSection: 0,
    instruction: "All Question are compulsory",
  });

  useEffect(() => {
    if (canRead) {
      setPermissionData(readScope);
    }
  }, [canRead, readScope]);

  useEffect(() => {
    apiClient
      .get("/store/subject")
      .then((response) => {
        setSubjectData(Array.isArray(response.data) ? response.data : []);
      })
      .catch((error) => {
        console.error("Error fetching Subject data:", error);
        setSubjectData([]);
      });

    apiClient
      .get("/store/classes")
      .then((response) => {
        setClassData(Array.isArray(response.data) ? response.data : []);
      })
      .catch((error) => {
        console.error("Error fetching class data:", error);
        setClassData([]);
      });
  }, []);

  useEffect(() => {
    if (!permissionData || !Array.isArray(permissionData) || permissionData.length === 0) {
      setAllowedSubjects(SubjectData || []);
      return;
    }
    const allowedSubIds = new Set(permissionData.map((p) => String(p.subjectId)));
    const filtered = (SubjectData || []).filter((s) => allowedSubIds.has(String(s.id)));
    setAllowedSubjects(filtered);
  }, [permissionData, SubjectData]);

  useEffect(() => {
    const sid = formData.subjectId;
    if (!sid) {
      setAllowedClasses([]);
      setFormData((prev) => ({ ...prev, classId: "", class: "" }));
      return;
    }

    if (!permissionData || !Array.isArray(permissionData) || permissionData.length === 0) {
      const fallback = (classData || []).filter(
        (c) =>
          String(c.subjectId) === String(sid) ||
          String(c.id) === String(sid) ||
          String(c.class) === String(sid)
      );
      setAllowedClasses(fallback);
      return;
    }
    const perm = permissionData.find((p) => String(p.subjectId) === String(sid));
    if (!perm) {
      setAllowedClasses([]);
      return;
    }
    const allowedClassIds = new Set((perm.classIds || []).map((x) => String(x)));
    const filtered = (classData || []).filter((c) => allowedClassIds.has(String(c.class)));
    setAllowedClasses(filtered);
  }, [formData.subjectId, permissionData, classData]);

  useEffect(() => {
    const loc = location.state;
    if (!loc) return;
    if (loc.previousFilter) {
      const pf = loc.previousFilter;
      setFormData((prev) => {
        const next = { ...prev };
        if (pf.subject) next.subjectId = pf.subject;
        if (pf.std) next.classId = pf.std;
        return next;
      });
      setFilter(loc.previousFilter);
    }
  }, [location.state]);

  useEffect(() => {
    if (!formData.subjectId && !formData.classId) return;
    setFormData((prev) => {
      const next = { ...prev };
      if (prev.subjectId) {
        const subj = (SubjectData || []).find((s) => String(s.id) === String(prev.subjectId));
        if (subj && (!prev.subjectName || prev.subjectName === "")) {
          next.subjectName = subj.subject || subj.name || "";
        }
      }
      if (prev.classId) {
        const cls = (classData || []).find(
          (c) => String(c.class) === String(prev.classId) || String(c.id) === String(prev.classId)
        );
        if (cls && (!prev.class || prev.class === "")) {
          next.class = cls.class || String(cls.id);
        }
      }
      return next;
    });
  }, [SubjectData, classData]);

  useEffect(() => {
    if (location.state?.generaldetail) {
      const data = location.state.generaldetail;
      setIsInitialLoad(true);
      setSectionCount(Number(data.sectionsData?.length || 0));
      setFormData((prev) => ({ ...prev, ...data }));
      setTimeout(() => setIsInitialLoad(false), 0);
    } else {
      setIsInitialLoad(false);
    }

    if (location.state?.previouslySelected) {
      const prev = location.state.previouslySelected;
      const activeIndex = typeof location.state.activeSectionIndex === "number" ? Number(location.state.activeSectionIndex) : null;

      if (Array.isArray(prev)) {
        const mapped = prev.map(q => (q && q.section) ? q : (activeIndex != null ? { ...q, section: String(Number(activeIndex) + 1) } : q));
        setSelectedQuestion((cur) => {
          const byId = new Map(cur.map(i => [i.id, i]));
          for (const it of mapped) {
            byId.set(it.id, it);
          }
          return Array.from(byId.values());
        });
      }
    }

    if (location.state?.selectedQuestion) {
      const prev = location.state.selectedQuestion;
      if (Array.isArray(prev)) {
        setSelectedQuestion((cur) => {
          const byId = new Map(cur.map(i => [i.id, i]));
          for (const it of prev) byId.set(it.id, it);
          return Array.from(byId.values());
        });
      }
    }

    if (location.state?.previousFilter) {
      setFilter(location.state.previousFilter);
    }
  }, [location.state]);

  useEffect(() => {
    if (isInitialLoad) return;
    setFormData((prev) => {
      const desired = Number(sectionCount) || 0;
      const prevSections = Array.isArray(prev.sectionsData) ? prev.sectionsData : [];
      let nextSections = prevSections.slice(0, desired);
      if (nextSections.length <= desired) {
        const start = nextSections.length;
        for (let i = start; i < desired; i++) {
          nextSections.push(defaultSection(i));
        }
      }
      return {
        ...prev,
        section: String(desired),
        sectionsData: nextSections,
      };
    });
  }, [sectionCount, isInitialLoad]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "maxMarks") {
      setFormData((prev) => ({ ...prev, [name]: Number(value) }));
      return;
    }
    if (name === "section") {
      const count = Math.max(0, Math.min(MAX_SECTIONS, Number(value || 0)));
      setSectionCount(count);
      return;
    }

    if (name === "subjectId") {
      const subj = (SubjectData || []).find((s) => String(s.id) === String(value));
      const label = subj ? subj.subject || subj.name || "" : "";
      setFormData((prev) => ({ ...prev, subjectId: value, subjectName: label, classId: "", class: "" }));
      return;
    }

    if (name === "classId") {
      const cls = (classData || []).find((c) => String(c.class) === String(value) || String(c.id) === String(value));
      const label = cls ? `Class ${cls.class}` : value;
      setFormData((prev) => ({ ...prev, classId: value, class: label }));
      return;
    }

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSectionFieldChange = (index, field, value) => {
    setFormData((prev) => {
      const next = prev.sectionsData.map((s, i) => (i === index ? { ...s, [field]: value } : s));
      return { ...prev, sectionsData: next };
    });
  };

  const incSectionCount = () => setSectionCount((c) => Math.min(MAX_SECTIONS, c + 1));
  const decSectionCount = () => setSectionCount((c) => Math.max(0, c - 1));

  const handleStartSection = (index) => {
    const form = formRef.current;
    if (!form) return;
    if (!form.checkValidity()) {
      setWasValidated(true);
      return;
    }
    setWasValidated(true);
    const payload = { ...formData };
    if (sectionCount > 0 && sectionMarks !== formData.maxMarks) {
      setShowAlert(true)
      return;
    }
    const previouslySelected = (selectedQuestion || []).filter(q => String(q.section) === String(index + 1));

    const sectionQuestionType = (formData.sectionsData[index].questionType) || filter.questionType || "";

    const previousFilterForQuestion = {
      subject: formData.subjectId || filter.subject || "",
      std: formData.classId || filter.std || "",
      quesType: sectionQuestionType,
    };

    navigate("/question", {
      state: { generaldetail: payload, previousFilter: previousFilterForQuestion, previouslySelected, allPreviouslySelected: selectedQuestion, activeSectionIndex: index }
    });
  };

  useEffect(() => {
    const total = formData.sectionsData.reduce((sum, sec) => sum + Number(sec.marksPerSection), 0)
    setSectionMarks(Number(total))
  }, [formData.sectionsData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const form = formRef.current;
    if (!form) return;
    if (!form.checkValidity()) {
      setWasValidated(true);
      return;
    }
    setWasValidated(true);

    const payload = { ...formData };

    const previousFilterForQuestion = {
      subject: formData.subjectId || filter.subject || "",
      std: formData.classId || filter.std || "",
    };
    if (Number(sectionCount) === 0) {
      navigate("/question", {
        state: {
          generaldetail: payload,
          previousFilter: previousFilterForQuestion,
          selectedQuestion,
        },
      });
      return;
    }
  };

  const durationOptions = (() => {
    const options = [];
    const maxMinutes = 4 * 60;
    for (let min = 5; min <= maxMinutes; min += 5) {
      const hours = Math.floor(min / 60);
      const minutes = min % 60;
      const hh = String(hours).padStart(2, "0");
      const mm = String(minutes).padStart(2, "0");
      options.push(`${hh}:${mm}`);
    }
    return options;
  })();

  const countSelectedForSection = (index) => {
    return (selectedQuestion || []).filter(q => String(q.section) === String(index + 1)).length;
  };

  const isSectionCompleted = (index) => {
    return countSelectedForSection(index) > 0;
  };

  const hasSectionsConfigured = Array.isArray(formData.sectionsData) && formData.sectionsData.length > 0;

  const handleUpdateAndPreview = () => {
    if (sectionCount > 0 && sectionMarks !== formData.maxMarks) {
      setShowAlert(true)
      return;
    }
    const deduped = Array.from(new Map((selectedQuestion || []).map(q => [q.id, q])).values());
    // const payload = { ...formData };
    navigate("/questionPreview", { state: { selectedQuestion: deduped, filter, paperinfo: formData } });
  };
  const updateNumberField = (index, field, currentValue, action, min = 0, max = 50) => {
    let newValue = Number(currentValue) || 0;
    if (action === "inc") newValue = Math.min(max, newValue + 1);
    if (action === "dec") newValue = Math.max(min, newValue - 1);
    handleSectionFieldChange(index, field, newValue);
  };
  const startAutoChange = (index, field, action) => {
    const timerKey = `${index}-${field}`;
    if (repeatTimersRef.current.has(timerKey)) return;
    const current = formDataRef.current.sectionsData?.[index]?.[field] ?? 0;
    updateNumberField(index, field, current, action);
    const id = setInterval(() => {
      const cur = formDataRef.current.sectionsData?.[index]?.[field] ?? 0;
      updateNumberField(index, field, cur, action);
    }, 120);
    repeatTimersRef.current.set(timerKey, id);
  };
  const stopAutoChange = (index, field) => {
    const timerKey = `${index}-${field}`;
    const id = repeatTimersRef.current.get(timerKey);
    if (id) {
      clearInterval(id);
      repeatTimersRef.current.delete(timerKey);
    }
  };
  const handleBtnKeyDown = (e, index, field, action) => {
    if (e.key === " " || e.key === "Enter") {
      e.preventDefault();
      startAutoChange(index, field, action);
    }
  };
  const handleBtnKeyUp = (e, index, field) => {
    if (e.key === " " || e.key === "Enter") {
      e.preventDefault();
      stopAutoChange(index, field);
    }
  };
  useEffect(() => {
    const textareas = document.querySelectorAll("textarea");
    textareas.forEach((ta) => {
      ta.style.height = "auto";
      ta.style.height = `${ta.scrollHeight}px`;
    });
  }, [formData.generalInstruction, formData.sectionsData]);

  const autoResize = (el) => {
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  };

  return (
    <div className="p-lg-4">
      <div className="container-fluid">
        <div className="row h-85vh">
          <div className="col-12 mx-auto content-bg p-lg-4 py-4">
            <h4 className="mb-4 fw-bold pagetitle">Create General Details</h4>
            <ShowMessage type="toast" show={showAlert} variant="danger" message={`Maximum Marks and section is not Matched`} onClose={() => setShowAlert(false)} />
            <form onSubmit={handleSubmit} ref={formRef} noValidate className={`needs-validation ${wasValidated ? "was-validated" : ""}`}>
              <div className="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-3">
                <div className="col">
                  <label className="form-label" htmlFor="name">Paper Name</label>
                  <input id="name" autoComplete="off" type="text" className="form-control form-control-sm" name="name" value={formData.name} onChange={handleChange} required />
                  <div className="invalid-feedback">Paper name is required.</div>
                </div>

                <div className="col">
                  <label className="form-label" htmlFor="subjectName">Subject Name</label>
                  {allowedSubjects && allowedSubjects.length > 0 ? (
                    <CustomDropdown dropdownKey="subjectId" placeholder="Select Subject" value={formData.subjectId || ""} openKey={openKey} setOpenKey={setOpenKey} required
                      options={[
                        ...allowedSubjects.map((s) => ({
                          value: s.id,
                          label: s.subject || s.name,
                        })),
                      ]}
                      onChange={(val) =>
                        handleChange({
                          target: { name: "subjectId", value: val },
                        })
                      }
                    />
                  ) : (
                    <div className="form-control form-control-sm">No subjects available for your permissions</div>
                  )}
                  <div className="invalid-feedback">Subject Name is required.</div>
                </div>

                <div className="col">
                  <label className="form-label" htmlFor="class">Class</label>
                  {allowedClasses && allowedClasses.length > 0 ? (
                    <CustomDropdown dropdownKey="classId" placeholder="Select Class" value={formData.classId || ""} openKey={openKey} setOpenKey={setOpenKey} required
                      options={[
                        ...allowedClasses.map((c) => ({
                          value: c.class,
                          label: c.class,
                        })),
                      ]}
                      onChange={(val) =>
                        handleChange({
                          target: { name: "classId", value: val },
                        })
                      }
                    />
                  ) : (
                    <select className="form-select form-select-sm" disabled>
                      <option>{formData.subjectId ? "No classes available for selected subject" : "Select subject to see classes"}</option>
                    </select>
                  )}
                  <div className="invalid-feedback">Class is required.</div>
                </div>

                <div className="col">
                  <label className="form-label" htmlFor="session">Session</label>
                  <CustomDropdown dropdownKey="session" placeholder="Select Session" value={formData.session || ""} openKey={openKey} setOpenKey={setOpenKey} required
                    options={[
                      { value: "Term 1", label: "Term 1" },
                      { value: "Term 2", label: "Term 2" },
                      { value: "1st Semester", label: "1st Semester" },
                      { value: "Term 3", label: "Term 3" },
                      { value: "Term 4", label: "Term 4" },
                      { value: "Final Semester", label: "Final Semester" },
                    ]}
                    onChange={(val) =>
                      handleChange({ target: { name: "session", value: val } })
                    }
                  />
                  <div className="invalid-feedback">Session is required.</div>
                </div>

                <div className="col">
                  <label className="form-label" htmlFor="year">Academic Year</label>
                  <CustomDropdown dropdownKey="year" placeholder="Select Academic Year" value={formData.year || ""} openKey={openKey} setOpenKey={setOpenKey} required
                    options={[
                      ...Array.from({ length: 6 }, (_, index) => {
                        const currentYear = new Date().getFullYear();
                        const startYear = currentYear + index;
                        const endYear = (startYear + 1).toString().slice(-2);
                        const academicYear = `${startYear}-${endYear}`;
                        return {
                          value: academicYear,
                          label: academicYear,
                        };
                      }),
                    ]}
                    onChange={(val) =>
                      handleChange({ target: { name: "year", value: val, }, })
                    }

                  />
                  <div className="invalid-feedback">Academic Year is required.</div>
                </div>

                <div className="col">
                  <label htmlFor="totalTime" className="form-label">Duration</label>
                  <CustomDropdown dropdownKey="totalTime" placeholder="Hrs:Min" value={formData.totalTime || ""} openKey={openKey} setOpenKey={setOpenKey} required
                    options={[
                      ...durationOptions.map((time) => ({
                        value: time,
                        label: time,
                      })),
                    ]}
                    onChange={(val) =>
                      handleChange({ target: { name: "totalTime", value: val } })
                    }
                  />
                </div>

                <div className="col">
                  <label className="form-label" htmlFor="maxMarks">Total Marks</label>
                  <input id="maxMarks" type="number" autoComplete="off" className="form-control form-control-sm" name="maxMarks" min="1" value={formData.maxMarks} onChange={handleChange} required />
                  <div className="invalid-feedback">Enter valid marks (&gt;0).</div>
                </div>

                <div className="col w-100">
                  <label className="form-label" htmlFor="generalInstruction">General Instruction</label>
                  <textarea className="form-control form-control-sm" name="generalInstruction" id="generalInstruction" value={formData.generalInstruction}
                    onChange={(e) => {
                      handleChange(e);
                      autoResize(e.target);
                    }}
                    style={{ resize: "none", overflow: "hidden" }}
                    required />
                  <div className="invalid-feedback">General Instruction is required.</div>
                </div>

                <div className="col">
                  <div className="d-flex flex-column">
                    <label className="form-label" htmlFor="section">No of Section</label>
                    <div className="d-flex">
                      <button type="button" className="btn btn-sm btn-secondary rounded-end-0" onClick={decSectionCount}>-</button>
                      <input
                        className="form-control text-center rounded-0"
                        id="section"
                        type="text"
                        value={sectionCount}
                        name="section"
                        onChange={(e) => {
                          const value = e.target.value;
                          if (/^\d*$/.test(value) && value <= 10) {
                            setSectionCount(value);
                          }
                        }}
                      />
                      <button type="button" className="btn btn-sm btn-secondary rounded-start-0" onClick={incSectionCount}>+</button>
                    </div>
                  </div>
                </div>
              </div>

              {formData.sectionsData && formData.sectionsData.length > 0 && (
                <div className="row mt-4">
                  <h5>Section-wise Configuration</h5>
                  {formData.sectionsData.map((sec, index) => (
                    <section className="card col-md-5 p-3 m-3" key={index}>
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <h6 className="mb-0">Section {index + 1}</h6>
                        <div>
                          <span className="badge bg-success me-2">{countSelectedForSection(index)}</span>
                          <button type="button" className={`btn btn-sm ${isSectionCompleted(index) ? "btn-success" : "btn-secondary"}`} onClick={() => handleStartSection(index)} disabled={isSectionCompleted(index)} title={isSectionCompleted(index) ? "Section completed — Start disabled" : `Start Section ${index + 1}`}>
                            {isSectionCompleted(index) ? "Completed" : "Start"}
                          </button>
                        </div>
                      </div>
                      <div className="row g-2 align-items-center">
                        <label htmlFor={`quesType-${index}`} className="col-6 form-label mb-0">Question Type</label>
                        <div className="col-6 mb-2">
                          <CustomDropdown dropdownKey={`quesType-${index}`} placeholder="Question Type" value={sec.questionType || ""} openKey={openKey} setOpenKey={setOpenKey}
                            options={[
                              { value: "multipleChoice", label: "Multiple Choice" },
                              { value: "trueFalse", label: "True/False" },
                              { value: "oneWord", label: "One Word" },
                              { value: "CR", label: "Written Response" },
                              { value: "fillups", label: "Fill in the Blanks" },
                              { value: "match", label: "Match the Following" },
                            ]}
                            onChange={(val) =>
                              handleSectionFieldChange(index, "questionType", val)
                            }
                          />
                        </div>
                        <label htmlFor={`marksSection-${index}`} className="col-6 form-label mb-0">Marks Per Section</label>
                        <div className="col-6 mb-2">
                          <div className="d-flex">
                            <button
                              type="button"
                              className="btn btn-sm btn-secondary rounded-end-0"
                              onMouseDown={() => startAutoChange(index, "marksPerSection", "dec")}
                              onMouseUp={() => stopAutoChange(index, "marksPerSection")}
                              onMouseLeave={() => stopAutoChange(index, "marksPerSection")}
                              onTouchStart={() => startAutoChange(index, "marksPerSection", "dec")}
                              onTouchEnd={() => stopAutoChange(index, "marksPerSection")}
                              onKeyDown={(e) => handleBtnKeyDown(e, index, "marksPerSection", "dec")}
                              onKeyUp={(e) => handleBtnKeyUp(e, index, "marksPerSection")}
                            >
                              -
                            </button>

                            <input
                              className="form-control form-control-sm text-center rounded-0"
                              id={`marksSection-${index}`}
                              inputMode="numeric"
                              autoComplete="off"
                              value={sec.marksPerSection === "" ? "" : Number(sec.marksPerSection)}
                              onChange={(e) => {
                                const value = e.target.value;
                                if (/^\d*$/.test(value) && Number(value) <= 50) handleSectionFieldChange(index, "marksPerSection", value === "" ? "" : Number(value));
                              }}
                              min={0}
                              max={50}
                            />

                            <button
                              type="button"
                              className="btn btn-sm btn-secondary rounded-start-0"
                              onMouseDown={() => startAutoChange(index, "marksPerSection", "inc")}
                              onMouseUp={() => stopAutoChange(index, "marksPerSection")}
                              onMouseLeave={() => stopAutoChange(index, "marksPerSection")}
                              onTouchStart={() => startAutoChange(index, "marksPerSection", "inc")}
                              onTouchEnd={() => stopAutoChange(index, "marksPerSection")}
                              onKeyDown={(e) => handleBtnKeyDown(e, index, "marksPerSection", "inc")}
                              onKeyUp={(e) => handleBtnKeyUp(e, index, "marksPerSection")}
                            >
                              +
                            </button>
                          </div>
                        </div>

                        <div className="col-12 mt-2">
                          <label className="form-label" htmlFor={`instruction-${index}`}>Section {index + 1} Instruction</label>
                          <textarea className="form-control form-control-sm" id={`instruction-${index}`} value={sec.instruction} onChange={(e) => handleSectionFieldChange(index, "instruction", e.target.value)} />
                        </div>
                      </div>
                    </section>
                  ))}
                </div>
              )}

              <div className="mt-3 d-flex gap-2">
                {!hasSectionsConfigured && selectedQuestion.length === 0 && (
                  <button className="btn btn-primary h45">Next</button>
                )}
                {location.state?.generaldetail && (
                  <button type="button" className="btn btn-primary h45" onClick={handleUpdateAndPreview}>Update detail</button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserQuestions;
