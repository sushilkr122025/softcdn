
import apiClient from './apiService'

class UserServices {
  getRoles = async () => {
    try {
      const response = await apiClient.get(`store/roles`)     
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
}

export default new UserServices()