import { useMemo } from "react";
import useAuth from "../context/AuthContext";

export default function usePermission(module) {
  const { user } = useAuth();

  return useMemo(() => {
    const permissionData = user?.permission || [];
    const modulePermission = permissionData.find((p) => p.module === module);

    if (!modulePermission) {
      return {
        canRead: false,
        canWrite: false,
        canApprove: false,
        canReview: false,
        canSupervise: false,
        readScope: [],
        writeScope: [],
        approveScope: [],
        reviewScope: [],
        superviseScope: [],
      };
    }

    const readScope = modulePermission.permissions?.READ ?? [];
    const writeScope = modulePermission.permissions?.WRITE ?? [];
    const approveScope = modulePermission.permissions?.APPROVE ?? [];
    const reviewScope = modulePermission.permissions?.REVIEW ?? [];
    const superviseScope = modulePermission.permissions?.SUPERVISE ?? [];

    return {
      canRead: readScope.length > 0,
      canWrite: writeScope.length > 0,
      canApprove: approveScope.length > 0,
      canReview: reviewScope.length > 0,
      canSupervise: superviseScope.length > 0,

      readScope,
      writeScope,
      approveScope,
      reviewScope,
      superviseScope,
    };
  }, [module, user?.permission]);
}
