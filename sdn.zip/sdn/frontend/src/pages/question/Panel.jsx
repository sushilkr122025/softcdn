import { useEffect, useRef, useState } from "react";
import useAuth from '../../context/AuthContext';
import { BsFillChatSquareTextFill } from "react-icons/bs";
import { IoSend, IoReturnDownBack } from "react-icons/io5";
import { SlOptionsVertical } from "react-icons/sl";
import './Panel.css';
import QuestionServices from "../../api/QuestionServices";

const Panel = ({ receiverId, receiverName }) => {
  const menuRef = useRef(null);
  const { socket, user } = useAuth()  
  const [messages, setMessages] = useState([]);
  const [unseenCount, setUnseenCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const currentUser = user.id; 
  const qId = "global";   
  const [input, setInput] = useState("");


  const [item, setItem] = useState([]);
  const messagesEndRef = useRef(null);
  const options = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }]
  const cleanHtml = (html) => {
    if (!html) return "";
    html = html.replace(/\s*style="[^"]*"/gi, "");
    html = html.replace(/<\/?p[^>]*>/gi, "");
    return html;
  };

  // Load messages history when receiverId changes
  useEffect(() => {
    if (!socket || !qId) return;

    socket.emit("load_messages", { otherUserId: qId });

    socket.on("messages_history", (history) => {
      setMessages(history);
    });

    return () => {
      socket.off("messages_history");
    };
  }, [socket, qId]);

  // Listen for real-time new messages
  useEffect(() => {
    if (!socket) return;

    socket.on("receive_message", (msg) => {
      // only add if relevant to current conversation
      if (
        (msg.senderId === qId && msg.qId === user.id) ||
        (msg.senderId === user.id && msg.qId === qId)
      ) {
        setMessages((prev) => [...prev, msg]);
      }
    });

    return () => {
      socket.off("receive_message");
    };
  }, [socket, qId, user]);

  // Send message
  const sendMessage = () => {
    console.log("sendMessage called with input:", input);    
    if (!input.trim()) return;
    socket.emit("send_message", { qId, message: input });
    setInput("");
  };

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    const fetchQuestion = async () => {      
      const response = await QuestionServices.getQuestionById({params:{id:250}});
      if(response){               
        setItem(response)
      }
    }
    fetchQuestion();
  }, []);

  return (
    <div className="container-fluid ">
      <div className="row">
        
      <div className="col-10  mb-3">              
                      <h4 className="questionprevhead mb-3">Ques. ID: {item?.customId}</h4>
                      Approve id = {item?.approverId}
                      <div className="d-flex">
                        <span className='ps-2 me-3'>Q-</span>
                        <div
                          style={{maxWidth: "580px"}}
                          className="qustionPreviewcontainer d-flex flex-wrap flex-grow-1 justify-content-between align-items-start"
                          dangerouslySetInnerHTML={{
                            __html: `${cleanHtml(item?.question) || "No content available"}`,
                          }}
                        />
                      </div>
                      <ol className="list-group mt-3" type="A">
                        {options.map((key, i) => {
                          const option = item?.[key.optns];
                          const optionimg = item?.[key.images];
                          if (!option && !optionimg) return null;
                          const isCorrect = key.optns === item.correctAns;
                          return (
                            <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                              <div className='d-flex justify-content-between align-items-center'>
                                {option && (
                                  <div
                                    dangerouslySetInnerHTML={{ __html: option }}
                                  />
                                )}
                                {optionimg && <div><img src={optionimg} className='img-fluid' style={{ maxWidth: "100px" }} alt="" /></div>}
                                {isCorrect && <div className="text-success fw-bold">✔</div>}
                              </div>
                            </li>
                          );
                        })}
                      </ol>
                    
      </div>
      <div className="col-2 text-center mb-3">
    <div className="card w-100" style={{ maxWidth: "300px", height: "80vh" }}>
      <div className="d-flex justify-content-between align-items-center p-3 bg-primary text-white fw-bold">
                <div className="position-relative d-inline-flex align-items-center">
                  <BsFillChatSquareTextFill size={20} />
                  {unseenCount > 0 && (
                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                      {unseenCount}
                    </span>
                  )}
                </div>
      
                <div className="position-relative" ref={menuRef}>
                  <span role="button" className="p-1" onClick={() => setOpen(!open)}>
                    <SlOptionsVertical size={20} />
                  </span>
      
                  {open && (
                    <div className="position-absolute end-0 mt-2 bg-white text-dark shadow rounded z-1">
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">
                        copy
                      </div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">edit</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">pin</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">info</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">search</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">delete</div>
                    </div>
                  )}
                </div>
              </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "0 0.5rem 0 0.5rem" }}>
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`p-2 rounded max-w-xs ${
              msg.senderId === user.id
                ? "ml-auto bg-blue-500 text-white"
                : "mr-auto bg-gray-200"
            }`}
          >
            {msg.content}
            <div className="text-xs text-gray-600 mt-1">
              {new Date(msg.createdAt).toLocaleTimeString()}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-2 d-flex" style={{ flex: "0 0 auto" }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="form-control me-2"
          placeholder="Type a message..."
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
        />
         <button className="btn border btn-primary pt-1"
          onClick={sendMessage}
        >
          <IoSend size={20} />
          </button>
      </div>
    </div>
    </div>
    </div>
    </div>
  );
};

export default Panel;
