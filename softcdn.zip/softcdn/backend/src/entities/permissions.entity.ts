import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'permissions' })
export class Permissions {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 20 })
  scope: string;

  @Column({ length: 10 })
  type: string;
}
