import React from "react";
import KpiCard from "./KpiCard";
import Table from "./TableRender";
import ChartRenderer from "./ChartRenderer";

const DashboardRenderer = ({ config, data }) => {
  return (
    <div className="container-fluid">

      {config.map((block, i) => {

        // ===== KPI =====
        if (block.type === "kpi") {
          return (
            <div className="row mb-4" key={i}>
              {block.items.map((item, idx) => (
                <KpiCard
                  key={idx}
                  title={item.label}
                  value={data[block.key]?.[item.field]}
                />
              ))}
            </div>
          );
        }

        // ===== CHART =====
        if (block.type === "chart") {
          return (
            <div className="card mb-4 p-3" key={i}>
              <h5>{block.title}</h5>
              <ChartRenderer
                type={block.chartType}
                data={data[block.dataKey]}
                options={block.options}
              />
            </div>
          );
        }

        // ===== TABLE =====
        if (block.type === "table") {
          return (
            <div className="card mb-4 p-3" key={i}>
              <h5>{block.title}</h5>
              <Table
                columns={block.columns}
                data={data[block.dataKey]}
              />
            </div>
          );
        }

        return null;
      })}
    </div>
  );
};

export default DashboardRenderer;