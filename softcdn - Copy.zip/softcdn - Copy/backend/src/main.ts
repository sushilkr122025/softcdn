import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import * as cookieParser from 'cookie-parser';
import { WinstonModule } from 'nest-winston';
import { winstonLoggerOptions } from './config/winston.logger';
import { AllExceptionsFilter } from './auth/http-exception.filter';
import { Logger } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    logger: WinstonModule.createLogger(winstonLoggerOptions),
  });
  app.setGlobalPrefix('api');
  app.use(cookieParser());
  const configService = app.get(ConfigService);
  const port = configService.get<string>('app.port') || '3000';
  const allowedOrigins =
    configService
      .get<string>('app.origin')
      ?.split(',')
      .map((origin) => origin.trim()) || [];
  // const allowedOrigins = ['http://fpserver:5174', 'http://devlap4:5174'];
  app.enableCors({
    // origin: configService.get<string>('app.origin') ?? 'http://localhost:5174',
    origin: (origin, callback) => {
      // console.log('CORS Origin:', origin);
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
  });
  app.useGlobalFilters(new AllExceptionsFilter());
  await app.listen(port);
  // await app.listen(8081, '0.0.0.0');
}
bootstrap();
