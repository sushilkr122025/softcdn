import React from 'react'
import SectionReport from './SectionReport'

function TeacherReport() {
  return (
    <SectionReport />
  )
}

export default TeacherReport