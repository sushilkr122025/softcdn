import React from 'react'
import { NavLink } from 'react-router-dom'
import Logo from '../../assets/images/logo.png'
import AppHeaderDropdown from './AppHeaderDropdown'
import { PiToggleRightLight, PiToggleLeftLight } from "react-icons/pi";
import { RiMenu2Line, RiMenu3Fill, RiMenuFill } from "react-icons/ri";
import { CiPower } from "react-icons/ci";
import { PiBellLight } from "react-icons/pi";
import NotificationBell from '../NotificationBell';

const AppHeader = ({ isCollapsed, setIsCollapsed, setCollapseFully, collapseFully }) => {
  return (    
    <header className="d-flex justify-content-between align-items-center py-3 bg-white shadow-sm">
      <div className='d-flex justify-content-between align-items-center'>
        <button
          className="btn btn-primary ms-4 d-none d-md-block"
          onClick={() => {
            if (!isCollapsed && !collapseFully) {
              setIsCollapsed(true)
            } else if (isCollapsed && !collapseFully) {
              setCollapseFully(true)
            } else {
              setCollapseFully(false);
              setIsCollapsed(false);
            }
          }}
        >
          {collapseFully ? (
            <RiMenu2Line />
          ) : (isCollapsed ?
            <RiMenuFill />
            : <RiMenu3Fill />

          )}
        </button>
        <button
          className="btn btn-primary d-block d-md-none"
          onClick={() => {
            if (!isCollapsed && !collapseFully) {
              setIsCollapsed(true);
            } else {
              setCollapseFully(false);
            }
          }}
        >
          {collapseFully ? (
            <RiMenu2Line />
          ) : (isCollapsed ?
            <RiMenuFill />
            : <RiMenu3Fill />

          )}
        </button>
        <input
          type="text"
          className="form-control d-none d-lg-block ms-5"
          placeholder="Search"
          style={{ width: "40rem" }}
        />
      </div>
      <div className='d-flex justify-content-around align-items-center'>
        <NotificationBell />
        <a className="px-4 bg-white border-0 border-start rounded-0 text-grey-400" href='/logout'><CiPower style={{fontSize: "25px"}} /></a>
      </div>

    </header>
  );
};

export default AppHeader
