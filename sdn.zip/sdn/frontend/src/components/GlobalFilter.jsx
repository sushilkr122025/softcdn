import React, { useEffect, useState } from 'react'
import apiClient from '../api/apiService'

const GlobalFilter = ({
  icon,
  heading,
  headClass,
  questionData,
  defaults = {},
  table = 'questions',
  page = null,
  data = null,
}) => {
  const [SubjectData, setSubjectData] = useState([])
  const [classData, setClassData] = useState([])
  const [errors, setErrors] = useState({})

  useEffect(() => {
    apiClient.get('/store/subject')
      .then((response) => {
        setSubjectData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })

    apiClient.get('/store/classes')
      .then((response) => {
        setClassData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching class data:', error)
      })
  }, [])

  const submitForm = (e) => {
    e.preventDefault()

    const newErrors = {}

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)
    // setClassSubject(payload);

    if (!payload.subject) {
      newErrors.subject = 'Subject is required'
    }

    if (!payload.class) {
      newErrors.class = 'Class is required'
    }

    setErrors(newErrors)

    if (Object.keys(newErrors).length !== 0) {
      return
    } else {
      apiClient
        .post(`/school/makePaper`, {
          subject: payload.subject,
          class: payload.class,
          table: table,
          page: page,
          data: data,
        })
        .then((response) => {
          questionData(response.data)
        })
        .catch((error) => {
          console.error(error)
        })
    }
  }
  return (
    <section className={'top-header ' + headClass}>
      <form action="" method="post" autoComplete="false" onSubmit={submitForm}>
        <div className="row gx-3 align-items-center header">
          <div className="col-lg-7 col-md col-sm-12 mb-3 mb-md-3 ">
            <div className="header-icon">
              <div className="breadcrumb-icon me-2">{icon}</div>
              <h5 className="mb-0 fw-normal pt-1 ">{heading}</h5>
            </div>
          </div>
          <div className="col-lg-2 col-md-3 col-sm-5 mb-2 form-div ">
            <label htmlFor="subject" className="col-form-label pe-2">
              Subject
            </label>
            <div className="input-group">
              <select
                className="form-select form-select-sm"
                id="subject"
                name="subject"
                defaultValue={defaults.Subject}
              >
                <option value="">Select Subject</option>
                {SubjectData.map((subject) => (
                  <option key={subject.id} value={subject.id}>
                    {subject.subject}
                  </option>
                ))}
              </select>
              {errors.subject && <div>{errors.subject}</div>}
            </div>
          </div>
          <div className="col-lg-2 col-md-3 col-sm-5 mb-2 form-div ">
            <label htmlFor="class" className="col-form-label pe-2">
              Class
            </label>
            <div className="input-group">
              <select
                className="form-select form-select-sm"
                id="class"
                name="class"
                defaultValue={defaults.class}
              >
                <option value="">Select Class Level</option>
                {classData.map((classes) => (
                  <option key={classes.id} value={classes.class}>
                    {classes.class}
                  </option>
                ))}
              </select>
              {errors.class && <div>{errors.class}</div>}
            </div>
          </div>
          <div className="col-lg-1 col-md-auto col-sm-2 mb-2  text-sm-center">
            <input
              type="submit"
              value="submit"
              className={'btn btn-sm lq-' + headClass + '-color'}
            />
          </div>
        </div>
      </form>
    </section>
  )
}

export default GlobalFilter
