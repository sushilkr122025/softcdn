import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { getClientIp } from '../utils/ip.util';

@Injectable()
export class RequestLoggerMiddleware implements NestMiddleware {
  constructor() {}

  use(req: Request, res: Response, next: NextFunction) {
    const start = Date.now();
    const ip = getClientIp(req);

    res.on('finish', () => {
      const duration = Date.now() - start;
    //   const userId = req['user']?.id || 'Guest'; | ${userId}

      console.log(
        `[${req.method}] ${req.originalUrl} | ${res.statusCode} | ${ip} | ${duration}ms`
      );
    });

    next();
  }
}
