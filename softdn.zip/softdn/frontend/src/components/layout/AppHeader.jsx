import React from 'react';
import logo from '../../assets/images/logo.png';
import user from '../../assets/images/user/user.jpg';
import off from '../../assets/images/off.svg';
import { FaPowerOff } from "react-icons/fa";
import ThemeToggle from './ThemeToggle';
import NotificationBell from '../NotificationBell';

const AppHeader = ({ toggleSidebar }) => {
  return (
    <header className="d-flex justify-content-between align-items-center py-1 shadow-sm fixed-top appheaderbg" style={{ zIndex: 1100 }}>
      <div className='d-flex justify-content-between align-items-center'>
        <button className='btn text-white border-0' id="toggleBtn" onClick={toggleSidebar} >☰</button>
        <img src={logo} alt="logo" width={40} className='img-fluid me-5' />
      </div>
      <div className='d-flex justify-content-around align-items-center'>
        <ThemeToggle />
        <NotificationBell />
        <div className="dropdown">
          <button className="btn border-0 btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
            <img src={off} alt="logout" width={20} title='Logout' />
          </button>
          <div className="dropdown-menu mt-3 rounded-0 profile-box">
            <div className='p-2 profile-dropdown d-flex flex-column align-items-center'>
              <img src={user} className="Avatar-img" alt="profile" />
              <p className='mb-0 text-secondary-400'>Hi, User !</p>
              <p className='mb-0 text-grey-400'>user@sansol.in</p>
              <div className='bg-light d-flex p-1 border rounded'>
                <a className="text-grey-400 d-flex align-items-center border-end px-3" href='/logout'>Forget ?</a>
                <a className="text-danger d-flex align-items-center px-3" href='/logout'><FaPowerOff className='me-1' />Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
export default AppHeader;
