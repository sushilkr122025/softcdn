import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'questions' })
export class Questions {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50', nullable: true, default: null })
  customId: string;

  @Column({ type: 'int', nullable: true })
  tId: number; // Teacher ID

  @Column({ type: 'int', nullable: true })
  subject: number;

  @Column({ type: 'int', nullable: true })
  class: number;

  @Column({ type: 'int', nullable: true, default: null })
  subDomain: number;

  @Column({ type: 'text', nullable: true })
  difficulty: string;

  @Column({ type: 'int', nullable: true, default: null })
  cg: number;

  @Column({ type: 'text', nullable: true })
  competency: string;

  @Column({ type: 'varchar', nullable: true, length: '100' })
  quesType: string;

  @Column({ type: 'longtext', nullable: true })
  question: string;

  @Column({ type: 'varchar', length: '500', nullable: true })
  correctAns: string;

  @Column({ type: 'longtext', nullable: true, default: null })
  optA: string;

  @Column({ type: 'longtext', nullable: true, default: null })
  optB: string;

  @Column({ type: 'longtext', nullable: true, default: null })
  optC: string;

  @Column({ type: 'longtext', nullable: true, default: null })
  optD: string;

  @Column({ type: 'varchar', length: '300', default: null })
  optAimg: string;

  @Column({ type: 'varchar', nullable: true, length: '300', default: null })
  optBimg: string;

  @Column({ type: 'varchar', nullable: true, length: '300', default: null })
  optCimg: string;

  @Column({ type: 'varchar', nullable: true, length: '300', default: null })
  optDimg: string;

  @Column({ type: 'varchar', nullable: true, length: '300', default: null })
  image: string;

  @Column({ type: 'varchar', length: '20', default: 'UNAPPROVED' })
  status: string;

  @Column({ type: 'varchar', length: '20', default: 'NOCONTEXT' })
  contextstatus: string;

  @Column({ type: 'int', nullable: true, default: null })
  contextid: number;

  @Column({ type: 'varchar', nullable: true, length: '50' })
  approverId: string;

  @Column({ type: 'varchar', nullable: true, length: '10' })
  createdBy: string;

  @Column({ type: 'varchar', nullable: true, length: '100', default: null })
  chapter: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @Column({ type: 'varchar', length: '50', nullable: true })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;
}
