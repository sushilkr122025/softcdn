import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import * as cookieParser from 'cookie-parser';
import helmet from 'helmet';
import * as csurf from 'csurf';

import { WinstonModule } from 'nest-winston';
import { winstonLoggerOptions } from './config/winston.logger';
import { WinstonExceptionFilter } from './config/filters/winston-exception.filter';
import { TypeOrmExceptionFilter } from './config/filters/typeorm-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    logger: WinstonModule.createLogger(winstonLoggerOptions),
  });

  app.useGlobalFilters(
    new TypeOrmExceptionFilter(),
    new WinstonExceptionFilter()
  );

  app.set('trust proxy', 1);
  app.setGlobalPrefix('api');
  app.use(cookieParser());

  app.use(
    helmet({
      crossOriginResourcePolicy: true,
    })
  );

  const configService = app.get(ConfigService);
  const origin = configService.get<string>('app.origin');
  const port = configService.get<string>('app.port') || '3000';

  app.enableCors({
    origin,
    credentials: true,
  });
/*
  const csrfMiddleware = csurf({
    cookie: {
      httpOnly: true,
      secure: false, // change true in production https
      sameSite: 'lax',
    },
  });

  app.use((req, res, next) => {
    const safeMethods = ['HEAD', 'OPTIONS'];

    if (safeMethods.includes(req.method)) {
      return next();
    }

    const excludedRoutes = [
      '/api/auth/login',
      '/api/auth/logout',
      '/api/auth/register',
    ];

    if (
      excludedRoutes.includes(req.path) ||
      req.path.startsWith('/api/lookup')
    ) {
      return next();
    }

    return csrfMiddleware(req, res, next);
  });
*/
  /* ---------------- START SERVER ---------------- */
  await app.listen(port);
}

void bootstrap();
