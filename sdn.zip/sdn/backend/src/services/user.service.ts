import { Injectable, NotFoundException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, Not } from 'typeorm';
import { plainToInstance } from 'class-transformer';
import { Login } from '../entities/login.entity';
import { LoginDto, UpdateLoginDto } from '../dto/login.dto';
import { ConfigService } from '@nestjs/config';
import { UserDetail } from '../entities/userdetail.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { StudentInformationDto } from '../dto/student.information.dto';
import { UserPermission } from '../entities/user.permissions.entity';

@Injectable()
export class UserService {
  private readonly keybrcyt: string;
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Login)
    private loginRepository: Repository<Login>,
    @InjectRepository(UserDetail)
    private detailRepository: Repository<UserDetail>,
    @InjectRepository(StudentInformation)
    private studentRepository: Repository<StudentInformation>,
    @InjectRepository(UserPermission)
    private userPermissionRepository: Repository<UserPermission>,
    private readonly configuration: ConfigService
  ) {
    this.keybrcyt = this.configuration.get<string>('keybcrypt') || 'education';
  }

  async findAll(tenantid: string, notin: number): Promise<any[]> {
    try {
      const result = await this.loginRepository.find({
        where: { tenantid: tenantid, dmlType: 'I', id: Not(notin) },
        select: [
          'id',
          'name',
          'userid',
          'gender',
          'mobileno',
          'email',
          'role',
          'createdate',
        ],
      });
      return result;
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }  


  // async findAll(tenantid: string): Promise<any[]> {
  //   try {
  //     const result = await this.dataSource.transaction(async (manager) => {
  //       const data = await manager
  //         .createQueryBuilder()
  //         .select([
  //           'l.id AS id',
  //           'l.name AS name',
  //           'u.DOJ AS DOJ',
  //           'u.contactNo AS contactNo',
  //           'u.emailId AS emailId',
  //           'u.empType AS empType',
  //           'u.status AS status',
  //           'l.role AS role',
  //         ])
  //         .from('userdetail', 'u')
  //         .innerJoin('login', 'l', 'u.userId = l.id')
  //         .where('l.tenantId = :tenantid', { tenantid })
  //         .getRawMany();
  //       return data;
  //     });

  //     return result;
  //   } catch (error) {
  //     console.error('Transaction failed. Rolled back.', error);
  //     throw error;
  //   }
  // }
  async finsUserDetails(data: {
    tenantid: string;
    id: number;
  }): Promise<UpdateLoginDto> {
    const { tenantid, id } = data;
    try {
      const user = await this.loginRepository.findOne({
        where: { tenantid, id },
      });

      if (!user) {
        throw new Error('User not found');
      }

      return plainToInstance(UpdateLoginDto, user, {
        excludeExtraneousValues: true,
      });
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  findByEmail(email: string): Promise<Login | null> {
    return this.loginRepository.findOne({ where: { email } });
  }

  async findById(id: number): Promise<Login | null> {
    const user = await this.loginRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  async createUser(loginDto: LoginDto): Promise<any> {
    const { id, password, tenantid } = loginDto;

    let user: Login | undefined;

    if (loginDto.id) {
      user = await this.loginRepository.preload(loginDto);
      if (!user) {
        throw new NotFoundException(`User with id ${id} not found`);
      }
    } else {
      user = this.loginRepository.create({
        ...loginDto,
        password: password + this.keybrcyt,
      });
      await user.hashPassword();
    }
    const create = await this.loginRepository.save(user);
    if (create) {
      return create.id;
    } else {
      throw new NotFoundException('Error from backend service');
    }
  }
  // async createUser(loginDto: LoginDto): Promise<any> {
  //   console.log('Creating user with DTO:', loginDto);
  //   const {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   } = loginDto;
  //   const user = new Login();
  //   Object.assign(user, {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   });
  //   user.password = user.password + this.keybrcyt;
  //   await user.hashPassword();
  //   const create = await this.loginRepository.save(user);
  //   if (create) {
  //     return create.id;
  //   } else {
  //     throw new NotFoundException('Error from backend service');
  //   }
  // }

  async createStudent(studentDto: StudentInformationDto): Promise<any> {
    const student = new StudentInformation();
    Object.assign(student, studentDto);
    const create = await this.studentRepository.save(student);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    const studentData = {
      id: create.Id,
      name: create.name,
      rollNo: create.rollNo,
      fatherName: create.fatherName,
      motherName: create.motherName,
    };
    return studentData;
  }

  async findAllStudent(tenantid: string, q): Promise<StudentInformation[]> {
    return this.studentRepository.find({
      where: { tenantid: tenantid, class: 7, section: 'A' },
    });
  }

  async addUserPermissions(
    userId: number,
    permission: any,
    tenantid: string
  ): Promise<any> {
    const data = permission.map((e) => ({
      scope: e.module,
      permissions: e,
      userId,
      tenantid,
    }));
    console.log('data', permission);
    const create = await this.userPermissionRepository.insert(data);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Permissions inserted successfully',
      insertedCount: create.identifiers.length,
    };
  }
}
