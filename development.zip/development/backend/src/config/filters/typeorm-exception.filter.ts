import { Catch, ArgumentsHost, ExceptionFilter, HttpStatus } from '@nestjs/common';
import { QueryFailedError } from 'typeorm';

@Catch(QueryFailedError)
export class TypeOrmExceptionFilter implements ExceptionFilter {
  catch(exception: any, host: ArgumentsHost) {
    const response = host.switchToHttp().getResponse();

    console.error('🔥 TYPEORM ERROR:', exception);

    response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      message: exception.message,
      detail: exception.detail,
      code: exception.code,
    });
  }
}
