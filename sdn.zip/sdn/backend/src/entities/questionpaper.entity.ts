import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'questionpaper' })
export class QuestionPaper {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '15' })
  examCode: string;

  @Column({ type: 'varchar', length: '80' })
  name: string;

  @Column({ type: 'int' })
  class: number;

  @Column({ type: 'varchar', length: '50' })
  subject: string;

  @Column({ type: 'varchar', length: '10' })
  section: string;

  @Column({ type: 'int' })
  maxMarks: number;

  @Column({ type: 'varchar', length: '15' })
  totalTime: string;

  @Column({ type: 'varchar', length: '10' })
  createdFrom: string;

  @CreateDateColumn({ type: 'timestamp' })
  examDate: Date;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  dateTime: Date;
}
