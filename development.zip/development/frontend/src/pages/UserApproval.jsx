import React, { useEffect, useState, useCallback } from 'react'
import { MdRemoveCircleOutline, MdAddCircleOutline } from 'react-icons/md'
import { AiOutlineCloseCircle } from 'react-icons/ai'
import UserServices from '../api/UserServices'
import apiClient from '../api/apiService'
import { useParams, useNavigate } from 'react-router-dom'
import ShowMessage from '../components/ShowMessage'

const UserApproval = () => {
  const [subjectData, setSubjectData] = useState([])
  const [rowData, setRowData] = useState({})
  const [rows, setRows] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [activeRow, setActiveRow] = useState(null)
  const [selectedTeachers, setSelectedTeachers] = useState([])
  const [availableTeacher, setAvailableTeacher] = useState([])
  const [showToast, setShowToast] = useState(false)

  const navigator = useNavigate()

  const { userid } = useParams()
  const updateId = userid || null

  // --- helper: empty row ---
  const makeEmptyRow = useCallback(
    () => ({
      id: `temp-${Date.now()}-${Math.random()}`,
      classId: '',
      subjectId: '',
      teacherIds: [],
    }),
    []
  )
const [userData, setUserData] = useState()
useEffect(() => {
  let isMounted = true // Prevent state updates if component unmounts

  const loadAll = async () => {
    try {
      const [userRes, subjectRes, userRule] = await Promise.all([
        UserServices.getUser({ params: { id: updateId } }),
        apiClient.get('/store/subject'),
        UserServices.getUserRule({ params: { id: updateId } }),
      ])

      if (!isMounted) return // Don't update state if unmounted     
      setUserData(userRes.userdata);

      const quesmodule = userRes?.permission.find((mod) => mod.module === 'QUESTION')
      const writePermission = quesmodule?.permissions?.WRITE || []
      const teacherSubjects = writePermission || []

      // Initialize shaped with ALL permitted subject-class combinations
      const shaped = {}
      teacherSubjects.forEach((s) => {
        shaped[s.subjectId] = s.classIds.map((cid) => ({
          classId: Number(cid),
          selectedteachers: [],
          availableTeacher: [],
        }))
      })

      // Filter subjects user can access
      const filteredSubjects = subjectRes.data.filter((s) =>
        teacherSubjects.some((t) => Number(t.subjectId) === s.id)
      )

      if (!isMounted) return
      setSubjectData(filteredSubjects)

      if (userRule && userRule.length > 0) {
        // Deduplicate userRule by id (in case backend returns duplicates)
        const uniqueRules = userRule.reduce((acc, rule) => {
          if (!acc.find((r) => r.id === rule.id)) {
            acc.push(rule)
          }
          return acc
        }, [])

        const preloadedRows = await Promise.all(
          uniqueRules.map(async (r) => {
            const subjectId = String(r.subjectId)
            const classId = String(r.classId)

            // Convert teacher string "8,7,3" → [8,7,3]
            const teachers = r.teachersId
              ? String(r.teachersId)
                  .split(',')
                  .map((t) => Number(t.trim()))
              : []

            // Fetch available teachers for this subject-class pair
            const response = await UserServices.getTeacherBySubjectClass({
              params: { classIds: classId, subjectId },
            })

            const available = (response || []).filter((t) => Number(t.id) !== Number(updateId))

            // Update the existing entry in shaped (from permissions)
            if (shaped[subjectId]) {
              const existingIndex = shaped[subjectId].findIndex(
                (c) => c.classId === Number(classId)
              )

              if (existingIndex !== -1) {
                // Update existing entry with loaded data
                shaped[subjectId][existingIndex] = {
                  ...shaped[subjectId][existingIndex],
                  availableTeacher: available,
                  selectedteachers: teachers,
                }
              } else {
                // Class exists in rule but not in permissions (edge case)
                shaped[subjectId].push({
                  classId: Number(classId),
                  availableTeacher: available,
                  selectedteachers: teachers,
                })
              }
            } else {
              // Subject exists in rule but not in permissions (edge case)
              shaped[subjectId] = [
                {
                  classId: Number(classId),
                  availableTeacher: available,
                  selectedteachers: teachers,
                },
              ]
            }

            return {
              id: r.id, // Keep the database ID
              subjectId,
              classId,
              teacherIds: teachers,
            }
          })
        )

        // console.log('preloadedRows before setting:', preloadedRows)
        // console.log('preloadedRows IDs:',preloadedRows.map((r) => r.id))
        
        if (!isMounted) return
        setRowData({ ...shaped })
        setRows(preloadedRows)
      } else {
        // --- Insert mode (no existing approval data)
        if (!isMounted) return
        setRowData(shaped)
        setRows([makeEmptyRow()])
      }
    } catch (error) {
      console.error('Error loading user approval data:', error)
    }
  }

  loadAll()

  return () => {
    isMounted = false // Cleanup
  }
}, [makeEmptyRow, updateId])

  // --- subject change handler ---
const handleSubjectChange = (rowIndex, subjectId) => {
  setRows((prev) =>
    prev.map((row, i) => {
      if (i === rowIndex) {
        // If it's a temp ID, keep it. If it's a real ID, mark for new rule creation
        const newId =
          typeof row.id === 'string' && row.id.startsWith('temp-')
            ? row.id
            : `temp-${Date.now()}-${Math.random()}`

        return {
          ...row,
          id: newId,
          subjectId,
          classId: '',
          teacherIds: [],
        }
      }
      return row
    })
  )
}


  const handleClassSelect = async (rowIndex, classId) => {
    const subjectId = rows[rowIndex]?.subjectId

    if (!subjectId) {
      alert('Please select a subject first!')
      return
    }

    const prevClassId = rows[rowIndex]?.classId

    console.log({ classId })

    // If user selected the same class again => open modal (preserve id)
    if (String(prevClassId) === String(classId)) {
      // Try to find cached available teachers first
      const existingAvailable =
        rowData[subjectId]?.find((c) => c.classId === Number(classId))?.availableTeacher || []

      setAvailableTeacher(existingAvailable)
      setActiveRow(rowIndex)
      setSelectedTeachers(rows[rowIndex].teacherIds || [])
      setShowModal(true)
      return
    }

    // Check duplicates BEFORE changing rows
    const isDuplicate = rows.some(
      (r, i) =>
        i !== rowIndex &&
        String(r.subjectId) === String(subjectId) &&
        String(r.classId) === String(classId)
    )

    if (isDuplicate) {
      alert('This subject and class combination already exists!')
      setRows((prev) => prev.map((row, i) => (i === rowIndex ? { ...row, classId: classId } : row)))
      return
    }

    // Valid change — update the row and reset id (since it's a different rule)
    const updated = rows.map((row, i) =>
      i === rowIndex ? { ...row, id: null, classId, teacherIds: [] } : row
    )
    setRows(updated)

    try {
      // Fetch available teachers from backend
      const response = await UserServices.getTeacherBySubjectClass({
        params: { classIds: classId, subjectId },
      })
      const available = (response || []).filter((t) => Number(t.id) !== Number(updateId))
      console.log(available);
      

      // Update rowData structure
      setRowData((prev) => {
        const newRowData = { ...prev }
        if (!newRowData[subjectId]) newRowData[subjectId] = []

        const existingIndex = newRowData[subjectId].findIndex((c) => c.classId === Number(classId))

        if (existingIndex !== -1) {
          newRowData[subjectId][existingIndex] = {
            ...newRowData[subjectId][existingIndex],
            availableTeacher: available,
            // selectedteachers remains existing (we already reset row-level teacherIds)
          }
        } else {
          newRowData[subjectId].push({
            classId: Number(classId),
            selectedteachers: [],
            availableTeacher: available,
          })
        }
        return newRowData
      })

      // open modal
      setActiveRow(rowIndex)
      setAvailableTeacher(available)
      setSelectedTeachers(updated[rowIndex].teacherIds || [])
      setShowModal(true)
    } catch (error) {
      console.error('Error fetching teachers:', error)
    }
  }

  // --- save selected teachers ---
  const handleSaveTeachers = () => {
    if (activeRow === null) return

    const { subjectId, classId } = rows[activeRow]

    // update row-level (preserve id)
    setRows((prev) =>
      prev.map((row, i) =>
        i === activeRow ? { ...row, teacherIds: selectedTeachers.map((t) => Number(t)) } : row
      )
    )

    // update nested rowData (preserve any existing selectedteachers)
    setRowData((prev) => {
      const newRowData = { ...prev }
      if (!newRowData[subjectId]) return newRowData

      newRowData[subjectId] = newRowData[subjectId].map((c) =>
        c.classId === Number(classId)
          ? { ...c, selectedteachers: selectedTeachers.map((t) => Number(t)) }
          : c
      )

      return newRowData
    })

    setShowModal(false)
    setActiveRow(null)
  }

  // --- remove selected teacher ---
  const handleRemoveTeacher = (rowIndex, teacherId) => {
    const { subjectId, classId } = rows[rowIndex]

    // update table row (preserve id)
    setRows((prev) =>
      prev.map((row, i) =>
        i === rowIndex ? { ...row, teacherIds: row.teacherIds.filter((t) => t !== teacherId) } : row
      )
    )

    // update rowData
    setRowData((prev) => {
      const newRowData = { ...prev }
      if (!newRowData[subjectId]) return newRowData

      newRowData[subjectId] = newRowData[subjectId].map((c) =>
        c.classId === Number(classId)
          ? {
              ...c,
              selectedteachers: c.selectedteachers.filter((t) => t !== teacherId),
            }
          : c
      )
      return newRowData
    })
  }

const handleSaveForm = async () => {
  try {
    // Filter out incomplete rows
    const validRows = rows.filter((r) => r.subjectId && r.classId && r.teacherIds.length > 0)

    if (validRows.length === 0) {
      alert('Please select at least one subject, class, and teacher')
      return
    }

    const payload = validRows.map((row) => ({
      // Only include id if it's a real database ID (number), not a temp ID (string)
      id: typeof row.id === 'number' ? row.id : undefined,
      userId: updateId,
      subjectId: Number(row.subjectId),
      classId: Number(row.classId),
      teachersId: row.teacherIds,
    }))

    console.log('Final flat payload:', payload)

    const response = await UserServices.setRule(payload)
    if (response.status === 201 || response.status === 200) {
      setShowToast(true)
      console.log(response)
    } else {
      alert('Failed to save user approval data.')
    }
  } catch (error) {
    console.error('Error saving form:', error)
    alert('Error while saving user approval data.')
  }
}

  return (
    <div className="container-fluid py-4">
      <div className="row ms-5">
        <div className="col-12 col-lg-11 ms-5 bg-white shadow-sm rounded p-4">
          <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
            <h3 className="fw-bold text-primary">{userData && userData.name}'s Set Approval</h3>
          </div>

          <table className="table table-bordered align-middle text-center">
            <thead className="table-light">
              <tr>
                <th style={{ width: '30%' }}>Subject</th>
                <th style={{ width: '30%' }}>Class</th>
                <th style={{ width: '40%' }}>Teacher</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const subjectClasses = rowData[String(row.subjectId)]?.map((c) => c.classId) || []

                // Robust lookup: flatten availableTeacher lists safely
                const availableFlatten =
                  rowData[String(row.subjectId)]?.flatMap((c) => c.availableTeacher || []) || []

                const selectedTeacherObjects =
                  (row.teacherIds || [])
                    .map((id) => availableFlatten.find((t) => t?.id === id))
                    .filter(Boolean) || []

                return (
                  <tr key={row.id}>
                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.subjectId}
                        onChange={(e) => handleSubjectChange(i, e.target.value)}
                      >
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.classId}
                        onChange={(e) => handleClassSelect(i, e.target.value)}
                      >
                        <option value="">Select Class</option>
                        {subjectClasses.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="text-start">
                      {selectedTeacherObjects.length > 0 ? (
                        selectedTeacherObjects.map((t) => (
                          <span
                            key={t.id}
                            className="badge bg-primary me-2 p-2 d-inline-flex align-items-center"
                          >
                            {t.name}
                            <AiOutlineCloseCircle
                              className="ms-1"
                              style={{ cursor: 'pointer' }}
                              onClick={() => handleRemoveTeacher(i, t.id)}
                            />
                          </span>
                        ))
                      ) : (
                        <span className="text-muted">No teacher selected</span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>

            <tfoot>
              <tr>
                <td colSpan={3}>
                  <span
                    className="me-4 text-danger fs-5"
                    onClick={() => rows.length > 1 && setRows((prev) => prev.slice(0, -1))}
                    style={{ cursor: 'pointer' }}
                  >
                    <MdRemoveCircleOutline />
                  </span>
                  <span
                    className="text-success fs-5"
                    onClick={() => setRows((prev) => [...prev, makeEmptyRow()])}
                    style={{ cursor: 'pointer' }}
                  >
                    <MdAddCircleOutline />
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
          <div className="d-flex justify-content-end mt-3">
            <button className="btn btn-secondary" onClick={handleSaveForm}>
              Save Approval Data
            </button>
          </div>
        </div>
      </div>

      {/* Teacher selection modal */}
      {showModal && (
        <div
          className="modal fade show"
          style={{ display: 'block', background: 'rgba(0,0,0,0.5)' }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Select Teachers</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                {availableTeacher.map((teacher) => (
                  <div key={teacher.id} className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={String(teacher.id)}
                      checked={selectedTeachers.includes(teacher.id)}
                      onChange={(e) => {
                        const checked = e.target.checked
                        setSelectedTeachers((prev) =>
                          checked ? [...prev, teacher.id] : prev.filter((t) => t !== teacher.id)
                        )
                      }}
                    />
                    <label className="form-check-label" htmlFor={String(teacher.id)}>
                      {teacher.name}
                    </label>
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button className="btn btn-secondary" onClick={handleSaveTeachers}>
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <ShowMessage
        show={showToast}
        type="toast"
        message="Saved user approval data successfully"
        variant="info"
        onClose={() => {
          setShowToast(false)
          navigator('/users')
        }}
      />
    </div>
  )
}

export default UserApproval
