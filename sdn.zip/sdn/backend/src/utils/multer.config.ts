import { diskStorage } from 'multer';
import { join } from 'path';
import * as fs from 'fs';
import { Request } from 'express';

export const multerConfig = {
  storage: diskStorage({
    destination: (req: Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) => {
      const folderName = req.body.name ? req.body.name.replace(/\s+/g, '-') : 'default';
      const uploadPath = join(__dirname, '..', '..', 'uploads', folderName);
      // Create directory if it doesn't exist
      if (!fs.existsSync(uploadPath)) {
        fs.mkdirSync(uploadPath, { recursive: true });
      }
      cb(null, uploadPath);
    },
    filename: (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
      // Generate a unique filename
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      const originalName = file.originalname.replace(/\s+/g, '-');
      const filename = `${uniqueSuffix}-${originalName}`;
      cb(null, filename);
    },
  }),
  // Optional: Add file filter and limits
  /*
  fileFilter: (req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
    if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'), false);
    }
  },
  limits: {
    fileSize: 1024 * 1024 * 5 // 5MB
  }
  */
};
