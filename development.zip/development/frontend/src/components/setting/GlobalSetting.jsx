import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Modal, Button } from 'react-bootstrap'

const GlobalSetting = () => {
  const [showModal, setShowModal] = useState(false)

  const handleShow = () => setShowModal(true)
  const handleClose = () => setShowModal(false)

  return (
    <div className="m-3">
      <div className="row">
        <div className="col-12 col-sm-6 col-md-4 col-lg-3">
          <div className="setting-header teal">Configuration Settings</div>

          <Link className="setting-item d-block mb-2" onClick={handleShow}>
            Approval Rule
          </Link>
          <Link className="setting-item d-block mb-2">Enable Notifications</Link>
        </div>
      </div>

      <Modal show={showModal} onHide={handleClose} centered size="lg" backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Approval Rule Settings</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form action="" method="post">
            <div className="row g-3 align-items-center">
              <div className="col-8">
                <label htmlFor="approvalRule" className="col-form-label required">
                  Rule Name
                </label>
                <input
                  type="text"
                  name="approvalRule"
                  id="approvalRule"
                  className="form-control form-control-sm"
                />
              </div>
              <div className="col-4">
                <label htmlFor="waitFor" className="col-form-label required">
                  Wait For
                </label>
                <select name="waitFor" id="waitFor" className="form-select form-select-sm">
                  <option value="ANY">Anyone to Approve</option>
                  <option value="ALL">Everyone to Approve</option>
                  <option value="FRA">First Response Action</option>
                  <option value="MAJORITY">Majority to Approve</option>
                </select>
              </div>
            </div>
          </form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={() => alert('Saved!')}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default GlobalSetting
