import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import apiClient from '../api/apiService'

const YourComponent = () => {
  const [Name, setName] = useState('')
  const [RollNo, setRollNo] = useState('')
  const [FatherName, setFatherName] = useState('')
  const [MotherName, setMotherName] = useState('')
  const [Gender, setGender] = useState('')
  const [DateOfBirth, setDateOfBirth] = useState('')
  const [classlevel, setclasslevel] = useState('')
  const [classOptions, setClassOptions] = useState([])
  const [section, setSection] = useState('')
  const [ContactNumber, setContactNumber] = useState('')
  const [AlternativeContactNumber, setAlternativeContactNumber] = useState('')
  const [EmailID, setEmailID] = useState('')
  const [Address, setAddress] = useState('')
  const [State, setState] = useState('')
  const [stateOptions, setStateOptions] = useState([])
  const [districtOptions, setDistrictOptions] = useState([])
  const [District, setDistrict] = useState('')
  const navigator = useNavigate()
  const [errors, setErrors] = useState({})

  const handleName = (e) => {
    setName(e.target.value)
  }
  const handleRollNo = (e) => {
    const inputValue = e.target.value
    // Check if the input value contains only numeric characters
    const isValidInput = /^\d*$/.test(inputValue)
    // If the input value contains only numeric characters, update the state
    if (isValidInput) {
      setRollNo(inputValue)
    } else {
      setErrors({ ...errors, RollNo: 'Enter only number' })
    }
  }
  const handleFatherName = (e) => {
    setFatherName(e.target.value)
  }
  const handleMotherName = (e) => {
    setMotherName(e.target.value)
  }
  const handleGender = (e) => {
    setGender(e.target.value)
  }
  const handleDateOfBirth = (e) => {
    setDateOfBirth(e.target.value)
  }
  useEffect(() => {
    // Fetch class options from the backend API
    apiClient
      .get('/options')
      .then((response) => {
        setClassOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching classes:', error)
      })

    apiClient
      .get('/api/states')
      .then((response) => {
        // console.log(response.data);
        setStateOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }, []) // Run only once on component mount

  const handleClassLevel = (e) => {
    setclasslevel(e.target.value)
  }
  const handleSection = (e) => {
    setSection(e.target.value)
  }
  // const handleContactNumber = (e) => {
  //   const inputValue = e.target.value;
  //   // Check if the input value matches the desired pattern (10 digits starting with 6, 7, 8, or 9)
  //   const isValidInput = /^[6-9]\d{9}$/.test(inputValue);
  //   console.log(inputValue)
  //   // If the input value matches the pattern, update the state
  //   if (isValidInput) {
  //     setContactNumber(inputValue);
  //   }
  // }
  const handleContactNumber = (e) => {
    const inputValue = e.target.value
    // Check if the input value contains only numeric characters
    const isValidInput = /^\d*$/.test(inputValue)
    // If the input value contains only numeric characters, update the state
    if (isValidInput) {
      setContactNumber(inputValue)
    }
  }
  const handleAlternativeContactNumber = (e) => {
    const inputValue = e.target.value
    // Check if the input value contains only numeric characters
    const isValidInput = /^\d*$/.test(inputValue)
    // If the input value contains only numeric characters, update the state
    if (isValidInput) {
      setAlternativeContactNumber(inputValue)
    }
  }
  const handleEmailID = (e) => {
    const inputValue = e.target.value
    // Regular expression pattern for validating email addresses
    const isValidEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(inputValue)
    // If the input value matches the pattern, update the state
    if (isValidEmail) {
      setEmailID(inputValue)
    }
  }
  const handleAddress = (e) => {
    setAddress(e.target.value)
  }
  const handleState = (e) => {
    setState(e.target.value)

    apiClient
      .post('/district', { stateId: e.target.value })
      .then((response) => {
        // console.log(response.data);
        setDistrictOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }
  const handleDistrict = (e) => {
    setDistrict(e.target.value)
  }

  const onSubmitHandler = async (e) => {
    e.preventDefault()
    const newErrors = {}
    if (!Name) newErrors.Name = 'Name is required'
    if (!RollNo) newErrors.RollNo = 'Roll No is required'
    if (!EmailID) newErrors.EmailID = 'Email is required'
    if (!FatherName) newErrors.FatherName = 'Father`s Name is required'
    if (!MotherName) newErrors.MotherName = 'Mother`s Name is required'
    if (!Gender) newErrors.Gender = 'Gender is required'
    if (!DateOfBirth) newErrors.DateOfBirth = 'Date Of Birth is required'
    if (!classlevel) newErrors.class = 'Class is required'
    if (!section) newErrors.section = 'Section is required'
    if (!ContactNumber) newErrors.ContactNumber = 'Contact Number is required'
    if (!Address) newErrors.Address = 'Address is required'
    if (!State) newErrors.State = 'State is required'
    if (!District) newErrors.District = 'District is required'
    console.log(newErrors)

    setErrors(newErrors)

    // If there are errors, stop submission
    if (Object.keys(newErrors).length > 0) {
      return
    }

    const StudentData = {
      Name,
      RollNo,
      FatherName,
      MotherName,
      Gender,
      DateOfBirth,
      classlevel,
      section,
      ContactNumber,
      AlternativeContactNumber,
      EmailID,
      Address,
      State,
      District,
      // Add other data to be sent to the backend
    }
    try {
      // Check if formData has an id
      if (StudentData.id) {
        // If formData has an id, send a PUT request to update data
       const response = await apiClient.put(`/Student/${StudentData.id}`, StudentData)

        if (response.ok) {
          console.log('Data updated successfully!')
          navigator('/dashboard')
        } else {
          console.error('Failed to update data.')
        }
      } else {
        // If formData does not have an id, send a POST request to insert data
        const response = await apiClient.post(`/Student`, StudentData)

        if (response.ok) {
          console.log('Data inserted successfully!')
          navigator('/dashboard')
        } else {
          console.error('Failed to insert data.')
        }
      }
    } catch (error) {
      console.error('An error occurred:', error)
    }
  }
  return (
    <div className="container">
      <nav className="mt-5">
        <div className="nav nav-tabs border-0" id="nav-tab" role="tablist">
          <button className="nav-link me-2 lq-red-color active">Student Registration</button>
        </div>
      </nav>
      <div className="tab-content bg-white px-5 py-4" id="nav-tabContent">
        <div className="tab-pane fade show active">
          <div className="App">
            <form className="forms red" onSubmit={onSubmitHandler}>
              <div className="row mb-3">
                <div className="col-12"></div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="name"
                      id="name"
                      className="form-control"
                      onChange={handleName}
                      placeholder="Enter the concept"
                    />
                    <label htmlFor="name" className=" floatinginput required">
                      Name
                    </label>
                    {errors.Name && <span className="error ">{errors.Name}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="RollNo"
                      id="RollNo"
                      className="form-control"
                      value={RollNo}
                      onChange={handleRollNo}
                      placeholder="Enter the Roll Number"
                    />
                    <label htmlFor="RollNo" className=" floatinginput required">
                      Roll No.
                    </label>
                    {errors.RollNo && <span className="error ">{errors.RollNo}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="FatherName"
                      id="FatherName"
                      className="form-control"
                      value={FatherName}
                      onChange={handleFatherName}
                      placeholder="Enter the Father's Name"
                    />
                    <label htmlFor="FatherName" className=" floatinginput required">
                      Father&apos;s Name
                    </label>
                    {errors.FatherName && <span className="error ">{errors.FatherName}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="MotherName"
                      id="MotherName"
                      className="form-control"
                      value={MotherName}
                      onChange={handleMotherName}
                      placeholder="Enter the Roll Number"
                    />
                    <label htmlFor="MotherName" className="floatinginput required">
                      Mother&apos;s Name
                    </label>
                    {errors.MotherName && <span className="error ">{errors.MotherName}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <select
                      className="form-select"
                      id="Gender"
                      name="Gender"
                      value={Gender}
                      onChange={handleGender}
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="May Not Prefer">May Not Prefer</option>
                    </select>
                    <label htmlFor="Gender" className=" floatinginput required">
                      Gender
                    </label>
                    {errors.Gender && <span className="error">{errors.Gender}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="date"
                      name="DateOfBirth"
                      id="DateOfBirth"
                      className="form-control"
                      value={DateOfBirth}
                      onChange={handleDateOfBirth}
                      placeholder="Enter the Roll Number"
                    />
                    <label htmlFor="DateOfBirth" className=" floatinginput required">
                      Date Of Birth
                    </label>
                    {errors.DateOfBirth && <span className="error ">{errors.DateOfBirth}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <select
                      className="form-select"
                      id="class"
                      name="class"
                      value={classlevel}
                      onChange={handleClassLevel}
                    >
                      <option value="">Select Class</option>
                      {classOptions.map((option, index) => (
                        <option key={index} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                    <label htmlFor="class" className=" floatinginput required">
                      Class
                    </label>
                    {errors.class && <span className="error ">{errors.class}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <select
                      className="form-select"
                      id="section"
                      name="section"
                      value={section}
                      onChange={handleSection}
                    >
                      <option value="">Select Section</option>
                      <option value="All">All</option>
                      <option value="A">A</option>
                      <option value="B">B</option>
                      <option value="C">C</option>
                      <option value="D">D</option>
                      <option value="E">E</option>
                    </select>
                    <label htmlFor="section" className=" floatinginput required">
                      Section
                    </label>
                    {errors.section && <span className="error ">{errors.section}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="ContactNumber"
                      id="ContactNumber"
                      className="form-control"
                      value={ContactNumber}
                      onChange={handleContactNumber}
                      placeholder="Enter the Roll Number"
                    />
                    <label htmlFor="ContactNumber" className=" floatinginput required">
                      Contact Number
                    </label>
                    {errors.ContactNumber && <span className="error ">{errors.ContactNumber}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="AlternativeContactNumber"
                      id="AlternativeContactNumber"
                      className="form-control"
                      value={AlternativeContactNumber}
                      onChange={handleAlternativeContactNumber}
                      placeholder="Enter the Roll Number"
                    />
                    <label htmlFor="AlternativeContactNumber" className=" floatinginput">
                      Alternative Contact Number
                    </label>
                    {errors.AlternativeContactNumber && (
                      <span className="error ">{errors.AlternativeContactNumber}</span>
                    )}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="EmailID"
                      id="EmailID"
                      className="form-control"
                      defaultValue={EmailID}
                      onChange={handleEmailID}
                      placeholder="Email ID"
                    />
                    <label htmlFor="EmailID" className="floatinginput required">
                      Email ID
                    </label>
                    {errors.EmailID && <span className="error ">{errors.EmailID}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <input
                      type="text"
                      name="Address"
                      id="Address"
                      className="form-control"
                      defaultValue={Address}
                      onChange={handleAddress}
                      placeholder="Email ID"
                    />
                    <label htmlFor="Address" className=" floatinginput required">
                      Address
                    </label>
                    {errors.Address && <span className="error ">{errors.Address}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <select
                      className="form-select"
                      id="State"
                      name="State"
                      value={State}
                      onChange={handleState}
                    >
                      <option value="">Select State</option>
                      {stateOptions.map((e, i) => (
                        <option key={e.Id} value={e.Id}>
                          {e.stateNConsti}
                        </option>
                      ))}
                    </select>
                    <label htmlFor="State" className=" floatinginput required">
                      State
                    </label>
                    {errors.State && <span className="error">{errors.State}</span>}
                  </div>
                </div>
                <div className="col-md-4 mb-3">
                  <div className="form-floating">
                    <select
                      className="form-select"
                      id="District"
                      name="District"
                      value={District}
                      onChange={handleDistrict}
                    >
                      <option value="">Please Select</option>
                      {districtOptions.map((e, i) => (
                        <option key={i} value={e.Id}>
                          {e.stateNConsti}
                        </option>
                      ))}
                    </select>
                    <label htmlFor="District" className=" floatinginput required">
                      District
                    </label>
                    {errors.District && <span className="error">{errors.District}</span>}
                  </div>
                </div>
                <div className="col-12 text-center">
                  <button className="shadow-lg rounded p-2 lq-red-color border-0" type="submit">
                    SUBMIT
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
export default YourComponent
