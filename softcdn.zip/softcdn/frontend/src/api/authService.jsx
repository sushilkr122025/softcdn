import apiClient from './apiService'

export const loginUser = async (email, password) => {
  // const response = await apiClient.post('/auth/login', { email, password }, { withCredentials: true })
  const response = await apiClient.post('/auth/login', { email, password })
  return response.data
}
