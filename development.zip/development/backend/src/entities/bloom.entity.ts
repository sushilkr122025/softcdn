import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'bloom' })
export class Bloom {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  taxonomy!: string;

  @Column({ type: 'char', length: 5, default: 'I' })
  dmlType!: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdate!: Date;
}
