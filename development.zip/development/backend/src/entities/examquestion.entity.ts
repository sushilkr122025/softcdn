import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('examquestion')
export class ExamQuestion {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'int', nullable: true })
  paperId!: number;

  @Column({ type: 'int', nullable: true })
  questionId!: number;

  @Column({ type: 'int', nullable: true })
  sequence!: number;

  @Column({ type: 'int', nullable: true })
  marks!: number;

  @Column({ type: 'int', default: null })
  section!: number;

  @Column({ type: 'int', default: null })
  subOf!: number;

  @Column({ type: 'varchar', length: 10, nullable: true })
  connector!: string;

  @Column({ type: 'boolean', default: false, nullable: true })
  isSub!: string;

  @Column({ type: 'json', nullable: true })
  ui!: object | null;

  @Column({ type: 'varchar', length: 20, nullable: true })
  queslabel!: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  contextLabel!: string;

  @Column({ type: 'varchar', length: 250, nullable: true })
  contextTitle!: string;

  @Column({ type: 'varchar', length: 250, nullable: true })
  contextSubTitle!: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;
}
