import apiClient from './apiService'
class ReportServices{
    getAnalyticsReport = async (fdata) => {
    try {
      const response = await apiClient.get('/report/analytics', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  getPrincipalAnalytics = async (fdata) => {
    try {
      const response = await apiClient.get('/report/principal', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
}

export default new ReportServices()