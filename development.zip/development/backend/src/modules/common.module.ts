import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommonService } from '../services/common.service';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { Questions } from '../entities/questions.entity';
import { QuestionsMarkingSchemeHistory } from '../entities/question.markscheme.history.entity';
import { QuestionRule } from '../entities/question.rule.entity';
import { QuestionsHistory } from '../entities/questions.history.entity';
import { CurriculumGoal } from '../entities/curriculum.goal.entity';
import { QuestionsMarkingScheme } from '../entities/question.markscheme.entity';
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Questions,
      QuestionIdTracker,
      QuestionsHistory,
      QuestionsMarkingSchemeHistory,
      QuestionRule,
      CurriculumGoal,
      QuestionsMarkingScheme,
    ]),
  ],
  providers: [CommonService],
  exports: [CommonService],
})
export class CommonModule {}
