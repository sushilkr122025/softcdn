import {
  Controller,
  Get,
  Res,
  Req,
  Param,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { AppService } from './app.service';
import { Response } from 'express';
import { LookupService } from './services/lookup.service';
import { EncryptionService } from './services/encryption.service';
import { Request } from 'express';

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly lookupService: LookupService,
    private readonly encryptionService: EncryptionService
  ) {}

  @Get()
  getHello() {
    return { message: '404 not found' };
  }

  // company.controller.ts
  @Get('lookup/:slug')
  async lookup(
    @Param('slug') slug: string,
    @Res({ passthrough: true }) res: Response
  ): Promise<any> {
    console.log('Company slug:', slug);
    const result = await this.lookupService.findBySlug(slug);
    // console.log('Company result:', result);
    if (!result) throw new NotFoundException('Company not found');
    const { company, school } = result;
    const encrypted = this.encryptionService.encrypt(company.getlocation);
    res.cookie('companyToken', encrypted, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000,
    });

    return school;
  }

  @Get('company/me')
  async getCompanyInfo(@Req() req: Request): Promise<any> {
    const token = req.cookies['companyToken'];
    if (!token) throw new UnauthorizedException();
    const decryptedSlug = this.encryptionService.decrypt(token);
    if (!decryptedSlug) throw new UnauthorizedException('Invalid token');
    // console.log('Decrypted controller verify slug:', decryptedSlug);
    const result = await this.lookupService.findBySlug(decryptedSlug);
    if (!result) throw new NotFoundException('Company not found');
    const { company, school } = result;
    // console.log('Decrypted controller verify company:', company.getlocation);

    if (!company) throw new NotFoundException();
    return school;
  }
}
