import React, { useEffect, useState } from "react";
import './Marksheet.css';

const Marksheet = () => {
  const [answers, setAnswers] = useState({});
  const [noOfQuestions, setNoOfQuestions] = useState(30);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const raw = urlParams.get("data");
    console.log(raw);
    
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        console.log(parsed);
        
        // The data might come as { answers: [...] } or as the array itself
        const dataArray = Array.isArray(parsed)
          ? parsed
          : parsed.answers || [];

        const tempAnswers = {};
        dataArray.forEach((item) => {
          // Each item has `question` (number) and `prediction` (string)
          const qNum = item.question;
          const key = `Q${qNum}`;
          if (qNum >= 1 && qNum <= noOfQuestions) {
            tempAnswers[key] = {
              value: item.prediction,
              review: item.Review || false,
            };
          }
        });
        setAnswers(tempAnswers);
      } catch (e) {
        console.error("Invalid data:", e);
      }
    }
  }, [noOfQuestions]); // Re-run if question count changes

  // Build question labels
  const questions = Array.from({ length: noOfQuestions }, (_, i) => `Q${i + 1}`);
  const columns = Math.ceil(noOfQuestions / 10);
  const columnIndices = Array.from({ length: columns }, (_, i) => i);
  const handleChange = (e, questionKey) => {
    setAnswers((prev) => ({
      ...prev,
      [questionKey]: {
        ...prev[questionKey],
        value: e.target.value,
      },
    }));
  };


  return (
    <div className="marksheet-container">
      <h2>ABCD SCHOOL MARKSHEET</h2>
      <label>
        Number of Questions:
        <input type="number" className="w-25 mb-3" value={noOfQuestions} onChange={(e) => setNoOfQuestions(Number(e.target.value) || 0)} />
      </label>

      <div className="info-section">
        <div>
          <label>Student Name:</label>
          <input type="text" />
        </div>
        <div className="row-info">
          <div>
            <label>Class:</label>
            <input type="text" />
          </div>
          <div>
            <label>Sec:</label>
            <input type="text" />
          </div>
          <div>
            <label>Roll No:</label>
            <input type="text" />
          </div>
        </div>
        <div>
          <label>Subject:</label>
          <input type="text" />
        </div>
      </div>

      <div className="questions-grid">
        {columnIndices.map((col) => (
          <div key={col} className="column">
            {questions.slice(col * 10, col * 10 + 10).map((q) => (
              <div className="question-box" key={q}>
                <span>{q}:</span>
                <input className={`square-box ${answers[q]?.review ? 'review-box' : ''}`} type="text" value={answers[q]?.value || ''} onChange={(e) => handleChange(e, q)} />
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marksheet;
