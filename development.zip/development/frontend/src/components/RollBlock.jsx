import { useEffect, useState, useMemo } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import './RollBlock.css'
import QuestionServices from '../api/QuestionServices'
import CustomDropdown from './layout/CustomDropdown'
const RollBlock = () => {
  const navigate = useNavigate()
  const { paperId, section } = useParams()

  const [examDetail, setExamDetail] = useState(null)
  const [allStudents, setAllStudents] = useState([])
  const [selectedSection, setSelectedSection] = useState('')
  const [quesDetailData, setQuesDetailData] = useState([])
  const [idArr, setIdArr] = useState([])
  const [selectedBox, setSelectedBox] = useState([])
  const [result, setResult] = useState(false)
  const [openKey, setOpenKey] = useState("");
  /* ================= FETCH EXAM DETAIL ================= */

  useEffect(() => {
    if (!paperId) return

    const fetchExamDetail = async () => {
      try {
        const res = await QuestionServices.getPaperById({ id: paperId })
        // console.log('rest', res);
        setExamDetail(res)
      } catch (err) {
        console.error('Failed to fetch exam detail:', err)
      }
    }

    fetchExamDetail()
  }, [paperId])

  /* ================= FETCH STUDENTS + QUESTIONS ================= */

  useEffect(() => {
    if (!examDetail) return

    const fetchData = async () => {
      try {
        const res = await QuestionServices.GetStudentByClass({
          class: examDetail.class,
          section: examDetail.section,
          paperId: examDetail.paperId,
        })

        setAllStudents(res.studentData)
        setQuesDetailData(res.questionData)
        console.log('res', res);


        const firstSec = [...new Set(res.studentData.map((s) => s.section))][0] || ''

        const initialSection = section || firstSec;
        setSelectedSection(initialSection);
      } catch (error) {
        console.error('Student fetch failed:', error)
      }
    }

    const answeredCheck = async () => {
      try {
        const res = await QuestionServices.CheckStudentAnswered({
          paperId: examDetail.paperId,
        })

        const studentIds = res.data.map((item) => item.id)
        setIdArr(studentIds)
      } catch (error) {
        console.error('Answered check failed:', error)
      }
    }

    fetchData()
    answeredCheck()
  }, [examDetail])

  /* ================= DERIVED DATA ================= */

  const sectionData = useMemo(() => [...new Set(allStudents.map((s) => s.section))], [allStudents])

  const studentData = useMemo(
    () => allStudents.filter((s) => s.section === selectedSection),
    [allStudents, selectedSection]
  )

  useEffect(() => {
    const allAnswered =
      allStudents.length > 0 && allStudents.every((student) => idArr.includes(student.Id))

    setResult(allAnswered)
  }, [idArr, allStudents])

  /* ================= HANDLERS ================= */

  const handleSection = (val) => {
    setSelectedSection(val);
    navigate(`/rollblock/${paperId}/${val}`, { replace: true });
  };

  const handleClick = (id, roll) => {
    if (idArr.includes(id)) return

    const student = studentData.find((s) => s.rollNo === roll)
    if (!student) return

    const examHeader = {
      ...student,
      paperId: examDetail.paperId,
      class: examDetail.class,
      subject: examDetail.subjectName,
      Rollsection: selectedSection,
      examCode: examDetail.examCode,
      examDate: examDetail?.examDate?.split("T")[0],
    };

    /* ===== MOBILE FLOW ===== */
    if (window.ReactNativeWebView) {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'openCamera',
          rollNumber: roll,
          header: examHeader,
          body: quesDetailData,
        })
      )
    } else {
      /* ===== WEB FLOW ===== */
      navigate('/marksheet', {
        state: {
          header: examHeader,
          body: quesDetailData,
        },
      })
    }

    setSelectedBox((prev) =>
      prev.includes(roll) ? prev.filter((item) => item !== roll) : [...prev, roll]
    )
  }

  if (!examDetail) return null

  const createResult = async () => {
    try {
      const response = await QuestionServices.CreateResult({
        paperid: examDetail.paperId,
        class: examDetail.class,
        // section: selectedSection,
      })
      console.log('Create Result Response:', response)
    } catch (error) {
      console.error('Error creating result:', error)
    }
  }

  /* ================= UI ================= */

  return (
    <div className="rollblock-page p-3">
      <div className="container">
        <div className="d-flex align-items-center flex-wrap gap-2 mb-4">
          <h4 className="mb-0 rollblock-title">{examDetail.name}</h4>
          <h6 className="mb-0 text-muted rollblock-code">{examDetail.examCode}</h6>
        </div>

        <div className="row align-items-center justify-content-between mb-4">
          <div className="col-12 col-md-auto mb-3 mb-md-0">
            <div className="mb-0 fw-bold pagetitle">Class: {examDetail.class}</div>
          </div>

          <div className="col-12 col-md-auto">
            <div className="d-flex align-items-center justify-content-md-end flex-wrap gap-2">
              <CustomDropdown
                dropdownKey="rollSection"
                placeholder="Select Section"
                openKey={openKey}
                setOpenKey={setOpenKey}
                value={selectedSection}
                disabled={sectionData.length === 1}
                options={sectionData.map((sec) => ({
                  value: sec,
                  label: sec,
                }))}
                onChange={(val) => handleSection(val)}
              />
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-12">
            <div className="studentRollNotable">
              {studentData.map((student, i) => (
                <div
                  key={i}
                  className={`selectfield ${idArr.includes(student.Id) ? 'active' : ''}`}
                  onClick={() => handleClick(student.Id, student.rollNo)}
                >
                  <span className="studentRollNo">{student.rollNo}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="col-12 text-center mt-4">
            <button className="btn btn-primary h45" onClick={createResult}>
              Create Result
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RollBlock