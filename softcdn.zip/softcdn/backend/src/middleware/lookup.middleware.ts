import {
  Injectable,
  NestMiddleware,
  UnauthorizedException,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { LookupService } from '../services/lookup.service';
import { EncryptionService } from '../services/encryption.service';

@Injectable()
export class LookupMiddleware implements NestMiddleware {
  constructor(
    private readonly lookupService: LookupService,
    private readonly encryptionService: EncryptionService
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const token = req.cookies['companyToken'];
    if (!token) throw new UnauthorizedException('Missing company token');

    try {
      const slug = this.encryptionService.decrypt(token);
      if (!slug) throw new UnauthorizedException('Invalid token');
      // console.log('Decrypted middleware slug:', slug);
      const company = await this.lookupService.findBySlug(slug);
      if (!company) throw new UnauthorizedException('Company not found');
      // console.log('Decrypted middleware company:', company.school.schoolid);
      if (!company) throw new UnauthorizedException('Invalid company');
      req['company'] = company.school.tenantid;
      req['schoolname'] = company.school.schoolname;
      next();
    } catch (err) {
      throw new UnauthorizedException('Invalid or expired company token');
    }
  }
}
