const LOCAL_KEY = 'logged'

export const getLocal = () => localStorage.getItem(LOCAL_KEY)
export const setLocal = (local) => localStorage.setItem(LOCAL_KEY, local)
export const removeLocal = () => localStorage.removeItem(LOCAL_KEY)

// Clear
export const clearAll = () => {
  removeLocal()
}
