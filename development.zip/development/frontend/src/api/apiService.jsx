import axios from 'axios';
const API_BASE_URL = import.meta.env.VITE_APIHOST;
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// Response interceptor
apiClient.interceptors.response.use(
  res => res,
  async err => {
    if (err.response?.status === 403) {
      // Token expired → refresh
      const res = await apiClient.get('/csrf-token');
      const token = res.data.csrfToken;

      apiClient.defaults.headers.common['X-CSRF-Token'] = token;
      err.config.headers['X-CSRF-Token'] = token;

      return apiClient(err.config);
    }

    if (err.response?.status === 401) {
      return Promise.reject(err);
    }

    console.error(err);
    return Promise.reject(err);
  }
);

export default apiClient;
