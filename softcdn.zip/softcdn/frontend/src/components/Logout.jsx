// Logout.js
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import config from '../../../config'

const Logout = () => {
  const navigate = useNavigate()

  axios.get(config.apihost + '/logout').then((res) => {
    if (res.data.Status === 'Success') {
      sessionStorage.clear()
      document.cookie = 'role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/'
      document.cookie = 'access=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/'
      navigate('/login')
    }
  })

  return null // Return null to avoid rendering anything
}

export default Logout
