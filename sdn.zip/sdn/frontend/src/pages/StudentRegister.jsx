import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Row, Col, Button, Form } from 'react-bootstrap'
import { formatDate } from '../utils/util'
import apiClient from '../api/apiService'
import { useNavigate } from 'react-router-dom'
// import '../App.css'

const StudentRegister = () => {
  const [sectionData, setSectionData] = useState([])
  const [classOptions, setClassOptions] = useState([])
  const [stateOptions, setStateOptions] = useState([])
  const [districtOptions, setDistrictOptions] = useState([])
  // const [state, setState] = useState('')

  const navigator = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    mode: 'onChange',
  })

  const [userData] = useState()
  const parameters = new URLSearchParams(window.location.search)
  const updateId = parameters.get('id')

  const fetchUserData = async () => {
    if (updateId) {
      try {
        // Fetch data logic goes here
      } catch (error) {
        console.error(error.message)
      }
    }
  }

  useEffect(() => {
    fetchUserData()
  }, [updateId])

  useEffect(() => {
    apiClient
    .get('/store/section')
      .then((response) => {
        setSectionData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        setClassOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching classes:', error)
      })

    apiClient
      .get('/store/statesndistrict',{ params:{ stateId: '0' } })
      .then((response) => {
        setStateOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }, [])

  const handleState = (e) => {
    // setState(e.target.value)
    // console.log(e.target.value)

    apiClient
    .get('/store/statesndistrict',{ params:{ stateId: e.target.value }})
      .then((response) => {
        console.log(response.data)
        setDistrictOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }

  const onSubmit = async (data) => {
    console.log('Form Data:', data)
    try {
      if (data.id) {
        const response = apiClient.put(`/user/student/${data.id}`, data)

        if (response.status === 200) {
          navigator('/dashboard')
        } else {
          console.error('Failed to update data.')
        }
      } else {
        const response = await apiClient.post(`/user/student`, data)

        if (response.status === 200) {
          console.log('Data inserted successfully!')
          navigator('/dashboard')
        } else {
          console.error('Failed to insert data.')
        }
      }
    } catch (error) {
      console.error('An error occurred:', error)
    }
  }

  if (updateId && !userData) {
    return <div>Loading...</div>
  }

  // const Status = ['Permanent', 'Part Time', 'Internship', 'Bond based']
  // const Role = ['Admin', 'Teacher', 'co-ordinator']

  const handleselect = (e) => {
    const selectEl = e.target
    // selectEl.classList.remove('is-invalid')

    const formFloatingEl = selectEl.closest('.form-floating')
    if (selectEl && formFloatingEl) {
      formFloatingEl.querySelector('label').style.transform = 'scale(0.85) translateY(-3.1rem)'
    }
  }

  return (
    <Row className="container-box p-0 pt-5 p-sm-2 mt-5">
      <Col lg={6} className="col-10 mx-auto">
        <Form className="form-box mb-5" onSubmit={handleSubmit(onSubmit)}>
          <div className="form-header mb-5">
            <h2>Student Registration</h2>
          </div>
          <Row className="form-grid g-4">
            <Col md={6}>
              <Form.Group controlId="name" className="form-floating">
                <Form.Control
                  type="text"
                  placeholder="User Name"
                  className={`${errors.name ? 'is-invalid' : ''}`}
                  {...register('name', {
                    required: 'Name is required',
                    pattern: {
                      value: /^[A-Za-z\s]+$/,
                      message: 'Only alphabetic characters are allowed',
                    },
                  })}
                />
                <Form.Label>Name</Form.Label>
                {errors.Name && (
                  <div className="invalid-feedback d-block">{errors.name.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="RollNo" className="form-floating">
                <Form.Control
                  type="text"
                  placeholder="Enter the Roll Number"
                  {...register('rollNo', { required: 'Roll Number is required' })}
                  className={`${errors.rollNo ? 'is-invalid' : ''}`}
                />
                <Form.Label>RollNo</Form.Label>
                {errors.rollNo && (
                  <div className="invalid-feedback d-block">{errors.rollNo.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="className" className="form-floating">
                <Form.Select
                  {...register('class', {
                    required: 'Class is required',
                    onChange: (e) => {
                      handleselect(e)
                    },
                  })}
                  // onChange={handleselect}
                  className={`${errors.class ? 'is-invalid' : ''}`}
                >
                  <option value="">Select Class</option>
                  {classOptions.map((e, i) => (
                    <option key={i} value={e.class}>
                      {e.class}
                    </option>
                  ))}
                </Form.Select>
                <Form.Label>Class</Form.Label>
                {errors.class && (
                  <div className="invalid-feedback d-block">{errors.class.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="section" className="form-floating">
                <Form.Select
                  {...register('section', { required: 'Section is required' })}
                  // onChange={handleselect}
                  className={`${errors.section ? 'is-invalid' : ''}`}
                >
                  <option value="">Select Section</option>
                  {sectionData.map((e, i) => (
                    <option key={i} value={e.section}>
                      {e.section}
                    </option>
                  ))}
                </Form.Select>
                <Form.Label>Section</Form.Label>
                {errors.section && (
                  <div className="invalid-feedback d-block">{errors.section.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="gender" className="form-floating">
                <Form.Select
                  {...register('gender', { required: 'Gender is required' })}
                  onChange={handleselect}
                  className={`${errors.Gender ? 'is-invalid' : ''}`}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="May not prefer">May Not Prefer</option>
                </Form.Select>
                <Form.Label>Gender</Form.Label>
                {errors.gender && (
                  <div className="invalid-feedback d-block">{errors.gender.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="dob" className="form-floating">
                <Form.Control
                  type="date"
                  {...register('dateOfBirth', { required: 'Date of Birth is required' })}
                  className={errors.dateOfBirth ? 'is-invalid' : ''}
                  defaultValue={userData?.dob && formatDate(userData.dob)}
                />
                <Form.Label>Date of Birth</Form.Label>
                {errors.dateOfBirth && (
                  <div className="invalid-feedback d-block">{errors.dateOfBirth.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="EmailID" className="form-floating">
                <Form.Control
                  type="email"
                  defaultValue={userData?.emailId}
                  {...register('emailId', { required: 'Email ID is required' })}
                  className={errors.emailId ? 'is-invalid' : ''}
                />

                <Form.Label>Email ID</Form.Label>
                {errors.emailId && (
                  <div className="invalid-feedback d-block">{errors.emailId.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="FatherName" className="form-floating">
                <Form.Control
                  type="text"
                  placeholder="Enter the Father's Name"
                  {...register('fatherName', {
                    required: 'Father Name is required',
                    pattern: {
                      value: /^[A-Za-z\s]+$/,
                      message: 'Only alphabetic characters are allowed',
                    },
                  })}
                  className={errors.fatherName ? 'is-invalid' : ''}
                />

                <Form.Label>Father Name</Form.Label>
                {errors.fatherName && (
                  <div className="invalid-feedback d-block">{errors.fatherName.message}</div>
                )}
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="MotherName" className="form-floating">
                <Form.Control
                  type="text"
                  placeholder="Enter the Mother's Name"
                  {...register('motherName', {
                    required: 'Mother Name is required',
                    pattern: {
                      value: /^[A-Za-z\s]+$/,
                      message: 'Only alphabetic characters are allowed',
                    },
                  })}
                  className={errors.motherName ? 'is-invalid' : ''}
                />

                <Form.Label>MotherName</Form.Label>
                {errors.motherName && (
                  <div className="invalid-feedback d-block">{errors.motherName.message}</div>
                )}
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="ContactNumber" className="form-floating">
                <Form.Control
                  type="text"
                  maxLength={10}
                  placeholder="Enter the Contact Number"
                  {...register('contactNumber', {
                    required: 'Contact Number is required',
                    pattern: {
                      value: /^[0-9]{10}$/,
                      message: 'Number must be 10 digits and Numerical',
                    },
                  })}
                  className={errors.contactNumber ? 'is-invalid' : ''}
                />

                <Form.Label>ContactNumber</Form.Label>
                {errors.ContactNumber && (
                  <div className="invalid-feedback d-block">{errors.contactNumber.message}</div>
                )}
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="AlternativeContactNumber" className="form-floating">
                <Form.Control
                  type="text"
                  maxLength={10}
                  placeholder="Enter the Alternative Contact Number"
                  {...register('alternativeContactNumber', {
                    pattern: {
                      value: /^[0-9]{10}$/,
                      message: 'Number must be 10 digits and numerical',
                    },
                  })}
                />

                <Form.Label>AlternativeContactNumber</Form.Label>
                {errors.alternativeContactNumber && (
                  <div className="invalid-feedback d-block">
                    {errors.alternativeContactNumber.message}
                  </div>
                )}
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="Address" className="form-floating">
                <Form.Control
                  type="text"
                  placeholder="Enter the Address"
                  {...register('address', { required: 'Address is required' })}
                  className={errors.address ? 'is-invalid' : ''}
                />
                <Form.Label>Address</Form.Label>
                {errors.address && (
                  <div className="invalid-feedback d-block">{errors.address.message}</div>
                )}
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="State" className="form-floating">
                <Form.Control
                  as="select"
                  // onChange={handleState}
                  {...register('state', {
                    required: 'State is required',
                    onChange: (e) => {
                      handleState(e)
                    },
                  })}
                  className={errors.state ? 'is-invalid' : ''}
                >
                  <option value="">Select State</option>
                  {stateOptions.map((e, i) => (
                    <option key={i} value={e.id}>
                      {e.stateNConsti}
                    </option>
                  ))}
                </Form.Control>

                <Form.Label>State</Form.Label>
                {errors.state && (
                  <div className="invalid-feedback d-block">{errors.state.message}</div>
                )}
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group controlId="District" className="form-floating">
                <Form.Control
                  as="select"
                  {...register('district', { required: 'District is required' })}
                  className={errors.district ? 'is-invalid' : ''}
                >
                  <option value="">Select District</option>
                  {districtOptions.map((e, i) => (
                    <option key={i} value={e.id}>
                      {e.stateNConsti}
                    </option>
                  ))}
                </Form.Control>

                <Form.Label>District</Form.Label>
                {errors.district && (
                  <div className="invalid-feedback d-block">{errors.district.message}</div>
                )}
              </Form.Group>
            </Col>

            {/* Submit Button */}
            <div className="text-center mt-3">
              <Button variant="primary" size="lg" disabled={isSubmitting} type="submit">
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </Button>
            </div>
          </Row>
        </Form>
      </Col>
    </Row>
  )
}

export default StudentRegister
