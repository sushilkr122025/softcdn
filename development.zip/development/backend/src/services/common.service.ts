import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { QuestionsMarkingSchemeHistory } from '../entities/question.markscheme.history.entity';
import { QuestionRule } from '../entities/question.rule.entity';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { Questions } from '../entities/questions.entity';
import { QuestionsHistory } from '../entities/questions.history.entity';
import { Subject } from '../entities/subject.entity';
import { DataSource, In, Repository } from 'typeorm';
import { CurriculumGoal } from '../entities/curriculum.goal.entity';
import { QuestionsMarkingScheme } from '../entities/question.markscheme.entity';

interface QuestionData {
  editId?: number;
  subject: number;
  std: number;
  question: string;
  tenantid: number;
  tId: number;
  contextid: number;
  contextstatus: string;
  subdomain: number;
  difficulty: string;
  cg: number;
  competency: string;
  cgtext: number;
  competencytext: string;
  quesType: string;
  corrAns: string;
  optA: string;
  optB: string;
  optC: string;
  optD: string;
  optAimg?: string;
  optBimg?: string;
  optCimg?: string;
  optDimg?: string;
  image?: string;
  chapter: string;
  marks: number;
  user: number;
}
@Injectable()
export class CommonService {
  constructor(
    @InjectRepository(QuestionsHistory)
    private questionHistoryRepository: Repository<QuestionsHistory>,
    @InjectRepository(QuestionsMarkingScheme)
    private questionsMScRepository: Repository<QuestionsMarkingScheme>,
    @InjectRepository(QuestionsMarkingSchemeHistory)
    private questionsMScHistory: Repository<QuestionsMarkingSchemeHistory>,
    @InjectRepository(QuestionRule)
    private questionRuleRepository: Repository<QuestionRule>,
    @InjectRepository(CurriculumGoal)
    private cGRepository: Repository<CurriculumGoal>,
    private dataSource: DataSource
  ) {}

  async transferQuestion(qid: number, tenantid: string): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        const q = await this.questionHistoryRepository.findOneBy({
          id: qid,
        });

        if (!q) {
          throw new Error('Missing required question fields');
        }

        const trackerRepo = manager.getRepository(QuestionIdTracker);
        const questionRepo = manager.getRepository(Questions);
        const subjectRepo = manager.getRepository(Subject);

        const getsubject = await subjectRepo.findOne({
          where: { id: q?.subject },
        });

        if (!getsubject) {
          throw new NotFoundException('Subject not found');
        }
        let shortsubject = getsubject.subject.substring(0, 2).toUpperCase();
        if (getsubject.subject === 'Social Science') {
          shortsubject = 'SS';
        }

        const cgtextObj = await this.cGRepository.findBy({
          id: In([q.cg, q.competency]),
        });

        let cgtext;
        let competencytext;
        cgtextObj.forEach((element) => {
          if (element.id === q.cg) {
            cgtext = element.cgNo;
          }
          if (element.id === Number(q.competency)) {
            competencytext = element.cgNo;
          }
        });

        const year = new Date().getFullYear();
        const subject = getsubject.id;
        const className = q.class;
        const tenantId = tenantid;

        let tracker = await trackerRepo.findOne({
          where: {
            tenantId: tenantid,
            subject: String(subject),
            class: String(className),
            year,
            cg: String(q.cg),
            competency: String(q.competency),
          },
        });

        if (!tracker) {
          tracker = trackerRepo.create({
            tenantId: tenantid,
            subject: String(subject),
            class: String(className),
            cg: String(q.cg),
            competency: String(q.competency),
            year,
            currentCounter: 1,
          });
        } else {
          tracker.currentCounter += 1;
        }

        const paddedCounter = String(tracker.currentCounter).padStart(4, '0');
        const customId = `${year}-${shortsubject}-G${className}-${competencytext}#${paddedCounter}`;

        await trackerRepo.save(tracker);

        const Qdata = {
          tId: q.tId,
          contextid: q.contextid,
          contextstatus: q.contextstatus,
          subject,
          class: className,
          subDomain: q.subDomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          bloomTexonomy: q.bloomTaxonomy,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.correctAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          tenantid: tenantId,
          createdBy: 'bank',
          customId,
          marks: q.marks,
          descriptors: q.descriptors,
          status: 'APPROVED',
          // file paths could go here
        };
        // const newQuestion = questionRepo.create(Qdata);
        // await this.notificationService.sendToUser(tenantId, userId, {
        //     type: 'ORDER_PLACED',
        //     message: `Your order #${orderData.id} has been placed successfully.`,
        //   });
        const createdQuestion = await questionRepo.save(Qdata);
        // Update history with new question ID
        const savedid = createdQuestion.id;
        const getmarkscheme = await this.questionsMScHistory.findOneBy({
          qId: q.id,
          revision: q.revision,
        });
        if (getmarkscheme) {
          const mSdata = {
            qId: savedid,
            expectedFromat: getmarkscheme.expectedFromat,
            markingScheme: getmarkscheme.markingScheme,
            dmlType: 'I',
          };
          const newMSc = this.questionsMScRepository.create(mSdata);
          await this.questionsMScRepository.save(newMSc);
          q.qId = savedid;
          q.status = 'TRANSFERRED';
          await this.questionHistoryRepository.save(q);
        }

        return savedid;
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async rejectQuestion(qId: number): Promise<void> {
    try {
      await this.dataSource.transaction(async (manager) => {
        const q = await this.questionHistoryRepository.findOneBy({
          id: qId,
        });
        if (!q) {
          throw new NotFoundException('Question not found');
        }
        q.status = 'REJECTED';
        await this.questionHistoryRepository.save(q);
      });
    } catch (error) {
      console.error('Error rejecting question:', error);
      throw new Error('Failed to reject question');
    }
  }

  async reviseQuestion(qId: number): Promise<void> {
    try {
      await this.dataSource.transaction(async () => {
        const q = await this.questionHistoryRepository.findOneBy({
          id: qId,
        });
        if (!q) {
          throw new NotFoundException('Question not found');
        }
        q.status = 'REVISING';
        await this.questionHistoryRepository.save(q);
      });
    } catch (error) {
      console.error('Error rejecting question:', error);
      throw new Error('Failed to reject question');
    }
  }

  /*
  async createQuestion(q: QuestionData): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }
        let version = 0;
        if (q.editId) {
          const existing = await this.questionHistoryRepository.findOneBy({
            id: q.editId,
          });
          if (existing) {
            const { id: _, ...copy } = existing;
            copy.trailId = existing.id;
            const inserted = await this.questionHistoryRepository.save(copy);
            version = inserted.revision;
          }
        }

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          contextid: q.contextid,
          contextstatus: q.contextstatus,
          subject: q.subject,
          class: q.std,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          revision: 1 + version,
          marks: q.marks,
          trailId: 0,
          createdBy: 'bank',
        };
        const result = await this.questionHistoryRepository.upsert(Qdata, [
          'id',
        ]);
        if (!result) {
          throw new NotFoundException('Failed to create question history');
        }
        // Qdata['historyId'] = result.identifiers[0]?.id;
        const qid = result.identifiers[0]?.id;
        const getApprovalIds = await this.questionRuleRepository.findOneBy({
          userId: q.user,
          subjectId: String(q.subject),
          classId: String(q.std),
          dmlType: 'I',
        });
        if (getApprovalIds && getApprovalIds.teachersId) {
          const setapprovers = await this.questionHistoryRepository.findOneBy({
            id: qid,
          });
          if (setapprovers) {
            setapprovers.approverId = getApprovalIds.teachersId;
            await this.questionHistoryRepository.save(setapprovers);
          }
        }
        return {
          id: qid,
          message: 'Approval request sent successfully to approver(s)',
        };
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }*/
}
