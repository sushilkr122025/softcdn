import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { OcrService } from '../services/ocr.service';
import { OcrController } from '../controllers/ocr.controller';

@Module({
  imports: [HttpModule],
  providers: [OcrService],
  controllers: [OcrController],
})
export class OcrModule {}
