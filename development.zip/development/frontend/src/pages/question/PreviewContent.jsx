import React, { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import QuestionServices from "../../api/QuestionServices";
import { FiPrinter } from "react-icons/fi";
import MarkingScheme from "./MarkingScheme";
import { PiBookOpenText } from "react-icons/pi";
import { MdOutlinePreview } from "react-icons/md";

export default function PreviewContent({ questions: initialQuestions, generalDetails: initialGeneralDetails }) {
    const previewRef = useRef(null);
    const { paperId } = useParams();
    const [generalDetails, setgeneralDetails] = useState(initialGeneralDetails);
    const [questions, setquestions] = useState(initialQuestions || []);
    const [isActive, setIsActive] = useState(false);
    const [currentIds, setCurrentIds] = useState([]);

    useEffect(() => {
        if (initialQuestions && initialQuestions.length > 0) return;
        const getPaper = async () => {
            const payload = { paperId: Number(paperId), reqType: "paper" };
            const response = await QuestionServices.GetQuestionPaper(payload);
            if (response) {
                const rawSections = response.generalDetails?.sectionsData || [];
                let parsedSections = [];
                if (typeof rawSections === "string") {
                    try {
                        parsedSections = JSON.parse(rawSections);
                    } catch (e) {
                        console.error(e)
                        parsedSections = [];
                    }
                } else if (Array.isArray(rawSections)) { parsedSections = rawSections; }
                setgeneralDetails({ ...(response.generalDetails || {}), sectionsData: parsedSections, });
                setquestions(response.questions || []);
            }
        };
        getPaper();
    }, [initialQuestions, paperId]);
    useEffect(() => {
        const currentIds = questions.map(q => ({
            id: q.id,
            ...(q.sequence && { sequence: q.sequence }),
            ...(q.section && { section: q.section }),
            ...(q.connector && { connector: q.connector }),
            ...(q.isSub && { isSub: q.isSub }),
            ...(q.subOf && { subOf: q.subOf }),
            ...(q.contextLabel && { contextLabel: q.contextLabel }),
            ...(q.queslabel && { queslabel: q.queslabel }),
        }));
        setCurrentIds(currentIds);
    }, [questions]);

    const sanitizeHtml = (html) => {
        if (!html) return "";
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        html = html.replace(/font-size\s*:\s*[^;"]+;?/gi, "");
        html = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        return html;
    };

    const findImageSizing = (ui = {}, qId, kind, matchIndex, occIndex) => {
        if (!ui || !ui.imageSizes) return null;
        const sizes = ui.imageSizes;
        const qPrefix = `q-${qId}`;
        const candidates = [
            `${qPrefix}-${kind}-img-${matchIndex}`,
            `${qPrefix}-${kind}-img-${occIndex}`,
            `${qPrefix}-${kind}-text-img-${matchIndex}`,
            `${qPrefix}-${kind}-text-img-${occIndex}`,
            `${qPrefix}-text-img-${matchIndex}`,
            `${qPrefix}-text-img-${occIndex}`,
            `${qPrefix}-img-${matchIndex}`,
            `${qPrefix}-img-${occIndex}`,
            `${qPrefix}-${kind}-img-0`,
            `${qPrefix}-main`,
            `${qPrefix}-main-img-${matchIndex}`,
            `${qPrefix}-main-img-${occIndex}`,
        ];

        for (const c of candidates) {
            if (Object.prototype.hasOwnProperty.call(sizes, c)) return sizes[c];
        }

        const lowerKind = String(kind || "").toLowerCase();
        const keys = Object.keys(sizes);
        for (const k of keys) {
            if (!k.includes(qPrefix)) continue;
            const kl = k.toLowerCase();
            const matchesKind = lowerKind && kl.includes(lowerKind);
            const hasImgIdx = (matchIndex !== undefined && k.includes(`img-${matchIndex}`)) || (occIndex !== undefined && k.includes(`img-${occIndex}`));
            if (matchesKind && hasImgIdx) return sizes[k];
        }

        for (const k of keys) {
            if (!k.includes(qPrefix)) continue;
            if ((matchIndex !== undefined && k.includes(`img-${matchIndex}`)) || (occIndex !== undefined && k.includes(`img-${occIndex}`))) {
                return sizes[k];
            }
        }

        for (const k of keys) {
            if (k.includes(qPrefix) && k.toLowerCase().includes("img")) return sizes[k];
        }
        return null;
    };

    const renderHtmlWithImages = (html, qId, kind = "text", ui = {}) => {
        if (!html) return null;
        html = sanitizeHtml(html);
        const parts = [];
        let occCounter = 0;
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(html)) !== null) {
            const matchIndex = match.index;
            if (matchIndex > lastIndex) {
                const chunk = html.slice(lastIndex, matchIndex);
                parts.push(
                    <span key={`chunk-${qId}-${kind}-${lastIndex}`} dangerouslySetInnerHTML={{ __html: chunk }} />
                );
            }
            const src = match[1];
            const occIndex = occCounter++;
            const sizing = findImageSizing(ui, qId, kind, matchIndex, occIndex) || {};

            const widthVal = (sizing && (sizing.width === 0 || sizing.width)) ? Number(sizing.width) : undefined;
            const heightVal = (sizing && (sizing.height === 0 || sizing.height)) ? Number(sizing.height) : undefined;
            parts.push(
                <img key={`img-${qId}-${kind}-${matchIndex}-${occIndex}`} src={src} alt=""
                    style={{
                        width: widthVal !== undefined ? widthVal : undefined,
                        height: heightVal !== undefined ? heightVal : undefined,
                        margin: "5px 0",
                    }}
                />
            );

            lastIndex = imgRegex.lastIndex;
        }

        if (lastIndex < html.length) {
            const chunk = html.slice(lastIndex);
            parts.push(
                <div key={`chunk-${qId}-${kind}-${lastIndex}`} dangerouslySetInnerHTML={{ __html: chunk }} />
            );
        }
        return parts;
    };

    const getSectionNumberFromObj = (sec) => {
        if (!sec) return null;
        if (typeof sec === "number") return sec;
        if (typeof sec === "string") {
            const parts = String(sec).split("-");
            const last = parts[parts.length - 1];
            const num = Number(last);
            return Number.isFinite(num) ? num : null;
        }
        if (typeof sec === "object") {
            const possible = sec.id ?? sec.section;
            if (typeof possible === "number") return possible;
            if (typeof possible === "string") {
                const parts = String(possible).split("-");
                const last = parts[parts.length - 1];
                const num = Number(last);
                return Number.isFinite(num) ? num : sec.section ?? null;
            }
            return sec.section ?? null;
        }
        return null;
    };

    const optionLabelFromType = (type, idx) => {
        switch (type) {
            case "A":
                return String.fromCharCode(65 + idx);
            case "a":
                return String.fromCharCode(97 + idx);
            case "1":
                return idx + 1;
            case "i":
                return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][idx] || idx + 1;
            case "I":
                return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][idx] || idx + 1;
            default:
                return String.fromCharCode(65 + idx);
        }
    };

    const matchesSection = (qSection, secObj, secNumber) => {
        if (qSection === undefined || qSection === null || qSection === "") return false;
        if (String(qSection) === String(secObj?.id)) return true;
        if (String(qSection) === String(secNumber)) return true;
        const qNum = Number(qSection);
        if (!Number.isNaN(qNum) && Number.isFinite(qNum) && Number(qNum) === Number(secNumber)) return true;
        return false;
    };

    const getDisplayNumber = (qId) => {
        const idx = questions.findIndex(x => x.id === qId);
        if (idx === -1) return null;
        return questions.slice(0, idx + 1).filter((x) => !x.isSub && !x.isConnector && !x.isSection).length;
    };

    const getQuestionDisplayLabel = (q, displayNum) => {
        if (q && q.queslabel !== undefined && q.queslabel !== null) {
            const s = String(q.queslabel).trim();
            if (s !== "") return s;
        }
        return `Q${displayNum}`;
    };
    const isFirstQuestionForContext = (q) => {
        if (!q || !q.context) return false;
        const firstIdx = questions.findIndex(x => x.contextId === q.contextId && !x.isSub);
        const thisIdx = questions.findIndex(x => x.id === q.id);
        return firstIdx !== -1 && firstIdx === thisIdx;
    };

    const renderOptionsBlock = (optsArray, qId, ui = {}, effectiveOptionIdType = "A") => {
        if (!optsArray || optsArray.length === 0) return null;
        return (
            <div
                className="ps-5 ms-4"
                style={{
                    fontSize: `${ui.fontSize || 16}px`,
                    textAlign: ui.align || "left",
                    display: "flex",
                    flexDirection: ui.optionLayout === "vertical" ? "column" : "row",
                    flexWrap: ui.optionLayout === "horizontal" || ui.optionLayout === "two-column" ? "wrap" : "nowrap",
                    gap: ui.optionLayout === "horizontal" ? "40px" : "10px",
                }}>
                {optsArray.map((opt, idx) => {
                    const optionKind = `opt${String.fromCharCode(65 + idx)}`;
                    return (
                        <div key={`opt-${qId}-${idx}`} style={{ display: "flex", alignItems: "center", width: ui.optionLayout === "two-column" ? "45%" : "auto", minWidth: ui.optionLayout === "two-column" ? "200px" : "auto" }}>
                            <span className="fw-bold me-2">{optionLabelFromType(ui.optionIdType || effectiveOptionIdType, idx)}.</span>
                            <>{renderHtmlWithImages(opt, qId, optionKind, ui)}</>
                        </div>
                    );
                })}
            </div>
        );
    };

    const renderPreviewGrouped = () => {
        const sectionsArr = Array.isArray(generalDetails?.sectionsData) ? generalDetails.sectionsData : [];
        const rendered = [];

        const renderQuestionList = (list) => {
            const out = [];
            for (let i = 0; i < list.length; i++) {
                const q = list[i];
                const ui = (q.ui && typeof q.ui === "object") ? q.ui : {};
                const effectiveOptionIdType = ui.optionIdType || "A";
                const previewText = q.question ?? "";
                const previewOptions = [q.optA ?? "", q.optB ?? "", q.optC ?? "", q.optD ?? ""].filter((opt) => opt && String(opt).trim() !== "");
                const displayNum = getDisplayNumber(q.id) ?? questions.slice(0, i + 1).filter((x) => !x.isSub && !x.isConnector && !x.isSection).length;
                const qLabel = getQuestionDisplayLabel(q, displayNum);
                const subsForQ = questions.filter(x => x.isSub && x.subOf === q.id);
                if (q.connector && subsForQ.length > 0) {
                    out.push(
                        <div key={`q-${q.id}`} className="my-1">
                            <div className="d-flex justify-content-between my-1">
                                <div className="question-html mt-2 d-flex" style={{ fontSize: `${ui.fontSize || 16}px`, textAlign: ui.align || "left" }}>
                                    {!q.isSub ? (
                                        <div>
                                            {isFirstQuestionForContext(q) && q.context ? (
                                                <div className="context-html mb-2 d-flex">
                                                    <div className="d-flex">
                                                        <strong className="me-2 text-nowrap">{`Q-${q.contextLabel ?? displayNum}`}</strong>
                                                        <div>{renderHtmlWithImages(q.context, q.id, "context", ui)}</div>
                                                    </div>
                                                </div>
                                            ) : null}
                                            <div className="d-flex gap-1">
                                                <strong className="me-2">Q{qLabel}</strong>
                                                <div className="d-flex justify-content-between">
                                                    <div>{previewText ? renderHtmlWithImages(previewText, q.id, "text", ui) : null}</div>
                                                    {q.marks && <div className="ms-4 text-nowrap">({q.marks})</div>}
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="d-flex flex-column ps-3">
                                            <strong className="me-2">{qLabel}</strong>
                                            {previewText ? renderHtmlWithImages(previewText, q.id, "text", ui) : null}
                                            {q.marks && <div className="ms-4 text-nowrap">({q.marks})</div>}
                                        </div>
                                    )}
                                </div>
                                {/* {q.marks && <div style={{ marginLeft: "20px", whiteSpace: "nowrap" }}>({q.marks})</div>} */}
                            </div>
                            {renderOptionsBlock(previewOptions, q.id, ui, effectiveOptionIdType)}
                            <div className="text-center fw-bold connector-row py-2">{q.connector}</div>
                        </div>
                    );
                    continue;
                }

                if (q.isConnector || (!q.connector && q.connector !== undefined && q.isConnector)) {
                    out.push(
                        <div key={`conn-${q.id}`} className="my-1">
                            <div className="text-center fw-bold">{q.connector || ""}</div>
                        </div>
                    );
                    continue;
                }

                out.push(
                    <div key={`q-${q.id}`} className="my-1">
                        <div className="my-1">
                            <div className="question-html mt-2 flex-grow-1" style={{ fontSize: `${ui.fontSize || 16}px`, textAlign: ui.align || "left" }}>
                                {!q.isSub ? (
                                    <div>
                                        {isFirstQuestionForContext(q) && q.context ? (
                                            <div className="context-html mb-2">
                                                <div className="d-flex align-items-start">
                                                    <strong className="me-2 text-nowrap">{`Q${q.contextLabel ?? displayNum} `}</strong>
                                                    <div>{renderHtmlWithImages(q.context, q.id, "context", ui)}</div>
                                                </div>
                                            </div>
                                        ) : null}
                                        <div className="d-flex justify-content-between">
                                            <div className="d-flex gap-1">
                                                <strong className={`me-2 ${isNaN(qLabel) && "ps-4"}`}> {!isNaN(qLabel) ? `Q${qLabel} ` : qLabel}</strong>
                                                <div>
                                                    {previewText ? renderHtmlWithImages(previewText, q.id, "text", ui) : null}
                                                </div>
                                            </div>
                                            {q.marks && <div className="ms-4 text-nowrap">({q.marks})</div>}
                                        </div>
                                        {q.image ? (() => {
                                            const sizing = findImageSizing(ui, q.id, "main", undefined, 0) || {};
                                            const widthVal = (sizing && (sizing.width === 0 || sizing.width)) ? Number(sizing.width) : undefined;
                                            const heightVal = (sizing && (sizing.height === 0 || sizing.height)) ? Number(sizing.height) : undefined;
                                            return (
                                                <img
                                                    src={q.image}
                                                    alt=""
                                                    style={{
                                                        width: widthVal !== undefined ? widthVal : undefined,
                                                        height: heightVal !== undefined ? heightVal : undefined,
                                                        margin: "5px 0",
                                                    }}
                                                />
                                            );
                                        })() : null}
                                    </div>
                                ) : (
                                    <div className="d-flex flex-column ps-4">
                                        {previewText ? renderHtmlWithImages(previewText, q.id, "text", ui) : null}</div>
                                )}
                            </div>
                            {/* <div className="d-flex flex-column ps-2">
                                             <strong className="me-2">{qLabel}</strong>
                                            {previewText ? renderHtmlWithImages(previewText, q.id, "text", ui) : null}
                                            {q.marks && <div className="ms-4 text-nowrap">({q.marks})</div>}
                                        </div> */}
                            {/* {q.marks && <div className="ms-4 text-nowrap">({q.marks})</div>} */}
                        </div>
                        {renderOptionsBlock(previewOptions, q.id, ui, effectiveOptionIdType)}
                    </div>
                );
            }
            return out;
        };

        // If sections present: render each section and its questions. Unassigned questions go to "Unassigned".
        if (sectionsArr.length > 0) {
            for (let sIdx = 0; sIdx < sectionsArr.length; sIdx++) {
                const sec = sectionsArr[sIdx];
                const secNumber = getSectionNumberFromObj(sec) ?? sec.section ?? sIdx + 1;

                rendered.push(
                    <div key={`sec-header-${sec.id || sIdx}`} className="my-2">
                        <div className="text-center fw-bold fs-5">
                            <u>Section - {secNumber}</u>
                        </div>
                        {sec.marksPerSection !== undefined && sec.marksPerSection !== null ? (
                            <div className="text-end ps-3 pb-1">
                                <small className="fw-semibold">
                                    Marks : {sec.marksPerSection}{" "}
                                    {/* <span className="text-capitalize">{sec.questionType}</span> */}
                                </small>
                            </div>
                        ) : null}
                        {sec.instruction && (
                            <div className="text-center ps-3 pb-2">
                                <small className="fw-semibold">{sec.instruction}</small>
                            </div>
                        )}
                    </div>
                );

                const sectionQuestions = questions.filter(q => matchesSection(q.section, sec, secNumber));
                if (sectionQuestions.length > 0) {
                    rendered.push(...renderQuestionList(sectionQuestions));
                }
            }

            // Unassigned: those questions that didn't match any section
            const assignedIds = new Set();
            sectionsArr.forEach((sec, sIdx) => {
                const secNumber = getSectionNumberFromObj(sec) ?? sec.section ?? sIdx + 1;
                questions.forEach(q => {
                    if (matchesSection(q.section, sec, secNumber)) assignedIds.add(q.id);
                });
            });

            const remaining = questions.filter(q => !assignedIds.has(q.id));
            if (remaining.length > 0) {
                rendered.push(
                    <div key="unassigned-header" className="my-2">
                        <div className="text-center fw-bold fs-6 text-danger">Unassigned</div>
                    </div>
                );
                rendered.push(...renderQuestionList(remaining));
            }

            return rendered;
        }

        // fallback: no sections — render all questions in original order (but grouped logic still applied)
        return renderQuestionList(questions);
    };

    const handlePrint = () => {
        if (!previewRef.current) return;
        const iframe = document.createElement("iframe");
        iframe.style.position = "fixed";
        iframe.style.right = "0";
        iframe.style.bottom = "0";
        iframe.style.width = "0";
        iframe.style.height = "0";
        iframe.style.border = "0";
        document.body.appendChild(iframe);
        const iframeDoc = iframe.contentWindow.document;
        const styles = [...document.querySelectorAll("link[rel='stylesheet'], style")];
        const stylesHTML = styles.map((s) => s.outerHTML).join("\n");

        iframeDoc.open();
        iframeDoc.write(`
        <html>
            <head>
                ${stylesHTML}
                <style>
                    body {
                        padding: 20px;
                        font-family: Arial, sans-serif;
                    }
                </style>
            </head>
            <body>
                ${previewRef.current.innerHTML}
            </body>
        </html>
    `);
        iframeDoc.close();

        iframe.onload = () => {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();

            setTimeout(() => {
                document.body.removeChild(iframe);
            }, 500);
        };
    };

    return (
        <div className="container">
            {generalDetails && questions ? (
                <>
                    <div className="d-flex gap-2 align-items-center my-2">
                        <button className="btn btn-primary no-print h45 px-3 gap-3" type="button" onClick={handlePrint}> <FiPrinter /> Print</button>
                        <button className="btn btn-info btn-sm px-2 no-print d-flex align-items-center gap-2 h45" type="button" onClick={() => setIsActive(false)}> <MdOutlinePreview /> Questions</button>
                        <button className="btn btn-warning btn-sm px-2 no-print d-flex align-items-center gap-2 h45" type="button" onClick={() => setIsActive(true)}> <PiBookOpenText /> Marking Scheme</button>
                    </div>
                    <div ref={previewRef} className="border pt-4 pb-5 px-5 bg-white mb-3">
                        {!isActive ? <>
                            <div className="text-center mb-3">
                                <h5 className="fw-semibold fs-5">{generalDetails.name}</h5>
                                <div className="fw-semibold fs-6 mb-11">{generalDetails.subjectName}</div>
                                <div className="fw-semibold fs-6 mb-11">{generalDetails.session} {generalDetails.year}</div>
                                <div className="fw-semibold fs-6 mb-11">Class - {generalDetails.class}</div>
                                <div className="d-flex justify-content-between mt-2 px-1 fs-6">
                                    <span><strong>Time Durations:</strong> {generalDetails.totalTime} hrs</span>
                                    <span><strong>Total Marks:</strong> {generalDetails.maxMarks}</span>
                                </div>
                            </div>
                            <div className="mb-3">
                                <h6 className="fw-semibold px-1 fs-5 mb-3">General Instructions:-</h6>
                                <div className="row">
                                    <div className="col-12"><pre className="fw-semibold ps-3 fs-6 mb-0">{generalDetails.generalInstruction}</pre></div>
                                </div>
                            </div>
                            <hr className="my-4" />
                            <div className="questions-list">
                                {renderPreviewGrouped()}
                            </div>
                        </> : <>
                            <MarkingScheme currentIds={currentIds} generalDetails={generalDetails} />
                        </>}
                    </div>
                </>
            ) : <div className="d-flex justify-content-center align-items-center h-85vh fw-bold">No Questions found </div>}
        </div>
    );
}