import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';
@Entity({ name: 'openairesult' })
export class OpenAIResult {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: 40 })
  paperId!: string;

  @CreateDateColumn({ type: 'timestamp', default: null })
  paperDate!: number; // paper ID

  @Column({ type: 'text', default: null })
  response!: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt!: Date;
}
