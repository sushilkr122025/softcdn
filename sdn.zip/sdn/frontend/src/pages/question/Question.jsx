import React, { useState, useEffect } from 'react';
import GlobalFilters from '../../components/GlobalFilters';
import apiClient from '../../api/apiService';
import { FaEllipsisVertical } from "react-icons/fa6";
import { PiFilePdfLight, PiMicrosoftWordLogoLight } from "react-icons/pi";
import './Question.css';
import jsPDF from "jspdf";
import bank from '../../assets/images/bank-grey.svg';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Header,
  Footer,
  PageNumber,
  AlignmentType
} from "docx";
import { saveAs } from "file-saver";

const stripHtml = (html) => {
  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = html;
  return tempDiv.textContent || tempDiv.innerText || "";
};

const Question = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState({
    std: '',
    subject: '',
    cg: '',
    competency: '',
    difficulty: '',
    quesType: '',
    subDomain: '',
  });
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState([]);
  const options = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }]
  const handleFiltersChange = (newFilters) => {
    setFilter((prev) => {
      const classChanged = prev.std !== newFilters.std;
      const subjectChanged = prev.subject !== newFilters.subject;

      return {
        ...prev,
        ...newFilters,
        cg: classChanged || subjectChanged ? '' : newFilters.cg,
        competency: classChanged || subjectChanged ? '' : newFilters.competency,
        difficulty: classChanged || subjectChanged ? '' : newFilters.difficulty,
        quesType: classChanged || subjectChanged ? '' : newFilters.quesType,
        subDomain: classChanged || subjectChanged ? '' : newFilters.subDomain,
      };
    });
  };

  useEffect(() => {
    const { std, subject } = filter;

    if (!std || !subject) return;

    apiClient
      .post('/school/makePaper', {
        subject,
        class: std,
        table: 'questions',
        page: null,
        data: null,
      })
      .then((res) => {
        console.log('Responsesdf:', res);
        setData(res.data || []);
        console.log('Fetched questions:', res.data);
      })
      .catch((err) => {
        console.error('Error fetching questions:', err);
        setData([]);
      });
  }, [filter]);

  const filteredData = data.filter((q) => {
    if (filter.subDomain && q.subDomain !== filter.subDomain) return false;
    if (filter.cg && q.cg !== filter.cg) return false;
    if (filter.competency && q.competency !== filter.competency) return false;
    if (filter.difficulty && q.difficulty !== filter.difficulty) return false;
    if (filter.quesType && q.quesType !== filter.quesType) return false;
    return true;
  });

  const handleRowClick = (question) => {
    setSelectedQuestion([question]);
    setShowPreviewModal(true);
  };

  const exportToWord = () => {
    if (selectedQuestion.length === 0) {
      alert("Please select at least one question.");
      return;
    }

    const paragraphs = selectedQuestion.map((item, idx) => [
      new Paragraph({
        children: [
          new TextRun({ text: `Q${idx + 1} (ID: ${item.customId})`, bold: true }),
        ],
        spacing: { after: 200 },
      }),
      new Paragraph({ text: `Q: ${stripHtml(item.question) || 'Question not found.'}` }),
      new Paragraph(""),
    ]).flat();

    const header = new Header({
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "ABCD SCHOOL", bold: true })],
        }),
      ],
    });

    const footer = new Footer({
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun("Sanskrit e Solutions & Services Pvt. Ltd.")],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun("Page "),
            new TextRun({ children: [PageNumber.CURRENT] }),
            new TextRun(" of "),
            new TextRun({ children: [PageNumber.TOTAL_PAGES] }),
          ],
        }),
      ],
    });

    const doc = new Document({
      sections: [
        {
          headers: { default: header },
          footers: { default: footer },
          children: paragraphs,
        },
      ],
    });

    Packer.toBlob(doc).then((blob) => {
      saveAs(blob, `selected-questions.docx`);
    });
  };

  const exportToPDF = () => {
    if (selectedQuestion.length === 0) {
      alert("Please select at least one question.");
      return;
    }

    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 10;
    let y = margin;
    const lineHeight = 7;

    const addFooter = (pageNum, totalPages) => {
      doc.setFontSize(10);
      doc.text("Sanskrit e Solutions & Services Pvt. Ltd.", pageWidth / 2, pageHeight - 10, { align: 'center' });
      doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth / 2, pageHeight - 5, { align: 'center' });
    };

    const addHeader = () => {
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("ABCD SCHOOL", pageWidth / 2, y, { align: "center" });
      y += lineHeight + 2;
    };

    const renderQuestion = (question, index) => {
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(`Q${index + 1} (ID: ${question.customId})`, margin, y);
      y += lineHeight;

      doc.setFont("helvetica", "normal");
      const cleanQuestion = stripHtml(question.question);
      const splitText = doc.splitTextToSize(`Q: ${cleanQuestion}`, pageWidth - margin * 2);
      splitText.forEach(line => {
        doc.text(line, margin, y);
        y += lineHeight;
      });
      y += lineHeight;
    };

    const totalPages = Math.ceil(selectedQuestion.length / 4);
    let currentPage = 1;

    addHeader();
    selectedQuestion.forEach((item, idx) => {
      if (y + 40 > pageHeight - 20) {
        addFooter(currentPage, totalPages);
        doc.addPage();
        currentPage++;
        y = margin;
        addHeader();
      }
      renderQuestion(item, idx);
    });

    addFooter(currentPage, totalPages);
    doc.save(`selected-questions.pdf`);
  };

  const handleChange = (item) => {
    if (selectedQuestion.some(q => q.id === item.id)) {
      setSelectedQuestion(selectedQuestion.filter(q => q.id !== item.id));
    } else {
      setSelectedQuestion([...selectedQuestion, item]);
    }
  }

  const cleanHtml = (html) => {
    if (!html) return "";
    html = html.replace(/\s*style="[^"]*"/gi, "");
    html = html.replace(/<\/?p[^>]*>/gi, "");
    return html;
  };

  return (
    <div className="container-fluid">
      <div className="row align-items-center">
        <div className="col-6 py-3 d-flex align-items-end">
          <img
            src={bank}
            alt="questionbank"
            style={{ width: "25px" }} />
          <h5 className='text-grey-400 mb-0 ms-3'>Question Bank</h5>
        </div>
        <div className="col-6 py-3 text-end">
          <button className='btn btn-sm btn-primary'>Add Question</button>
        </div>
      </div>
      <GlobalFilters onFiltersChange={handleFiltersChange} selectedValues={filter} show={['subject', 'class', 'subDomain', 'cg', 'competency', 'difficulty', 'quesType', 'author']} />
      <main>
        <div className="text-end pb-3">
          <button className="btn btn-sm btn-primary border-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Export
          </button>
          <ul className="dropdown-menu mt-2">
            <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={exportToPDF}><PiFilePdfLight className='me-2' /><span>PDF</span></li>
            <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={exportToWord}><PiMicrosoftWordLogoLight className='me-2' /><span>Word</span></li>
          </ul>
        </div>
        <div className="table-responsive">
          <table className="table table-hover border">
            <thead>
              <tr>
                <th className='text-center'>-</th>
                <th>Unique Id</th>
                <th>Class</th>
                <th>CG</th>
                <th>Competency</th>
                <th>Author</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((item, index) => (
                <tr key={index}>
                  <td className='text-center cursor-pointer' onClick={() => handleChange(item)}>
                    <input
                      type="checkbox"
                      id={item.id}
                      className="form-check-input"
                      checked={selectedQuestion.some(q => q.id === item.id)}
                      onChange={() => {
                        handleChange(item)
                      }}
                    />
                  </td>
                  <td >
                    <span className='cursor-pointer' onClick={() => handleRowClick(item)}>{item.customId}</span>
                  </td>
                  <td>{item.class}</td>
                  <td>{item.cg}</td>
                  <td>{item.competency}</td>
                  <td>{item.createdBy}</td>
                  <td>
                    <button type="button" className="btn btn-sm border-0" data-bs-toggle="dropdown" aria-expanded="false">
                      <FaEllipsisVertical className="text-primary" />
                    </button>
                    <ul className="dropdown-menu p-2">
                      <li><a href={`/questionGeneration/${item.id}`} className="dropdown-item">Edit</a></li>
                    </ul>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
      {showPreviewModal && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog" >
            <div className="modal-dialog modal-lg modal-dialog-centered" role="document">
              <div className="modal-content bg-white border-0 rounded-0 shadow p-3 py-4">
                <div className='d-flex justify-content-end'>
                  <button type="button" className="btn-close" onClick={() => setShowPreviewModal(false)}></button>
                </div>
                <div className="modal-body">
                  {selectedQuestion.map((item, index) => (
                    <div key={index}>
                      <h4 className="questionprevhead mb-3">Ques. ID: {item?.customId}</h4>
                      <div className="d-flex">
                        <span className='ps-2 me-3'>Q-</span>
                        <div
                          style={{maxWidth: "580px"}}
                          className="qustionPreviewcontainer d-flex flex-wrap flex-grow-1 justify-content-between align-items-start"
                          dangerouslySetInnerHTML={{
                            __html: `${cleanHtml(item?.question) || "No content available"}`,
                          }}
                        />
                      </div>
                      <ol className="list-group mt-3" type="A">
                        {options.map((key, i) => {
                          const option = item?.[key.optns];
                          const optionimg = item?.[key.images];
                          if (!option && !optionimg) return null;
                          const isCorrect = key.optns === item.correctAns;
                          return (
                            <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                              <div className='d-flex justify-content-between align-items-center'>
                                {option && (
                                  <div
                                    dangerouslySetInnerHTML={{ __html: option }}
                                  />
                                )}
                                {optionimg && <div><img src={optionimg} className='img-fluid' style={{ maxWidth: "100px" }} alt="" /></div>}
                                {isCorrect && <div className="text-success fw-bold">✔</div>}
                              </div>
                            </li>
                          );
                        })}
                      </ol>
                    </div>
                  ))}
                </div>

              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </>
      )}
    </div>
  );
};


export default Question;
