import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import apiClient from '../api/apiService'
import Cookies from 'js-cookie'
import { useNavigate } from 'react-router'

export default function TenantEntry() {
  const [error, setError] = useState(null)

  const navigate = useNavigate()

  const { schoolID } = useParams()
  useEffect(() => {
    const fetchTenant = async () => {
      try {
        const response = await apiClient.post(`/api/tenant`, { schoolID })
        if (response.data.length > 0) {
          const data = response.data[0]
          Cookies.set('schoolID', data.schoolID, { expires: 7 })
          Cookies.set('logo', data.logo)
          navigate('/tenantLogin')
        } else {
          setError('Invalid URL')
        }
      } catch (error) {
        console.error('Error fetching tenant data:', error)
      }
    }
    fetchTenant()
  }, [schoolID])

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}
    </div>
  )
}
