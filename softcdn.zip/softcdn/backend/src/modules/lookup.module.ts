import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LookupSchool } from 'src/entities/lookup.school.entity';
import { LookupService } from 'src/services/lookup.service';
import { School } from 'src/entities/school.entity';

@Module({
  imports: [TypeOrmModule.forFeature([LookupSchool, School])],
  providers: [LookupService],
  exports: [LookupService],
})
export class LookupModule {}
