import { useState, useEffect, useMemo } from 'react'
import { useParams } from 'react-router-dom'
import arucoTL from "../../assets/images/aruco_markers/marker_0.png";
import arucoTR from "../../assets/images/aruco_markers/marker_1.png";
import arucoBL from "../../assets/images/aruco_markers/marker_2.png";
import arucoBR from "../../assets/images/aruco_markers/marker_3.png";
import { BsLayoutSplit } from "react-icons/bs";
import { IoTabletPortraitOutline } from "react-icons/io5";
import QuestionServices from '../../api/QuestionServices';

// ─── Layout Constants ──────────────────────────────────────────────────────────
const BOX      = 40   // answer box size (px)
const ROW_GAP  = 8    // vertical gap between rows
const COL_GAP  = 14   // horizontal gap between columns

// A4 at 96dpi
const A4_W = 794
const A4_H = 1123

// ── Portrait ──
const P_PAD       = 28   // page outer padding
const P_HEADER_H  = 155  // header + student info table height
const P_ARUCO_PAD = 44   // padding inside aruco zone (each side top/bottom)
const P_ARUCO     = 46   // aruco marker size
// Usable height for question rows
const P_BODY_H    = A4_H - P_PAD * 2 - P_HEADER_H - P_ARUCO_PAD * 2  // 824px
const P_MAX_ROWS  = Math.floor(P_BODY_H / (BOX + ROW_GAP))            // 17
const P_MAX_COLS  = 5
const P_PAGE_CAP  = P_MAX_ROWS * P_MAX_COLS                            // 80

// ── Landscape ──
// Landscape A4 page = 1123px wide × 794px tall; each half = 561px wide
const L_HALF_W    = Math.floor(A4_H / 2)  // 561
const L_PAGE_H    = A4_W                   // 794
const L_HALF_PAD  = 16   // half inner padding (top/bottom)
const L_HEADER_H  = 155
const L_ARUCO_PAD = 44   // padding inside aruco zone
const L_ARUCO     = 38   // aruco marker size
const L_BODY_H    = L_PAGE_H - L_HALF_PAD * 2 - L_HEADER_H - L_ARUCO_PAD * 2  // 527px
const L_MAX_ROWS  = Math.floor(L_BODY_H / (BOX + ROW_GAP))                     // 10 ✓
const L_MAX_COLS  = 4
const L_HALF_CAP  = L_MAX_ROWS * L_MAX_COLS  // 40

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * Distribute questions into N columns top→bottom, left→right.
 * Each column gets ceil(total/n) rows except the last which may be shorter.
 */
const toColumns = (questions, colCount, maxRows) => {
  const n = Math.max(1, colCount)
  // Use maxRows as the fixed row capacity per column so the layout never
  // re-equalises on the last page — questions simply fill top-down left-right
  // with the same column spacing used on every other page.
  const rowsPerCol = maxRows || Math.ceil(questions.length / n)
  const cols = []
  for (let c = 0; c < n; c++) {
    cols.push(questions.slice(c * rowsPerCol, c * rowsPerCol + rowsPerCol))
  }
  return cols
}

/**
 * Calculate the global column count from the TOTAL question count.
 * This is called ONCE and reused on every page so all pages share
 * the same column structure regardless of how many questions land on each page.
 */
const calcGlobalColCount = (total, maxRows, maxCols) => {
  return Math.max(1, Math.min(maxCols, Math.ceil(total / maxRows)))
}

/**
 * Split questions into portrait pages.
 * colCount is pre-calculated globally and passed in — never recalculated per page.
 */
const toPortraitPages = (questions, globalColCount) => {
  const pages = []
  let rem = [...questions]
  while (rem.length) {
    pages.push(rem.splice(0, P_PAGE_CAP))
  }
  return pages.map(pageQs => ({ questions: pageQs, colCount: globalColCount }))
}

/**
 * Split questions into landscape pages (each page = left half + right half).
 * colCount is pre-calculated globally and passed in.
 */
const toLandscapePages = (questions, globalColCount) => {
  const total = questions.length

  if (total <= L_HALF_CAP) {
    // ≤40: duplicate — both halves show identical content
    return [{
      left: questions,
      right: questions,
      duplicate: true,
      colCount: globalColCount,
    }]
  }

  const pages = []
  let rem = [...questions]
  while (rem.length) {
    const left  = rem.splice(0, L_HALF_CAP)
    const right = rem.splice(0, L_HALF_CAP)
    pages.push({
      left,
      right,        // may be empty array on last page if questions were exact multiple
      duplicate: false,
      colCount: globalColCount,  // same colCount for every page, every half
    })
  }
  return pages
}

// ─── Sub-components ───────────────────────────────────────────────────────────

const AnswerBox = () => (
  <div style={{ width: BOX, height: BOX, border: '2px solid #000', flexShrink: 0 }} />
)

const QuestionRow = ({ q }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
    <span style={{ minWidth: 42, fontWeight: 600, fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
      {q.queslabel}:
    </span>
    <AnswerBox />
  </div>
)

/**
 * Renders questions as evenly spaced columns.
 * colCount is always the global value — columns are evenly distributed
 * even if the last page has fewer questions (they just appear in fewer rows).
 */
const QuestionColumns = ({ questions, colCount, maxRows }) => {
  const cols = toColumns(questions, colCount, maxRows)
  return (
    <div style={{
      display: 'flex',
      gap: COL_GAP,
      width: '100%',
      justifyContent: 'space-between',
    }}>
      {/* Always render exactly colCount slots — empty slots keep spacing identical on last page */}
      {Array.from({ length: colCount }).map((_, ci) => (
        <div key={ci} style={{ display: 'flex', flexDirection: 'column', gap: ROW_GAP, flex: 1 }}>
          {(cols[ci] || []).map(q => <QuestionRow key={q.id} q={q} />)}
        </div>
      ))}
    </div>
  )
}

const ArucoCorners = ({ size }) => {
  const s = { width: size, height: size, position: 'absolute' }
  return (
    <>
      <img src={arucoTL} alt="tl" style={{ ...s, top: 0, left: 0 }} />
      <img src={arucoTR} alt="tr" style={{ ...s, top: 0, right: 0 }} />
      <img src={arucoBL} alt="bl" style={{ ...s, bottom: 0, left: 0 }} />
      <img src={arucoBR} alt="br" style={{ ...s, bottom: 0, right: 0 }} />
    </>
  )
}

const SheetHeader = () => (
  <div style={{ marginBottom: 6 }}>
    <div style={{ textAlign: 'center', marginBottom: 4 }}>
      <div style={{ fontWeight: 700, fontSize: '0.95rem', lineHeight: 1.3 }}>ABCD Govt. School</div>
      <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>MARKSHEET</div>
    </div>
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.75rem' }}>
      <tbody>
        <tr>
          <td colSpan={3} style={{ border: '1px solid #000', padding: '3px 5px', height: 24 }}>
            <strong>Student Name:</strong>
          </td>
        </tr>
        <tr>
          <td style={{ border: '1px solid #000', padding: '3px 5px', height: 22, width: '33%' }}><strong>Class:</strong></td>
          <td style={{ border: '1px solid #000', padding: '3px 5px', width: '33%' }}><strong>Sec:</strong></td>
          <td style={{ border: '1px solid #000', padding: '3px 5px', width: '34%' }}><strong>Roll No:</strong></td>
        </tr>
        <tr>
          <td colSpan={3} style={{ border: '1px solid #000', padding: '3px 5px', height: 22 }}>
            <strong>Subject:</strong>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
)

const Sheet = ({ questions, colCount, arucoSize, arucoPad, maxRows }) => (
  <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%' }}>
    <SheetHeader />
    {/*
      This div MUST stretch to fill all remaining vertical space (flex:1 + alignSelf:stretch).
      Only then does position:absolute bottom:0 on the bottom aruco markers mean
      "bottom of the page area" rather than "bottom of the question list".
    */}
    <div style={{
      position: 'relative',
      flex: 1,
      alignSelf: 'stretch',
      // Prevent this container from shrinking to content height
      minHeight: 0,
    }}>
      {/* Top-left / top-right markers — always at top of zone */}
      <img src={arucoTL} alt="tl" style={{ width: arucoSize, height: arucoSize, position: 'absolute', top: 0, left: 0 }} />
      <img src={arucoTR} alt="tr" style={{ width: arucoSize, height: arucoSize, position: 'absolute', top: 0, right: 0 }} />
      {/* Bottom markers — pinned to true bottom of the full-height zone */}
      <img src={arucoBL} alt="bl" style={{ width: arucoSize, height: arucoSize, position: 'absolute', bottom: 0, left: 0 }} />
      <img src={arucoBR} alt="br" style={{ width: arucoSize, height: arucoSize, position: 'absolute', bottom: 0, right: 0 }} />
      {/* Questions are inset from all sides to never overlap markers */}
      <div style={{
        position: 'absolute',
        top: arucoPad,
        left: arucoPad,
        right: arucoPad,
        // No bottom constraint — questions flow downward freely within the safe zone
      }}>
        <QuestionColumns questions={questions} colCount={colCount} maxRows={maxRows} />
      </div>
    </div>
  </div>
)

// ─── Portrait Page ─────────────────────────────────────────────────────────────
const PortraitPage = ({ questions, colCount }) => (
  <div
    className="print-page"
    style={{
      width: A4_W,
      height: A4_H,          // fixed height — NOT minHeight — so flex:1 children resolve correctly
      padding: P_PAD,
      boxSizing: 'border-box',
      backgroundColor: '#fff',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}
  >
    <Sheet
      questions={questions}
      colCount={colCount}
      arucoSize={P_ARUCO}
      arucoPad={P_ARUCO_PAD}
      maxRows={P_MAX_ROWS}
    />
  </div>
)

// ─── Landscape Page ────────────────────────────────────────────────────────────
const LandscapePage = ({ left, right, duplicate, colCount }) => (
  <div
    className="print-page"
    style={{
      width: A4_H,
      height: A4_W,          // fixed height so flex:1 children resolve correctly
      display: 'flex',
      flexDirection: 'row',
      backgroundColor: '#fff',
      boxSizing: 'border-box',
      overflow: 'hidden',
    }}
  >
    {/* Left half */}
    <div style={{
      width: L_HALF_W,
      height: '100%',
      padding: `${L_HALF_PAD}px 18px`,
      boxSizing: 'border-box',
      borderRight: '1px dashed #bbb',
      display: 'flex',
      flexDirection: 'column',
    }}>
      <Sheet
        questions={left}
        colCount={colCount}
        arucoSize={L_ARUCO}
        arucoPad={L_ARUCO_PAD}
        maxRows={L_MAX_ROWS}
      />
    </div>

    {/* Right half */}
    <div style={{
      width: L_HALF_W,
      height: '100%',
      padding: `${L_HALF_PAD}px 18px`,
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {(right && right.length > 0) || duplicate ? (
        <Sheet
          questions={duplicate ? left : right}
          colCount={colCount}
          arucoSize={L_ARUCO}
          arucoPad={L_ARUCO_PAD}
          maxRows={L_MAX_ROWS}
        />
      ) : (
        <div style={{ flex: 1 }} />
      )}
    </div>
  </div>
)

// ─── Main ──────────────────────────────────────────────────────────────────────
const QuesTemplate = () => {
  const { paperId } = useParams()
  const [questions, setQuestions] = useState([])
  const [loading, setLoading]     = useState(false)
  const [error, setError]         = useState(null)
  const [mode, setMode]           = useState('landscape')

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const res = await QuestionServices.GetQuestionData({
          params: {
            paperId: paperId,
          },
        });
        console.log('qiestionData', res);
        
        setQuestions(res?.questions || res || [])
      } catch (err) {
        console.error('Failed to fetch questions:', err)
        setError('Failed to load questions.')
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [paperId])

  const sorted = useMemo(
    () => [...questions].sort((a, b) => a.sequence - b.sequence),
    [questions]
  )

  // ── Calculate global column counts ONCE from total, reuse on every page ──
  const globalPortraitCols  = useMemo(
    () => calcGlobalColCount(sorted.length, P_MAX_ROWS, P_MAX_COLS),
    [sorted.length]
  )
  const globalLandscapeCols = useMemo(
    () => calcGlobalColCount(sorted.length, L_MAX_ROWS, L_MAX_COLS),
    [sorted.length]
  )

  const portraitPages  = useMemo(
    () => toPortraitPages(sorted, globalPortraitCols),
    [sorted, globalPortraitCols]
  )
  const landscapePages = useMemo(
    () => toLandscapePages(sorted, globalLandscapeCols),
    [sorted, globalLandscapeCols]
  )

  const handlePrint = () => {
    const printRoot = document.getElementById('ques-print-root')
    if (!printRoot) return

    const printWindow = window.open('', '_blank', 'width=1200,height=900')
    if (!printWindow) {
      alert('Pop-up blocked. Please allow pop-ups for this site and try again.')
      return
    }

    const styles = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
      .map(el => el.outerHTML)
      .join('\n')

    const pageSize = mode === 'landscape' ? 'A4 landscape' : 'A4 portrait'

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Print</title>
          ${styles}
          <style>
            * { box-sizing: border-box; }
            body { margin: 0; padding: 0; background: #fff; }
            @page { size: ${pageSize}; margin: 0; }
            .print-page { page-break-after: always; box-shadow: none !important; }
            .print-page:last-child { page-break-after: auto; }
            .no-print { display: none !important; }
          </style>
        </head>
        <body>
          ${printRoot.innerHTML}
        </body>
      </html>
    `)

    printWindow.document.close()

    printWindow.onload = () => {
      const images = printWindow.document.images
      if (images.length === 0) {
        printWindow.focus()
        printWindow.print()
        printWindow.close()
        return
      }
      let loaded = 0
      const onImageLoad = () => {
        loaded++
        if (loaded === images.length) {
          printWindow.focus()
          printWindow.print()
          printWindow.close()
        }
      }
      Array.from(images).forEach(img => {
        if (img.complete) {
          onImageLoad()
        } else {
          img.onload = onImageLoad
          img.onerror = onImageLoad
        }
      })
    }
  }

  const pageCount = mode === 'landscape' ? landscapePages.length : portraitPages.length

  return (
    <div style={{ background: '#d0d0d0', minHeight: '100vh', padding: 24 }}>

      {/* ── Toolbar ── */}
      <div
        className="no-print"
        style={{
          display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24,
          marginLeft: 'auto', marginRight: 'auto',
          background: '#fff', padding: '10px 18px', borderRadius: 8,
          boxShadow: '0 1px 6px rgba(0,0,0,0.14)', width: 'fit-content',
        }}
      >
        <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#333' }}>Preview Mode:</span>

        <div style={{ display: 'flex', border: '1.5px solid #1a1a2e', borderRadius: 6, overflow: 'hidden' }}>
          {[
            { key: 'portrait',  label: 'Portrait',  icon: <IoTabletPortraitOutline /> },
            { key: 'landscape', label: 'Landscape', icon: <BsLayoutSplit /> },
          ].map(({ key, label, icon }) => (
            <button
              key={key}
              onClick={() => setMode(key)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '6px 18px', border: 'none', cursor: 'pointer',
                fontWeight: 600,
                background: mode === key ? '#1a1a2e' : '#fff',
                color: mode === key ? '#fff' : '#1a1a2e',
                fontSize: '0.82rem', transition: 'all 0.25s',
              }}
            >
              {icon} {label}
            </button>
          ))}
        </div>

        <button
          onClick={handlePrint}
          style={{
            padding: '7px 22px', background: '#1a1a2e', color: '#fff',
            border: 'none', borderRadius: 6, cursor: 'pointer',
            fontWeight: 700, fontSize: '0.82rem',
          }}
        >
          🖨 Print
        </button>

        {!loading && (
          <span style={{ fontSize: '0.78rem', color: '#666' }}>
            {sorted.length} questions · {pageCount} page{pageCount !== 1 ? 's' : ''}
            {mode === 'landscape' && sorted.length <= L_HALF_CAP ? ' (duplicated)' : ''}
          </span>
        )}
      </div>

      {/* ── Print Root ── */}
      <div id="ques-print-root">
        {loading && (
          <div style={{ textAlign: 'center', padding: 60, color: '#555' }}>Loading questions…</div>
        )}
        {error && (
          <div style={{ background: '#fee', padding: 16, borderRadius: 8, color: '#c00' }}>{error}</div>
        )}
        {!loading && !error && sorted.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#888' }}>No questions found.</div>
        )}

        {!loading && !error && sorted.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 32 }}>

            {mode === 'portrait' && portraitPages.map((page, pi) => (
              <div key={pi} style={{ boxShadow: '0 3px 16px rgba(0,0,0,0.20)' }}>
                <PortraitPage questions={page.questions} colCount={page.colCount} />
              </div>
            ))}

            {mode === 'landscape' && landscapePages.map((page, pi) => (
              <div key={pi} style={{ boxShadow: '0 3px 16px rgba(0,0,0,0.20)' }}>
                <LandscapePage
                  left={page.left}
                  right={page.right}
                  duplicate={page.duplicate}
                  colCount={page.colCount}
                />
              </div>
            ))}

          </div>
        )}
      </div>
    </div>
  )
}

export default QuesTemplate
