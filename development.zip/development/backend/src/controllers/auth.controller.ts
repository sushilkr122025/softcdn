import {
  Controller,
  Get,
  Req,
  Res,
  Post,
  Body,
  UsePipes,
  ValidationPipe,
  UseGuards,
  UnauthorizedException,
} from '@nestjs/common';
import { LoginDto } from '../dto/login.dto';
import { Login } from '../entities/login.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Request, Response } from 'express';
import { AuthService } from '../services/auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}
  private readonly isProd = process.env.NODE_ENV === 'production';

  @Post('register')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async createUser(@Body() loginDto: LoginDto): Promise<Login> {
    return this.authService.createUser(loginDto);
  }

  @Post('login')
  async login(
    @Body()
    loginDto: {
      email: string;
      password: string;
    },
    @Res({ passthrough: true }) res: Response,
    @Req() req: Request
  ) {
    const userAgent = req.headers['user-agent'] as string;
    const lookupid = req['company'] as string;
    const data = await this.authService.validateUser(
      loginDto.email,
      loginDto.password,
      lookupid,
      userAgent
    );
    if (!data) {
      throw new UnauthorizedException('Invalid credentials');
      // return res.json({
      //   authorize: false,
      //   message: 'Invalid credentials',
      // });
    }
    res.cookie('token', data.access_token, {
      httpOnly: true,
      secure: this.isProd,
      sameSite: 'lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000,
    });

    const responseData = {
      ...data.user,
      authorize: true,
      permission: data.permission,
    };

    return responseData;
  }
  @Get('verify')
  @UseGuards(JwtAuthGuard)
  async verify(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const userId = (req.user as { id: number }).id;
    const lookupid = req['company'] as string;
    const data = await this.authService.findUserAndPermission(userId, lookupid);
    if (!data) {
      res.clearCookie('token');
      return res.json({
        authorize: false,
        message: 'Session expired',
      });
    }
    return { ...data, authorize: true };
  }
  @Get('logout')
  logout(@Res({ passthrough: true }) res: Response, @Req() req: Request) {
    const userAgent = req.headers['user-agent'] as string;
    res.clearCookie('token', {
      httpOnly: true,
      secure: this.isProd,
      sameSite: 'lax',
      path: '/',
      expires: new Date(0),
    });
    return { message: 'Logged out' };
  }

  @Get('appsetting')
  @UseGuards(JwtAuthGuard)
  async getAppSetting(@Req() req: Request) {
    const lookupid = req['company'] as string;
    const data = await this.authService.findAppSetting(lookupid);
    if (!data) {
      return {
        authorize: false,
      };
    }
    return { setting: data, authorize: true };
  }

  @Get('clearall')
  clearcookie(@Res({ passthrough: true }) res: Response) {
    res.clearCookie('token', {
      httpOnly: true,
      secure: this.isProd,
      sameSite: 'lax',
      path: '/',
      expires: new Date(0),
    });
    return { message: 'Session expired' };
  }
}
