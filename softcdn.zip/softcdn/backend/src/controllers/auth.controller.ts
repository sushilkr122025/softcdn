import {
  Controller,
  Get,
  Req,
  Res,
  Post,
  Body,
  NotFoundException,
  UsePipes,
  ValidationPipe,
  UseGuards,
} from '@nestjs/common';
import { LoginDto } from 'src/dto/login.dto';
import { Login } from '../entities/login.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Request, Response } from 'express';
import { AuthService } from 'src/services/auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async createUser(@Body() loginDto: LoginDto): Promise<Login> {
    return this.authService.createUser(loginDto);
  }

  @Post('login')
  async login(
    @Body()
    loginDto: {
      email: string;
      password: string;
    },
    @Res()
    res: Response,
    @Req()
    req: Request
  ) {
    //console.log('req login company', req['company']);
    const userAgent = req.headers['user-agent'] as string;
    const lookupid = req['company'] as string;
    // console.log('req login company', lookupid);
    const { access_token, user } = await this.authService.validateUser(
      loginDto.email,
      loginDto.password,
      lookupid,
      userAgent
    );
    if (!user) {
      throw new NotFoundException('Invalid credentials');
    }
    res.cookie('token', access_token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000,
    }); //{ httpOnly: true, secure: false }
    return res.json(user);
  }
  @Get('verify')
  @UseGuards(JwtAuthGuard)
  async verify(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    //console.log('req verify company', req['company']);
    const userId = (req.user as { id: number }).id;
    const lookupid = req['company'] as string;
    const user = await this.authService.findById(userId, lookupid);
    if (!user) {
      res.clearCookie('token');
      throw new NotFoundException('Invalid credentials');
    }
    const userData = {
      id: user.id,
      name: user.name,
      role: user.role,
    };
    return userData;
  }
  @Get('logout')
  logout(@Res({ passthrough: true }) res: Response, @Req() req: Request) {
    const userAgent = req.headers['user-agent'] as string;
    // const user = await this.authService.createLog(userAgent, lookupid);
    // if (!user) {
    //   res.clearCookie('token');
    //   throw new NotFoundException('Invalid credentials');
    // }
    res.clearCookie('token');
    return { message: 'Logged out' };
  }

  @Get('clearall')
  clearcookie(@Res({ passthrough: true }) res: Response) {
    res.clearCookie('token');
    return { message: 'Session expired' };
  }
}
