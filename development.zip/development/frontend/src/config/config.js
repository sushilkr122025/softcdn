const config = {
  hostname: String(import.meta.env.VITE_HOST),
  apihost: String(import.meta.env.VITE_APIHOST),
  sockethost: String(import.meta.env.VITE_SOCKET_HOST),
}

export default config
