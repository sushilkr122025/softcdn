// notification.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, LessThan } from 'typeorm';
import { Notification } from '../entities/notification.entity';
import { NotificationGateway } from '../gateway/notification.gateway';

@Injectable()
export class NotificationService {
  constructor(
    @InjectRepository(Notification)
    private repo: Repository<Notification>,
    private gateway: NotificationGateway,
  ) {}

  // Create notification
  async create(tenantid: string, userId: number, type: string, message: string) {
    const notification = this.repo.create({tenantid, userId, type, message });
    await this.repo.save(notification);

    // Push if online
    const sent = this.gateway.sendToUser(tenantid, userId, notification.message);
    if (!sent) console.log(`💤 User ${userId} offline, will see later`);

    return notification;
  }

  // Unread list
  async getUnread(userId: number) {
    return this.repo.find({
      where: { userId, isRead: false },
      order: { createdAt: 'DESC' },
    });
  }

  // All history
  async getAll(userId: number) {
    return this.repo.find({
      where: { userId },
      order: { createdAt: 'DESC' },
    });
  }

  // Mark as read , userId: number , userId
  async markAsRead(id: number) {
    return this.repo.update({ id }, { isRead: true });
  }

  // Cleanup old notifications
  async cleanupOld(days = 30) {
    const date = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    return this.repo.delete({ createdAt: LessThan(date) });
  }
}
