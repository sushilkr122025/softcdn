/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Injectable, HttpException, HttpStatus, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, In } from 'typeorm';
import { Repository, DataSource } from 'typeorm';
import { Result } from '../entities/result.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { Answer } from '../entities/answer.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { Questions } from '../entities/questions.entity';
import { Grade } from '../entities/grade.entity';
import { Alert } from '../entities/alerts.entity';
import { Subject } from '../entities/subject.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
interface SubdomainData {
  subdomain: string;
  percentage: number;
  grade: string;
}

interface QuestionItem {
  id: number;
  subdomain: string;
  data: number;
}

interface ResultRow {
  id: number;
  paperid: number;
  studentid: number;
  studentclass: string;
  studentsection: string;
  rollno: string;
  studentname: string;
  studentpercentage: number;
  studentgrade: string;
  studentpercentile: number;
  questiondata: QuestionItem[];
}

@Injectable()
export class ResultService {
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Result)
    private readonly resultRepository: Repository<Result>,
    @InjectRepository(StudentInformation)
    private readonly studentRepository: Repository<StudentInformation>,
    @InjectRepository(QuestionPaper)
    private readonly questionPaperRepository: Repository<QuestionPaper>,
    @InjectRepository(Answer)
    private readonly answerRepository: Repository<Answer>,
    @InjectRepository(ExamQuestion)
    private readonly examQuestionRepository: Repository<ExamQuestion>,
    @InjectRepository(Questions)
    private readonly questionRepository: Repository<Questions>,
    @InjectRepository(Grade)
    private readonly gradeRepository: Repository<Grade>,
    @InjectRepository(Alert)
    private readonly alertRepository: Repository<Alert>,
  ) {}
  async getGradeAll(): Promise<Grade[]> {
    const grades = await this.gradeRepository.find({ where: { status: 1 } });
    if (!grades || grades.length === 0) {
      throw new NotFoundException('No grades found');
    }
    return grades;
  }

  async createResult(paperid: string, section: string, cls: string) {
    return await this.dataSource.transaction(async (manager) => {
      const existingResults = await manager.find(Result, {
        where: { paperid, studentclass: cls, studentsection: section },
      });
      if (existingResults.length > 0) {
        return {
          message: 'Result already available',
          success: 'Result Present',
        };
      }
      const answers = await manager.query(
        `
        SELECT si.Id as studentid, si.Name as studentname, si.RollNo as rollno, an.section as section,
              GROUP_CONCAT(eq.questionId ORDER BY eq.sequence ASC) AS qid,
              GROUP_CONCAT(an.uanswer ORDER BY eq.sequence ASC) AS uanswer,
              GROUP_CONCAT(an.canswer ORDER BY eq.sequence ASC) AS canswer,
              GROUP_CONCAT(sub.subject ORDER BY eq.sequence ASC) AS subdomain
        FROM answer as an 
        LEFT JOIN studentinformation si ON an.studentid = si.Id  
        LEFT JOIN examquestion eq ON an.qid = eq.questionId 
        LEFT JOIN questions q ON eq.questionId = q.id 
        LEFT JOIN subject sub ON sub.id=q.subdomain
        WHERE an.status = 1 AND an.paperid = ? AND an.class = ? AND an.section = ? 
        GROUP BY an.section, an.studentid 
        ORDER BY an.studentid, eq.sequence ASC;
      `,
        [paperid, cls, section]
      );

      if (!answers.length) {
        throw new HttpException('No answers found', HttpStatus.NOT_FOUND);
      }

      const grades = await manager.find(Grade, { where: { status: 1 } });

      const resultsData = answers.map((answer) => {
        const questionIds = answer.qid.split(',');
        const studentAnswers = answer.uanswer.split(',');
        const correctAnswers = answer.canswer.split(',');
        const subdomains = answer.subdomain.split(',');

        const scoreData = questionIds.map(
          (qid: string, i: string | number) => ({
            id: parseInt(qid),
            subdomain: subdomains[i],
            data: studentAnswers[i] === correctAnswers[i] ? 1 : 0,
            answered: studentAnswers[i],
          })
        );

        const subdomainStats = this.sumDataBySubdomain(scoreData);
        const subdomandata = Object.entries(subdomainStats).map(([subdomain, statsRaw]) => {
            const stats = statsRaw as { sum: number; count: number };
            const subPercent = (stats.sum / stats.count) * 100;
            const subGrade = grades.find(g => subPercent > (g.markstart - 1) && subPercent <= g.markend)?.grade || 'F';
            return { subdomain, percentage: subPercent.toFixed(2), grade: subGrade };
        });
        const percentage = ((scoreData.reduce((a, b) => a + b.data, 0) / scoreData.length) * 100).toFixed(2);
        const grade = grades.find(g => parseFloat(percentage) > (g.markstart - 1) && parseFloat(percentage) <= g.markend)?.grade || 'F';              
        return {
          paperid,
          studentid: answer.studentid,
          studentclass: cls,
          studentsection: section.toUpperCase(),
          rollno: answer.rollno,
          studentname: answer.studentname,
          studentpercentage: percentage,
          studentgrade: grade,
          studentpercentile: '',
          questiondata: scoreData,
          subdomandata: subdomandata,
        };
      });

      const insertResult = await manager.insert(Result, resultsData);
      await this.alertCheck(manager, insertResult.identifiers[0].id, insertResult.raw.affectedRows, cls, section);
      
      return { message: 'Transaction completed successfully', success: 'success', results: resultsData };
    });
  }
    

  public sumDataBySubdomain(dataList) {
    return dataList.reduce((acc, item) => {
      if (!acc[item.subdomain]) {
        acc[item.subdomain] = { sum: 0, count: 0 };
      }
      acc[item.subdomain].sum += item.data;
      acc[item.subdomain].count += 1;
      return acc;
    }, {});
  }

  private async alertCheck(manager, insertId: number, affectedRows: number, cls: string, section: string) {
    const firstId = insertId;
    const lastId = firstId + affectedRows - 1;
    
    const results = await manager.find(Result, { where: { id: Between(firstId, lastId) } });
    const alertData = results
      .filter(result => result.studentpercentage <= 35)
      .map(result => ({
        id: result.studentid,
        rollno: result.rollno,
        name: result.studentname,
        percentage: result.studentpercentage,
        grade: result.studentgrade,
      }));
    
    if (alertData.length > 0) {
      const existingAlerts = await manager.find(Alert, {
        where: { alertpaperid: results[0].paperid, alertclass: cls, alertsection: section },
      });

      if (existingAlerts.length === 0) {
        await manager.insert(Alert, {
          alertpaperid: results[0].paperid,
          alertclass: cls,
          alertsection: section,
          alertstype: 'STUDENTPERFORMANCE',
          alertdetails: JSON.stringify(alertData),
        });
      }
    }
  }

//-------
async getReportData(studentClass: string, paperId?: string, subdomain?: string) {
  const queryRunner = this.dataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();

  try {  
    const paperQuery = await this.questionPaperRepository
    .createQueryBuilder('p')
    .innerJoin(Subject, 's', 's.id = p.subject')
    .select([
      'p.id AS id',
      'p.class AS class',
      's.subject AS subject' // Adjust if your Subject entity uses 'subjectname'
    ])
    .where(qb => {
      const subQuery = qb
        .subQuery()
        .select('DISTINCT r.paperid')
        .from(Result, 'r')
        .where('r.status = 1')
        .andWhere('r.studentclass = :studentClass', { studentClass })
        .groupBy('DATE_FORMAT(r.createdate, "%Y-%m")')
        .getQuery();
      return 'p.id IN ' + subQuery;
    })
    .setParameter('studentClass', studentClass)
    .getRawMany(); 
    
    const papers = paperQuery;
    // console.log('papers', papers.length);
    if (papers.length === 0) {
      throw new HttpException('No Result found', HttpStatus.NOT_FOUND);
    }   
    const paperIds = papers.map(p => p.id);

    const grades = await this.gradeRepository.find({ where: { status: 1 } });

    const means = grades.map((g) => {
      const len = g.markend - (g.markstart - 2);
      const numbers = Array.from({ length: len }, (_, i) => g.markstart - 1 + i);
      return numbers.reduce((sum, val) => sum + val, 0) / numbers.length;
    });
    const mean = means.slice(0, means.length - 1);

    const resultConditions: any = {
      status: 1,
      studentclass: studentClass,
    };

    if (paperId) {
      resultConditions.paperid = Number(paperId);
    } else {
      resultConditions.paperid = paperIds.length > 0 ? paperIds : -1;
    }

    const results = await this.resultRepository.find({
      where: resultConditions,
      //relations: ['questiondata'],
    });

    const sections = Array.from(new Set(results.map((r) => r.studentsection)));

    const quesid = {};
    const answerData: { paperid: number; data: Record<string, any> }[] = [];

    for (const p of papers) {
      const sectionData = {};
      const qids: number[] = [];

      for (const section of sections) {
        const countGrade = {};
        grades.forEach((g) => (countGrade[g.grade] = 0));

        const filteredResults = results.filter(
          (r) => Number(r.paperid) === Number(p.id) && r.studentsection === section,
        );

        for (let i = 0; i < filteredResults.length; i++) {
          const r = filteredResults[i];
          let correct = 0;
          let totalQuestions = 0;

          const questionData = Array.isArray(r.questiondata) 
            ? r.questiondata 
            : typeof r.questiondata === 'string' 
              ? JSON.parse(r.questiondata || '[]') 
              : [];
          for (const q of questionData) {
            const match = !subdomain || subdomain === q.subdomain;
            if (match) {
              correct += q.data;
              totalQuestions++;
              if (i === 0 && !qids.includes(q.id)) qids.push(q.id);
            }
          }

          let percent = (correct * 100) / totalQuestions;
          const grade = grades.find(
            (g) => percent >= g.markstart && percent <= g.markend,
          );
          if (grade) countGrade[grade.grade]++;
        }

        const total: any = Object.values(countGrade).reduce((a, b) => (a as number) + (b as number), 0 as number);
        const percentGrades = Object.entries(countGrade).map(
          ([_, count]) => ((Number(count) * 100) / total).toFixed(2),
        );

        let meanPercent = 0;
        Object.values(countGrade).forEach((count, i) => {
          if (i < mean.length) {
            meanPercent += (count as number) * mean[i];
          }
        });

        sectionData[section] = {
          count: Object.values(countGrade),
          percent: percentGrades,
          meanpercent: (meanPercent / total).toFixed(2),
        };
      }

      answerData.push({ paperid: p.id, data: sectionData });
      quesid[p.id] = qids;
    }

    await queryRunner.commitTransaction();

    return {
      message: 'Transaction completed successfully',
      section: sections,
      paper: papers,
      answer: answerData,
      quesid,
    };
  } catch (err) {
    await queryRunner.rollbackTransaction();
    throw err;
  } finally {
    await queryRunner.release();
  }
}
async getStudentByClass(studentClass: string, paperId?: string, section?: string) {
    const where: any = {};
    where.class = studentClass;    
    if (section && section !== 'undefined') {
      where.section = section;
    }
    const result1 = await this.studentRepository.find({
      where: where,      
    });
    
    if (!result1 || result1.length === 0) {
      throw new NotFoundException('No students found for the given class');
    }

    const result2 = await this.examQuestionRepository
    .createQueryBuilder('eq')
    .innerJoin('questions', 'q', 'q.id = eq.questionId')
    .where('eq.paperId = :paperId', { paperId })
    .orderBy('eq.sequence', 'ASC')
    .select([
      'q.id AS id',
      'eq.sequence AS sequence',
      'q.quesType AS quesType',
      'q.correctAns AS correctAns',
      'eq.marks AS marks',
    ])
    .getRawMany();

    if (!result2 || result2.length === 0) {
      throw new NotFoundException('No students found for the given class and paper');
    }
    return {
      message: 'Students found successfully',
      studentData: result1,
      questionData: result2,
    }
 }

 /*
  async getResultList(query: any) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const subdomain = query.subdomain;
      const qarr = [];
      const rowsection = [];
      const subdomainlist = [];
      const result = [];

      const resultSql = `
        SELECT * FROM result 
        WHERE paperid = ? AND studentclass = ? AND studentsection = ?
      `;
      const result1 = await queryRunner.query(resultSql, [
        query.paperid,
        query.class,
        query.section,
      ]);
      
      if (!result1.length) {
        await queryRunner.rollbackTransaction();
        return { message: 'no data' };
      }

      const grades = await queryRunner.query(
        `SELECT grade, markstart, markend FROM grade WHERE status = 1`,
      );

      const countgrade = {};
      const percentile = {};

      grades.forEach((item) => {
        countgrade[item.grade] = 0;
      });

      result1[0].subdomandata.forEach((item) => {
        subdomainlist.push(item.subdomain);
      });

      result1[0].questiondata.forEach((ques) => {
        if (!subdomain || subdomain === ques.subdomain) {
          qarr.push(ques.id);
        }
      });

      result1.forEach((ques) => {
        let data = [];
        let quesdata = [];
        let percentage = ques.studentpercentage;
        let grade = ques.studentgrade;

        if (subdomain) {
          ques.subdomandata.forEach((item) => {
            if (item.subdomain === subdomain) {
              percentage = item.percentage;
              grade = item.grade;
              countgrade[grade]++;
              percentile[percentage] = (percentile[percentage] || 0) + 1;
            }
          });
        } else {
          countgrade[grade]++;
          percentile[percentage] = (percentile[percentage] || 0) + 1;
        }

        ques.questiondata.forEach((idata) => {
          if (!subdomain || subdomain === idata.subdomain) {
            data.push(idata.data);
            quesdata.push(idata);
          }
        });

        result.push({
          id: ques.id,
          paperid: ques.paperid,
          studentid: ques.studentid,
          studentclass: ques.studentclass,
          studentsection: ques.studentsection,
          rollno: ques.rollno,
          studentname: ques.studentname,
          studentpercentage: percentage,
          studentgrade: grade,
          studentpercentile: ques.studentpercentile,
          questiondata: quesdata,
        });

        rowsection.push({ data });
      });

      const studentcount = rowsection.length;
      let avg = [];
      let vsum = [];

      rowsection.forEach((item, index) => {
        if (index === 0) {
          vsum = item.data;
        } else {
          vsum = vsum.map((val, i) => val + item.data[i]);
        }
      });

      avg = vsum.map((val) =>
        parseFloat(((val * 100) / studentcount).toFixed(2).replace(/[.,]00$/, '')),
      );

      await queryRunner.commitTransaction();

      return {
        message: 'data',
        qid: qarr,
        result: result,
        avg: avg,
        subDomain: subdomainlist,
        countgrade: countgrade,
        percentile: percentile,
      };
    } catch (err) {
      console.log('Error in getResultList:', err);
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }
*/

async getResultList(data: any) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const subdomain = data.subdomain;
      const qarr: number[] = [];
      const rowsection: { data: number[] }[] = [];
      const subdomainlist: string[] = [];
      const result: ResultRow[] = [];
      const avg: number[] = [];
      let vsum: number[] = [];

      const result1 = await queryRunner.query(
        `SELECT * FROM result WHERE paperid = ? AND studentclass = ? AND studentsection = ?`,
        [data.paperid, data.class, data.section],
      );

      if (!result1.length) {
        await queryRunner.rollbackTransaction();
        return { message: 'no data adf' };
      }

      const grades = await queryRunner.query(
        `SELECT grade, markstart, markend FROM grade WHERE status = 1`,
      );

      const countgrade: Record<string, number> = {};
      const percentile: Record<number, number> = {};

      grades.forEach((item: any) => {
        countgrade[item.grade] = 0;
      });

      result1[0].subdomandata.forEach((item: SubdomainData) => {
        subdomainlist.push(item.subdomain);
      });

      result1[0].questiondata.forEach((ques: QuestionItem) => {
        if (!subdomain || subdomain === ques.subdomain) {
          qarr.push(ques.id);
        }
      });

      result1.forEach((ques: any) => {
        const data: number[] = [];
        const quesdata: QuestionItem[] = [];

        let percentage = ques.studentpercentage;
        let grade = ques.studentgrade;

        if (subdomain) {
          ques.subdomandata.forEach((item: SubdomainData) => {
            if (item.subdomain === subdomain) {
              percentage = item.percentage;
              grade = item.grade;

              countgrade[grade]++;
              percentile[percentage] = (percentile[percentage] || 0) + 1;
            }
          });
        } else {
          countgrade[grade]++;
          percentile[percentage] = (percentile[percentage] || 0) + 1;
        }

        ques.questiondata.forEach((idata: QuestionItem) => {
          if (!subdomain || subdomain === idata.subdomain) {
            data.push(idata.data);
            quesdata.push(idata);
          }
        });

        const inresult: ResultRow = {
          id: ques.id,
          paperid: ques.paperid,
          studentid: ques.studentid,
          studentclass: ques.studentclass,
          studentsection: ques.studentsection,
          rollno: ques.rollno,
          studentname: ques.studentname,
          studentpercentage: percentage,
          studentgrade: grade,
          studentpercentile: ques.studentpercentile,
          questiondata: quesdata,
        };

        result.push(inresult);
        rowsection.push({ data });
      });

      const studentcount = rowsection.length;

      rowsection.forEach((item, index) => {
        if (index === 0) {
          vsum = [...item.data];
        } else {
          vsum = vsum.map((val, i) => val + item.data[i]);
        }
      });

      const avgResult = vsum.map((val) =>
        parseFloat(((val * 100) / studentcount).toFixed(2).replace(/[.,]00$/, '')),
      );

      await queryRunner.commitTransaction();

      return {
        message: 'data',
        qid: qarr,
        result: result,
        avg: avgResult,
        subDomain: subdomainlist,
        countgrade: countgrade,
        percentile: percentile,
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async getAvg(query: any): Promise<any> {
    console.log('getAvg query', query);
    const questions = await this.questionRepository.findOne({
      where: { id: query.qid, dmlType: 'I' }
      });
      const answerMap: Record<string, string> = {
        A: 'optA',
        B: 'optB',
        C: 'optC',
        D: 'optD',
      };
      try {
      const canswer = answerMap[questions?.correctAns?.toLocaleUpperCase() || ''] || '';

    // console.log('query', query);
    const queryBuilder = this.resultRepository
    .createQueryBuilder('result')
    .where(`JSON_CONTAINS(result.questiondata, CAST(:jsonData AS JSON), '$')`)
    .andWhere('result.paperid = :paperid', { paperid: query.paperid })
    .andWhere('result.studentclass = :studentclass', { studentclass: query.class })
    .setParameters({
      jsonData: JSON.stringify({ id: Number(query.qid) }),
    })
    .addOrderBy('result.studentsection', 'ASC')    

  if (query?.section) {
      queryBuilder.andWhere('result.studentsection = :section', { section: query.section });
    }        
  const rows = await queryBuilder.getMany();

  const grouped: Record<string, number> = {};

  for (const row of rows) {
    if (!row.questiondata) continue;

    let questions: any[] = [];
    if (typeof row.questiondata === 'string') {
      questions = JSON.parse(row.questiondata);
    } else if (Array.isArray(row.questiondata)) {
      questions = row.questiondata;
    } else {
      continue;
    }

    const q = questions.find((q: any) => q.id === Number(query.qid));
    if (q && q.answered) {
      const key = `${q.answered}`; // can include more keys if needed
      grouped[key] = (grouped[key] || 0) + 1;
    }
  }
  console.log('grouped', grouped);
  const allstudent = Object.values(grouped).reduce((a, b) => a + b, 0);

  const result = Object.entries(grouped).map(([uanswer, count]) => {
  const percent: any = ((count * 100) / allstudent)
    .toFixed(2)
    .replace(/[.,]00$/, "");

  return {
    // section: (query.section).toUpperCase(),
    // studentsection,    
    qid: Number(query.qid),
    uanswer,
    canswer: canswer,
    count,
    tval: percent
    };
  });

  const sortedResult = result.sort((a, b) => {
  return a.uanswer.localeCompare(b.uanswer);
});

  const rdata: Record<string, any[]> = {};
  rdata[query.section] = sortedResult;    
  return rdata ;
  } catch (error) {
    console.error('Error in findQuestions:', error);
    throw new NotFoundException('Error retrieving questions');
  }
}

 async findQuestions(qids: string): Promise<any> {
    if (!qids) {
      throw new NotFoundException('ID is required');
    }
    const ids = qids.split(',').map(id => parseInt(id, 10));
    if (ids.some(isNaN)) {
      throw new NotFoundException('Invalid question IDs provided');
    }
    console.log('ids', Array.isArray(ids));
    
    const questions = await this.questionRepository.find({
      where: { id: In(ids), dmlType: 'I' },      
    });
    
    if (!questions || questions.length === 0) {
      throw new NotFoundException('No questions found for this paper');
    }
    return questions;
  }
}
