const config = {
  hostname: String(import.meta.env.VITE_HOST),
  apihost: String(import.meta.env.VITE_APIHOST),
}

export default config
