import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'studentsubdomainresult' })
export class StudentSubdomainResult {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  paperid!: number;

  @Column()
  studentid!: number;

  @Column()
  class!: string;

  @Column({ nullable: true })
  section!: string;

  @Column()
  subdomain!: string;

  @Column('float')
  obtainedMarks!: number;

  @Column('float')
  maxMarks!: number;

  @Column('float')
  percentage!: number;

  @Column()
  grade!: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;
}
