import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
    DndContext,
    closestCenter,
    PointerSensor,
    useSensor,
    useSensors,
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    useSortable,
    verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { CiBank } from "react-icons/ci";
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaArrowsAlt, FaBars, FaGripHorizontal, FaPlus, FaMinus, FaList } from "react-icons/fa";
import { AiOutlineColumnWidth, AiOutlineColumnHeight } from "react-icons/ai";
import { useLocation } from 'react-router-dom';
import { FaPen } from "react-icons/fa6";


const normalizeQuestions = (raw) =>
    raw.map((r) => {
        const options = [];
        const addOpt = (labelText, img) => {
            if (img) {
                options.push({ text: labelText, image: img });
            } else {
                options.push(labelText);
            }
        };
        addOpt(r.optA ?? '');
        addOpt(r.optB ?? '');
        addOpt(r.optC ?? '');
        addOpt(r.optD ?? '');
        return {
            id: r.id,
            text: r.question || '',
            options,
            marks: r.marks ?? null,
            image: r.image ?? null,
        };
    });

const Toolbar = ({ onAction, optionLayout, fontSize, currentMarks, selectedImageSize, optionIdType, setOptionIdType }) => (
    <div className="d-flex gap-3 mb-2 px-3 toolcontainer rounded bg-opacity-10">
        <div className='border-end pe-3'>
            <div className='my-2 btn-group justify-content-between' role="group">
                <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => onAction("increaseText")}>
                    <FaPlus />
                </button>
                <span type="button" className='btn btn-sm btn-outline-secondary p-0 m-0' >
                    <select
                        type="button"
                        value={fontSize}
                        onChange={(e) => onAction("setFontSize", parseInt(e.target.value))}
                        className="form-select toolbar-select "
                    >
                        {[2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40].map((size) => (
                            <option key={size} value={size}>
                                {size}
                            </option>
                        ))}
                    </select>
                </span>
                <button className='btn btn-sm btn-outline-secondary' onClick={() => onAction("decreaseText")}>
                    <FaMinus />
                </button>
            </div>
        </div>

        <div className='border-end pe-3'>
            <div className='my-2 btn-group justify-content-between' role="group">
                <input
                    type="number"
                    value={selectedImageSize?.width || ""}
                    onChange={(e) => onAction("setImageWidth", parseInt(e.target.value) || 0)}
                    className='btn btn-outline-secondary input-container'
                />
                <div type="button" className="btn pt-1 btn-outline-secondary" >
                    <AiOutlineColumnWidth size={22} />
                </div>
                <div type="button" className="btn pt-1 btn-outline-secondary" >
                    <AiOutlineColumnHeight size={22} />
                </div>
                <input
                    type="number"
                    value={selectedImageSize?.height || ""}
                    onChange={(e) => onAction("setImageHeight", parseInt(e.target.value) || 0)}
                    className='btn  btn-outline-secondary input-container'
                />
            </div>
        </div>

        <div className='border-end pe-3'>
            <div className="my-2 btn-group justify-content-between dropdown">
                <button
                    className="btn btn-outline-secondary dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    Marks: {currentMarks ?? ""}
                </button>
                <ul className="dropdown-menu">
                    {[0.5, 1, 2, 3, 4, 5].map((m) => (
                        <li key={m}>
                            <button
                                className="dropdown-item"
                                onClick={() => onAction("setMarks", m)}
                            >
                                {m}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>

        <div className='border-end pe-3'>
            <div className="my-2 btn-group justify-content-between dropdown">
                <button
                    className="btn dropdown-toggle d-flex align-items-center justify-content-center btn-outline-secondary"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    <FaList size={25} className='pe-2' /> {optionIdType || "  "}
                </button>

                <ul className="dropdown-menu text-center">
                    {["A", "a", "1", "i", "I"].map((opt) => (
                        <li key={opt}>
                            <button
                                type="button"
                                className={`dropdown-item border-bottom ${optionIdType === opt ? "active" : ""}`}
                                onPointerDown={(e) => {
                                    e.preventDefault();
                                    setOptionIdType(opt);
                                }}
                                onClick={() => setOptionIdType(opt)}
                                aria-pressed={optionIdType === opt}
                            >
                                {opt}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>



        <div className='border-end pe-3'>
            <div className="my-2 btn-group justify-content-between">
                <button
                    type="button"
                    className="btn btn-sm btn-outline-secondary p-2 "
                    onClick={() => onAction("toggleLayout")}
                >
                    {optionLayout === "vertical" && <FaBars />}
                    {optionLayout === "horizontal" && <FaGripHorizontal />}
                    {optionLayout === "two-column" && (
                        <FaGripHorizontal style={{ transform: "rotate(90deg)" }} size={17} />
                    )}
                </button>
            </div>
        </div>
    </div>
);

export function SortableQuestion({
    question,
    index,
    handleChangeMarks,
    optionIdType,
    setOptionIdType,
    ui = {},
    updateUi = () => { }
}) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
        id: question.id,
    });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        padding: "10px",
    };

    const [fontSize, setFontSize] = useState(ui.fontSize ?? 16);
    const [align, setAlign] = useState(ui.align ?? "left");
    const [imageSizes, setImageSizes] = useState(ui.imageSizes ?? {});
    const [selectedImageKeys, setSelectedImageKeys] = useState(new Set(ui.selectedImageKeys ?? []));
    const [optionLayout, setOptionLayout] = useState(ui.optionLayout ?? "vertical");

    useEffect(() => {
        if (!ui) return;
        if (ui.fontSize !== undefined) setFontSize(ui.fontSize);
        if (ui.align) setAlign(ui.align);
        if (ui.imageSizes) setImageSizes(ui.imageSizes);
        if (ui.selectedImageKeys !== undefined) setSelectedImageKeys(new Set(ui.selectedImageKeys));
        if (ui.optionLayout) setOptionLayout(ui.optionLayout);
    }, [ui]);

    const handleToolbarAction = (action, value) => {
        const firstSelected = [...selectedImageKeys][0];

        if (firstSelected) {
            if (action === "setImageWidth" || action === "setImageHeight") {
                setImageSizes((prev) => {
                    const current = prev[firstSelected] || { width: 120, height: 50 };
                    const next = {
                        ...prev,
                        [firstSelected]: {
                            ...current,
                            width: action === "setImageWidth" ? (value || 50) : current.width,
                            height: action === "setImageHeight" ? (value || 50) : current.height
                        }
                    };
                    updateUi({ imageSizes: next, selectedImageKeys: [firstSelected] });
                    return next;
                });
                return;
            }
        }

        switch (action) {
            case "increaseText":
                setFontSize((f) => {
                    const next = f + 2;
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "decreaseText":
                setFontSize((f) => {
                    const next = Math.max(10, f - 2);
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "setFontSize":
                setFontSize(value);
                updateUi({ fontSize: value });
                break;
            case "setMarks":
                if (handleChangeMarks) {
                    handleChangeMarks(question.id, value);
                }
                break;
            case "toggleLayout":
                setOptionLayout((prev) => {
                    const next =
                        prev === "vertical" ? "horizontal" :
                            prev === "horizontal" ? "two-column" :
                                "vertical";
                    updateUi({ optionLayout: next });
                    return next;
                });
                break;
            default:
                break;
        }
    };

    function removeInlineStyles(html) {
        if (!html) return "";
        html = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        return html;
    }

    function parseQuestionText(html, questionId) {
        if (!html) return null;
        const cleanHtml = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        const parts = [];
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(cleanHtml)) !== null) {
            if (match.index > lastIndex) {
                const chunk = cleanHtml.slice(lastIndex, match.index);
                parts.push(
                    <span
                        key={`chunk-${lastIndex}`}
                        dangerouslySetInnerHTML={{ __html: chunk }}
                    />
                );
            }

            const src = match[1];
            const imgKey = `q-${questionId}-text-img-${match.index}`;
            parts.push(
                <img
                    key={imgKey}
                    src={src}
                    alt=""
                    onClick={() => {
                        setSelectedImageKeys(new Set([imgKey]));
                        setImageSizes((prev) => {
                            if (prev[imgKey]) {
                                updateUi({ selectedImageKeys: [imgKey] });
                                return prev;
                            }
                            const next = {
                                ...prev,
                                [imgKey]: { width: 120, height: 50 }
                            };
                            updateUi({ imageSizes: next, selectedImageKeys: [imgKey] });
                            return next;
                        });
                    }}
                    onPointerDown={(e) => e.stopPropagation()}
                    style={{
                        width: imageSizes[imgKey]?.width || 120,
                        height: imageSizes[imgKey]?.height || 50,
                        border: selectedImageKeys.has(imgKey) ? "2px solid blue" : "none",
                        cursor: "pointer",
                        margin: "5px 0"
                    }}
                />
            );
            lastIndex = imgRegex.lastIndex;
        }
        if (lastIndex < cleanHtml.length) {
            const chunk = cleanHtml.slice(lastIndex);
            parts.push(
                <span
                    key={`chunk-${lastIndex}`}
                    dangerouslySetInnerHTML={{ __html: chunk }}
                />
            );
        }
        return parts;
    }

    const effectiveOptionIdType = ui?.optionIdType || optionIdType;
    const getOptionLabel = (i) => {
        switch (effectiveOptionIdType) {
            case "A":
                return String.fromCharCode(65 + i);
            case "a":
                return String.fromCharCode(97 + i);
            case "1":
                return i + 1;
            case "i":
                return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][i] || i + 1;
            case "I":
                return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][i] || i + 1;
            default:
                return String.fromCharCode(65 + i);
        }
    };

    useEffect(() => {
        function handleClickOutside(e) {
            if (
                selectedImageKeys.size > 0 &&
                !e.target.closest("img") &&
                !e.target.closest(".toolcontainer")
            ) {
                setSelectedImageKeys(new Set());
                updateUi({ selectedImageKeys: [] });
            }
        }
        document.addEventListener("click", handleClickOutside);
        return () => document.removeEventListener("click", handleClickOutside);
    }, [selectedImageKeys, updateUi]);

    const mainImgKey = `q-${question.id}-main`;

    // function parseRichText(content) {
    //     return { __html: content };
    // }

    const optionsContainerStyle = {
        fontSize: `${fontSize}px`,
        textAlign: align,
        display: "flex",
        flexDirection: optionLayout === "vertical" ? "column" : "row",
        flexWrap: optionLayout === "two-column" ? "wrap" : "nowrap",
        gap: optionLayout === "horizontal" ? "40px" : "10px",
        alignItems: optionLayout === "vertical" ? "flex-start" : "center",
    };

    return (
        <div ref={setNodeRef} style={style} className="mb-3 border p-2 rounded bg-white">
            <Toolbar
                onAction={handleToolbarAction}
                optionLayout={optionLayout}
                fontSize={fontSize}
                currentMarks={question.marks}
                optionIdType={effectiveOptionIdType}
                setOptionIdType={(val) => {
                    setOptionIdType(val);
                    updateUi({ optionIdType: val });
                }}
                selectedImageSize={
                    [...selectedImageKeys].length > 0
                        ? imageSizes[[...selectedImageKeys][0]]
                        : { width: "", height: "" }
                }
            />

            {/* move dnd-kit attributes/listeners to the small grab handle only (no stopPropagation here) */}
            <div style={{ fontSize: `${fontSize}px`, textAlign: align }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div className="question-html d-flex">
                        <span
                            className="me-2"
                            style={{ cursor: "grab" }}
                            {...attributes}
                            {...listeners}
                        >
                            <FaArrowsAlt />
                        </span>

                        <strong className="me-1">{`Ques.${index + 1}`}</strong>{" "}
                        <div>
                            <div className="question-html d-flex flex-column align-items-start mb-2 questionstylecustom">
                                {parseQuestionText(removeInlineStyles(question.text), question.id)}
                            </div>
                        </div>
                    </div>

                    {question.marks && (
                        <div style={{ marginLeft: "20px", whiteSpace: "nowrap" }}>({question.marks})</div>
                    )}
                </div>

                {question.image && (
                    <img
                        src={question.image}
                        alt="question"
                        onClick={() => {
                            const key = mainImgKey;
                            setSelectedImageKeys(new Set([key]));
                            setImageSizes(prev => {
                                if (prev[key]) {
                                    updateUi({ selectedImageKeys: [key] });
                                    return prev;
                                }
                                const next = { ...prev, [key]: { width: 120, height: 50 } };
                                updateUi({ imageSizes: next, selectedImageKeys: [key] });
                                return next;
                            });
                        }}
                        onPointerDown={(e) => e.stopPropagation()}
                        style={{
                            width: imageSizes[mainImgKey]?.width || 120,
                            height: imageSizes[mainImgKey]?.height || 50,
                            border: selectedImageKeys.has(mainImgKey) ? "2px solid blue" : "none",
                            cursor: "pointer",
                            margin: "5px 0"
                        }}
                    />
                )}
            </div>

            {/* Options container applies layout styles here */}
            <div className="mt-2" style={optionsContainerStyle}>
                {question.options.map((opt, i) => {
                    const imgKey = `q-${question.id}-opt-${i}`;

                    // option item style for two-column mode
                    const optionItemStyle = {
                        display: "flex",
                        alignItems: "center",
                        width: optionLayout === "two-column" ? "45%" : "auto",
                        minWidth: optionLayout === "two-column" ? "200px" : "auto",
                        marginBottom: optionLayout === "vertical" ? "8px" : "0",
                    };

                    return (
                        <div key={i} style={optionItemStyle}>
                            <span className="fw-bold me-2">{getOptionLabel(i)}.</span>

                            {typeof opt === "string" ? (
                                <div className="option-html d-flex align-items-center">
                                    {parseQuestionText(removeInlineStyles(opt), `${question.id}-opt-${i}`)}
                                </div>
                            ) : (
                                <>
                                    <div className="option-html d-flex align-items-center">
                                        {parseQuestionText(removeInlineStyles(opt.text || ""), `${question.id}-opt-${i}`)}
                                    </div>

                                    {opt.image && (
                                        <img
                                            src={opt.image}
                                            alt={`option-${i}`}
                                            onClick={() => {
                                                setSelectedImageKeys(new Set([imgKey]));
                                                setImageSizes(prev => {
                                                    if (prev[imgKey]) {
                                                        updateUi({ selectedImageKeys: [imgKey] });
                                                        return prev;
                                                    }
                                                    const next = { ...prev, [imgKey]: { width: 50, height: 50 } };
                                                    updateUi({ imageSizes: next, selectedImageKeys: [imgKey] });
                                                    return next;
                                                });
                                            }}
                                            onPointerDown={(e) => e.stopPropagation()}
                                            style={{
                                                width: imageSizes[imgKey]?.width || 50,
                                                height: imageSizes[imgKey]?.height || 50,
                                                marginLeft: "10px",
                                                border: selectedImageKeys.has(imgKey) ? "2px solid blue" : "none",
                                                cursor: "pointer",
                                            }}
                                        />
                                    )}
                                </>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

const QuestionPreview = () => {
    const [active, setActive] = useState(true);
    const location = useLocation();
    const { selectedQuestion } = location.state || { selectedQuestion: [] };

    const [rawInitial, setrawInitial] = useState(selectedQuestion);

    const [questions, setQuestions] = useState(() => normalizeQuestions(rawInitial));

    const sensors = useSensors(useSensor(PointerSensor));

    const handleDragEnd = (event) => {
        const { active, over } = event;
        if (!over) return;
        if (active.id !== over?.id) {
            const oldIndex = questions.findIndex((q) => q.id === active.id);
            const newIndex = questions.findIndex((q) => q.id === over?.id);
            if (oldIndex !== -1 && newIndex !== -1) {
                setQuestions(arrayMove(questions, oldIndex, newIndex));
            }
        }
    };

    const [optionIdType, setOptionIdType] = useState("A");
    const previewRef = useRef(null);
    const LOCAL_STORAGE_KEY = 'qb_ui_settings';
    const [generalDetails, setGeneralDetails] = useState({
        paperName: "Sample Question Paper",
        duration: "70 min",
        className: "X-B",
        maxMarks: "X",
        subjectName: "Mathematics(201)",
        date: "22-07-2025"
    });

    const [uiSettings, setUiSettings] = useState(() => {
        try {
            const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === 'object' && parsed.uiSettings) return parsed.uiSettings;
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
            return {};
        } catch (e) {
            console.error("Failed to parse local storage data", e);
            return {};
        }
    });

    const unwrapSavedWrapper = (html) => {
        if (!html || typeof html !== 'string') return html;
        const wrapperRegex = /^<div[^>]*style\s*=\s*(['"])(?:(?!\1)[\s\S])*?(?:font-size|text-align)[\s\S]*?\1[^>]*>([\s\S]*?)<\/div>$/i;
        const m = html.match(wrapperRegex);
        if (m && m[2] !== undefined) {
            return m[2];
        }
        return html;
    };

    const unwrapOptionIfWrapped = (html) => {
        return unwrapSavedWrapper(html);
    };

    useEffect(() => {
        const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (!raw) return;
        let parsed;
        try {
            parsed = JSON.parse(raw);
        } catch (e) {
            console.error("Failed to parse local storage data", e);
            return;
        }

        if (parsed.questions) {
            const normalized = parsed.questions.map(q => {
                // Build options array from optA..optD if needed
                const hasOptionsArray = Array.isArray(q.options) && q.options.length > 0;
                const optionsFromOpts = [
                    q.optA !== undefined ? q.optA : "",
                    q.optB !== undefined ? q.optB : "",
                    q.optC !== undefined ? q.optC : "",
                    q.optD !== undefined ? q.optD : ""
                ];

                // Unwrap saved styled text back to raw editable text
                const rawText = unwrapSavedWrapper(q.text || "");

                // For options, unwrap each option (they might have been saved as wrapped HTML)
                const rawOptions = (hasOptionsArray ? q.options : optionsFromOpts).map(opt => {
                    if (typeof opt === 'string') {
                        return unwrapOptionIfWrapped(opt || "");
                    } else if (opt && typeof opt === 'object') {
                        // object option e.g. { text: "...", image: "data:..." }
                        return {
                            ...opt,
                            text: unwrapOptionIfWrapped(opt.text || "")
                        };
                    } else {
                        return opt;
                    }
                });

                return {
                    ...q,
                    // use raw, unwrapped HTML for editable state (so future saves re-wrap with latest UI)
                    text: rawText,
                    options: rawOptions
                };
            });

            setQuestions(normalized);
        }

        if (parsed.generalDetails) setGeneralDetails(parsed.generalDetails);

        const uiMap = {};
        parsed.questions?.forEach(q => {
            if (q.ui) uiMap[q.id] = q.ui;
        });
        setUiSettings(uiMap);
    }, []);

    useEffect(() => {
        const totalMarks = questions.reduce((sum, q) => {
            return sum + (parseFloat(q.marks) || 0);
        }, 0);

        setGeneralDetails(prev => ({
            ...prev,
            maxMarks: totalMarks
        }));
    }, [questions]);

    const uiPatchQueue = useRef([]);
    const uiFlushScheduled = useRef(false);

    const flushUiQueue = useCallback(() => {
        if (uiPatchQueue.current.length === 0) {
            uiFlushScheduled.current = false;
            return;
        }
        setUiSettings(prev => {
            const next = { ...(prev || {}) };
            for (const { questionId, patch } of uiPatchQueue.current) {
                next[questionId] = {
                    ...(next[questionId] || {}),
                    ...patch
                };
            }
            return next;
        });
        uiPatchQueue.current = [];
        uiFlushScheduled.current = false;
    }, []);

    const updateUiForQuestion = useCallback((questionId, patch) => {
        uiPatchQueue.current.push({ questionId, patch });
        if (!uiFlushScheduled.current) {
            uiFlushScheduled.current = true;
            setTimeout(() => {
                flushUiQueue();
            }, 0);
        }
    }, [flushUiQueue]);

    useEffect(() => {
        setUiSettings(prev => {
            const copy = { ...(prev || {}) };
            let changed = false;
            questions.forEach(q => {
                if (!copy[q.id]) {
                    copy[q.id] = {
                        fontSize: 16,
                        align: 'left',
                        optionLayout: 'vertical',
                        optionIdType: optionIdType || 'A',
                        imageSizes: {},
                        selectedImageKey: null,
                        marks: q.marks || null
                    };
                    changed = true;
                } else {
                    if (copy[q.id].marks === undefined) { copy[q.id].marks = q.marks || null; changed = true; }
                    if (!copy[q.id].optionIdType) { copy[q.id].optionIdType = optionIdType || 'A'; changed = true; }
                }
            });
            return changed ? copy : prev;
        });
    }, [questions]);

    useEffect(() => {
        if (!uiSettings || Object.keys(uiSettings).length === 0) return;
        setQuestions(prev => {
            let changed = false;
            const updated = prev.map(q => {
                const saved = uiSettings[q.id];
                if (saved && saved.marks != null && saved.marks !== q.marks) {
                    changed = true;
                    return { ...q, marks: saved.marks };
                }
                return q;
            });
            return changed ? updated : prev;
        });
    }, [uiSettings]);

    const handleChangeMarks = (id, newMarks) => {
        setQuestions((prev) =>
            prev.map((q) =>
                q.id === id ? { ...q, marks: newMarks } : q
            )
        );
        updateUiForQuestion(id, { marks: newMarks });
    };

    const handleSetOptionIdTypeGlobal = (questionId, val) => {
        setOptionIdType(val);
        updateUiForQuestion(questionId, { optionIdType: val });
    };

    const sanitizeHtml = (html) => {
        if (!html) return "";
        // Remove empty <p>
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        // Remove inline font-size from any element
        html = html.replace(/font-size\s*:\s*[^;"]+;?/gi, "");
        return html;
    };


    const buildContainerStyleString = (ui = {}, isOption = false) => {
        const fontSize = (ui && ui.fontSize) ? `${ui.fontSize}px` : '16px';
        const textAlign = ui && ui.align ? ui.align : 'left';
        let styleObj = {
            'font-size': fontSize,
            'text-align': textAlign,
        };

        if (isOption) {
            const layout = ui && ui.optionLayout ? ui.optionLayout : 'vertical';
            if (layout === 'vertical') {
                styleObj.display = 'flex';
                styleObj['flex-direction'] = 'column';
                styleObj.gap = (ui && ui.optionLayout === 'horizontal') ? '40px' : '10px';
            } else if (layout === 'horizontal') {
                styleObj.display = 'flex';
                styleObj['flex-direction'] = 'row';
                styleObj['flex-wrap'] = 'wrap';
                styleObj.gap = '40px';
            } else if (layout === 'two-column') {
                styleObj.display = 'flex';
                styleObj['flex-direction'] = 'row';
                styleObj['flex-wrap'] = 'wrap';
                styleObj.gap = '10px';
            } else {
                styleObj.display = 'flex';
                styleObj['flex-direction'] = 'column';
            }
        }

        return Object.entries(styleObj).map(([k, v]) => `${k}:${v}`).join(';');
    };

    const applyUiInlineToHtml = (html, ui = {}, qId, kind = 'text', isOption = false, optionIndex = null) => {
        if (!html) {
            const containerStyle = buildContainerStyleString(ui, isOption);
            return `<div style="${containerStyle}"></div>`;
        }

        // Only remove empty <p> but keep inline styles in the inner HTML.
        html = sanitizeHtml(html);

        const imgRegex = /<img[^>]+src=(['"])([^'"]+)\1[^>]*>/gi;
        let lastIndex = 0;
        let out = "";
        let match;
        while ((match = imgRegex.exec(html)) !== null) {
            if (match.index > lastIndex) {
                out += html.slice(lastIndex, match.index);
            }
            const src = match[2];

            let imgKey;
            if (kind === 'text') {
                imgKey = `q-${qId}-text-img-${match.index}`;
            } else {
                imgKey = `q-${qId}-${kind}-text-img-${match.index}`;
            }

            const altKey1 = optionIndex != null ? `q-${qId}-opt-${optionIndex}-img-${match.index}` : null;
            const altKey2 = optionIndex != null ? `q-${qId}-opt-${optionIndex}-text-img-${match.index}` : null;

            const sizing = (ui && ui.imageSizes && (
                ui.imageSizes[imgKey] ||
                (altKey1 && ui.imageSizes[altKey1]) ||
                (altKey2 && ui.imageSizes[altKey2])
            )) || {};

            const width = sizing.width || (isOption ? 50 : 120);
            const height = sizing.height || (isOption ? 50 : 50);

            out += `<img src="${src}" alt="" style="width:${width}px;height:${height}px;margin:5px 0;max-width:100%;"/>`;

            lastIndex = imgRegex.lastIndex;
        }

        if (lastIndex < html.length) {
            out += html.slice(lastIndex);
        }

        const containerStyle = buildContainerStyleString(ui, isOption);
        return `<div style="${containerStyle}">${out}</div>`;
    };

    const buildOptionHtmlStringForSave = (opt, ui = {}, qId, optionIndex) => {
        if (!opt) return applyUiInlineToHtml('', ui, qId, `opt-${optionIndex}`, true, optionIndex);

        if (typeof opt === 'string') {
            return applyUiInlineToHtml(opt, ui, qId, `opt-${optionIndex}`, true, optionIndex);
        } else {
            const textHtml = sanitizeHtml(opt.text || "");
            let combined = textHtml;
            if (opt.image) {
                const sizingKey1 = `q-${qId}-opt-${optionIndex}-img-0`;
                const sizingKey2 = `q-${qId}-opt-${optionIndex}-text-img-0`;
                const imgSizing = (ui && ui.imageSizes && (ui.imageSizes[sizingKey1] || ui.imageSizes[sizingKey2])) || {};
                const width = imgSizing.width || 50;
                const height = imgSizing.height || 50;
                combined += `<img src="${opt.image}" alt="option-image" style="width:${width}px;height:${height}px;margin-left:10px;max-width:100%;"/>`;
            }
            return applyUiInlineToHtml(combined, ui, qId, `opt-${optionIndex}`, true, optionIndex);
        }
    };

    const handleSaveChanges = () => {
        try {
            const mergedQuestions = questions.map((q) => {
                const ui = uiSettings[q.id] || {};

                const styledText = applyUiInlineToHtml(q.text || "", ui, q.id, 'text', false, null);

                const optionStrings = [];
                const sourceOptions = Array.isArray(q.options) ? q.options : [
                    q.optA !== undefined ? q.optA : "",
                    q.optB !== undefined ? q.optB : "",
                    q.optC !== undefined ? q.optC : "",
                    q.optD !== undefined ? q.optD : ""
                ];

                for (let idx = 0; idx < 4; idx++) {
                    const opt = sourceOptions[idx] !== undefined ? sourceOptions[idx] : "";
                    const optHtml = buildOptionHtmlStringForSave(opt, ui, q.id, idx);
                    optionStrings.push(optHtml);
                }

                // copy q, remove transient fields like `options` (we save optA..optD)
                const copy = { ...q };
                if (copy.hasOwnProperty('options')) delete copy.options;

                return {
                    ...copy,
                    // save the styled HTML inline for text and options
                    text: styledText,
                    optA: optionStrings[0] || "",
                    optB: optionStrings[1] || "",
                    optC: optionStrings[2] || "",
                    optD: optionStrings[3] || "",
                    ui: ui
                };
            });

            const payload = {
                questions: mergedQuestions,
                generalDetails
            };

            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(payload));
            alert("Saved successfully");
        } catch (e) {
            alert("Save failed — see console");
            console.error(e);
        }
    };

    const handlePrint = () => {
        if (!previewRef.current) return;
        const printContents = previewRef.current.innerHTML;
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
        window.location.reload();
    };

    const renderHtmlWithImages = (html, qId, kind, ui) => {
        if (!html) return null;
        // keep inline styles; only strip empty paragraphs
        html = sanitizeHtml(html);
        const parts = [];
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(html)) !== null) {
            if (match.index > lastIndex) {
                const chunk = html.slice(lastIndex, match.index);
                parts.push(
                    <span
                        key={`chunk-${qId}-${kind}-${lastIndex}`}
                        dangerouslySetInnerHTML={{ __html: chunk }}
                    />
                );
            }
            const src = match[1];
            const imgKey = kind === 'text'
                ? `q-${qId}-text-img-${match.index}`
                : `q-${qId}-${kind}-text-img-${match.index}`;
            const sizing = ui?.imageSizes?.[imgKey] || {};
            parts.push(
                <img
                    key={`img-${qId}-${kind}-${match.index}`}
                    src={src}
                    alt=""
                    style={{
                        width: sizing.width || 120,
                        height: sizing.height || 50,
                        margin: "5px 0",
                    }}
                />
            );
            lastIndex = imgRegex.lastIndex;
        }

        if (lastIndex < html.length) {
            const chunk = html.slice(lastIndex);
            parts.push(
                <div
                    key={`chunk-${qId}-${kind}-${lastIndex}`}
                    dangerouslySetInnerHTML={{ __html: chunk }}
                />
            );
        }

        return parts;
    };

    return (
        <div className='container-fluid QuestionExport-container'>
            <div className='d-flex align-items-center py-3'>
                <h5 className='mb-0 d-flex align-items-center'>
                    <CiBank size={20} className='me-1'/>
                    Question Bank</h5>
            </div>
            <div className="card border-0 rounded-0 bg-white container-fluid">
                <div className="d-flex flex-column">
                    <div className='d-flex border-bottom border-2 align-items-center position-relative'>
                        <div
                            className={`ps-1 pe-2 py-3 cursor-pointer ${active ? 'underline' : 'text-muted'}`}
                            onClick={() => setActive(true)}
                        >
                            Design
                        </div>
                        <div
                            className={`ps-1 pe-2 py-3 cursor-pointer ${active ? 'text-muted' : 'underline'}`}
                            onClick={() => setActive(false)}
                        >
                            Preview
                        </div>
                        {active && (<button
                            className="btn btn-primary px-3 py-1 m-3 position-absolute top-0 end-0 no-print"
                            type="button"
                            onClick={handleSaveChanges}
                        >
                            Save Changes
                        </button>)}
                        {!active && (
                            <button
                                className="btn btn-primary px-3 py-1 m-3 position-absolute top-0 end-0 no-print"
                                type="button"
                                onClick={handlePrint}
                            >
                                Print
                            </button>
                        )}
                    </div>

                    {active ? (
                        <>
                            <div className='row fs-12 themeUnderline mx-1'>
                                <div className="col-6 border-end border-2 px-3">
                                    <div className="row">
                                        <div className="col-12 px-2 py-3">
                                            <h6 className='Question-header-color mb-0 d-flex align-items-center'>General Details
                                                <FaPen size={15} className='ms-1' />
                                            </h6>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-3 ps-3 p-0">
                                            <div className='fw-bold'>Paper Name</div>
                                        </div>
                                        <div className="col-5 text-start p-0 text-muted">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0'
                                                value={generalDetails.paperName}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, paperName: e.target.value })}
                                            />
                                        </div>
                                        <div className="col-2 text-start p-0">
                                            <div className='fw-bold'>Duration</div>
                                        </div>
                                        <div className="col-2 p-0 text-muted text-start">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0 w-100'
                                                value={generalDetails.duration}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, duration: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-3 ps-3 p-0">
                                            <div className='fw-bold'>Class</div>
                                        </div>
                                        <div className="col-5 text-start p-0 text-muted">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0'
                                                value={generalDetails.className}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, className: e.target.value })}
                                            />
                                        </div>
                                        <div className="col-2 p-0">
                                            <div className='fw-bold'>Max marks</div>
                                        </div>
                                        <div className="col-2 p-0 text-muted text-start">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0 w-100'
                                                value={generalDetails.maxMarks}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, maxMarks: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-3 ps-3 p-0">
                                            <div className='fw-bold'>Subject Name</div>
                                        </div>
                                        <div className="col-5 text-start p-0 text-muted">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0'
                                                value={generalDetails.subjectName}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, subjectName: e.target.value })}
                                            />
                                        </div>
                                        <div className="col-2 text-start p-0">
                                            <div className='fw-bold'>Date</div>
                                        </div>
                                        <div className="col-2 p-0 text-muted text-start">
                                            <input
                                                type='text'
                                                className='text-nowrap border-0 w-100'
                                                value={generalDetails.date}
                                                onChange={(e) => setGeneralDetails({ ...generalDetails, date: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="col-6 px-3 pb-2">
                                    <div className="row">
                                        <div className="col-12 p-0 p-2 py-3">
                                            <h6 className='Question-header-color mb-0 d-flex align-items-center'>General Instruction <FaPen size={15} className='ms-1' />
                                            </h6>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-12 fw-semibold ">
                                            <p className='mb-0 ps-3'><span>1.</span> Write your Name on the top of the question paper cum answer sheet</p>
                                            <p className='mb-0 ps-3'><span>2.</span> All questions are compulsory.</p>
                                            <p className='mb-0 ps-3'><span>3.</span> All questions include MCQ, one word & para question .</p>
                                            <p className='mb-0 ps-3'><span>4.</span> Handwriting should be neat & clean.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-12 px-4 py-3">
                                    <h6 className='Question-header-color mb-0 d-flex align-items-center'>
                                        Questions<FaPen size={15} className='ms-1' />
                                    </h6>
                                </div>
                                <div className="container px-5">
                                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                        <SortableContext items={questions.map((q) => q.id)} strategy={verticalListSortingStrategy}>
                                            {questions.map((q, index) => (
                                                <SortableQuestion
                                                    key={q.id}
                                                    question={q}
                                                    index={index}
                                                    handleChangeMarks={handleChangeMarks}
                                                    optionIdType={optionIdType}
                                                    setOptionIdType={(val) => handleSetOptionIdTypeGlobal(q.id, val)}
                                                    ui={uiSettings[q.id] || {}}
                                                    updateUi={(patch) => updateUiForQuestion(q.id, patch)}
                                                />
                                            ))}
                                        </SortableContext>
                                    </DndContext>
                                </div>
                            </div>
                        </>
                    ) : (<>
                        <div ref={previewRef} className="container border pt-4 pb-5 px-5 bg-white mt-2 mb-5">
                            <div className="text-center mb-3">
                                <h5 className="fw-semibold fs-5">{generalDetails.paperName}</h5>
                                <div className="fw-semibold fs-6">{generalDetails.subjectName}</div>
                                <div className="fw-semibold fs-6">Class - {generalDetails.className}</div>
                                <div className="fw-semibold fs-6">Date : {generalDetails.date}</div>
                                <div className="d-flex justify-content-between mt-2 px-1 fs-6">
                                    <span>[<strong>Duration:</strong> {generalDetails.duration}]</span>
                                    <span>[<strong>Maximum Marks:</strong> {generalDetails.maxMarks}]</span>
                                </div>
                            </div>

                            <div className="mb-3">
                                <h6 className="fw-semibold px-1 fs-5">General Instructions:-</h6>
                                <ol className="ps-5 fw-semibold">
                                    <li>Write your Name on the top of the question paper cum answer sheet.</li>
                                    <li>All questions are compulsory.</li>
                                    <li>All questions include MCQ, one word & para question.</li>
                                    <li>Handwriting should be neat & clean.</li>
                                </ol>
                            </div>

                            <div className="text-center mb-3">
                                <svg width="90%" height="30" viewBox="0 0 500 30">
                                    <defs>
                                        <marker id="diamond" viewBox="0 0 10 10" refX="5" refY="5"
                                            markerWidth="10" markerHeight="10" orient="auto"
                                            markerUnits="strokeWidth">
                                            <polygon points="5,0 10,5 5,10 0,5" fill="black" />
                                        </marker>
                                    </defs>
                                    <line x1="0" y1="15" x2="500" y2="15" stroke="black" strokeWidth="1.5"
                                        markerStart="url(#diamond)" markerEnd="url(#diamond)" />
                                </svg>
                            </div>

                            <ol className="ps-0 fs-6">
                                {questions.map((q, i) => {
                                    const ui = uiSettings[q.id] || {};
                                    const effectiveOptionIdType = ui.optionIdType || optionIdType || 'A';
                                    const getOptionLabelForPreview = (idx) => {
                                        switch (effectiveOptionIdType) {
                                            case "A": return String.fromCharCode(65 + idx);
                                            case "a": return String.fromCharCode(97 + idx);
                                            case "1": return idx + 1;
                                            case "i": return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][idx] || idx + 1;
                                            case "I": return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][idx] || idx + 1;
                                            default: return String.fromCharCode(65 + idx);
                                        }
                                    };
                                    return (
                                        <div key={i}>
                                            <div className="d-flex justify-content-between my-1">
                                                <div className="question-html ps-3 mt-2 d-flex"
                                                    style={{ fontSize: `${ui.fontSize || 16}px`, textAlign: ui.align || 'left' }}>
                                                    <strong className='me-2'>{`Q${i + 1}`}</strong>
                                                    <div className='d-flex flex-column'>
                                                        {q.text ? renderHtmlWithImages(q.text, q.id, 'text', ui) : null}
                                                    </div>
                                                </div>
                                                {q.marks && (
                                                    <div style={{ marginLeft: "20px", whiteSpace: "nowrap" }}>
                                                        ({q.marks})
                                                    </div>
                                                )}
                                            </div>
                                            {q.options?.length > 0 && (
                                                <div
                                                    className="ps-5"
                                                    style={{
                                                        fontSize: `${ui.fontSize || 16}px`,
                                                        textAlign: ui.align || "left",
                                                        display: "flex",
                                                        flexDirection: ui.optionLayout === "vertical" ? "column" : "row",
                                                        flexWrap: ui.optionLayout === "horizontal" || ui.optionLayout === "two-column" ? "wrap" : "nowrap",
                                                        gap: ui.optionLayout === "horizontal" ? "40px" : "10px",
                                                    }}
                                                >
                                                    {q.options.map((opt, idx) => {
                                                        const optKind = `opt-${idx}`;
                                                        return (
                                                            <div
                                                                key={idx}
                                                                style={{
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    width: ui.optionLayout === "two-column" ? "45%" : "auto",
                                                                    minWidth: ui.optionLayout === "two-column" ? "200px" : "auto",
                                                                }}
                                                            >
                                                                <span className="fw-bold me-2">{getOptionLabelForPreview(idx)}.</span>
                                                                {typeof opt === 'string' ? (
                                                                    <>{renderHtmlWithImages(opt, q.id, optKind, ui)}</>
                                                                ) : (
                                                                    <>
                                                                        <span style={{ fontSize: `${ui.fontSize || 16}px` }} className='questionstylecustom' dangerouslySetInnerHTML={{ __html: opt.text || '' }} />
                                                                        {opt.image && (
                                                                            <img
                                                                                src={opt.image}
                                                                                alt={`option-${idx}`}
                                                                                style={{
                                                                                    width:
                                                                                        ui.imageSizes?.[`q-${q.id}-opt-${idx}-img-0`]?.width
                                                                                        || ui.imageSizes?.[`q-${q.id}-opt-${idx}-text-img-0`]?.width
                                                                                        || 50,
                                                                                    height:
                                                                                        ui.imageSizes?.[`q-${q.id}-opt-${idx}-img-0`]?.height
                                                                                        || ui.imageSizes?.[`q-${q.id}-opt-${idx}-text-img-0`]?.height
                                                                                        || 50,
                                                                                    marginLeft: "10px"
                                                                                }}
                                                                            />
                                                                        )}
                                                                    </>
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </ol>
                        </div>
                    </>)}
                </div>
            </div>

            <div
                className="modal fade"
                id="saveSuccessModal"
                tabIndex="-1"
                aria-labelledby="saveSuccessModalLabel"
                aria-hidden="true"
            >
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="saveSuccessModalLabel">Success</h5>
                            <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                            ></button>
                        </div>
                        <div className="modal-body">
                            Your changes have been saved successfully!
                        </div>
                        <div className="modal-footer">
                            <button
                                type="button"
                                className="btn btn-primary"
                                data-bs-dismiss="modal"
                            >
                                OK
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    );
};

export default QuestionPreview;
