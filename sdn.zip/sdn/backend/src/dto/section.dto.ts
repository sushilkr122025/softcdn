import { IsString, IsOptional, IsInt, Length, Min } from 'class-validator';
import { Transform } from 'class-transformer';

export class SectionDto {
  @Transform(({ value }) => {
    const n = Number(value);
    return value === '' || isNaN(n) || n === 0 ? undefined : n;
  })
  @IsOptional()
  @IsInt()
  id?: number;

  @IsString()
  @Length(1, 20)
  section: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  status?: number;

  @IsOptional()
  @IsInt()
  @Min(0)
  visible?: number;
}
