import React, { useEffect, useState } from "react";
import apiClient from "../api/apiService";
import { classToStage } from "../utils/util";
import CustomDropdown from '../components/layout/CustomDropdown';
import useAuth from '../context/AuthContext';

const GlobalFilters = ({ onFiltersChange, selectedValues = {}, show = [], permissions = [], errors = {},
}) => {
  const { appSetting } = useAuth();
  const setting = appSetting.find(item => item.settingName === "Taxonomy");
  // console.log('App settings in GlobalFilters:', setting);
  const isVisible = (key) => show.includes(key);
  const marksNumber = Array.from({ length: 24 }, (_, i) => (i + 1) * 0.5);
  /* ---------------- META STATES ---------------- */
  const [std, setStd] = useState("");
  const [subject, setSubject] = useState("");
  const [subDomain, setSubDomain] = useState("");
  const [cg, setCg] = useState("");
  const [competency, setCompetency] = useState("");
  const [bloom, setBloom] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [quesType, setQuesType] = useState("");
  const [context, setContext] = useState("");
  const [marks, setMarks] = useState("");
  const [openKey, setOpenKey] = useState("");
  const [cgtext, setCgtext] = useState("");
  const [competencytext, setCompetencytext] = useState("");

  /* ---------------- API DATA ---------------- */
  const [SubjectData, setSubjectData] = useState([]);
  const [classData, setClassData] = useState([]);
  const [subDomainData, setSubDomainData] = useState([]);
  const [cgData, setCgData] = useState([]);
  const [competencyData, setCompetencyData] = useState([]);
  const [bloomData, setBloomData] = useState([]); 

  /* ---------------- LOAD INITIAL SELECTED VALUES ---------------- */
  useEffect(() => {
    if (Object.keys(selectedValues).length > 0) {
      console.log('Selected values on load:', selectedValues);
      if (selectedValues.std && selectedValues.std.toString() !== std)
        setStd(selectedValues.std.toString());
      if (
        selectedValues.subject &&
        selectedValues.subject.toString() !== subject
      )
        setSubject(selectedValues.subject.toString());
      if (selectedValues.difficulty && selectedValues.difficulty !== difficulty)
        setDifficulty(selectedValues.difficulty);
      if (selectedValues.quesType && selectedValues.quesType !== quesType)
        setQuesType(selectedValues.quesType);
      if (
        selectedValues.subDomain &&
        selectedValues.subDomain.toString() !== subDomain
      )
        setSubDomain(selectedValues.subDomain.toString());
      if (selectedValues.cg && selectedValues.cg.toString() !== cg)
        setCg(selectedValues.cg.toString());
      if (
        selectedValues.competency &&
        selectedValues.competency.toString() !== competency
      )
        setCompetency(selectedValues.competency.toString());
      if (
        selectedValues.bloom &&
        selectedValues.bloom.toString() !== bloom
      )
        setBloom(selectedValues.bloom.toString());
    }
  }, [selectedValues]);

  /* ---------------- LOAD SUBJECT + CLASS ---------------- */
  useEffect(() => {
    apiClient
      .get("/store/subject")
      .then((res) => setSubjectData(res.data))
      .catch((err) => console.error("Error fetching Subject:", err));

    apiClient
      .get("/store/classes")
      .then((res) => setClassData(res.data))
      .catch((err) => console.error("Error fetching Classes:", err));

    apiClient
      .get("/store/bloom")
      .then((res) => setBloomData(res.data))
      .catch((err) => console.error("Error fetching Bloom:", err));
  }, []);

  /* ---------------- SUBDOMAIN ---------------- */
  useEffect(() => {
    setSubDomain("");
    setSubDomainData([]);

    if (subject) {
      apiClient
        .get("/store/subDomain", { params: { subject: parseInt(subject) } })
        .then((res) => setSubDomainData(res.data))
        .catch((err) => console.error("Subdomain fetch error:", err));
    }
  }, [subject]);

  /* ---------------- CG ---------------- */
  useEffect(() => {
    setCg("");
    setCompetency("");
    setCgData([]);
    setCompetencyData([]);
    setCgtext("");
    setCompetencytext("");

    if (std && subject) {
      const stage = classToStage[std];
      apiClient
        .get("/store/cg", { params: { stage, subject: parseInt(subject) } })
        .then((res) => setCgData(res.data))
        .catch((err) => console.error("CG fetch error:", err));
    }
  }, [std, subject]);

  /* ---------------- COMPETENCY ---------------- */
  useEffect(() => {
    // setCompetency("");
    setCompetencyData([]);
    setCompetencytext("");

    if (cg) {
      apiClient
        .get("/store/competency", { params: { id: parseInt(cg) } })
        .then((res) => setCompetencyData(res.data))
        .catch((err) => console.error("Competency fetch error:", err));
    }
  }, [cg]);

  /* ---------------- UPDATE TEXT VALUES ON DATA LOAD ---------------- */
  useEffect(() => {
    if (cg && cgData.length) {
      const match = cgData.find((i) => i.id.toString() === cg.toString());
      if (match && match.cgNo !== cgtext) setCgtext(match.cgNo);
    }
  }, [cg, cgData]);

  useEffect(() => {
    if (competency && competencyData.length) {
      const match = competencyData.find(
        (i) => i.id.toString() === competency.toString(),
      );
      if (match && match.cgNo !== competencytext) setCompetencytext(match.cgNo);
    }
  }, [competency, competencyData]);

  /* ---------------- PERMISSION CHECK ---------------- */
  useEffect(() => {
    if (subject && permissions.length > 0) {
      const perm = permissions.find((p) => p.subjectId === subject?.toString());
      if (perm && std && !perm.classIds.includes(std.toString())) {
        setStd("");
      }
    }
  }, [subject, permissions, std]);

  /* ---------------- SEND FILTERS TO PARENT ---------------- */
  useEffect(() => {
    // Convert string values to numbers for parent component   
    const filters = {
      std: std ? parseInt(std) : "",
      subject: subject ? parseInt(subject) : "",
      subDomain: subDomain ? parseInt(subDomain) : "",
      cg: cg ? parseInt(cg) : "",
      bloomTaxonomy: bloom ? parseInt(bloom) : "",
      cgtext,
      competency: competency ? parseInt(competency) : "",
      competencytext,
      difficulty,
      quesType,
      context,
      marks
      // SubjectData,
    };   

    onFiltersChange(filters);
  }, [std, subject, subDomain, cg, cgtext, competency, competencytext, difficulty, quesType, context, marks, bloom]);

  return (
    <div className="row g-0 gap-2">
      {isVisible("subject") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="subject"
            placeholder="Subject"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={subject}
            error={!!errors.subject}
            options={SubjectData.filter((s) =>
              permissions.some((p) => p.subjectId === s.id.toString()),
            ).map((s) => ({
              value: s.id.toString(),
              label: s.subject,
            }))}
            onChange={(val) => setSubject(val)}
          />
        </div>
      )}

      {/* CLASS */}
      {isVisible("class") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="class"
            placeholder="Class"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={std}
            error={!!errors.class}
            disabled={!subject}
            options={classData
              .filter((cls) => {
                if (!subject) return false;
                const perm = permissions.find(
                  (p) => p.subjectId === subject.toString(),
                );
                return perm ? perm.classIds.includes(cls.class.toString()) : false;
              })
              .map((c) => ({
                value: c.class.toString(),
                label: c.class,
              }))}
            onChange={(val) => setStd(val)}
          />
        </div>
      )}
      {isVisible('context') && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="context"
            placeholder="Ques. Type"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={context}
            options={[
              { value: "CONTEXT", label: "Context" },
              { value: "NONCONTEXT", label: "Non Context" },
            ]}
            onChange={(val) => setContext(val)}
          />
        </div>
      )}
      {isVisible("subDomain") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="subDomain"
            placeholder="Sub Domain"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={subDomain}
            disabled={!subject}
            options={subDomainData.map((sd) => ({
              value: sd.id.toString(),
              label: sd.subject,
            }))}
            onChange={(val) => setSubDomain(val)}
          />
        </div>
      )}
      {isVisible("difficulty") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="difficulty"
            placeholder="Difficulty"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={difficulty}
            error={!!errors.difficulty}
            disabled={!subject}
            options={[
              { value: "Easy", label: "Easy" },
              { value: "Medium", label: "Medium" },
              { value: "Hard", label: "Hard" },
            ]}
            onChange={(val) => setDifficulty(val)}
          />
        </div>
      )}
      {setting?.settingValue.toUpperCase() === "BLOOM" && isVisible("bloom") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="bloom"
            placeholder="Bloom"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={bloom}
            error={!!errors.bloom}           
            options={bloomData.map((c) => ({
              value: c.id.toString(),
              label: c.taxonomy,
            }))}
            onChange={(val) => {
              setBloom(val);              
            }}
          />
        </div>
      )}
      {setting?.settingValue.toUpperCase() === "NCF" && isVisible("cg") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="cg"
            placeholder="CG"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={cg}
            error={!!errors.cg}
            disabled={!std || !subject}
            options={cgData.map((c) => ({
              value: c.id.toString(),
              label: c.cgNo,
            }))}
            onChange={(val) => {
              setCg(val);
              const selectedText = cgData.find(
                (item) => item.id.toString() === val.toString(),
              );
              if (selectedText) setCgtext(selectedText.cgNo);
              if (!val) setCgtext("");
            }}
          />
        </div>
      )}
      {setting?.settingValue.toUpperCase() === "NCF" && isVisible("competency") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="competency"
            placeholder="Competency"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={competency}
            error={!!errors.competency}
            disabled={!cg}
            options={competencyData.map((c) => ({
              value: c.id.toString(),
              label: c.cgNo,
            }))}
            onChange={(val) => {
              setCompetency(val);
              const selectedText = competencyData.find(
                (item) => item.id.toString() === val.toString(),
              );
              if (selectedText) setCompetencytext(selectedText.cgNo);
              if (!val) setCompetencytext("");
            }}
          />
        </div>
      )}
      {isVisible("quesType") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="quesType"
            placeholder="Ques. Format"
            openKey={openKey}
            setOpenKey={setOpenKey}
            value={quesType}
            error={!!errors.quesType}
            options={[
              { value: "multipleChoice", label: "Multiple Choice" },
              { value: "trueFalse", label: "True/False" },
              { value: "oneWord", label: "One Word" },
              { value: "CR", label: "Written Response" },
              { value: "fillups", label: "Fill in the Blanks" },
              { value: "match", label: "Match the Following" },
            ]}
            onChange={(val) => setQuesType(val)}
          />
        </div>
      )}
      {isVisible('marks') && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="marks"
            openKey={openKey}
            setOpenKey={setOpenKey}
            placeholder="Marks"
            value={marks}
            options={marksNumber.map((num) => ({
              value: num.toString(),
              label: num.toString(),
            }))}
            onChange={(val) => setMarks(val)}
          />
        </div>
      )}
      {isVisible("author") && (
        <div className="col-lg col-md-3 col-sm-4 col-6 mb-3 maxWidth150">
          <CustomDropdown
            dropdownKey="author"
            openKey={openKey}
            setOpenKey={setOpenKey}
            placeholder="Author"
            value=""
            options={[]}
            disabled
            onChange={() => { }}
          />
        </div>
      )}
    </div>
  );
};

export default GlobalFilters;