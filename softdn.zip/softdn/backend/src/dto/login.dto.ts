import { Expose } from 'class-transformer';
import {
  IsEmail,
  IsOptional,
  MinLength,
  IsNotEmpty,
  IsNumberString,
} from 'class-validator';

export class LoginDto {
  id?: number;

  @MinLength(3, { message: 'Name must be at least 3 characters long' })
  name: string;

  @IsNumberString()
  userid: string;

  @IsEmail({}, { message: 'Invalid email format' })
  email: string;

  @MinLength(6, { message: 'Password must be at least 6 characters long' })
  password: string;

  @IsOptional()
  role?: string;

  @IsOptional()
  designation?: string;

  @IsOptional()
  gender?: string;

  @IsOptional()
  teacherSubject?: object;

  @IsOptional()
  address?: string;

  @IsOptional()
  mobileno?: string;

  @IsOptional()
  classTeacher?: string;

  @IsOptional()
  section?: string;

  @IsNotEmpty()
  tenantid?: string;
}

export class UpdateLoginDto {
  @Expose()
  id: number;

  @Expose()
  userid: string;

  @Expose()
  name?: string;

  @Expose()
  email?: string;

  @Expose()
  role?: string;

  @Expose()
  gender?: string;

  @Expose()
  mobileno?: string;

  @Expose()
  address?: string;

  @Expose()
  teacherSubject?: object;

  @Expose()
  classTeacher?: string;

  @Expose()
  section?: string;
}
