import { useEffect, useState, useRef } from "react";

const CustomDropdown = ({ dropdownKey, openKey, setOpenKey, placeholder, value, options = [], onChange, disabled = false, error = false, }) => {
    const selectedItem = options.find((opt) => opt.value?.toString() === value?.toString(),);
    const [openDirection, setOpenDirection] = useState("down");
    const dropdownRef = useRef(null);
    
    useEffect(() => {
        const handleOutsideClick = (e) => {
            if (!e.target.closest(".custom-dropdown")) {
                setOpenKey("");
            }
        };
        document.addEventListener("click", handleOutsideClick);
        return () => {
            document.removeEventListener("click", handleOutsideClick);
        };
    }, [setOpenKey]);

    return (
        <div className="custom-dropdown" ref={dropdownRef}>
            <div className={`dropdown-header ${error ? "border-danger" : ""} ${disabled ? "disabled" : ""}`} onClick={() => {
                if (disabled) return;
                const isOpening = openKey !== dropdownKey;
                if (isOpening && dropdownRef.current) {
                    const rect = dropdownRef.current.getBoundingClientRect();
                    const spaceBelow = window.innerHeight - rect.bottom;
                    const dropdownHeight = 300;
                    if (spaceBelow < dropdownHeight) {
                        setOpenDirection("up");
                    } else {
                        setOpenDirection("down");
                    }
                }
                setOpenKey((prev) => (prev === dropdownKey ? "" : dropdownKey));
            }}>
                <span className={selectedItem ? "selected-text" : "placeholder-text"}>{selectedItem ? selectedItem.label : placeholder}</span>
                <span className={`arrow ${openKey === dropdownKey ? "open" : ""}`}>▾</span>
            </div>
            {openKey === dropdownKey && !disabled && (
                <ul className={`dropdown-list ${openDirection === "up" ? "open-up" : "open-down"}`}>
                    <li className="dropdown-item dropdown-placeholder" onClick={() => {
                        onChange(""); setOpenKey("");
                    }}>{placeholder}</li>
                    {options.map((opt) => (
                        <li key={opt.value} data-value={opt.value} className={`dropdown-item ${value?.toString() === opt.value?.toString() ? "active" : ""} ${opt.disabled ? "disabled" : ""}`}
                            onClick={() => {
                                if (opt.disabled) return;
                                onChange(opt.value);
                                setOpenKey("");
                            }}
                        >{opt.label}</li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default CustomDropdown