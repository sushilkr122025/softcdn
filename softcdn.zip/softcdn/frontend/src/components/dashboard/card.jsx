import React from 'react'

const card = ({ icon, link, color, href }) => {
  return (
    <div className={'card ' + color} onClick={href}>
      <div className="icon">{icon}</div>
      <div className="card-text link">
        <p className="mb-0">{link}</p>
      </div>
    </div>
  )
}

export default card
