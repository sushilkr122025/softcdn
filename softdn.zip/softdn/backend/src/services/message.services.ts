import { Injectable } from '@nestjs/common';
import { Message } from '../entities/message.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class MessageService {
  constructor(
    @InjectRepository(Message)
    private repoMessage: Repository<Message>
  ) {}

  async createMessage(data: Partial<Message>): Promise<any> {
    const message = this.repoMessage.create(data);
    const res = await this.repoMessage.save(message);
    const id = res.id;
    // console.log('Created message ID:', id);
    const response:
      | {
          id: number;
          qId: number;
          message: string;
          createdAt: Date;
          userId: number;
          name: string;
        }
      | undefined = await this.repoMessage
      .createQueryBuilder('message')
      .leftJoin('login', 'login', 'login.id = message.userId')
      .select([
        'message.id AS id',
        'message.qId AS qId',
        'message.message AS message',
        'message.createdAt AS createdAt',
        'message.userId AS userId',
        'login.name AS name',
      ])
      .andWhere('message.id = :id', { id: id })
      .getRawOne();
    // console.log('Created message response:', response);
    return response;
  }

  async getMessages(tenantId: string, qId: string): Promise<any[]> {
    // return this.repoMessage.find({
    //   where: { tenantid: tenantId, qId: Number(qId) },
    //   order: { createdAt: 'ASC' },
    // });
    return this.repoMessage
      .createQueryBuilder('message')
      .leftJoin('login', 'login', 'login.id = message.userId')
      .select([
        'message.id AS id',
        'message.qId AS qId',
        'message.message AS message',
        'message.createdAt AS createdAt',
        'message.userId AS userId',
        'login.name AS name',
      ])
      .where('message.tenantid = :tenantId', { tenantId })
      .andWhere('message.qId = :qId', { qId: Number(qId) })
      .andWhere('message.dmlType = :dmlType', { dmlType: 'I' })
      .orderBy('message.id', 'ASC')
      .getRawMany();
  }
}
