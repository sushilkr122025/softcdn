import {
  Controller,
  Get,
  Param,
  NotFoundException,
  UseGuards,
  Req,
  Post,
  Body,
  Query,
} from '@nestjs/common';
import { UserService } from '../services/user.service';
import { Login } from '../entities/login.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { LoginDto } from '../dto/login.dto';
import { EncryptionService } from '../services/encryption.service';
import { Request } from 'express';
import { StudentInformationDto } from '../dto/student.information.dto';

@UseGuards(JwtAuthGuard)
@Controller('user')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly encryptionService: EncryptionService
  ) {}

  @Post('adduser')
  async addUser(@Req() req: Request, @Body() dto: LoginDto): Promise<any> {
    console.log('req company', req['company']);
    const token = req['company'] as string;
    const loginDto = {
      ...dto,
      tenantid: token,
    };
    return this.userService.createUser(loginDto);
  }

  @Get('all')
  async findAllUsers(@Req() req: Request): Promise<any[]> {
    const lookupid = req['company'] as string;
    const users = await this.userService.findAll(lookupid);
    if (!users) {
      throw new NotFoundException('No users found');
    }
    return users;
  }

  @Get('details')
  async UpdateUser(@Req() req: Request, @Query('id') id: number): Promise<any> {
    const data = {
      tenantid: req['company'] as string,
      id: id,
    };

    console.log('UpdateUser id', id);
    const user = await this.userService.finsUserDetails(data);
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  @Get('id/:id')
  async findUserById(@Param('id') id: number): Promise<Login> {
    const user = await this.userService.findById(id);
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  @Post('student')
  async addStudent(
    @Req() req: Request,
    @Body() dto: StudentInformationDto
  ): Promise<any> {
    console.log('req company', req['company']);
    const token = req['company'] as string;
    const studentDto = {
      ...dto,
      tenantid: token,
    };
    return await this.userService.createStudent(studentDto);
  }

  @Get('student')
  async findAllStudent(@Req() req: Request, @Query() query): Promise<any[]> {
    // console.log('req', query.class);
    const lookupid = req['company'] as string;
    const users = await this.userService.findAllStudent(lookupid, query);
    if (!users) {
      throw new NotFoundException('No users found');
    }
    return users;
  }
}
