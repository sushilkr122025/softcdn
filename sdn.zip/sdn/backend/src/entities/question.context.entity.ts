import {
  BeforeInsert,
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';
import baseX from 'base-x';
import { v7 as uuidv7 } from 'uuid';
const BASE62 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
type BaseX = {
  encode: (buf: Uint8Array | Buffer) => string;
  decode: (str: string) => Uint8Array;
};
const base62: BaseX = baseX(BASE62);

function shortUuid7() {
  const uuid = uuidv7();
  const hex = uuid.replace(/-/g, '');
  const buf = Buffer.from(hex, 'hex');
  return base62.encode(buf);
}
@Entity({ name: 'questioncontext' })
export class QuestionContext {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', unique: true, length: 40 })
  shortUuid: string;

  @Column({ type: 'int' })
  tId: number; // Teacher ID

  @Column({ type: 'varchar', length: 255 })
  topicName: string; // might be chapter name also

  @Column({ type: 'varchar', length: 15, default: 'CONTEXT' })
  contextstatus: string;

  @Column({ type: 'int' })
  subject: number;

  @Column({ type: 'int' })
  class: number;

  @Column({ type: 'text', default: null })
  context: string;

  @Column({ type: 'varchar', length: '10', default: 'bank' })
  createdBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'varchar', length: '5', default: 'I' })
  dmlType: string;

  @BeforeInsert()
  generateUUID() {
    this.shortUuid = shortUuid7();
  }
}
