import React from 'react'
import { FaQuestionCircle } from 'react-icons/fa'

const AppFooter = () => {
  return (
    <footer className="bg-light py-2 border-top border-dark">
      <div className="container">
        <div className="row">
          <div className="col">
            <span>&copy; Sanskrit-e-solutions</span>
          </div>
          <div className="col text-end">
            <FaQuestionCircle className="me-1" />
            <span>Help</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default React.memo(AppFooter)
