import React, { useEffect, useState } from 'react';
import apiClient from '../api/apiService';
import { classToStage } from '../utils/util';

const GlobalFilters = ({ onFiltersChange, selectedValues = {}, show = [] }) => {
  const isVisible = (key) => show.includes(key);

  //meta data states
  const [std, setStd] = useState('');
  const [subject, setSubject] = useState('');
  const [subDomain, setSubDomain] = useState('');
  const [cg, setCg] = useState('');
  const [competency, setCompetency] = useState('');
  const [difficulty, setDifficulty] = useState('');
  const [quesType, setQuesType] = useState('');

  const [cgtext, setCgtext] = useState('');
  const [competencytext, setCompetencytext] = useState('');

  // api data
  const [SubjectData, setSubjectData] = useState([]);
  const [classData, setClassData] = useState([]);
  const [subDomainData, setSubDomainData] = useState([]);
  const [cgData, setCgData] = useState([]);
  const [competencyData, setCompetencyData] = useState([]);

  useEffect(() => {
    apiClient
      .get('/store/subject')
      .then((response) => {
        setSubjectData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error);
      });

    apiClient
      .get('/store/classes')
      .then((response) => {
        setClassData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching class data:', error);
      });
  }, []);

  useEffect(() => {
    setSubDomain('');
    setSubDomainData([]);

    if (subject) {
      apiClient
        .get('/store/subDomain', { params: { subject } })
        .then((res) => setSubDomainData(res.data))
        .catch((err) => console.error('Subdomain fetch error', err));
    }
  }, [subject]);

  useEffect(() => {
    setCg('');
    setCompetency('');
    setCgData([]);
    setCompetencyData([]);

    if (std && subject) {
      const stage = classToStage[std];
      apiClient
        .get('/store/cg', { params: { stage, subject } })
        .then((res) => {
          // console.log(res);          
           setCgData(res.data);
        })
        .catch((err) => console.error('CG fetch error', err));
    }
  }, [std, subject]);

  useEffect(() => {
    setCompetency('');
    setCompetencyData([]);

    if (cg) {
      apiClient
        .get('/store/competency', { params: { id: cg } })
        .then((res) => setCompetencyData(res.data))
        .catch((err) => console.error('Competency fetch error', err));
    }
  }, [cg]);

  useEffect(() => {
    if (cg && !cgtext && cgData.length) {
      const match = cgData.find((item) => item.id.toString() === cg.toString());
      if (match) setCgtext(match.cgNo);
    }
  }, [cgData, cg, cgtext]);

  useEffect(() => {
    if (competency && !competencytext && competencyData.length) {
      const match = competencyData.find((item) => item.id.toString() === competency.toString());
      if (match) setCompetencytext(match.cgNo);
    }
  }, [competencyData, competency, competencytext]);

  useEffect(() => {
    const filters = { std, subject, subDomain, cg, cgtext, competency, competencytext, difficulty, quesType };

    if (std && subject) {
      onFiltersChange(filters);
    }
  }, [std, subject, subDomain, cg, cgtext, competency, competencytext, difficulty, quesType]);

  useEffect(() => {
    // console.log('Selected Values:', selectedValues);
    if (selectedValues.std) setStd(selectedValues.std);
    if (selectedValues.subject) setSubject(selectedValues.subject);
    if (selectedValues.difficulty) setDifficulty(selectedValues.difficulty);
    if (selectedValues.quesType) setQuesType(selectedValues.quesType);
    if (selectedValues.subDomain) setSubDomain(selectedValues.subDomain);
    if (selectedValues.cg) setCg(selectedValues.cg);
    if (selectedValues.competency) setCompetency(selectedValues.competency);
  }, [selectedValues]);
  return (
    <div className="row my-3">
      <div className="col-12 d-flex">
        {isVisible('subject') && (
          <div className='flex-fill'>
            <label>Subject</label>
          <select className="form-select form-select-sm text-muted" value={subject} onChange={(e) => setSubject(e.target.value)}>
            <option value="">Select</option>
            {SubjectData.map((subject) => (
              <option key={subject.id} value={subject.id}>
                {subject.subject}
              </option>
            ))}
          </select>
          </div>
        )}

        {isVisible('class') && (
          <div className='flex-fill ps-3'>
            <label>Class</label>
          <select className="form-select form-select-sm text-muted " value={std} onChange={(e) => setStd(e.target.value)}>
            <option value="">Select</option>
            {classData.map((classes) => (
              <option key={classes.id} value={classes.class}>
                {classes.class}
              </option>
            ))}
          </select>
          </div>
        )}

        {isVisible('subDomain') && (
          <div className='flex-fill ps-3'>
            <label>Sub Domain</label>
          <select className="form-select form-select-sm text-muted" value={subDomain} onChange={(e) => setSubDomain(e.target.value)} disabled={!subject}>
            <option value="">Select</option>
            {subDomainData.map((subDomain) => (
              <option key={subDomain.id} value={subDomain.id}>
                {subDomain.subject}
              </option>
            ))}
          </select>
          </div>
        )}

        {isVisible('difficulty') && (
          <div className='flex-fill ps-3'>
            <label>Difficulty level</label>
          <select className="form-select form-select-sm text-muted" value={difficulty} onChange={(e) => setDifficulty(e.target.value)} disabled={!subject}>
            <option value="">Select</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
          </div>
        )}

        {isVisible('cg') && (
          <div className='flex-fill ps-3'>
            <label>Curriculum Goals</label>
          <select
            className="form-select form-select-sm text-muted"
            value={cg}
            onChange={(e) => {
              setCg(e.target.value);
              setCgtext(e.target.options[e.target.selectedIndex].text);
            }}
            disabled={!std || !subject}
          >
            <option value="">Select</option>
            {cgData.map((cg) => (
              <option key={cg.id} value={cg.id}>
                {cg.cgNo}
              </option>
            ))}
          </select>
          </div>
        )}

        {isVisible('competency') && (
          <div className='flex-fill ps-3'>
            <label>Competency</label>
          <select
            className="form-select form-select-sm text-muted"
            value={competency}
            onChange={(e) => {
              setCompetency(e.target.value);
              setCompetencytext(e.target.options[e.target.selectedIndex].text);
            }}
            disabled={!cg}
          >
            <option value="">Select</option>
            {competencyData.map((competency) => (
              <option key={competency.id} value={competency.id}>
                {competency.cgNo}
              </option>
            ))}
          </select>
          </div>
        )}

        {isVisible('quesType') && (
          <div className='flex-fill ps-3'>
            <label>Question Type</label>
          <select className="form-select form-select-sm text-muted" value={quesType} onChange={(e) => setQuesType(e.target.value)}>
            <option value="">Select</option>
            <option value="multipleChoice">Multiple Choice</option>
            <option value="trueFalse">True/False</option>
            <option value="oneWord">One Word</option>
            <option value="CR">Written Response</option>
            <option value="fillups">Fill in the Blanks</option>
            <option value="match">Match the Following</option>
          </select>
          </div>
        )}

        {isVisible('author') && (
          <div className='flex-fill ps-3'>
            <label>Author</label>
          <select className="form-select form-select-sm text-muted">
            <option>Select</option>
          </select>
          </div>
        )}
      </div>
    </div>
  );
};

export default GlobalFilters;
