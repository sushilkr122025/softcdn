import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserController } from '../controllers/user.controller';
import { UserService } from '../services/user.service';
import { Login } from '../entities/login.entity';
import { StateNConstituency } from '../entities/statenconstituencies.entity';
import { HelperController } from '../controllers/helper.controller';
import { HelperService } from '../services/helper.service';
import { EncryptionService } from '../services/encryption.service';
import { UserDetail } from '../entities/userdetail.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { Class } from '../entities/class.entity';
import { Section } from '../entities/section.entity';
import { Subject } from '../entities/subject.entity';
import { CurriculumGoal } from '../entities/curriculum.goal.entity';
import { Roles } from '../entities/roles.entity';
import { Permissions } from '../entities/permissions.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Login,
      StateNConstituency,
      UserDetail,
      StudentInformation,
      Class,
      Section,
      Subject,
      CurriculumGoal,
      Roles,
      Permissions
    ]),
  ],
  controllers: [UserController, HelperController],
  providers: [UserService, HelperService, EncryptionService],
})
export class UserModule {}
