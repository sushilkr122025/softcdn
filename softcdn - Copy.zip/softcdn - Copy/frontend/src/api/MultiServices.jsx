import apiClient from './apiService'

class MultiServices {
  getImages = async () => {
    try {
      const response = await apiClient.get(`school/gallery`)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getCanvas = async (imageId) => {
    try {
      const response = await apiClient.get(`api/canvas/${imageId}`)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getRoles = async (userId) => {
    try {
      const response = await apiClient.get(`api/roles/${userId}`)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  ExamList = async (fdata) => {
    try {
      const response = await apiClient.get('/getclass/' + fdata)
      return response.data
    } catch (error) {
      console.log(error)

      // setError(error.response.data.errtext);
    }
  }
  QuestionList = async (fdata) => {
    try {
      const response = await apiClient.get('/getpapaper/' + fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  AnswerList = async (fdata) => {
    try {
      const response = await apiClient.post('/submitanswer', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  StudentReport = async (fdata) => {
    try {
      const response = await apiClient.get('/reportcard', fdata)
      console.log(response.data)

      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }

  ClassList = async () => {
    try {
      const response = await apiClient.get('/api/classes')
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  SectionList = async () => {
    try {
      const response = await apiClient.get('/api/section')
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  SubjectList = async () => {
    try {
      const response = await apiClient.get('/api/subject')
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  SubdomainList = async (fdata) => {
    try {
      const response = await apiClient.post('/api/SubDomain', { subject: fdata })
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  ClassReport = async (fdata) => {
    try {
      // const response = await apiClient.get('/reportadmin',fdata);
      const response = await apiClient.get('/report/reportadminnew', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  ClassReportSubdomain = async (fdata) => {
    try {
      const response = await apiClient.get('/reportadmininner', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }

  GradeAdd = async (fdata) => {
    try {
      const response = await apiClient.post('/addgrade', fdata)
      const data = response.data
      console.log(data)
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  GradeList = async () => {
    try {
      const response = await apiClient.get('/report/grade')
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  GetAverage = async (fdata) => {
    try {
      const response = await apiClient.get('/report/getavg', fdata)
      console.log('response', response.data);
      
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  InnerReport = async (fdata) => {
    try {
      const response = await apiClient.get('innerdata', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  FindQuestionList = async (fdata) => {
    try {
      const response = await apiClient.get('/report/findquestions', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  FindSubdomainList = async (fdata) => {
    try {
      const response = await apiClient.get('/subdomain', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  AertCondition = async (fdata) => {
    try {
      const response = await apiClient.post('/alertcondition', fdata)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }
  AertConditionList = async () => {
    try {
      const response = await apiClient.get('/alertcondition')
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  GetStudentData = async (fdata) => {
    try {
      const response = await apiClient.get('/studentByClass', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  CreateResult = async (fdata) => {
    try {
      const response = await apiClient.get('/createresult', fdata)
      console.log('response.data')
      return response.data
    } catch (error) {
      console.log('response.data')
      console.log(error)
    }
  }
  GetAlertData = async (fdata) => {
    try {
      const response = await apiClient.get('/getalertdata', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  GetResultList = async (fdata) => {
    try {
      const response = await apiClient.get('/report/getresultlist', fdata)
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
  GetStudentByClass = async (fdata) => {
    try {      
      const response = await apiClient.get('/report/studentByClass', {params:fdata})
      return response.data
    } catch (error) {
      console.log(error)
      // setError(error.response.data.errtext);
    }
  }
}

export default new MultiServices()
