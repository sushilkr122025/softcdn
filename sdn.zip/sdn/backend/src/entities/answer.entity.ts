import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'answer' })
export class Answer {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int' })
  paperid: number;

  @Column({ type: 'int' })
  studentid: number;

  @Column({ type: 'int' })
  class: number;

  @Column({ type: 'varchar', length: '10' })
  section: string;

  @Column({ type: 'int' })
  qid: number;

  @Column({ type: 'varchar', length: '10' })
  uanswer: string;

  @Column({ type: 'varchar', length: '10' })
  canswer: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'int' })
  status: number;
}
