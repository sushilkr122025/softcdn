import React, { useState, useEffect } from 'react'
import { FaRegEdit, FaRegTrashAlt } from "react-icons/fa";
import { FaEllipsisVertical } from "react-icons/fa6";
import './admin.css'
// import { useNavigate } from 'react-router-dom'
import { Modal, Button } from 'react-bootstrap'
import apiClient from '../api/apiService';

function AdminSection() {
  const [classData, setClassData] = useState([])
  const [SectionData, setSectionData] = useState([])
  const [SubjectData, setSubjectData] = useState([])
  const [SubDomainData, setSubDomainData] = useState([])
  const [userData, setUserData] = useState([])

  const [errors, setErrors] = useState({})
  const [showSubDomain, setShowSubDomain] = useState(false)
  const [subjectModal, setSubjectModal] = useState(false)
  const [classModal, setClassModal] = useState(false)
  const [sectionModal, setSectionModal] = useState(false)

  const [subjectEdit, setSubjectEdit] = useState()
  const [classEdit, setClassEdit] = useState()
  const [sectionEdit, setSectionEdit] = useState()
  const [subDomainEdit, setSubDomainEdit] = useState()

  // const navigator = useNavigate()

  function getEmpTypeBadge(empType) {
    switch (empType) {
      case 'Permanent':
        return <span className="badge rounded-pill text-bg-primary">Permanent</span>;
      case 'Internship':
        return <span className="badge rounded-pill text-bg-success">Internship</span>;
      case 'PartTime':
        return <span className="badge rounded-pill text-bg-warning">Part Time</span>;
      case 'BondBased':
        return <span className="badge rounded-pill text-bg-info">Bond Based</span>;
      default:
        return <span className="badge rounded-pill text-bg-danger">User</span>;
    }
  }

  const handleSubjectEdit = (data) => {
    setSubjectEdit(data)
    openSubjectModal()
  }

  const handleDelete = (e, id) => { 
    const tableName = e.currentTarget.dataset.tablename

    const data = {
      tableName: tableName,
      id: id
    }

    apiClient.post(`/admin/SoftDelete`, data)
      .then((response) => {
       if (response.status === 200) {
        console.log(response.data);
       }
      })
      .catch((error) => {
      console.error(error)
      })
  }

  const openSubjectModal = () => setSubjectModal(true)
  const closeSubjectModal = () => {
    setSubjectModal(false);
    setSubjectEdit({});
  }

  const submitSubjectForm = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)
    payload['status'] = 'status' in payload ? 1 : 0;
    payload['parentId'] = 0

    const newErrors = {}

    if (!payload.subject) newErrors.subject = 'Subject is required'
    setErrors(newErrors)

    if (Object.keys(newErrors).length > 0) {
      return
    } else {
      console.log(payload);
      apiClient.post(`/store/Subject`, payload)
      .then((response) => {
       if (response.data.status === 1) closeSubjectModal()
      })
      .catch((error) => {
      console.error(error)
      })
    }
  }

  const openClassModal = () => setClassModal(true)
  const closeClassModal = () => {
    setClassModal(false)
    setClassEdit({})
  }

  const handleClassEdit = (data) => {
    setClassEdit(data)
    openClassModal()
  }

  const submitClassForm = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)
    payload['status'] = 'status' in payload ? 1 : 0;

    // console.log(payload);

    const newErrors = {}
    if (!payload.class) newErrors.class = 'class is required'

    setErrors(newErrors)

    if (Object.keys(newErrors).length > 0) {
      return;
    } else {
      apiClient.post(`/store/class`, payload)
      .then((response) => {
        if (response.status === 200) closeClassModal()
      })
      .catch((error) => console.error(error))
    }
    
  }

  const openSectionModal = () => setSectionModal(true)
  const closeSectionModal = () => {
    setSectionModal(false)
    setSectionEdit({})
  }

  const handleSectionEdit = (data) => {
    setSectionEdit(data)
    openSectionModal()
  }

  const submitSectionForm = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)
    payload['status'] = 'status' in payload ? 1 : 0;

    // console.log(payload);

    const newErrors = {}
    if (!payload.section) newErrors.section = 'section is required'

    setErrors(newErrors)

    if (Object.keys(newErrors).length > 0) {
      return;
    } else {
        apiClient.post(`/store/Section`, payload)
        .then((response) => {
          if (response.status === 200) closeSectionModal()
        })
        .catch((error) => console.error(error))
    }
    
  }

  const openSubDomain = () => setShowSubDomain(true)
  const closeSubDomain = () => {
    setShowSubDomain(false)
    setSubDomainEdit({})
  }

  const handleSubDomainEdit = (data) => {
    setSubDomainEdit(data)
    openSubDomain()
  }

  const submitSubdomainForm = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)
    payload['status'] = 'status' in payload ? 1 : 0;

    // payload['parentId'] = payload['domainSubject']
    // payload['subject'] = payload['SubDomain']
    // payload['book'] = payload['NameOfBook']

    console.log(payload);
    const newErrors = {}
    if (!payload.parentId) newErrors.domainSubject = 'Subject is required'
    if (!payload.subject) newErrors.SubDomain = 'Sub domain is required'

    setErrors(newErrors)

    if (Object.keys(newErrors).length > 0) {
      return
    } else {
      apiClient.post(`/store/Subject`, payload)
      .then((response) => {
       if (response.data.status === 1) closeSubDomain()
      })
      .catch((error) => {
      console.error(error)
      })
    }

   
  }

  useEffect(() => {
    
    apiClient
      .get('/store/subject')
      .then((response) => {
        // console.log(response.data);
        setSubjectData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        // console.log(response.data);
        setClassData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching class data:', error)
      })

    apiClient
      .get('/store/section')
      .then((response) => {
        // console.log(response.data);
        setSectionData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })

    apiClient
      .get('/store/subDomainData')
      .then((response) => {
        // console.log(response.data)
        setSubDomainData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })

      apiClient
      .get('/user/all')
      .then((response) => {        
        // setUserData(response.data)
      })
      .catch((error) => {
        console.error(error)
      })
  }, [])
  return (
    <section id="admin">
      <div className="container-fluid my-3">
      <div className="row mb-4">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <div className="d-flex align-items-center justify-content-between">
                <h6 className='text-primary mb-0 fw-semibold'>Teacher</h6>
                <a href='/UserRegistration' className="btn btn-sm btn-primary shadow">
                  + Add Teacher
                </a>
              </div>
            </div>
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-bordered table-hover text-center" id="userTable">
                  <thead>
                    <tr>
                      <th></th>
                      <th>Name</th>
                      <th>DOJ</th>
                      <th>Email</th>
                      <th>Contact</th>
                      <th>Emp. Type</th>
                      <th>Role</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                  {userData.map((row) => (
                        <tr key={row.id}>
                          <td>
                            <button type='button' className='btn btn-sm' data-bs-toggle="dropdown" aria-expanded="false">
                              <FaEllipsisVertical className='text-primary'/>
                            </button>
                            <ul className='dropdown-menu p-2'>
                              <li><a href={`/UserRegistration?id=${row.id}`} className='dropdown-item'>Edit Details</a></li>
                              <li><a href={`roles?id=${row.id}`} className='dropdown-item'>Set Roles</a></li>
                            </ul>
                          </td>
                          <td>{row.name}</td>
                          <td>{row.DOJ.split('T')[0]}</td>
                          <td>{row.emailId}</td>
                          <td>{row.contactNo}</td>
                          <td>{getEmpTypeBadge(row.empType)}</td>
                          <td>{row.role}</td>
                          <td>
                          {row.status === 1 ? <span className="badge rounded-pill text-bg-primary">ACTIVE</span> : <span className="badge rounded-pill text-bg-secondary">INACTIVE</span>}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div className="row mb-4">
          <div className="col-12 col-md-6">
            <div className="card">
              <div className="card-header">
                <div className="d-flex align-items-center justify-content-between">
                  <h6 className="text-primary mb-0 fw-semibold">Subject</h6>
                  <button className="btn btn-sm btn-primary shadow" onClick={openSubjectModal}>
                    + Add Subject
                  </button>
                </div>
              </div>
              <div className="card-body">
                <div className="table-responsive rounded">
                    <table className="table table-striped border" width={100}>
                      <thead>
                        <tr>
                          <th></th>
                          <th>Subject</th>
                          <th className="text-end " width={20}>
                            Status
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {SubjectData.map((row) => (
                          <tr key={row.id}>
                            <td className="edit">
                              <button
                                className="btn p-0 pe-2 text-primary "
                                onClick={() => handleSubjectEdit(row)}
                              >
                                <FaRegEdit />
                              </button>
                              <button
                                className="btn p-0 pe-2 text-danger"
                                data-tablename= "subject"
                                onClick={(e) => handleDelete(e, row.id)}
                              >
                                <FaRegTrashAlt />
                              </button>
                            </td>
                            <td>{row.subject}</td>
                            <td className="text-end">
                              {row.status === 1 ? <span className="badge text-bg-primary">ACTIVE</span> : <span className="badge text-bg-secondary">INACTIVE</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6">
            <div className="card">
              <div className="card-header">
                <div className="d-flex align-items-center justify-content-between">
                  <h6 className="text-primary mb-0 fw-semibold">Class</h6>
                  <button className="btn btn-sm btn-primary shadow" onClick={openClassModal}> + Add Class </button>
                </div>
              </div>
              <div className="card-body">
                <div className="table-responsive rounded">
                  <table className="table border table-striped" width={100}>
                    <thead>
                      <tr>
                        <th></th>
                        <th>Class</th>
                        <th className="text-end">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {classData.map((row) => (
                        <tr key={row.id}>
                          <td className="edit">
                            <button
                              className="btn text-primary py-0 ps-0"
                              onClick={() => handleClassEdit(row)}
                            >
                              <FaRegEdit />
                            </button>
                            <button
                              className="btn text-danger py-0 ps-0"
                              data-tablename= "class"
                              onClick={(e) => handleDelete(e, row.id)}
                            >
                              <FaRegTrashAlt />
                            </button>
                          </td>
                          <td>{row.class}</td>
                          <td className="text-end">
                            {row.status === 1 ? <span className="badge text-bg-primary">ACTIVE</span> : <span className="badge text-bg-secondary">INACTIVE</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-12 col-md-6">
            <div className="card mb-3">
              <div className="card-header">
                <div className="d-flex align-items-center justify-content-between">
                  <h6 className="text-primary mb-0 fw-semibold">Section</h6>
                  <button className="btn btn-sm btn-primary shadow" onClick={openSectionModal}>+ Add Section</button>
                </div>
              </div>
              <div className="card-body">
                <div className="table-responsive rounded">
                  <table className="table border table-striped" width={100}>
                    <thead>
                      <tr>
                        <th></th>
                        <th>Section</th>
                        <th className="text-end">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {SectionData.map((row) => (
                        <tr key={row.id}>
                          <td className="edit">
                            <button
                              className="btn text-primary py-0 ps-0"
                              onClick={() => handleSectionEdit(row)}
                            >
                              <FaRegEdit />
                            </button>
                            <button
                              className="btn text-danger py-0 ps-0"
                              data-tablename= "section"
                              onClick={(e) => handleDelete(e, row.id)}
                            >
                              <FaRegTrashAlt />
                            </button>
                          </td>
                          <td>{row.section}</td>
                          <td className="text-end">
                          {row.status === 1 ? <span className="badge text-bg-primary">ACTIVE</span> : <span className="badge text-bg-secondary">INACTIVE</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div className="card">
              <div className="card-header">
                <div className="d-flex align-items-center justify-content-between">
                  <h6 className="text-primary mb-0 fw-semibold">User</h6>
                  <a className="btn btn-sm btn-primary shadow" href='/UserRegistration'>+ Add User</a>
                </div>
              </div>
              <div className="card-body">
                <div className="table-responsive rounded">
                  <table className="table border table-striped" width={100}>
                    <thead>
                      <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Role</th>
                        <th className="text-end">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {userData.map((row) => (
                        <tr key={row.id}>
                          <td className="edit">
                            <a 
                              href={`/UserRegistration?id=${row.Id}`}
                              className="btn text-primary py-0 ps-0"
                            >
                              <FaRegEdit />
                            </a>
                            <button
                              className="btn text-danger py-0 ps-0"
                              data-tablename= "section"
                              onClick={(e) => handleDelete(e, row.id)}
                            >
                              <FaRegTrashAlt />
                            </button>
                          </td>
                          <td>{row.name}</td>
                          <td>{row.role}</td>
                          <td className="text-end">
                          {row.status === 1 ? <span className="badge text-bg-primary">ACTIVE</span> : <span className="badge text-bg-secondary">INACTIVE</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div className="col-12 col-md-6">
            <div className="card">
              <div className="card-header">
                <div className="d-flex align-items-center justify-content-between">
                  <h6 className="text-primary mb-0 fw-semibold">Sub domain</h6>
                  <button className="btn btn-sm btn-primary shadow" onClick={openSubDomain}>
                    + Add Sub domain
                  </button>
                </div>
              </div>
              <div className="card-body">
                <div className="table-responsive rounded">
                  <table className="table border table-striped" width={100}>
                    <thead>
                      <tr>
                        <th></th>
                        <th>Sub domain</th>
                        <th>Book</th>
                        <th>Subject</th>
                        <th className="text-end">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {SubDomainData.map((row) => (
                        <tr key={row.id}>
                          <td className="edit">
                            <button
                              className="btn text-primary py-0 ps-0"
                              onClick={() => handleSubDomainEdit(row)}
                            >
                              <FaRegEdit />
                            </button>
                            <button
                              className="btn text-danger py-0 ps-0"
                              data-tablename= "subject"
                              onClick={(e) => handleDelete(e, row.id)}
                            >
                              <FaRegTrashAlt />
                            </button>
                          </td>
                          <td>{row.subDomain}</td>
                          <td>{row.Book}</td>
                          <td>{row.subject}</td>
                          <td className="text-end">
                            {
                              row.status === 1 ? <span className="badge text-bg-primary">ACTIVE </span> : <span className="badge text-bg-secondary">INACTIVE</span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <Modal show={showSubDomain} onHide={closeSubDomain}>
              <Modal.Header closeButton>
                <Modal.Title>Add Sub Domain</Modal.Title>
              </Modal.Header>
              <form action="" method="post" autoComplete='off' onSubmit={submitSubdomainForm}>
              <Modal.Body>
                <div className="row gx-2 mb-3">
                  <div className="col-md-4">
                    <label htmlFor="domainSubject" className="mb-2">
                      Subject<span className="required text-danger"> *</span>
                    </label>
                    <input type="hidden" name="id" id="subDomainId" defaultValue={subDomainEdit?.id} />
                    <select id="domainSubject" name="parentId" className="form-select shadow-sm" defaultValue={subDomainEdit?.parentId}>
                      <option value="">Select Subject</option>
                      {SubjectData.map((SubjectData, index) => (
                        <option key={index} value={SubjectData.id}>
                          {SubjectData.subject}
                        </option>
                      ))}
                    </select>
                    {errors.domainSubject && <div>{errors.domainSubject}</div> }
                  </div>
                  <div className="col-md-4">
                    <label htmlFor="SubDomain" className="mb-2">Sub Domain</label>
                    <input type="text" name="subject" id="SubDomain" className="form-control shadow-sm" placeholder="Enter Sub Domain" defaultValue={subDomainEdit?.subDomain}/>
                    {errors.SubDomain && <div>{errors.SubDomain}</div> }
                  </div>
                  <div className="col-md-4">
                    <label htmlFor="NameOfBook" className="mb-2">Name Of Book</label>
                    <input type="text" name="book" id="NameOfBook" className="form-control shadow-sm" placeholder="Enter the Name Of Book" defaultValue={subDomainEdit?.book} />
                  </div>
                  <div className="col-12 mt-3">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" name="status" id="subdomainStatus" defaultChecked={subDomainEdit?.status === 1 ? true : false} />
                      <label className="form-check-label" htmlFor="subdomainStatus">Activate</label>
                    </div>
                  </div>
                </div>
              </Modal.Body>
              <Modal.Footer>``
                <Button variant="secondary" onClick={closeSubDomain}>
                  Cancel
                </Button>
                <Button variant="success" type='submit'>
                  Save
                </Button>
              </Modal.Footer>
              </form>
            </Modal>


            <Modal show={classModal} onHide={closeClassModal}>
              <Modal.Header closeButton>
                <Modal.Title>Class</Modal.Title>
              </Modal.Header>
              <form action="" method="post" autoComplete='off' onSubmit={submitClassForm}>
              <Modal.Body>
                <div className="row">
                  <div className="col-12">
                    <input type="hidden" name="id" id="classId" defaultValue={classEdit?.id} />
                    <input type="text" name="class" id="class" className="form-control shadow-sm" placeholder="Enter the Class" defaultValue={classEdit?.class}/>
                    {errors.class && <div>{errors.class}</div> }
                  </div>
                  <div className="col-12 mt-3">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" name="status" id="classStatus" defaultChecked={classEdit?.status === 1 ? true : false} />
                      <label className="form-check-label" htmlFor="classStatus">Activate</label>
                    </div>
                  </div>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={closeClassModal}>
                  Cancel
                </Button>
                <Button variant="success" type='submit'>
                  Submit
                </Button>
              </Modal.Footer>
              </form>
            </Modal>


            <Modal show={subjectModal} onHide={closeSubjectModal}>
              <Modal.Header closeButton>
                <Modal.Title>Subject</Modal.Title>
              </Modal.Header>
              <form method="post" autoComplete="false" onSubmit={submitSubjectForm}>
              <Modal.Body>
                <div className="row">
                  <div className="col">
                    <input type="hidden" name="id" id="subjectId" defaultValue={subjectEdit?.id} />
                    <input type="text" name="subject" id="subject" className="form-control shadow-sm" placeholder="Subject" defaultValue={subjectEdit?.subject} />
                    {errors.subject && <div>{errors.subject}</div> }
                  </div>
                  <div className="col">
                    <input type="text" name="book" id="book" className="form-control shadow-sm" placeholder="Book" defaultValue={subjectEdit?.book}/>
                  </div>
                  <div className="col-12 mt-3">
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" name="status" id="subjectStatus" defaultChecked={subjectEdit?.status === 1 ? true : false} />
                      <label className="form-check-label" htmlFor="subjectStatus">Activate</label>
                    </div>
                  </div>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={closeSubjectModal}>
                  Cancel
                </Button>
                <Button variant="success" type='submit'>
                  Submit
                </Button>
              </Modal.Footer>
              </form>
            </Modal>
            <Modal show={sectionModal} onHide={closeSectionModal}>
              <Modal.Header closeButton>
                <Modal.Title>Section</Modal.Title>
              </Modal.Header>
              <form action="" method="post" autoComplete='off' onSubmit={submitSectionForm}>
              <Modal.Body>
                <div className="row">
                  <div className="col-12">
                  <input type="hidden" name="id" id="sectionId" defaultValue={sectionEdit?.id} />
                    <input type="text" name="section" id="section" className="form-control shadow-sm" placeholder="Enter the Section" defaultValue={sectionEdit?.section} />
                    {errors.section && <div>{errors.section}</div> }
                  </div>
                  <div className="col-12">
                    <div className="col-12 mt-3">
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" name="status" id="sectionStatus" defaultChecked={sectionEdit?.status === 1 ? true : false} />
                        <label className="form-check-label" htmlFor="sectionStatus">Activate</label>
                      </div>
                    </div>
                  </div>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={closeSectionModal}>
                  Cancel
                </Button>
                <Button variant="success" type='submit' >
                  Submit
                </Button>
              </Modal.Footer>
              </form>
            </Modal>
          </div>
        </div>
      </div>
    </section>
  )
}

export default AdminSection
