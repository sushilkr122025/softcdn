import { Injectable } from '@nestjs/common';
import { Message } from '../entities/message.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class MessageService {
  constructor(
    @InjectRepository(Message)
    private repoMessage: Repository<Message>
  ) {}

  async createMessage(data: Partial<Message>): Promise<Message> {
    const message = this.repoMessage.create(data);
    return this.repoMessage.save(message);
  }
}
