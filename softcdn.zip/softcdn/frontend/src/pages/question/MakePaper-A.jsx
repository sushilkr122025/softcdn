import React, { useState, useEffect } from 'react'
import { GoFile, GoChevronDown } from 'react-icons/go'
import { IoFilterOutline } from "react-icons/io5";
import { useLocation, useNavigate } from 'react-router-dom'
import blankDataImage from '../../assets/images/MakePaper.png'
import GlobalFilter from '../../components/GlobalFilter';

const UserQuestions = () => {
  const [data, setData] = useState([])
  const [selectedQuestions, setSelectedQuestions] = useState([])
  const navigator = useNavigate()
  const [classSubject, setClassSubject] = useState();
  const location = useLocation()
  const {state} = location

  const [filters, setFilters] = useState({
    type: '',
    subject: '',
    class: '',
    difficulty: '',
    skill: '',
    learnObj: '',
  })

  useEffect(() => {
    if (state) {
      const selected = state.selectedQuestions.split(',').map(Number); // Ensure it's an array of numbers
            
      setSelectedQuestions(selected);
      setData(state.questions);
      setClassSubject({ class: state.questions[0].class, subjectName: state.questions[0].subject });
    }
  }, [state]);
  
  useEffect(() => {
    if (state && data.length > 0) {
      const selected = state.selectedQuestions.split(',').map(Number);
      
      selected.forEach(e => {
        const checkbox = document.querySelector(`[data-id="${e}"]`);
        if (checkbox) checkbox.checked = true;
      });
    }
  }, [data, state]);
  
  const isSelected = (questionId) => {
    return selectedQuestions.includes(questionId);
  };
  
  const toggleSelectQuestion = (questionIndex) => {
       console.log(questionIndex);
       
    setSelectedQuestions((prevSelected) =>
      prevSelected.includes(questionIndex)
        ? prevSelected.filter((index) => index !== questionIndex)
        : [...prevSelected, questionIndex]
    )      
  }

  // const isSelected = (questionIndex) => selectedQuestions.includes(questionIndex)
  
  
  const handleCheckboxChange = (questionIndex) => {
    toggleSelectQuestion(questionIndex)
  }

  const handleFilterChange = (filterType, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterType]: value,
    }))
  }

  const questionData = (childData) => {
    setData(childData)
    console.log(childData)
    
    setClassSubject({class: childData[0].class, subjectName: childData[0].subject})
  }

  const filteredData = data.filter(
    (item) =>
      (!filters.quesType || item.quesType === filters.quesType) &&
      (!filters.subject || item.subject === filters.subject) &&
      (!filters.class || item.class === filters.class) &&
      (!filters.difficulty || item.difficulty === filters.difficulty) &&
      (!filters.skill || item.skill === filters.skill) &&
      (!filters.learnObj || item.learnObj === filters.learnObj)
  )

  const renderTable = () => {
    if (filteredData.length === 0) {
      return <section className='text-center my-4'>
      <div className="row justify-content-center">
        <div className="col-8 col-sm-7 col-md-5 col-lg-3">
          <img src={blankDataImage} alt="Question Bank" className='img-fluid mb-4' />
        </div>
      </div>
      <h4 className='fw-normal'>No data available</h4>
      <p className='text-muted'>Start Filtering data according to your need</p>
    </section>;
    } else {
      document.getElementById('filter').classList.remove('d-none');
      return <>
      <div className='table-responsive sky'>
        <table className='table table-lg' id='questionTable' width={100}>
          <thead>
            <tr>
              <th colSpan={3} className='border-start border-end'>Questions</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map((item, index) => (
              <>
                <tr className='quesRow' key={index}>
                  <td className='border-start'>{item.question}</td>
                  <td><span className='pointer' onClick={() => handlePointer(index)}><GoChevronDown size={20} /></span></td>
                  <td className='border-end'>
                    <div className="form-check">
                      <input className="form-check-input" type="checkbox" data-id={item.id} checked={isSelected(item.id)} onChange={() => handleCheckboxChange(item.id)} />
                    </div>
                  </td>
                </tr>
                <tr className='subData d-none' data-id={`subData${index}`}>
                  <td colSpan={3} className='border-start border-end'>
                    <div className="d-flex justify-content-between">
                      <p className='me-2'><span className="fw-bold">1. </span>{item.opt1}</p>
                      <p className='me-2'><span className="fw-bold">2. </span>{item.opt2}</p>
                      <p className='me-2'><span className="fw-bold">3. </span>{item.opt3}</p>
                      <p className='me-2'><span className="fw-bold">4. </span>{item.opt4}</p>
                    </div>
                  </td>
                </tr>
              </>
            ))}
          </tbody>
        </table>
      </div>
      <div className="text-center my-4">
          <button
            className="btn lq-sky-color"
            type="button"
            onClick={() => {
              const selectedQuestionsQueryParam = selectedQuestions.join(',');
              const state = {
                selectedQuestion: selectedQuestionsQueryParam,
                class: classSubject.class,
                subject: classSubject.subjectName,
                questions: filteredData

              };
              navigator(`/MakePaper-B`, { state });
            } }
          >
            Create Question Paper
          </button>
        </div></>
    }
  }

  const handlePointer = (id) => {
    const element = document.querySelector('[data-id="subData'+id+'"]');
    element.classList.toggle('d-none');
    element.previousElementSibling.querySelector('.pointer > svg').classList.toggle('rotate')
  }

  return (
    <div className="container-fluid">
    <GlobalFilter icon={<GoFile />} heading={'Make Paper'} headClass={'sky'} questionData={questionData} />
    <section>
      <div className="row mb-3 d-none filter-header sky" id='filter'>
        <div className="col-lg-4 col-md-3 d-flex align-items-center mb-2">
          <IoFilterOutline /> Filters
        </div>
        <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
          <select className="form-select form-select-sm" id='type' value={filters.quesType} onChange={(e) => handleFilterChange('quesType', e.target.value)}>
            <option value="">Select Type</option>
            <option value="multipleChoice">Multiple Choice</option>
            <option value="trueFalse">True/False</option>
            <option value="oneword">one word</option>
            <option value="fillintheblank">fill in the blank</option>
            <option value="textquestion">text question</option>
            <option value="Matchthefollowing">Match the following</option>
            <option value="unseenpassage">unseen passage</option>
            <option value="imagebased">image based</option>
          </select>
        </div>
        <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
          <select className="form-select form-select-sm" value={filters.difficulty} onChange={(e) => handleFilterChange('difficulty', e.target.value)}>
            <option value="">Select Difficulty Level</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </div>
        <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
          <select className="form-select form-select-sm" value={filters.skill} onChange={(e) => handleFilterChange('skill', e.target.value)}>
            <option value="">Select Skill</option>
            <option value="Memory">Memory</option>
            <option value="Resoning">Reasoning</option>
            <option value="Arithmatic">Arithmatic</option>
          </select>
        </div>
        <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
          <select className="form-select form-select-sm" value={filters.learnObj} onChange={(e) => handleFilterChange('learnObj', e.target.value)}>
            <option value="">Select Learning objective </option>
            <option value="Creating new knowledge">Creating new knowledge (Cognitive)</option>
            <option value="Developing feelings and emotions">Developing feelings and emotions (Affective)</option>
            <option value="Enhancing physical and manual skills">Enhancing physical and manual skills (Psychomotor)</option>
          </select>
        </div>
      </div>
    </section>
    {renderTable()}
  </div>
  )
}

export default UserQuestions
