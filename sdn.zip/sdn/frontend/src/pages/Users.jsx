import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';
import { FaEllipsisVertical } from "react-icons/fa6";
import UserServices from '../api/UserServices';
import user from '../assets/images/user-grey.svg';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import './admin.css';
import { PiFilePdfLight, PiMicrosoftWordLogoLight } from "react-icons/pi";
import { FaFileWord } from "react-icons/fa";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Document, Packer, Paragraph, Table, TableCell, TableRow, WidthType, TextRun } from "docx";

function Users() {
  const [userData, setUserData] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [pageSize, setPageSize] = useState(10);
  const [debouncedSearchText, setDebouncedSearchText] = useState('');

  const [columnVisibilityModel, setColumnVisibilityModel] = useState(
    () => JSON.parse(localStorage.getItem("userColumnVisibility")) || {}
  );

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await UserServices.allUser()
        if (response) {
          setUserData(response)
        }
      } catch (error) {
        console.error(error)
      }
    }
    fetchUserData();
  }, [])

  const handleColumnVisibilityChange = (newModel) => {
    setColumnVisibilityModel(newModel);
    localStorage.setItem("userColumnVisibility", JSON.stringify(newModel));
  };

  const handleExportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(userData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Users");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(data, "Users.xlsx");
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();

    doc.text("User List", 14, 10);

    const tableColumn = columns
      .filter(col => col.field !== "action") // skip action column
      .map(col => col.headerName);

    const tableRows = filteredRows.map(row =>
      columns
        .filter(col => col.field !== "action")
        .map(col => {
          if (col.valueGetter) return col.valueGetter({ row });
          if (col.renderCell) return row[col.field] === 1 ? "Active" : "Inactive";
          return row[col.field] || "";
        })
    );

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save("Users.pdf");
  };

  const handleExportWord = async () => {
    const tableRows = [];

    const headerCells = columns
      .filter(col => col.field !== "action")
      .map(col => new TableCell({
        children: [new Paragraph({ text: col.headerName, bold: true })],
      }));
    tableRows.push(new TableRow({ children: headerCells }));

    filteredRows.forEach((row, rowIndex) => {
      const cells = columns
        .filter(col => col.field !== "action")
        .map((col, colIndex) => {
          let value = "";
          if (col.valueGetter) value = col.valueGetter({ row });
          else if (col.renderCell) value = row[col.field] === 1 ? "Active" : "Inactive";
          else value = row[col.field] || "";

          return new TableCell({
            children: [new Paragraph(String(value))],
          });
        });

      tableRows.push(
        new TableRow({
          children: cells,
        })
      );
    });


    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [new TextRun({ text: "User List", bold: true, size: 28 })],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: tableRows,
          }),
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "Users.docx");
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 1 },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    { field: 'mobileno', headerName: 'Contact', flex: 1 },
    { field: 'role', headerName: 'Role', flex: 1 },
    { field: 'userid', headerName: 'User Id', flex: 1 },
    {
      field: 'createdate',
      headerName: 'Created At',
      flex: 1,
      valueFormatter: (params) => {
        // Format the date to YYYY-MM-DD
        return params.value?.split('T')[0] || '';
      },
    },
    {
      field: 'action',
      headerName: 'Action',
      flex: 1,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <div>
          <button
            type="button"
            className='btn btn-sm border-0'
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <FaEllipsisVertical className="text-primary" />
          </button>
          <ul className="dropdown-menu p-2 bg-white">
            <li>
              <a href={`/users/${params.row.id}`} className="dropdown-item">
                Edit Details
              </a>
            </li>
            <li>
              <a href={`/users/roles/${params.row.id}`} className="dropdown-item">
                Set Roles
              </a>
            </li>
          </ul>
        </div>
      ),
    },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchText(searchText);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchText]);

  const filteredRows = userData.filter((row) =>
    row?.name?.toLowerCase().includes(debouncedSearchText.toLowerCase())
  );

  return (
    <section id="admin">
      <div className="container-fluid">
        <div className="row align-items-center">
          <div className="col-6 py-3 d-flex align-items-center">
            <img src={user} alt="student" style={{ width: "23px" }} />
            <h5 className='text-grey-400 mb-0 ms-3'>User</h5>
          </div>
          <div className="col-6 py-3 text-end d-flex justify-content-end align-items-center">
            <Link to="/users/add">
              <button className='btn btn-sm btn-primary me-2'>Add user</button>
            </Link>
            <div>
              <button className="btn btn-sm btn-primary border-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Export
              </button>
              <ul className="dropdown-menu mt-2">
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportPDF}><PiFilePdfLight className='me-2' /><span>PDF</span></li>
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportWord}><FaFileWord className='me-2' /><span>Word</span></li>
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportExcel}><PiMicrosoftWordLogoLight className='me-2' /><span>Excel</span></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="row mb-2 justify-content-end">
          <div className="col-12 col-md-2">
            <input
              type="text"
              className="form-control form-control-sm"
              placeholder="Search..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>
        </div>

        <div style={{ height: 600, width: '100%' }}>
          <DataGrid
            className="custom-data-grid"
            rows={filteredRows}
            columns={columns}
            pageSize={pageSize}
            onPageSizeChange={(newSize) => setPageSize(newSize)}
            pageSizeOptions={[10, 25, 50, 100]}
            // checkboxSelection
            disableRowSelectionOnClick
            initialState={{ pagination: { paginationModel: { pageSize: 10, page: 0 }, }, }}
            columnVisibilityModel={columnVisibilityModel}
            onColumnVisibilityModelChange={handleColumnVisibilityChange}
          />
        </div>
      </div>
    </section>
  );
}

export default Users;
