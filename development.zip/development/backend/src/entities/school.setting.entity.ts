import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'schoolsettings' })
export class SchoolSetting {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: '50', nullable: true })
  tenantid!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  settingName!: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  settingValue!: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdate!: Date;
}

export class SchoolSettingDto {
  id?: number;
  settingName?: string;
  settingValue?: string;
}
