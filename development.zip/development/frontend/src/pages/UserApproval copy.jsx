import React, { useEffect, useState, useCallback, useRef } from "react";
import { MdRemoveCircleOutline, MdAddCircleOutline, MdClose } from "react-icons/md";
import UserServices from '../api/UserServices';
import apiClient from "../api/apiService";
import { useParams } from "react-router-dom";

const UserApproval = () => {
  const [subjectData, setSubjectData] = useState([]);
  const [classData, setClassData] = useState([]);
  const [rowData, setRowData] = useState();
  const [teacherData, setTeacherData] = useState([]);
  const [rows, setRows] = useState([]);
  const [dirty, setDirty] = useState(false);
  const [lastSavedSnapshot, setLastSavedSnapshot] = useState("");
  const { userid } = useParams();
  const updateId = userid ? userid : null;
  const makeEmptyRow = useCallback(() => {
    return { classId: "", subjectId: "", teacherIds: [] };
  }, []);
  
  useEffect(() => {
    const loadAll = async () => {
      try {
         const userdata = await UserServices.getUser({ params: { id: updateId } });
          const clsdata = {};
          const subid = [];
          userdata.teacherSubject.map((s) => {            
            clsdata[s.subjectId] = s.classIds.map((c) => ({
              classId: parseFloat(c),
              teachers: [],
            }) );                      
            subid.push(parseFloat(s.subjectId));
          });          
        //  setClassData(clsdata[1]);    
        // console.log("clsdata", clsdata);    
         setRowData(clsdata);
          
        apiClient
          .get('/store/subject')
          .then((response) => {
            const subData = [];           
            response.data.map((s)=>{            
              if(subid.includes(s.id)){
                  subData.push(s);
              }
            })

            setSubjectData(subData);
          })
          .catch((error) => {
            console.error('Error fetching Subject data:', error);
          });

        // apiClient
        //   .get('/store/classes')
        //   .then((response) => {
        //     // console.log('classes', response.data);
        //     // setClassData(response.data);
        //   })
        //   .catch((error) => {
        //     console.error('Error fetching class data:', error);
        //   });

         

        const teachers = [
          { id: "t1", name: "Mr. Smith", subjectId: "1" },
          { id: "t2", name: "Ms. Johnson", subjectId: "1" },
          { id: "t3", name: "Dr. Adams", subjectId: "2" },
          { id: "t4", name: "Ms. Lee", subjectId: "2" },
          { id: "t5", name: "Mr. Brown", subjectId: "3" },
          { id: "t6", name: "Mrs. White", subjectId: "3" },
          { id: "t7", name: "Mr. Green", subjectId: "4" },
          { id: "t8", name: "Ms. Black", subjectId: "4" },
          { id: "t9", name: "Dr. Taylor", subjectId: "5" },
          { id: "t10", name: "Mr. Wilson", subjectId: "5" },
          { id: "t11", name: "Ms. Clark", subjectId: "6" },
          { id: "t12", name: "Mr. Harris", subjectId: "6" },
          { id: "t13", name: "Mrs. Allen", subjectId: "7" },
          { id: "t14", name: "Mr. Hall", subjectId: "7" },
          { id: "t15", name: "Dr. Young", subjectId: "8" },
          { id: "t16", name: "Ms. King", subjectId: "8" },
          { id: "t17", name: "Mr. Wright", subjectId: "9" },
          { id: "t18", name: "Mrs. Scott", subjectId: "9" },
          { id: "t19", name: "Ms. Lewis", subjectId: "10" },
          { id: "t20", name: "Mr. Walker", subjectId: "10" },
          { id: "t21", name: "Dr. Robinson", subjectId: "11" },
          { id: "t22", name: "Ms. Martinez", subjectId: "11" },
          { id: "t23", name: "Mr. Thompson", subjectId: "12" },
          { id: "t24", name: "Ms. Evans", subjectId: "12" },
          { id: "t25", name: "Mr. Sharma", subjectId: "13" },
          { id: "t26", name: "Mrs. Gupta", subjectId: "13" },
          { id: "t27", name: "Mr. aayu", subjectId: "13" },
          { id: "t28", name: "Mr. rana", subjectId: "13" },
          { id: "t29", name: "Mr. laddu", subjectId: "9" },
          { id: "t30", name: "Mr. window", subjectId: "10" },
          { id: "t31", name: "Mr. shiv", subjectId: "11" },
          { id: "t32", name: "Mr. Kidi", subjectId: "12" },
          { id: "t33", name: "Mr. Hudi", subjectId: "12" },
          { id: "t34", name: "Mr. Midi", subjectId: "2" },
          { id: "t35", name: "Mr. mojla", subjectId: "2" },
          { id: "t36", name: "Mr. aujla", subjectId: "3" },
        ];

        setTeacherData(teachers);

        const initialRows = [makeEmptyRow()];
        setRows(initialRows);

        const saved = localStorage.getItem("permissions");
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (parsed && parsed.permissions && Array.isArray(parsed.permissions) && parsed.permissions.length) {
              setRows(parsed.permissions);
              setLastSavedSnapshot(JSON.stringify(parsed.permissions));
            } else {
              setLastSavedSnapshot(JSON.stringify(initialRows));
            }
          } catch (err) {
            console.warn("failed to parse saved permissions, using defaults"+err);
            setLastSavedSnapshot(JSON.stringify(initialRows));
          }
        } else {
          setLastSavedSnapshot(JSON.stringify(initialRows));
        }
      } catch (err) {
        console.error("Error loading permission UI data:", err);
      }
    };

    loadAll();
  }, [makeEmptyRow]);

  useEffect(() => {
    try {
      const snap = JSON.stringify(rows);
      setDirty(snap !== lastSavedSnapshot);
    } catch (err) {
      setDirty(true);
      console.log("Error computing dirty state:", err);
      
    }
  }, [rows, lastSavedSnapshot]);

  const handleSubmitAll = async () => {
    try {
      if (document && document.activeElement && typeof document.activeElement.blur === "function") {
        document.activeElement.blur();
      }

      // validation: for rows that have a subject selected, ensure at least 1 teacher and at most 3
      const invalidRows = rows.reduce((acc, row, idx) => {
        if (row.subjectId) {
          const len = (row.teacherIds || []).length;
          if (len === 0) acc.push({ idx, msg: "Select at least 1 teacher" });
          else if (len > 3) acc.push({ idx, msg: "Maximum 3 teachers allowed" });
        }
        return acc;
      }, []);

      if (invalidRows.length > 0) {
        const messages = invalidRows.map((r) => `Row ${r.idx + 1}: ${r.msg}`).join("\n");
        alert(`Cannot save. Please fix the following:\n${messages}`);
        return;
      }

      const finalPayload = {
        module: "Approval",
        permissions: rows,
        userId: "TEMP_USER",
      };

      console.log("Mock save payload:", finalPayload);
      localStorage.setItem("permissions", JSON.stringify(finalPayload));
      setLastSavedSnapshot(JSON.stringify(rows));
      setDirty(false);
      alert("Permissions saved locally!");
    } catch (error) {
      console.error("Error in handleSubmitAll:", error);
      alert("Error saving permissions. Check console for details.");
    }
  };

  return (
    <div className="container-fluid py-4">
      <div className="row ms-5">
        <div className="col-12 col-lg-11 ms-5 bg-white shadow-sm rounded p-4">
          <div className="form-header mb-4 border-bottom pb-2 d-flex justify-content-between align-items-center">
            <h3 className="fw-bold text-primary">User Approval</h3>
            <button
              className="btn btn-secondary"
              onClick={handleSubmitAll}
              disabled={!dirty}
              title={!dirty ? "No changes to save" : "Save Permissions"}
            >
              Save Permissions
            </button>
          </div>

          {/* Permission Table */}
          <PermissionTable
            rowData={rowData}
            classData={classData}
            subjectData={subjectData}
            teacherData={teacherData}
            rows={rows}
            onRowsChange={setRows}
            makeEmptyRow={makeEmptyRow}
          />
        </div>
      </div>
    </div>
  );
};
const PermissionTable = ({
  rowData,
  classData,
  subjectData,
  teacherData,
  rows,
  onRowsChange,
  makeEmptyRow,
}) => {
  const [openDropdown, setOpenDropdown] = useState(null);
  const [searchMap, setSearchMap] = useState({});
  const [modalRowIndex, setModalRowIndex] = useState(null);
  const [errors, setErrors] = useState({});
  const containerRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!containerRef.current) return;
      if (!containerRef.current.contains(e.target)) {
        setOpenDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // validate rows whenever rows change
  useEffect(() => {
    const newErrors = {};
    rows.forEach((row, i) => {
      if (row.subjectId) {
        const len = (row.teacherIds || []).length;
        if (len === 0);
        else if (len > 3) newErrors[i] = "Maximum 3 teachers allowed";
      }
    });
    setErrors(newErrors);
  }, [rows]);

  const addRow = () => {
    onRowsChange([...rows, makeEmptyRow()]);
    setOpenDropdown(null);
  };

  const removeRow = () => {
    if (rows.length > 1) onRowsChange(rows.slice(0, -1));
    setOpenDropdown(null);
  };

  const handleChange = async (rowIndex, field, value) => {
    
    const updated = [...rows]; 
    updated[rowIndex] = { ...updated[rowIndex], [field]: value };
    if (field === "classId" || field === "subjectId") {
      // reset teachers when class/subject changes
      updated[rowIndex].teacherIds = [];
      setSearchMap((s) => ({ ...s, [rowIndex]: "" }));
    }

    onRowsChange(updated);
    // if(updated[rowIndex].classId && updated[rowIndex].subjectId){
    const { classId, subjectId } = updated[rowIndex];
    if (classId && subjectId) {
      console.log("Updated classid:", classId,"Updated subjectid:", subjectId);
      const response = await UserServices.getTeacherBySubjectClass({ params: { classIds: classId, subjectId: subjectId } });
      console.log("Teachers fetched:", response);
      const updatedRowData = { ...rowData };
      updatedRowData[subjectId] = updatedRowData[subjectId].map((c) =>
        c.classId === Number(classId) ? { ...c, teachers: response || [] } : c
      );
     // onRowsChange(updatedRowData);
    console.log("Updated:", updated);
    console.log("Updated rowData:", updatedRowData);
    }
    //onRowsChange(updated);
  };

  const handleTeacherToggle = (rowIndex, teacherId) => {
    const updated = [...rows];
    const current = updated[rowIndex]?.teacherIds || [];
    if (current.includes(teacherId)) {
      // remove
      updated[rowIndex].teacherIds = current.filter((t) => t !== teacherId);
    } else {
      // add - enforce max 3
      if (current.length >= 3) {
        // give immediate feedback
        alert("You can select up to 3 teachers only.");
        return;
      }
      updated[rowIndex].teacherIds = [...current, teacherId];
    }
    onRowsChange(updated);
  };

  const handleSearchChange = (rowIndex, value) => {
    setSearchMap((s) => ({ ...s, [rowIndex]: value }));
  };

  const getTeachersForRow = (row) => {
    if (!row.teacherIds || row.teacherIds.length === 0) return [];
    return teacherData.filter((t) => row.teacherIds.includes(t.id));
  };

  const getSubjectName = (id) => {
    const s = subjectData.find((x) => x.id === id);
    return s ? s.subject : "";
  };

  const INLINE_BADGE_LIMIT = 4;

  return (
    <div ref={containerRef}>
      <div className="prmsionTable text-center">
        <table className="table table-bordered align-middle table-hover">
          <thead className="table-light">
            <tr>
              <th style={{ width: "30%" }}>Subject</th>
              <th style={{ width: "30%" }}>Class</th>
              <th style={{ width: "40%" }}>Teacher</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((row, rowIndex) => {
              const filteredTeachersBySubject = teacherData.filter(
                (t) => !row.subjectId || t.subjectId === row.subjectId
              );

              const searchTerm = (searchMap[rowIndex] || "").toLowerCase();
              const filteredTeachers = filteredTeachersBySubject.filter((t) =>
                t.name.toLowerCase().includes(searchTerm)
              );

              const allSelected =
                filteredTeachers.length > 0 &&
                filteredTeachers.every((t) => row.teacherIds?.includes(t.id));

              const selectedTeachers = getTeachersForRow(row);
              const subjectName = getSubjectName(row.subjectId);

              const remaining = selectedTeachers.length > INLINE_BADGE_LIMIT
                ? selectedTeachers.slice(INLINE_BADGE_LIMIT)
                : [];

              const remainingNamesTooltip = remaining.map((t) => `${t.name} (${getSubjectName(t.subjectId)})`).join(", ");

              return (
                <React.Fragment key={rowIndex}>
                  <tr>
                    {/* Subject Dropdown */}
                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.subjectId}
                        onChange={(e) =>{ 
                          handleChange(rowIndex, "subjectId", e.target.value);                          
                        }}
                      >
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>
                    {/* Class Dropdown */}
                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.classId}
                        onChange={(e) => handleChange(rowIndex, "classId", e.target.value)}
                      >
                        <option value="">Select Class</option>
                        {(rowData?.[row.subjectId] || []).map((cls) => (
                        <option key={cls} value={cls.classId}>
                          {cls.classId}
                        </option>
                      ))}
                      </select>
                    </td>


                    <td>
                      {!row.subjectId ? (
                        <div className="text-muted">Select subject first</div>
                      ) : (
                        <div className="position-relative">
                          <div
                            className="text-start mx-auto border rounded bg-white d-flex align-items-center justify-content-between"
                            style={{ padding: "5px", cursor: "pointer" }}
                            onClick={() => setOpenDropdown(rowIndex === openDropdown ? null : rowIndex)}
                          >
                            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", maxWidth: "70%" }}>
                              {/* show up to INLINE_BADGE_LIMIT badges */}
                              {selectedTeachers.length === 0 ? (
                                <span className="text-muted">Select teacher</span>
                              ) : (
                                <>
                                  {selectedTeachers.slice(0, INLINE_BADGE_LIMIT).map((t) => (
                                    <span
                                      key={t.id}
                                      className="badge rounded-pill bg-light text-dark"
                                      style={{
                                        padding: "6px 8px",
                                        display: "inline-flex",
                                        alignItems: "center",
                                        gap: 6,
                                        maxWidth: 240,
                                      }}
                                      title={`${t.name} — ${getSubjectName(t.subjectId)}`}
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: 160 }}>
                                        {t.name} — <small className="text-muted">{getSubjectName(t.subjectId)}</small>
                                      </span>
                                      <button
                                        type="button"
                                        className="btn btn-sm p-0"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleTeacherToggle(rowIndex, t.id);
                                        }}
                                        aria-label={`Remove ${t.name}`}
                                        style={{ lineHeight: 1 }}
                                      >
                                        <MdClose />
                                      </button>
                                    </span>
                                  ))}

                                  {/* +N more badge */}
                                  {selectedTeachers.length > INLINE_BADGE_LIMIT && (
                                    <span
                                      className="badge rounded-pill bg-secondary text-white"
                                      style={{ padding: "6px 8px", cursor: "pointer" }}
                                      title={remainingNamesTooltip || `${selectedTeachers.length - INLINE_BADGE_LIMIT} more`}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setModalRowIndex(rowIndex);
                                      }}
                                    >
                                      +{selectedTeachers.length - INLINE_BADGE_LIMIT} more
                                    </span>
                                  )}
                                </>
                              )}
                            </div>

                            <div style={{ minWidth: 160, display: "flex", gap: 6, justifyContent: "flex-end" }}>
                              <div className="small text-muted align-self-center me-2">
                                {selectedTeachers.length ? `${selectedTeachers.length}` : 0}
                              </div>

                              <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary p-1"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setOpenDropdown(rowIndex);
                                }}
                              >
                                Edit
                              </button>
                            </div>
                          </div>

                          {/* show inline validation message if present */}
                          {errors[rowIndex] && (
                            <div className="text-start mt-1 small text-danger">{errors[rowIndex]}</div>
                          )}

                          {/* Dropdown card styled like Bootstrap dropdown menu */}
                          <div
                            className={`dropdown-menu p-2 ${openDropdown === rowIndex ? "show" : ""}`}
                            style={{ maxHeight: "260px", overflowY: "auto", width: "360px" }}
                          >
                            {/* Search box
                            <div className="mb-2">
                              <input
                                className="form-control form-control-sm"
                                placeholder="Search teachers..."
                                value={searchMap[rowIndex] || ""}
                                onChange={(e) => handleSearchChange(rowIndex, e.target.value)}
                                onClick={(e) => e.stopPropagation()}
                              />
                            </div>
 */}
                            {filteredTeachers.length === 0 ? (
                              <div className="text-muted small">No teachers found.</div>
                            ) : (
                              filteredTeachers.map((t) => (
                                <div className="form-check" key={t.id}>
                                  <input
                                    className="form-check-input"
                                    type="checkbox"
                                    id={`teacher-${rowIndex}-${t.id}`}
                                    checked={row.teacherIds?.includes(t.id) || false}
                                    onChange={(e) => {
                                      e.stopPropagation();
                                      handleTeacherToggle(rowIndex, t.id);
                                    }}
                                  />
                                  <label className="form-check-label" htmlFor={`teacher-${rowIndex}-${t.id}`}>
                                    {t.name} — <small className="text-muted">{getSubjectName(t.subjectId)}</small>
                                  </label>
                                </div>
                              ))
                            )}

                            <div className="d-flex justify-content-between mt-2">
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={() => setOpenDropdown(null)}
                              >
                                Done
                              </button>
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => handleChange(rowIndex, "teacherIds", [])}
                              >
                                Clear
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </td>
                  </tr>
                </React.Fragment>
              );
            })}
          </tbody>

          <tfoot>
            <tr>
              <td colSpan={3} className="text-center bg-light">
                <span
                  className="me-4 text-danger fs-5"
                  onClick={removeRow}
                  style={{ cursor: "pointer" }}
                >
                  <MdRemoveCircleOutline />
                </span>
                <span
                  className="text-success fs-5"
                  onClick={addRow}
                  style={{ cursor: "pointer" }}
                >
                  <MdAddCircleOutline />
                </span>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

export default UserApproval;
