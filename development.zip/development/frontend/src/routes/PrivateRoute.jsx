import { Navigate, Outlet, useLocation } from 'react-router-dom'
import useAuth from '../context/AuthContext'
import Loader from '../components/Loader'
import Forbidden from '../components/Page403'

const PrivateRoute = ({ allowedRoles }) => {
  const { isAuth, loading, user } = useAuth();
  const location = useLocation();

  if (loading) return <Loader />;

  if (!isAuth) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (
    allowedRoles &&
    allowedRoles.length > 0 &&
    !allowedRoles.includes(user?.role)
  ) {
    return <Navigate to="/404" replace />;
  }

  return <Outlet />;
};

export default PrivateRoute;