/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { School } from '../entities/school.entity';
import { Questions } from '../entities/questions.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { DataSource } from 'typeorm';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { Subject } from '../entities/subject.entity';
import { Gallery } from '../entities/gallery.entity';
import { CanvasImage } from 'src/entities/canvasimage.entity';
// import { ExamWithQuestionsDto } from 'src/dto/exam.questions.dto';

@Injectable()
export class SchoolService {
  constructor(
    @InjectRepository(School)
    private schoolRepository: Repository<School>,
    @InjectRepository(Questions)
    private questionRepository: Repository<Questions>,
    @InjectRepository(Gallery)
    private galleryRepository: Repository<Gallery>,
    @InjectRepository(CanvasImage)
    private canvasRepository: Repository<CanvasImage>,
    private dataSource: DataSource
  ) {}
  findById(id: number): Promise<School | null> {
    return this.schoolRepository.findOne({ where: { id } });
  }

  async getQuestion(data: Questions): Promise<Questions[]> {
    const question = await this.questionRepository.find({
      where: { subject: data.subject, class: data.class, createdBy: 'bank' },
    });
    if (!question) {
      throw new NotFoundException('Question not found');
    }
    return question;
  }

  async getQuestionPaper(formData: any): Promise<any[]> {
    const query = this.dataSource
      .createQueryBuilder()
      .select([
        'qp.id AS id',
        'qp.subject AS subject',
        'qp.class AS class',
        'eq.paperId AS paperId',
        'COUNT(eq.questionId) AS totalQuestion',
      ])
      .from(QuestionPaper, 'qp')
      .innerJoin(ExamQuestion, 'eq', 'qp.id = eq.paperId')
      .where('qp.subject = :subject', { subject: formData.subject })
      .andWhere('qp.class = :class', { class: formData.class });

    if (formData.data) {
      query.andWhere('qp.createdFrom = :createdFrom', {
        createdFrom: formData.data,
      });
    }
    query.groupBy('eq.paperId');
    return await query.getRawMany();
  }

  async setAnsKeyManual(data: any, tenantId: string): Promise<any> {
    return this.dataSource.transaction(async (manager) => {
      const paperData = data.questionpaper;
      const questionPaper = manager.create(QuestionPaper, {
        name: paperData.examName,
        class: paperData.className,
        subject: paperData.subject,
        maxMarks: paperData.marks,
        createdFrom: 'manual',
        examDate: paperData.examDate,
        tenantid: tenantId,
      });
      const savedPaper = await manager.save(questionPaper);
      savedPaper.examCode = `EX${savedPaper.id}-${savedPaper.class}-${savedPaper.subject}`;
      await manager.save(savedPaper);
      const questions = data.questions.map((q) =>
        manager.create(Questions, {
          tId: q.tId,
          subject: q.subject,
          class: q.class,
          subDomain: q.subdomain,
          quesType: q.quesType,
          correctAns: q.correctAns,
          createdBy: 'manual',
          tenantid: tenantId,
        })
      );
      const savedQuestions = await manager.save(questions);
      const examQuestions = savedQuestions.map((question, i) =>
        manager.create(ExamQuestion, {
          paperId: savedPaper.id,
          questionId: question.id,
          sequence: i + 1,
          marks: data.questions[i].marks,
          sectionNo: data.questions[i].sectionNo,
          paperFrom: 'manual',
        })
      );
      await manager.save(examQuestions);
      return { message: 'Saved all data with transaction' };
    });
  }
  
  async saveQuestion(q: any): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }

        const trackerRepo = manager.getRepository(QuestionIdTracker);
        const questionRepo = manager.getRepository(Questions);
        const subjectRepo = manager.getRepository(Subject);

        const getsubject = await subjectRepo.findOne({
          where: { id: q.subject },
        });

        if (!getsubject) {
          throw new NotFoundException('Subject not found');
        }
        let shortsubject = getsubject.subject.substring(0, 2).toUpperCase();
        if (getsubject.subject === 'Social Science') {
          shortsubject = 'SS';
        }

        const cgtext = q.cgtext;
        const competencytext = q.competencytext;

        const year = new Date().getFullYear();
        const subject = q.subject;
        const className = q.std;
        const tenantId = q.tenantid;

        let tracker = await trackerRepo.findOne({
          where: {
            tenantId,
            subject,
            class: className,
            year,
            cg: q.cg,
            competency: q.competency,
          },
        });

        if (!tracker) {
          tracker = trackerRepo.create({
            tenantId,
            subject,
            class: className,
            cg: q.cg,
            competency: q.competency,
            year,
            currentCounter: 1,
          });
        } else {
          tracker.currentCounter += 1;
        }

        const paddedCounter = String(tracker.currentCounter).padStart(4, '0');
        const customId = `${year} ${shortsubject} G${className} ${cgtext} ${competencytext} #${paddedCounter}`;

        await trackerRepo.save(tracker);

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          subject,
          class: className,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          opt1: q.opt1,
          opt2: q.opt2,
          opt3: q.opt3,
          opt4: q.opt4,
          opt1img: q.opt1img,
          opt2img: q.opt2img,
          opt3img: q.opt3img,
          opt4img: q.opt4img,
          image: q.image,
          chapter: q.chapter,
          tenantid: tenantId,
          createdBy: 'bank',
          customId,
          // file paths could go here
        };
        // const newQuestion = questionRepo.create(Qdata);
        return await questionRepo.upsert(Qdata, ['id']);
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async getQuestionByUser(approverId: number): Promise<Questions[]> {
    const question = (await this.questionRepository.query(
      `SELECT * FROM questions WHERE FIND_IN_SET(?, approverId) > 0`,
      [approverId]
    )) as Questions[];
    if (!question || question.length === 0) {
      throw new NotFoundException('Question not found');
    }
    return question;
  }

  async getGallery(): Promise<Gallery[]> {
    const gallery = await this.galleryRepository.find();
    if (!gallery) {
      throw new NotFoundException('Question not found');
    }
    return gallery;
  }

  async createGallery(
    files: Express.Multer.File[],
    galleryData: any
  ): Promise<any> {
    const fileDetails = files?.length
      ? files.map((file) => ({
          fileName: file.filename,
          filePath: `/${galleryData.folderName}/${file.filename}`,
        }))
      : [];

    const gallery = this.galleryRepository.create({
      ...galleryData,
      imageURL: fileDetails[0]?.filePath || undefined,
    });

    return await this.galleryRepository.save(gallery);
  }

  async createCanvasImage(data: Partial<CanvasImage>): Promise<any> {
    console.log('canvasdataser', data);
    console.log('Type of rawImage:', typeof data.rawImage);
    const canvasImage = this.canvasRepository.create(data);
    const create = await this.canvasRepository.save(canvasImage);
    console.log('canvasImage', create.id);
    if (!create) {
      throw new NotFoundException('Canvas image creation failed');
    } else {
      return create;
    }
  }

  async getQuestionById(id: number): Promise<Questions> {
    const question = await this.questionRepository.findOne({
      where: { id },
    });
    if (!question) {
      throw new NotFoundException('Canvas image not found');
    }
    return question;
  }
}
