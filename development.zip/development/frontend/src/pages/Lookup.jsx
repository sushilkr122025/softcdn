import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import SchoolServices from '../api/SchoolServices';
import { useNavigate } from 'react-router-dom';

const LookupPage = () => {
  const { schoolurl } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(true);
  const navigate = useNavigate();

   useEffect(() => {
    const lookupCompany = async () => {      
      try {
        const res = await SchoolServices.getLookup(schoolurl);       
        if(res){
          navigate('/login');
        //   const csrf = await SchoolServices.loadCsrfToken();
        //   if(csrf){
        //     localStorage.setItem('T-ACTION', 'STARTED');  
        //       setError(false);
        //       navigate('/login');
        //   }else{
        //     localStorage.removeItem('T-ACTION');
        //     setError(true);           
        //   }
        // }else{
        //   localStorage.removeItem('T-ACTION');
        //   setError(true);
        }
      } catch (err) {
        // localStorage.removeItem('T-ACTION');
        setError(true);
      } finally {
        setLoading(false);
      }
    };
    if (schoolurl) {
      lookupCompany();
    } else {
      // localStorage.removeItem('T-ACTION');
      setLoading(false);
      setError(false);
    }
  }, [schoolurl]);

  if (loading) return <p>Loading....</p>;
  return (
    <div className="container mt-4">
      {error ? (
        <div className="alert alert-danger">
          <h4>{error}</h4>
          <p><strong>Invalid URL: </strong> {schoolurl}</p>
        </div>
      ) : (        
          <div className="alert alert-success">            
            <h4>URL is missing.... {schoolurl}</h4>
            <p>You have not use any url, please add and try again</p>
          </div>
      )}
    </div>
  );
};

export default LookupPage;
