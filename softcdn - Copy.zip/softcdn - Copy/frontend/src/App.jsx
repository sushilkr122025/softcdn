import React, { Suspense } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './App.css'
import PrivateRoute from './routes/PrivateRoute'
import routes from './routes/routes'
// import AuthProvider from './context/AuthProvider'
// import LicenseProvider from './context/LicenseProvider'
// import CompanyProvider from './context/CompanyContext'
import Loader from './components/Loader'
import SectionReport from './pages/report/SectionReport'

const DefaultLayout = React.lazy(() => import('./components/layout/DefaultLayout'))

const Login = React.lazy(() => import('./components/Login'))
const Logout = React.lazy(() => import('./components/Logout'))
const Page404 = React.lazy(() => import('./components/Page404'))
const Page500 = React.lazy(() => import('./components/Page500'))
const ForgotPassword = React.lazy(() => import('./components/ForgotPassword'))
const Dashboard = React.lazy(() => import('./pages/Dashboard'))
const SchoolRegistration = React.lazy(() => import('./pages/schoolRegistration'))
// const TenantEntry = React.lazy(() => import('./components/TenantEntry'))
// const TenantLogin = React.lazy(() => import('./components/TenantLogin'))

const LookupPage = React.lazy(() => import('./pages/Lookup'))
const CompanyLayout = React.lazy(() => import('./components/layout/CompanyLayout'))
const AuthLayout = React.lazy(() => import('./components/layout/AuthLayout'))
const LicenseLayout = React.lazy(() => import('./components/layout/LicenseLayout'))

function App() {
  return (
    // <CompanyProvider>
    //   <AuthProvider>
    //     <LicenseProvider>
          <BrowserRouter>
            <Suspense fallback={<Loader />}>
              <Routes>
                <Route path="/" element={<LookupPage />} />
                <Route path="/:schoolurl" element={<LookupPage />} />   
                <Route element={<CompanyLayout />}>
                  <Route path="/login" name="Login Page" element={<Login />} />
                  <Route element={<AuthLayout />}>
                    <Route element={<LicenseLayout />}>
                      <Route element={<PrivateRoute />}>
                        <Route path="/schoolRegistration" element={<SchoolRegistration />} />
                        <Route path="/sectionreport" element={<SectionReport />} />
                        <Route element={<DefaultLayout />}>
                          <Route path="/dashboard" element={<Dashboard />} />
                          <Route index path="#" element={<Navigate to="/dashboard" replace />} />
                          {routes.map((route, idx) => {
                            return (
                              route.element && (
                                <Route
                                  key={idx}
                                  path={route.path}
                                  name={route.name}
                                  element={<route.element />}
                                />
                              )
                            )
                          })}
                          {/* Fallback */}
                          {/* <Route path="*" element={<Navigate to="/404" />} /> */}
                        </Route>
                      </Route>
                    </Route>
                  </Route>
                </Route>
                
                <Route path="/logout" name="Logout Page" element={<Logout />} />
                <Route path="/404" name="Page Not Found" element={<Page404 />} />
                {/* <Route path="/:schoolID" element={<TenantEntry />} />
                <Route path="/tenantLogin" element={<TenantLogin />} /> */}
              </Routes>
            </Suspense>
          </BrowserRouter>
    //     </LicenseProvider>
    //   </AuthProvider> 
    // </CompanyProvider>
  )
}

export default App
