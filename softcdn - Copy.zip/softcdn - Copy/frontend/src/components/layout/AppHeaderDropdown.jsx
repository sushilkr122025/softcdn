import React from 'react'
// import axios from 'axios'
// import { useNavigate } from 'react-router-dom'
// import config from '../../config'
import avatar10 from '../../assets/images/avatars/undraw_profile.png'


const AppHeaderDropdown = () => {
  // const [message, setMessage] = useState('');
  // const navigate = useNavigate();

  
    // const handleLogout = () => {
    //   axios.get(config.apihost + '/logout').then((res) => {
    //     if (res.data.Status === 'Success') {
    //       sessionStorage.clear()
    //       document.cookie = 'role=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/'
    //   document.cookie = 'access=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/'
    //       navigate('/login')
    //       // setMessage('Logout successfully')
    //     } else {
    //       // setMessage('Login Failed')
    //     }
    //   })
    // }
  return (
    <div className="dropdown">
    <div  type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
      <img src={avatar10} alt="Avatar" className="rounded-circle" width="30" height="30" />
    </div>
    <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
      <li>
        <a className="dropdown-item" href="/dashboard">
          <i className="me-2"><img src={avatar10} alt="Avatar" className="rounded-circle" width="20" height="20" /></i>
          Profile
        </a>
      </li>
      <li>
      {/* <div className="dropdown-item" onClick={handleLogout}>Log out</div> */}
      </li>
    </ul>
  </div>

  
  )
}

export default AppHeaderDropdown
