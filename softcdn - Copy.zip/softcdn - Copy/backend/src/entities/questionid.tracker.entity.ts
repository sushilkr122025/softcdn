import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  Index,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
@Entity({ name: 'questionidtracker' })
@Index(['tenantId', 'year', 'subject', 'class', 'cg', 'competency'], {
  unique: true,
})
export class QuestionIdTracker {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: '50' })
  tenantId: string;

  @Column()
  year: number;

  @Column({ length: '10' })
  cg: string;

  @Column({ length: '10' })
  competency: string;

  @Column({ length: '10' })
  subject: string;

  @Column({ length: '10' })
  class: string;

  @Column({ default: 1 })
  currentCounter: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
