import React, { useState, useEffect } from "react";
import { FaPlus } from "react-icons/fa";
import blankDataImage from "../../assets/images/blank-1.png";
import GlobalFilters from "../../components/GlobalFilters";
import QuestionPaperBlock from "../../components/question/QuestionPaperBlock";
import usePermission from "../../hooks/usePermission";
// import apiClient from "../../api/apiService";
import Forbidden from "../../components/Page403";
import QuestionServices from '../../api/QuestionServices';

const QuestionPaper = () => {
  const { canRead, canWrite, readScope, writeScope } = usePermission("BANK");

  const [permissionData, setPermissionData] = useState([]);
  const [filters, setFilters] = useState({ std: "", subject: "" });
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  // Inject permission scope

  useEffect(() => {
    if (canWrite) {
      setPermissionData(writeScope);
    } else if (canRead) {
      setPermissionData(readScope);
    } else {
      setPermissionData([]);
    }
  }, [canRead, canWrite, readScope, writeScope]);

  // API call logic lives here
  useEffect(() => {
    if (!canRead) return;
    if (!filters.std || !filters.subject) return;

    const fetchData = async () => {
      try {
        setLoading(true);

        const response = await QuestionServices.questionFromBank({
          subject: filters.subject,
          class: filters.std,
          table: "questionpaper",
          page: "questionPaper",
        });

        setData(response);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [filters.std, filters.subject, canRead]);

  // Handle filter changes (ONLY responsibility = receive)
  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  if (!canRead) {
    return <Forbidden />;
  }

  return (
    <div className="p-lg-2">
      <div className="container-fluid p-lg-4 py-2">
        <div className="row justify-content-center">
          <div className="col-12 col-xxl-12 d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-3 pb-2">
            <div className="col-8">
              <h4 className="mb-0 fw-bold pagetitle">Question Paper</h4>
              <p className="question-paper-subtitle">
                Select a subject and class to view available papers
              </p>

            </div>
            <div className="col-4">
              <GlobalFilters
                onFiltersChange={handleFiltersChange}
                selectedValues={filters}
                show={["subject", "class"]}
                permissions={permissionData}
              />
            </div>
          </div>
          <section className="paper-block mt-4">
            <div className="row">
              {loading && (
                <div className="col-12 col-sm-6 mb-3">Loading...</div>
              )}

              {!loading && data.length === 0 && (
                <section className="d-flex flex-column justify-content-center text-center mt-5">
                  <div className="row mx-0 justify-content-center">
                    <div className="col-8 col-sm-7 col-md-5 col-lg-3 pt-4">
                      <img
                        src={blankDataImage}
                        alt="Question Bank"
                        className="img-fluid mb-4"
                      />
                    </div>
                  </div>
                  <h4 className="text-center text-muted">No Question Paper Available</h4>
                  <div className="mx-auto mt-3">
                    {canWrite && (
                      <a href="/QuestionPaper/MakePaper-A">
                        <button className="btn btn-primary h45">
                          <FaPlus /> Create Exam
                        </button>
                      </a>
                    )}
                  </div>
                </section>
              )}

              {!loading &&
                data.length !== 0 &&
                data.map((e, i) => (
                  <div className="col-12 col-sm-6 mb-3">
                    <QuestionPaperBlock key={i} info={e} />
                  </div>
                ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default QuestionPaper;
