import React, { useState } from "react";
import useAuth from '../context/AuthContext'
import { PiBellLight } from "react-icons/pi";

export default function NotificationBell() {
  const { notifications, markAsRead } = useAuth();
  const [open, setOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)}  className="relative px-4 bg-white border-0 text-grey-400" title='Notification'>
        <PiBellLight style={{fontSize: "25px"}} />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 bg-red-500 text-white text-xs px-1 rounded-full">
            {unreadCount}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-64 bg-white shadow rounded">
          {notifications.length === 0 ? (
            <p className="p-4 text-gray-500">No notifications</p>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className={`p-3 border-b cursor-pointer ${n.read ? "bg-gray-100" : "bg-white"}`}
                onClick={() => markAsRead(n.id)}
              >
                {n.message}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
