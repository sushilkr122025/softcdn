import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('roles')
export class Roles {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50' })
  rolename: string;

  @Column({ type: 'varchar', length: '20' })
  createdBy: string;

  @Column({ type: 'varchar', length: '5', default: 'I' })
  dmlType: string;
}
