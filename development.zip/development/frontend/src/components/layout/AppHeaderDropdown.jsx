import React from 'react'
import avatar10 from '../../assets/images/avatars/undraw_profile.png'


const AppHeaderDropdown = () => {
  return (
    <div className="dropdown">
    <div  type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
      <img src={avatar10} alt="Avatar" className="rounded-circle" width="30" height="30" />
    </div>
    <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
      <li>
        <a className="dropdown-item" href="/dashboard">
          <i className="me-2"><img src={avatar10} alt="Avatar" className="rounded-circle" width="20" height="20" /></i>
          Profile
        </a>
      </li>
      <li>      
      </li>
    </ul>
  </div>

  
  )
}

export default AppHeaderDropdown
