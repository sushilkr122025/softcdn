import { useEffect, useState, useRef } from 'react';
import { MdFormatListBulleted, MdFormatListNumbered  } from "react-icons/md";
import './Question.css';
import { Modal } from 'react-bootstrap';
import queServices from '../../api/QuestionServices';
import useAuth from '../../context/AuthContext';
import MultiServices from '../../api/MultiServices';
import { useNavigate, useParams } from 'react-router-dom';
import JoditEditor from 'jodit-react';
import 'jodit/es2021/jodit.min.css';
import ShowMessage from '../../components/ShowMessage'
import { useMemo } from 'react';
import usePermission from '../../hooks/usePermission';
import Forbidden from '../../components/Page403';
import config from '../../config/config';
import { set } from 'jodit/esm/core/helpers';

const greekLetters = {
  π: "π", α: "α", β: "β", γ: "γ", ε: "ε", θ: "θ", λ: "λ", μ: "μ",
  σ: "σ", φ: "φ", ω: "ω",
  ϵ: "ϵ", η: "η", ψ: "ψ",
  hr1: "<hr>",
  Σ: "Σ", Φ: "Φ", Ω: "Ω", Υ: "Υ", Ψ: "Ψ",
};

const relations = {
  "=": "=", "≠": "≠", "<": "<", ">": ">", "≤": "≤", "≥": "≥", "≪": "≪",
  "≫": "≫", "≡": "≡", "≃": "≃", "∼": "∼", "≅": "≅", "≈": "≈",
  hr1: "<hr>",
  "⊂": "⊂", "⊃": "⊃", "⊆": "⊆", "⊇": "⊇", "∈": "∈", "∉": "∉", "∋": "∋",
};

const operators = {
  "×": "×", "÷": "÷", "·": "·", "±": "±", "*": "*",
  hr1: "<hr>",
  "∘ ": "∘", "⊕": "⊕", "⊗": "⊗",
  hr2: "<hr>",
  "∧": "∧", "∨": "∨", "∩": "∩", "∪": "∪",
  hr3: "<hr>",
  "ℕ": "ℕ", "ℝ": "ℝ", "ℚ": "ℚ", "ℤ": "ℤ", "∞": "∞",
  hr4: "<hr>",
  "∂": "∂", "∇": "∇", "△": "△",
}

const arrows = {
  "←": "←", "→": "→", "↔": "↔", "⇐": "⇐", "⇒": "⇒", "⇔": "⇔", "↑": "↑",
  "↓": "↓", "↕": "↕", "⇑": "⇑", "⇓": "⇓", "⇕": "⇕",
};

const functions = [
  { name: 'cuberoot', preview: '<span class="root"> <span class="rad-exponent">&#8203;n</span><span class="radical">√</span><span class="radicand">&#8203;n</span></span>' },
  { name: 'fraction', preview: '<span class="frac" style="font-size: 0.8em" contenteditable="true"><span class="fracnum">​a</span><span class="fracden">​b</span></span>' },
  { name: 'summation', preview: '<span class="summation" style="font-size: 1em"><span class="sum-upper">&#8203;n</span><span class="sum-symbol" contenteditable="true">∑</span><span class="sum-lower">&#8203;i=1</span></span>' },
  { name: 'integral', preview: '<span class="integration" style="font-size: 0.7em"><span class="int-symbol">∫</span><span class="int-lower">&#8203;a</span><span class="int-upper">&#8203;b</span></span>' },
  // { name: 'subscript', preview: 'xₐ' },
  // { name: 'superscript', preview: 'xᵇ' },
  // { name: 'subsup', preview: 'xᵇₐ' },
  { name: 'intersection', preview: '<span class="intersection" style="font-size: 1em"><span class="intersection-upper">&#8203;b</span><span class="intersection-symbol">∩</span><span class="intersection-lower">&#8203;a</span></span>' },
  { name: 'union', preview: '<span class="union" style="font-size: 1em"><span class="union-upper">&#8203;b</span><span class="union-symbol">∪</span><span class="union-lower">&#8203;a</span></span>' },
  { name: 'product', preview: '<span class="product" style="font-size: 0.8em"><span class="product-upper">&#8203;b</span><span class="product-symbol">∏</span><span class="product-lower">&#8203;a</span></span>' },
  { name: 'contour', preview: '<span class="contour-integral" style="font-size: 0.8em"><span class="contour-upper">b</span><span class="contour-symbol">∮</span><span class="contour-lower">a</span></span>' },
  { name: 'limit', preview: '<span class="limit" style="font-size: 0.8em"><span class="limit-symbol">lim</span><span class="limit-lower">&#8203;x → 0</span></span>' },
  { name: 'xbar', preview: 'x̄' },
  { name: 'xhat', preview: 'x̂' },
];

// A helper function to create popup content to avoid repetition
const createPopup = (jodit, data, insertFunc, close, isGrid = false) => {
  const container = jodit.create.div(isGrid ? 'symbol-grid' : 'symbol-list');

  Object.entries(data).forEach(([key, value]) => {
    // Handle horizontal rulers in data
    if (key.startsWith('hr')) {
      container.insertAdjacentHTML('beforeend', value);
      return;
    }

    const btn = jodit.create.element('button', { className: 'dd-item' });
    btn.innerHTML = isGrid ? `<span class="prev">${value.preview}</span>` : value;

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      // For functions, the key is the name; for symbols, it's the symbol itself
      const insertValue = isGrid ? value.name : key;
      insertFunc(jodit, insertValue);
      // close();
    });
    container.appendChild(btn);
  });
  return container;
};

function QuestionMarkScheme({ placeholder }) {
  const editor = useRef(null);
  const [content, setContent] = useState("");

  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [showLink, setShowLink] = useState(false);
  const [linkTxt, setLinkTxt] = useState(false);
  const [addTarget, setAddTarget] = useState(false);
  const qTypeConvert = { multipleChoice: 'Multiple Choice', trueFalse: 'True/False', oneWord: 'One Word', CR: 'Written Response', fillups: 'Fill in the Blanks', match: 'Match the Following' };

  const joeditor = useRef(null);
  const editorInstance = useRef(null);
  const savedSelection = useRef(null);  
  const { qid } = useParams();  
  const [questionData, setQuestionData] = useState({});
  const [isContext, setISContext] = useState();
  const [qContext, setQContext] = useState(false);
  const [contextId, setContextId] = useState(false);
  const [topicName, setTopicName] = useState(false);
  const [contextstatus, setContextstatus] = useState(false); 
  const [expectedFormat, setExpectedFormat] = useState(); 
  const handleRef = (wrapper) => {
    joeditor.current = wrapper;

    const waitForEditor = () => {
      const instance = wrapper?.editor;
      if (instance) {
        editorInstance.current = instance;
      } else {
        setTimeout(waitForEditor, 100);
      }
    };

    waitForEditor();
  };

  const joditconfig = useMemo(() => ({
    iframe: false, 
    readonly: false, // all options from 
    toolbarSticky: false,
    toolbarAdaptive: false,
    height: 350,
    placeholder: placeholder || "Start typing...",      

    extraButtons: [
      {
        name: "greek",
        icon: "<span>αβγ</span>",
        popup: (j, c, s, close) => createPopup(j, greekLetters, insertText, close)
      },
      {
        name: "relations",
        icon: "<span>= ≠ ≤</span>",
        popup: (j, c, s, close) => createPopup(j, relations, insertText, close)
      },
      {
        name: "operators",
        icon: "<span>Ops</span>",
        popup: (j, c, s, close) => createPopup(j, operators, insertText, close)
      },
      {
        name: "arrows",
        icon: "<span>→</span>",
        popup: (j, c, s, close) => createPopup(j, arrows, insertText, close)
      },
      {
        name: "functions",
        icon: "<span>ƒ(x)</span>",
        popup: (jodit, current, self, close) => {
          const container = jodit.create.div("symbol-grid");
          functions.forEach((func) => {
            const btn = jodit.create.element("button", { className: "dd-item" });
            btn.innerHTML = `<span class="prev">${func.preview}</span>`;
            btn.addEventListener("click", (e) => {
              e.preventDefault();
              insertEquation(jodit, func.name);
              close();
            });
            container.appendChild(btn);
          });
          return container;
        },
      },
    ],

    buttons: [
      'bold',
      'italic',
      'underline',
      'strikethrough',
      'subscript',
      'superscript',
      '|',
      'ul',
      'ol',
      '|',
      'outdent',
      'indent',
      'table',
      '|',
      'font',
      'fontsize',
      'brush',
      'paragraph',
      '|',
      'align',
      '|',
      'customImageUpload',
      '|',
      'undo',
      'redo',
      '|',
      'hr',
      'eraser',
      'copyformat',
      // '|', 'fullsize', 'preview'
    ],
    askBeforePasteFromWord: true,
    processPasteFromWord: true,
    defaultActionOnPaste: 'insert_clear_html',
    cleanHTML: {
      cleanOnPaste: true,
      removeEmptyElements: false,
      fillEmptyParagraph: false,
      removeEmptyTextNodes: false,
    },
    controls: {
      customImageUpload: {
        name: 'Insert Image',
        icon: 'image',
        exec: () => {
          setShow(true);          
        },
      },
    },
  }), [placeholder]);

  const navigator = useNavigate(); 

  const [filter, setFilter] = useState({
    std: '',
    subject: '',
    subDomain: '',
    cg: '',
    competency: '',
    difficulty: '',
    quesType: '',
    cgtext: '',
    competencytext: '',
  });
  const { quesType, cgtext, competencytext } = filter;
  const marksNumber = Array.from({ length: 25 }, (_, i) => i * 0.5);
  // const marksNumber = [0, Array.from({ length: 10 }, (_, i) => i + 0.5)];
  const levelRoman = ['NA','0','I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  const [frows, setFrows] = useState([
    { 
      level: '',
      descriptiors: '',
      guidelines: '',
      marks: '',     
    },
  ]);
  // Add row
   const addRow = () => {
    setFrows([...frows, { level: "", descriptiors: "",guidelines:"", marks: "" }]);
  };
  
  // Remove row
  const removeRow = (index) => {
    const updated = frows.filter((_, i) => i !== index);
    setFrows(updated);
  };

  // Handle input change
  // const handleChange = (index, field, value) => {
  //   const updated = [...frows];
  //   updated[index][field] = value;
  //   setFrows(updated);
  // };
 const handleChange = (index, field, value) => {
  setFrows((prev) => {
    const updated = [...prev];
    updated[index] = { ...updated[index], [field]: value };
    return updated;
  });

  setErrors((prev) => {
    if (!Array.isArray(prev)) return prev;

    const next = [...prev];

    if (!next[index]) return next;

    next[index] = { ...next[index] };
    delete next[index][field];

    return next;
  });
};

  const option = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }];  

  const [optionImages, setOptionImages] = useState({});
  const [activeOption, setActiveOption] = useState(null);

  const [show, setShow] = useState(false);
  const [preview, setPreview] = useState(false);
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState({});
  const alphabet = [{optA:'A', optB:'B', optC:'C', optD:'D'}];
  const [permissionData, setPermissionData] = useState();
  const [shortUrl, setShortUrl] = useState();

  const { canWrite, writeScope } = usePermission('QUESTION');

  useEffect(() => {
    if (canWrite) {
      setPermissionData(writeScope);
    }   

  }, [canWrite, writeScope]);



  useEffect(() => {
    // async function fetchImages() {
    //   const response = await MultiServices.getImages();
    //   setImages(response);
    // }
    // fetchImages();
    const isNumericId = /^\d+$/.test(qid);
    if (isNumericId == true && typeof (qid) != 'undefined') {
      fetchQuestion();
    }


    // joeditor 
    const editorInstance = joeditor.current?.editor;
    if (!editorInstance) return;
    const bindPasteHandler = () => {
      const container = editorInstance?.container;

      if (!container) return;

      const handlePaste = (event) => {
        const clipboardData = event.clipboardData || window.clipboardData;
        const html = clipboardData.getData("text/html");
        const text = clipboardData.getData("text/plain");

        event.preventDefault();

        if (html) {
          editorInstance.selection.insertHTML(html);
        } else {
          editorInstance.selection.insertHTML(text.replace(/\n/g, "<br>"));
        }
      };

      container.addEventListener("paste", handlePaste);

      // Cleanup
      return () => container.removeEventListener("paste", handlePaste);
    };

    const jodit = editorInstance;
    const root = jodit && jodit.editor;
    if (!root) return;

    // Classes whose element nodes must be preserved until empty
    const protectedClasses = [
      "radicand", "fracnum", "fracden", "sum-upper", "sum-lower",
      "int-lower", "int-upper", "int-content", "subsup-sub", "subsup-sup",
      "subsup-both-sub", "subsup-both-sup", "intersection-upper", "intersection-lower",
      "union-upper", "union-lower", "product-upper", "product-lower",
      "limit-lower", "rad-exponent"
    ];

    // ZWSP detection and "empty with <br>" handling
    const ZWSP_REGEX = /\u200B/g;


    const isEffectivelyEmpty = (el) => {
      if (!el) return true;
      // If the element only contains a single <br> or is empty text, treat as empty
      const onlyBr =
        el.childNodes.length === 1 &&
        el.firstChild &&
        el.firstChild.nodeType === Node.ELEMENT_NODE &&
        el.firstChild.nodeName === "BR";

      const txt = (el.textContent || "").replace(ZWSP_REGEX, "").trim();
      return onlyBr || txt.length === 0;
    };

    const getRangeSafe = () => {
      const domSel = document.getSelection && document.getSelection();
      return (
        (jodit && jodit.selection && jodit.selection.range) ||
        (domSel && domSel.rangeCount ? domSel.getRangeAt(0) : null)
      );
    };

    const findNearestProtected = (start) => {
      let el = start;
      while (el && el !== root) {
        if (el.classList) {
          for (const cls of protectedClasses) {
            if (el.classList.contains(cls)) return el;
          }
        }
        el = el.parentElement;
      }
      return null;
    };

    // Allow normal text deletion; only block removal of a protected element if it is empty
    const keydownHandler = (ev) => {
      if (ev.key !== "Backspace" && ev.key !== "Delete") return;

      const rng = getRangeSafe();
      if (!rng) return;

      let node = rng.startContainer || null;
      if (!node) return;

      let startEl =
        node.nodeType === Node.TEXT_NODE
          ? (node.parentElement || null)
          : (node instanceof Element ? node : null);

      const protectedEl = findNearestProtected(startEl);
      if (!protectedEl) return;

      // If inner text is NOT empty, allow deletion of characters
      if (!isEffectivelyEmpty(protectedEl)) {
        return; // do nothing: let the key event proceed
      }

      // Inner text is empty: prevent deleting the element node itself
      // But still keep caret behavior pleasant: ensure a ZWSP is present for caret
      ev.preventDefault();
      ev.stopPropagation();


      // Maintain a ZWSP so caret can stay inside the empty protected element
      if ((protectedEl.textContent || "").replace(ZWSP_REGEX, "").length === 0) {
        if (protectedEl.innerHTML === "" || protectedEl.innerHTML === "<br>") {
          protectedEl.innerHTML = "\u200B";
        }
      }
    };

    // Keep empty protected leaves caret-friendly
    const ensurePlaceholders = () => {
      protectedClasses.forEach((cls) => {
        root.querySelectorAll(`.${cls}`).forEach((el) => {
          const txt = (el.textContent || "").replace(ZWSP_REGEX, "");
          if (txt.length === 0) {
            // Replace stray <br> with ZWSP to avoid browser auto-removal/merge
            if (el.innerHTML === "" || el.innerHTML === "<br>") {
              el.innerHTML = "\u200B";
            }
          }
        });
      });
    };

    root.addEventListener("keydown", keydownHandler, true); // capture early to beat default deletion
    root.addEventListener("input", ensurePlaceholders);
    root.addEventListener("keyup", ensurePlaceholders);

    // Also guard programmatic delete route if present
    const offFns = [];
    const evApi = jodit && jodit.events;
    if (evApi && evApi.on) {
      const offBeforeCommand = evApi.on("beforeCommand", (command) => {
        if (command !== "delete") return;
        const rng = getRangeSafe();
        if (!rng) return;
        let node = rng.startContainer || null;
        if (!node) return;
        let el =
          node.nodeType === Node.TEXT_NODE
            ? (node.parentElement || null)
            : (node instanceof Element ? node : null);
        const protectedEl = findNearestProtected(el);
        if (protectedEl && isEffectivelyEmpty(protectedEl)) {
          return false; // cancel delete command when protected element is empty
        }
      });
      if (typeof offBeforeCommand === "function") offFns.push(() => offBeforeCommand());
    }

    // Wait until Jodit's DOM is ready
    const timeout = setTimeout(() => {
      bindPasteHandler();
    }, 100); // or use requestAnimationFrame

    // Initial pass to normalize placeholders
    ensurePlaceholders();
    updateHighlight();

    return () => {
      root.removeEventListener("keydown", keydownHandler, true);
      root.removeEventListener("input", ensurePlaceholders);
      root.removeEventListener("keyup", ensurePlaceholders);
      offFns.forEach((fn) => {
        try { fn(); } catch { }
      });
    };
  }, []);

  const insertImage = (url) => {
    const editor = editorInstance.current;
    console.log(editor?.selection?.restore, savedSelection.current)
    if (editor?.selection?.restore && savedSelection.current) {
      editor.selection.restore(savedSelection.current);
      editor.selection.insertHTML(`<img src="${url}" style="max-width: 100%;" />`);
      console.log("Image inserted");
      savedSelection.current = null;
    } else {
      alert("Editor not ready or selection missing");
    }
    setShow(false);
  };

  const fetchContext = async (qid) => {
    const response = await queServices.getContextByShortUuid({ params: { id: qid } });
    if (response.status == 200) {      
      const data = response.data;
      setFilter({
        std: data.class,
        subject: data.subject,
      });
      const type = data.contextstatus == 'CONTEXT' ? true : data.contextstatus == 'NONCONTEXT' ? false : false;
      setShortUrl(data.shortuuid)
      setISContext(type);
      setContextstatus(data.contextstatus);
      setTopicName(data.topicName);
      setQContext(data.context);
      setContextId(data.id);
    }
    if (response.status == 404 || response.status == 500) {
      setMsgType('modal');
      setMsgVariant('danger')
      setRedirect('/question')
      setBtnConfirm(true)
      setMessage(response.message)
      setShowMsg(true);
    }
  };

  const fetchQuestion = async () => {
    try {
      const response = await queServices.getQuestionById({ params: { id: qid } });      
      if (response && !["multipleChoice", "trueFalse", "oneWord"].includes(response.quesType) && response.status == 'MSCMREQUIRE') {      
      const data = response;      
          setQuestionData(data);          
          fetchContext(data.contextid);        
      }
      else{
        setMsgType('modal');
        setMsgVariant('danger')
        setRedirect('/question')
        setTextConfirm('Exit')
        setBtnConfirm(true)
        setMessage("Marking scheme not required for this question")
        setShowMsg(true);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const isEmptyHtml = (html) => {
    if (!html) return true;
    const text = html.replace(/<[^>]*>/g, "").trim();
    return text.length === 0;
  };

  const sanitizeHtml = (html) => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  const allowedTags = ["UL", "OL", "LI", "#text"];

  const cleanNode = (node) => {
    // keep text
    if (node.nodeType === Node.TEXT_NODE) {
      return document.createTextNode(node.textContent);
    }

    // remove disallowed elements
    if (!allowedTags.includes(node.nodeName)) {
      const fragment = document.createDocumentFragment();
      node.childNodes.forEach((child) => {
        fragment.appendChild(cleanNode(child));
      });
      return fragment;
    }

    // allowed elements
    const el = document.createElement(node.nodeName.toLowerCase());
    node.childNodes.forEach((child) => {
      el.appendChild(cleanNode(child));
    });
    return el;
  };

  const fragment = document.createDocumentFragment();
  doc.body.childNodes.forEach((node) => {
    fragment.appendChild(cleanNode(node));
  });

  const div = document.createElement("div");
  div.appendChild(fragment);
  return div.innerHTML;
};


  const onSubmitHandler = async (e) => {
    e.preventDefault();

    const payload = {
      qid: qid,  
      revision: questionData.revision,
      trailId: questionData.trailId,
      expectedFormat: expectedFormat,
      markScheme: frows,
    };

    const validateForm = (formData) => {
    const errors = [];

    formData.markScheme.forEach((row, index) => {
      const err = {};

      if (!row.level) {
        err.level = "Level is required";
      }

      if (!row.descriptiors || isEmptyHtml(row.descriptiors)) {
        err.descriptiors = "Descriptors are required";
      }

      if (row.marks === "" || row.marks === null) {
        err.marks = "Marks are required";
      }

      errors[index] = err; // always assign index
    });

    return errors;
  };


    const validationErrors = validateForm(payload);

    const hasErrors = validationErrors.some(
      (err) => err && Object.keys(err).length > 0
    );
    console.log('hasErrors',hasErrors);
    
    if (hasErrors) {
      setErrors(validationErrors);
      return;
    }    

    const response = await queServices.createMarkScheme(payload);
    console.log('Mark scheme', response);
    if (response.status == 201 || response.status == 200) {
      setMsgType('modal');      
      if(questionData.contextstatus == 'CONTEXT' && questionData.revision == '1'){
        setRedirect('/questionGeneration/'+shortUrl)
        setAddTarget('/question')
        setMessage("Marking scheme added Successfully")
        setTextConfirm('Add More Question') 
        setLinkTxt('Exit')
        setBtnClose(false)
        setBtnConfirm(true)
        setShowLink(true)
      }else{
        setRedirect('/question')
        setMessage("Marking scheme added Successfully")
        setTextConfirm('Exit')
        setBtnClose(false)
        setBtnConfirm(true)
      }
      setShowMsg(true);      
    }

    if (response.status == 500) {
      setTextConfirm('Exit')
      setRedirect('/question')
      setBtnClose(false)
      setBtnConfirm(true)
      setMessage(response.message)
      setShowMsg(true);
    }
  };

  // Highlighting logic remains the same
  const updateHighlight = () => {
    if (!editor.current) return;
    const editorRoot = editor.current.editor;
    editorRoot.querySelectorAll(".formula-highlight").forEach(el => el.classList.remove("formula-highlight"));
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    let node = sel.anchorNode;
    if (!node) return;
    let current = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    while (current && current !== editorRoot) {
      if (isFormulaElement(current)) {
        current.classList.add("formula-highlight");
        return;
      }
      current = current.parentElement;
    }
  };

  const isFormulaElement = (el) => {
    if (el.nodeType !== Node.ELEMENT_NODE) return false;
    const formulaClasses = ["root", "radicand", "rad-exponent", "exponent", "frac", "fracnum", "fracden", "summation", "sum-upper", "sum-lower", "sum-symbol", "integration", "int-lower", "int-upper", "int-symbol", "int-content", "paren", "paren-left", "paren-right", "paren-content", "subsup", "subsup-sub", "subsup-sup", "subsup-both", "subsup-both-sub", "subsup-both-sup", "xbar", "xhat", "intersection", "union", "product", "limit"];
    return formulaClasses.some(cls => el.classList.contains(cls));
  };

  const insertText = (jodit, text) => {
    if (!jodit) return;
    jodit.selection.insertHTML(text);
  };

  const insertEquation = (jodit, val) => {
    if (!jodit) return;
    let eqHTML = "";
    // Switch cases are identical to your original code
    switch (val) {
      case "cuberoot":
        eqHTML = `
    &#8203;
      <span class="root">
        <span class="rad-exponent">&#8203;n</span>
        <span class="radical">√</span>
        <span class="radicand">&#8203;n</span>
      </span>
    &#8203;`;
        break;

      case "fraction":
        eqHTML = `
    &#8203;
      <span class="frac" contenteditable="true">
        <span class="fracnum">&#8203;a</span>
        <span class="fracden">&#8203;b</span>
      </span>
      &#8203;`;
        break;

      case "summation":
        eqHTML = `
    &#8203;
      <span class="summation">
        <span class="sum-upper">&#8203;n</span>
        <span class="sum-symbol" contenteditable="true">∑</span>
        <span class="sum-lower">&#8203;i=1</span>
      </span>
      &#8203;`;
        break;

      case "integral":
        eqHTML = `
    &#8203;
      <span class="integration">
        <span class="int-symbol">∫</span>
        <span class="int-lower">&#8203;a</span>
        <span class="int-upper">&#8203;b</span>
        <span class="int-content">&#8203;f(x)dx</span>
      </span>
      &#8203;`;
        break;

      case "xbar":
        eqHTML = `&#8203;<span class="xbar">x</span>&#8203;`;
        break;

      case "xhat":
        eqHTML = `&#8203;<span class="xhat">x</span>&#8203;`;
        break;

      case "intersection":
        eqHTML = `
    &#8203;
      <span class="intersection">
        <span class="intersection-upper">&#8203;b</span>
        <span class="intersection-symbol">∩</span>
        <span class="intersection-lower">&#8203;a</span>
      </span>
      &#8203;`;
        break;

      case "union":
        eqHTML = `
    &#8203;
      <span class="union">
        <span class="union-upper">&#8203;b</span>
        <span class="union-symbol">∪</span>
        <span class="union-lower">&#8203;a</span>
      </span>
      &#8203;`;
        break;

      case "product":
        eqHTML = `
    &#8203;
      <span class="product">
        <span class="product-upper">&#8203;b</span>
        <span class="product-symbol">∏</span>
        <span class="product-lower">&#8203;a</span>
      </span>
      &#8203;`;
        break;

      case "contour":
        eqHTML = `
    &#8203;
      <span class="contour-integral">
        <span class="contour-upper">b</span>
        <span class="contour-symbol">∮</span>
        <span class="contour-lower">a</span>
      </span>
      <span class="contour-body"> f(x)dx</span>
      &#8203;`;
        break;

      case "limit":
        eqHTML = `
    &#8203; 
      <span class="limit">
        <span class="limit-symbol">lim</span>
        <span class="limit-lower">&#8203;x → 0</span>
      </span>
      &#8203; `;
        break;

      default:
        return;
    }

    jodit.selection.insertHTML(eqHTML + "&nbsp;");
  };

  const exec = (command) => {
    document.execCommand(command, false, null);
  };

  if (!canWrite) {
    return <Forbidden />;
  }

  return (
    <>
      <div className="p-lg-4">
        <div className="container-fluid" id="question-section">
          <div className="row h-85vh">
             { questionData &&
              <>
            <div className="col-12 mx-auto content-bg p-lg-4 py-4">              
              <div className='row'>
                <div className='col-md-12'>                  
                  <label className='h4'>Topic Name</label>
                  <h4 className='border p-1'>{topicName}</h4>
                </div>
              </div>
              {isContext && (
                <>
                  <div className="row bg-white">{isContext}
                    <div className="col-md-12"
                      dangerouslySetInnerHTML={{ __html: qContext }}
                    />
                  </div>
                </>
              )}             
              <div className="row">
                <div className="col-md-12 py-4"                 
                      dangerouslySetInnerHTML={{ __html: questionData.question }}
                    />
                    </div>
               <div className="row">
                        <div className="col-5">                         
                            <ol className="list-group" type="A">
                            {option.map((key, i) => {
                            const option = questionData?.[key.optns];
                            const optionimg = questionData?.[key.images];
                            if (!option && !optionimg) return null;
                            const isCorrect = key.optns === questionData.correctAns;
                            return (
                              <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                                <div className='d-flex justify-content-between align-items-center'>
                                  {option && (
                                    <div
                                      dangerouslySetInnerHTML={{ __html: option }}
                                    />
                                  )}
                                  {optionimg && <div><img src={optionimg} className='img-fluid' style={{ maxWidth: "100px" }} alt="" /></div>}
                                  {isCorrect && <div className="text-success fw-bold">✔</div>}
                                </div>
                              </li>
                            );
                          })}
                        </ol>                       
                          
                        </div>
                        <div className="col-7">
                          <table className="table table-bordered">
                            <thead>
                              <tr>
                                <th>Class</th>
                                <th>Subject</th>
                                <th>Subdomain</th>
                                <th>Question Type </th>
                               { ["multipleChoice", "trueFalse", "oneWord"].includes(questionData.quesType) && (<th>Correct Option</th>)}                                
                                <th>Difficulty</th>
                                <th>CG</th>
                                <th>Competency</th>
                                <th>Total Marks</th>
                                </tr>
                            </thead>
                            <tbody>
                              <tr>
                               <td>{questionData.class}</td>
                               <td>{questionData.subject}</td>
                               <td>{questionData.subDomain}</td>
                               <td>{qTypeConvert[questionData.quesType]}</td>
                               {
                                questionData.quesType == 'multipleChoice' && (
                                  <td> {alphabet[0][questionData.correctAns]}</td>
                                )} 

                               {["trueFalse", "oneWord"].includes(questionData.quesType) && (
                                <td> {questionData.correctAns}</td>
                                )
                              }                                                                 
                                <td>{questionData.difficulty}</td>
                                <td>{questionData.cg}</td>
                                <td>{questionData.competency}</td>
                                <td>{questionData.marks}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                     
              </div>     
              <div className="row d-none">
                <div className="col-md-12 py-4">
                  <h4 className="mb-3">Expected Answer / Format</h4>
                  {/* <JoditEditor
                    ref={editor}
                    config={joditconfig}
                    value={expectedFormat}
                    onBlur={(content) => { setContent(content); setExpectedFormat(content); }}
                    onChange={() => { }}
                    onInit={(j) => {
                      const protectedClasses = ["radicand", "fracnum", "fracden", "sum-upper", "sum-lower", "int-lower", "int-upper", "int-content", "subsup-sub", "subsup-sup", "subsup-both-sub", "subsup-both-sup", "intersection-upper", "intersection-lower", "union-upper", "union-lower", "product-upper", "product-lower", "limit-lower", "rad-exponent"];
                      const ensurePlaceholders = () => {
                        protectedClasses.forEach(cls => {
                          j.editor.querySelectorAll(`.${cls}`).forEach(el => {
                            if (el && el.textContent === "") {
                              el.innerHTML = "\u200B"; // zero-width space
                            }
                          });
                        });
                      };
                      j.events.on("keyup", ensurePlaceholders);
                      j.events.on("change", ensurePlaceholders);
                      ensurePlaceholders();
                    }}
                  /> */}
                </div>
              </div>
              
              <div className="row">
                <div className="col-md-12 p-4 border mt-4 mx-auto">     
             <form className="form" onSubmit={onSubmitHandler} encType="multipart/form-data">
                    <input type="hidden" name="editId" id="editId" defaultValue={questionData?.id} /> 
      <h4 className="mb-3">Marking Scheme</h4>
      <div className="row mb-2">
        <div className="col-md-1">Level of Response</div>
        <div className="col-md-6"><strong>Sample Answer</strong></div>      
        <div className="col-md-3">Guidelines</div>      
          <div className="col-md-1">Marks</div>
      </div>
      {frows.map((row, index) => (
        <div
          key={index}
          className="row border-bottom mb-3"
        >         
          <div className="col-md-1">
            <select
              className="form-select form-select-sm"
              value={row.level}
              onChange={(e) =>
                handleChange(index, "level", e.target.value)
              }              
            >
              <option value="">Level</option>
              {levelRoman.map((num) => (
                <option key={num} value={num}>
                  {num}
                </option>
              ))}
            </select>
            {errors[index]?.level && (
              <small className="text-danger d-block mt-1">
                {errors[index].level}
              </small>
            )}
          </div>

          <div className="col-md-6 pb-3">
            <div className='border rounded-top p-1 bg-light d-flex'>
        <button type="button" onClick={() => exec("insertUnorderedList")} className='btn btn-secondary btn-sm me-2'>
          <MdFormatListBulleted />
        </button>
        <button type="button" onClick={() => exec("insertOrderedList")} className='btn btn-secondary btn-sm'>
          <MdFormatListNumbered />
        </button>
      </div>          
            <div
            className='border rounded-bottom p-2'
              contentEditable
              suppressContentEditableWarning
              onInput={(e) => handleChange(index, "descriptiors", e.currentTarget.innerHTML)}
              dangerouslySetInnerHTML={{ __html: frows.descriptiors }}
              onPaste={(e) => {
                e.preventDefault();
                const clipboardData = e.clipboardData;
                const html = clipboardData.getData("text/html");
                const text = clipboardData.getData("text/plain");

                const clean = html
                  ? sanitizeHtml(html)
                  : text.replace(/\n/g, "<br>");

                document.execCommand("insertHTML", false, clean);
              }}
              style={{
                minHeight: "80px",
                outline: "none",
                background: "#fff",
              }}
            />            
            {errors[index]?.descriptiors && (
              <small className="text-danger">
                {errors[index].descriptiors}
              </small>
            )}
            </div>
          <div className="col-md-3">
            <textarea type='text'
              className="form-control"
              value={row.guidelines}
              onChange={(e) =>
                handleChange(index, "guidelines", e.target.value)
              }
              style={{
                minHeight: "120px",
                outline: "none",
                background: "#fff",
                resize: "none",
              }}
            />
          </div>
          <div className="col-md-2">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <div className="d-flex gap-2">
                <div>
              <select
                className="form-select form-select-sm"
                value={row.marks}
                onChange={(e) =>
                  handleChange(index, "marks", e.target.value)
                }              
              >
                <option value="">Marks</option>
                {marksNumber.map((num) => (
                  <option key={num} value={num}>
                    {num}
                  </option>
                ))}
              </select>
              </div>              
              </div>
              {frows.length > 1 && (
              <button
                type="button"
                className="btn btn-sm btn-outline-danger"
                onClick={() => removeRow(index)}
              >x
              </button>
            )}
            </div>
            {errors[index]?.marks && (
              <small className="text-danger">
                {errors[index].marks}
              </small>
            )}
          </div>
         
          
        </div>
      ))}

      <div className="mt-3 d-flex justify-content-center">       
        <button type="submit" className="btn btn-success me-2">
          Submit
        </button>
         <button
          type="button"
          className="btn btn-primary me-2"
          onClick={addRow}
        >
          + Add Row
        </button>

      </div>
    </form>
                                                                                            
                </div>
              </div>
            </div>
              </>
           }
          </div>
          <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose}
            textConfirm={textConfirm}
            textClose={textClose}
            linkUrl={addTarget}
            linkText={linkTxt}
            // linkTarget={addTarget}
            onClose={() => setShowMsg(false)}
            onConfirm={() => {
              setShowMsg(false);
              navigator(redirect);
            }}
          />

        </div>
      </div>
    </>
  );
}
export default QuestionMarkScheme;
