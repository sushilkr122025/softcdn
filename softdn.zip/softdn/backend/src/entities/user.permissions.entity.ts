import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'userpermissions' })
export class UserPermission {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;

  @Column({ length: 20 })
  module: string;

  @Column({ type: 'json' })
  permissions: object | null;

  @Column()
  createdBy: number;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;
}
