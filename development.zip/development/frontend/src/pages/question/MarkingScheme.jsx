import { useState, useEffect } from "react";
import QuestionServices from "../../api/QuestionServices";

const MarkingScheme = ({ currentIds, generalDetails }) => {
  const [Questions, setQuestions] = useState([]);

  useEffect(() => {
    if (!currentIds || currentIds.length === 0) {
      setQuestions([]);
      return;
    }
    const getPaper = async () => {
      try {
        const additionalMap = new Map(currentIds.map((item) => [String(item.id), item]));
        const selectedQuestion = currentIds.map((e) => e.id);
        const payload = { paperId: selectedQuestion, reqType: "questions" };
        const response = await QuestionServices.GetQuestionPaper(payload);
        const merged = response.questions.map((fetched) => ({
          ...fetched,
          ...(additionalMap.get(String(fetched.id)) || {}),
        }));

        const hasSequence = merged.some((q) => q.sequence !== undefined && q.sequence !== null);
        const finalQuestions = hasSequence ? [...merged].sort((a, b) => Number(a.sequence || 0) - Number(b.sequence || 0)) : merged;
        setQuestions(finalQuestions);
      } catch (err) {
        console.error("Failed to fetch questions", err);
      }
    };
    getPaper();
  }, [currentIds]);

  const parseMarkingScheme = (value) => {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    if (typeof value === "string") {
      try {
        return JSON.parse(value);
      } catch (err) {
        console.error("Invalid markingScheme JSON:", err);
        return [];
      }
    }
    return [];
  };

  const sanitizeHtml = (html = "") =>
    String(html)
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/<\/?p[^>]*>/gi, "")
      .replace(/<br\s*\/?>/gi, "")
      .replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "")
      .replace(/&nbsp;/gi, "");

  const decodeHtml = (html = "") => {
    const txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
  };

  function RenderDescriptor({ d }) {
    if (!d || !d.type || d.type === "text") {
      return <>{sanitizeHtml(d?.descriptiors ?? "")}</>;
    }
    if (d.type === "list") {
      const items = d.items ?? [];
      return (
        <ul className="mb-0">
          {items.map((it, i) => (
            <li key={i}>{decodeHtml(it)}</li>
          ))}
        </ul>
      );
    }
    if (d.type === "html") {
      return (
        <div
          dangerouslySetInnerHTML={{
            __html: sanitizeHtml(d.html ?? ""),
          }}
        />
      );
    }
    return <pre className="mb-0">{JSON.stringify(d)}</pre>;
  }

  return (
    <div className="container-fluid">
      {generalDetails ? (
        <>
          <div className="text-center mb-3">
            <h5 className="fw-semibold fs-5">{generalDetails.name}</h5>
            <div className="fw-semibold fs-6 mb-11">
              {generalDetails.subjectName}
            </div>
            <div className="fw-semibold fs-6 mb-11">
              {generalDetails.session} {generalDetails.year}
            </div>
            <div className="fw-semibold fs-6 mb-11">
              Class - {generalDetails.class}
            </div>
            <div className="fw-semibold fs-6 mb-11">
              Marking Scheme / Hints to Solutions
            </div>
            <div className="d-flex justify-content-between mt-2 px-1 fs-6">
              <span>
                <strong>Time Durations:</strong> {generalDetails.totalTime} hrs
              </span>
              <span>
                <strong>Total Marks:</strong> {generalDetails.maxMarks}
              </span>
            </div>
          </div>
          <div className="mb-3">
            <h6 className="fw-semibold px-1 fs-5 mb-3">General Instructions:-</h6>
            <div className="row">
              <div className="col-12">
                <pre className="fw-semibold ps-3 fs-6 mb-0">
                  {generalDetails.generalInstruction}
                </pre>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="fw-semibold fs-6 mb-11">Marking Scheme / Hints to Solutions</div>
      )}
      <hr className="my-4" />
      <div className="mb-3">
        <table className="table table-bordered mb-0">
          <thead>
            <tr className="text-center">
              <th style={{ width: "6%" }}>Q.Label</th>
              <th style={{ width: "34%" }}>Question</th>
              <th style={{ width: "25%" }}>Descriptor</th>
              <th style={{ width: "6%" }}>Level</th>
              <th style={{ width: "25%" }}>Guidelines</th>
              <th style={{ width: "4%" }}>Marks dist.</th>
              <th style={{ width: "4%" }}>Marks</th>
            </tr>
          </thead>

          <tbody>
            {(() => {
              const rows = [];
              let prevSection = null;
              let sectionCounter = 0;
              let prevContextId = null;
              Questions.forEach((q) => {
                const secRaw = q.section ?? "0";
                const secNum = Number(secRaw);
                const section = Number.isFinite(secNum) ? secNum : 0;
                const sectionChanged = prevSection !== section;
                if (sectionChanged) {
                  sectionCounter = 0;
                }
                if (section !== 0 && sectionChanged) {
                  rows.push(
                    <tr key={`section-header-${section}-${q.id}`}>
                      <td colSpan="7" className="text-center bg-light text-dark"><strong>Section {section}</strong></td>
                    </tr>
                  );
                }
                sectionCounter += 1;
                const hasContext = q.context !== undefined && q.context !== null && String(q.context).trim() !== "";
                const contextChanged = hasContext && prevContextId !== q.contextId && !q.isSub;
                if (contextChanged) {
                  rows.push(
                    <tr key={`context-${q.contextId || q.id}`}>
                      <td colSpan="7" className="text-dark">
                        <span>
                          <strong> Q{q.contextLabel ? q.contextLabel : ""}:</strong>
                          &nbsp;
                        </span>
                        <span dangerouslySetInnerHTML={{ __html: sanitizeHtml(q.context), }} />
                      </td>
                    </tr>
                  );
                  prevContextId = q.contextId;
                }
                const descs = parseMarkingScheme(q.markingScheme);
                const safeDescs = descs.length > 0 ? descs : [{ level: "", descriptiors: "", guidelines: "", marks: "" }];
                const descCount = safeDescs.length;
                const qLabel = q.queslabel !== undefined && q.queslabel !== null && String(q.queslabel).trim() !== "" ? q.queslabel : sectionCounter;

                safeDescs.forEach((d, di) => {
                  rows.push(
                    <tr key={`q-${q.id}-desc-${di}`} className="align-top">
                      {di === 0 && (
                        <td rowSpan={descCount} className={`text-center align-middle ${q.isSub ? "small text-muted" : ""}`}
                        >
                          <strong>{qLabel}</strong>
                        </td>
                      )}
                      {di === 0 && (
                        <td
                          rowSpan={descCount}
                          className={q.isSub ? "align-top ps-4" : "align-top"}
                        >
                          <div
                            dangerouslySetInnerHTML={{
                              __html: sanitizeHtml(q.question),
                            }}
                          />
                          {/* Optional: show parent link (uncomment if useful)
                              {q.isSub && q.subOf && <div className="small text-muted">sub of {q.subOf}</div>} */}
                        </td>
                      )}
                      <td>
                        <RenderDescriptor d={d} />
                      </td>
                      <td className="text-center">
                        <strong>{d.level}</strong>
                      </td>
                      <td>{d.guidelines ?? ""}</td>
                      <td className="text-center">{d.marks ?? ""}</td>
                      {di === 0 && (
                        <td rowSpan={descCount} className="text-center align-top">
                          <strong>{q.marks}</strong>
                        </td>
                      )}
                    </tr>
                  );
                });

                prevSection = section;
              });

              return rows;
            })()}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MarkingScheme;