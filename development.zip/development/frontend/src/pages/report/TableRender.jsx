import { Colors } from 'chart.js';
import Color from '../gallery/Color';
const Table = ({ columns, data }) => {
  if (!data || data.length === 0) {
    return <div className="text-center p-3">No Data</div>;
  }

  // Group by section
  const grouped = data.reduce((acc, row) => {
    if (!acc[row.section]) acc[row.section] = [];
    acc[row.section].push(row);
    return acc;
  }, {});

  return (
    <div className="table-responsive">
      <table className="table table-bordered table-hover table-striped ">
        <thead className="table-light">
          <tr>
            {columns.map((col, i) => (
              <th key={i}>{col.label}</th>
            ))}
          </tr>
        </thead>

        <tbody>
          {Object.entries(grouped).map(([section, rows], i) =>
            rows.map((row, j) => (
              <tr key={`${i}-${j}`}>
                
                {/* Section with rowspan */}
                {j === 0 && (
                  <td rowSpan={rows.length} className="align-middle text-center fw-bold">
                    {section}
                  </td>
                )}

                {/* Other columns */}
                <td style={{color: Color.bgColor[j]}}>{row.bloomLevel}</td>
                <td>{row.maxMarks}</td>
                <td>{row.obtainedMarks}</td>
                <td>{row.percentage}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};
export default Table;