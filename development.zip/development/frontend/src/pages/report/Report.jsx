import { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from "chart.js";
import { Bar } from "react-chartjs-2";
import ReportServices from "../../api/ReportServices";
import KpiCard from "./KpiCard";
import Table from "./TableRender";
import Color from '../gallery/Color'
import ChartRenderer from "./ChartRenderer";

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);


const AnalyticsDashboard = () => {
 const [data, setData] = useState(null)

  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(false);

  const paperid = 101; // dynamic later
  const cls = "10";

  // =========================
  // FETCH DATA
  // =========================
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await ReportServices.getPrincipalAnalytics({
            params: {
              paperid: 10,
              class: 10,              
              // level: "overall"
            }
          }
          );
          const d= await res
          console.log(d);
          console.log(d.kpis);
          // setChartData(json);
       
      // const res = await fetch(url);
      // const data = await res.json();

      setData(d);
    } catch (err) {
      console.error(err);
    }

    setLoading(false);
  };

  

  return (
    <div className="container mt-4">
      <h2>Principal Dashboard</h2>
      {loading && <p>Loading...</p>}
      {!loading && data && (
        <>
          <div className="row mb-4">
            <KpiCard title="Average Score" value={data.kpis.avgPercentage} />            
            <KpiCard title="Top Section" value={data.kpis.topSection} />
            <KpiCard title="Total Students" value={data.kpis.totalStudents} />
            <KpiCard title="Weak Section" value={data.kpis.weakSection} />
          </div>
          <div className="row mb-4">
            <div className="col-md-6">
              <h5>Section Performance</h5>              
          <ChartRenderer type={"bar"} data={data.sectionChart}  />
            </div>
            <div className="col-md-6">
              <h5>Bloom Taxonomy</h5> 
          <ChartRenderer type={"bar"} data={data.bloomChart}/>
            </div>
          </div>



          <Table
            title="Bloom Analysis"
            columns={[ { label: "Section", field: "section" },
              { label: "Bloom", field: "bloomLevel" },
              { label: "Marks", field: "maxMarks" },
              { label: "Obtained", field: "obtainedMarks" },
              { label: "%", field: "percentage" }
            ]}
            data={data.bloomTable}
          />
        </>
      )}
    </div>
  );
}

export default AnalyticsDashboard;