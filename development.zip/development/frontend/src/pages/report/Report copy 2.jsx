import { useEffect, useState } from "react";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from "chart.js";
import { Bar } from "react-chartjs-2";
import ReportServices from "../../api/ReportServices";

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

export default function AnalyticsDashboard() {
  const [level, setLevel] = useState("overall");
  const [section, setSection] = useState(null);
  const [subject, setSubject] = useState(null);
  const [kpis, setKpis] = useState(null);

  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(false);

  const paperid = 101; // dynamic later
  const cls = "10";

  // =========================
  // FETCH DATA
  // =========================
  useEffect(() => {
    fetchData();
  }, [level, section, subject]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await ReportServices.getPrincipalAnalytics({
            params: {
              paperid: 10,
              class: 10,              
              level: "overall"
            }
          }
          );
          const data = await res
          console.log(data);
          // setChartData(json);
       
      // const res = await fetch(url);
      // const data = await res.json();

      setChartData({
        labels: data.labels,
        datasets: data.datasets
      });
      setKpis(data.kpis);
    } catch (err) {
      console.error(err);
    }

    setLoading(false);
  };

  // =========================
  // DRILL DOWN
  // =========================
  const handleClick = (event, elements) => {
    if (!elements.length) return;

    const index = elements[0].index;
    const label = chartData.labels[index];

    if (level === "overall") {
      setLevel("section");
      setSection(label);
    } else if (level === "section") {
      setLevel("subject");
      setSubject(label);
    }
  };

  // =========================
  // BACK
  // =========================
  const handleBack = () => {
    if (level === "subject") {
      setLevel("section");
      setSubject(null);
    } else if (level === "section") {
      setLevel("overall");
      setSection(null);
    }
  };

  // =========================
  // BREADCRUMB
  // =========================
  const breadcrumb = (
    <nav aria-label="breadcrumb">
      <ol className="breadcrumb mb-2">
        <li className="breadcrumb-item">Class {cls}</li>

        {section && (
          <li className="breadcrumb-item active">{section}</li>
        )}

        {subject && (
          <li className="breadcrumb-item active">{subject}</li>
        )}
      </ol>
    </nav>
  );

  // =========================
  // CHART OPTIONS
  // =========================
  const options = {
    responsive: true,
    onClick: handleClick,
    plugins: {
      legend: {
        position: "top"
      }
    }
  };

  return (
     <div className="container mt-4">

      {/* HEADER */}
      <div className="row mb-3">
        <div className="col">
          <h3 className="fw-bold">Principal Analytics Dashboard</h3>
          {breadcrumb}
        </div>
      </div>

      {/* BACK BUTTON */}
      {level !== "overall" && (
        <div className="mb-3">
          <button className="btn btn-outline-primary" onClick={handleBack}>
            ⬅ Back
          </button>
        </div>
      )}
      {level === "overall" && kpis && (
  <div className="row mb-4">

    {/* Total Students */}
    <div className="col-md-3">
      <div className="card text-center shadow-sm border-0">
        <div className="card-body">
          <h6 className="text-muted">Total Students</h6>
          <h4 className="fw-bold">{kpis.totalStudents}</h4>
        </div>
      </div>
    </div>

    {/* Avg Percentage */}
    <div className="col-md-3">
      <div className="card text-center shadow-sm border-0">
        <div className="card-body">
          <h6 className="text-muted">Class Avg %</h6>
          <h4 className="fw-bold text-primary">
            {kpis.avgPercentage}%
          </h4>
        </div>
      </div>
    </div>

    {/* Top Section */}
    <div className="col-md-3">
      <div className="card text-center shadow-sm border-0">
        <div className="card-body">
          <h6 className="text-muted">Top Section</h6>
          <h4 className="fw-bold text-success">
            {kpis.topSection}
          </h4>
        </div>
      </div>
    </div>

    {/* Weak Section */}
    <div className="col-md-3">
      <div className="card text-center shadow-sm border-0">
        <div className="card-body">
          <h6 className="text-muted">Needs Improvement</h6>
          <h4 className="fw-bold text-danger">
            {kpis.weakSection}
          </h4>
        </div>
      </div>
    </div>

  </div>
)}
      {/* CARD */}
      <div className="card shadow-sm">
        <div className="card-body">

          {/* LOADING */}
          {loading && (
            <div className="text-center p-5">
              <div className="spinner-border" role="status"></div>
              <p className="mt-2">Loading analytics...</p>
            </div>
          )}

          {/* CHART */}
          {!loading && chartData && (
            <Bar data={chartData} options={options} />
          )}

        </div>
      </div>

    </div>
  );
}