import { useEffect, useState, useRef } from 'react';
import useAuth from '../../context/AuthContext';
import './Question.css';
import queServices from '../../api/QuestionServices';
import { useNavigate } from 'react-router-dom';
import JoditEditor from 'jodit-react';
import 'jodit/es2021/jodit.min.css';
import GlobalFilters from '../../components/GlobalFilters';
import ShowMessage from '../../components/ShowMessage';

const greekLetters = {
  π: "π", α: "α", β: "β", γ: "γ", ε: "ε", θ: "θ", λ: "λ", μ: "μ", 
  σ: "σ", φ: "φ", ω: "ω",
  ϵ: "ϵ", η: "η", ψ: "ψ",
  hr1: "<hr>",
  Σ: "Σ", Φ: "Φ", Ω: "Ω", Υ: "Υ", Ψ: "Ψ",
};

const relations = {
  "=": "=", "≠": "≠", "<": "<", ">": ">", "≤": "≤", "≥": "≥", "≪": "≪",
  "≫": "≫", "≡": "≡", "≃": "≃", "∼": "∼", "≅": "≅", "≈": "≈", 
  hr1: "<hr>",
  "⊂": "⊂", "⊃": "⊃", "⊆": "⊆", "⊇": "⊇", "∈": "∈", "∉": "∉", "∋": "∋",
};

const operators = {
  "×": "×", "÷": "÷", "·": "·", "±": "±", "*": "*",
  hr1: "<hr>",
  "∘ ": "∘", "⊕": "⊕", "⊗": "⊗", 
  hr2: "<hr>",
  "∧": "∧", "∨": "∨", "∩": "∩", "∪": "∪",
  hr3: "<hr>",
  "ℕ": "ℕ", "ℝ": "ℝ",  "ℚ": "ℚ", "ℤ": "ℤ","∞": "∞",
  hr4: "<hr>",
  "∂": "∂", "∇": "∇", "△": "△", 
}

const arrows = {
  "←": "←", "→": "→", "↔": "↔", "⇐": "⇐", "⇒": "⇒", "⇔": "⇔", "↑": "↑",
  "↓": "↓", "↕": "↕", "⇑": "⇑", "⇓": "⇓", "⇕": "⇕",
};

const functions = [
    { name: 'cuberoot', preview: '<span class="root"> <span class="rad-exponent">&#8203;n</span><span class="radical">√</span><span class="radicand">&#8203;n</span></span>' },
    { name: 'fraction', preview: '<span class="frac" style="font-size: 0.8em" contenteditable="true"><span class="fracnum">​a</span><span class="fracden">​b</span></span>' },
    { name: 'summation', preview: '<span class="summation" style="font-size: 1em"><span class="sum-upper">&#8203;n</span><span class="sum-symbol" contenteditable="true">∑</span><span class="sum-lower">&#8203;i=1</span></span>' },
    { name: 'integral', preview: '<span class="integration" style="font-size: 0.7em"><span class="int-symbol">∫</span><span class="int-lower">&#8203;a</span><span class="int-upper">&#8203;b</span></span>' },
    // { name: 'subscript', preview: 'xₐ' },
    // { name: 'superscript', preview: 'xᵇ' },
    // { name: 'subsup', preview: 'xᵇₐ' },
    { name: 'intersection', preview: '<span class="intersection" style="font-size: 1em"><span class="intersection-upper">&#8203;b</span><span class="intersection-symbol">∩</span><span class="intersection-lower">&#8203;a</span></span>' },
    { name: 'union', preview: '<span class="union" style="font-size: 1em"><span class="union-upper">&#8203;b</span><span class="union-symbol">∪</span><span class="union-lower">&#8203;a</span></span>' },
    { name: 'product', preview: '<span class="product" style="font-size: 0.8em"><span class="product-upper">&#8203;b</span><span class="product-symbol">∏</span><span class="product-lower">&#8203;a</span></span>' },
    { name: 'contour', preview: '<span class="contour-integral" style="font-size: 0.8em"><span class="contour-upper">b</span><span class="contour-symbol">∮</span><span class="contour-lower">a</span></span>' },
    { name: 'limit', preview: '<span class="limit" style="font-size: 0.8em"><span class="limit-symbol">lim</span><span class="limit-lower">&#8203;x → 0</span></span>' },
    { name: 'xbar', preview: 'x̄' },
    { name: 'xhat', preview: 'x̂' },
];

// A helper function to create popup content to avoid repetition
const createPopup = (jodit, data, insertFunc, close, isGrid = false) => {
  const container = jodit.create.div(isGrid ? 'symbol-grid' : 'symbol-list');
  
  Object.entries(data).forEach(([key, value]) => {
    // Handle horizontal rulers in data
    if (key.startsWith('hr')) {
      container.insertAdjacentHTML('beforeend', value);
      return;
    }
    
    const btn = jodit.create.element('button', { className: 'dd-item' });
    btn.innerHTML = isGrid ? `<span class="prev">${value.preview}</span>` : value;

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      // For functions, the key is the name; for symbols, it's the symbol itself
      const insertValue = isGrid ? value.name : key;
      insertFunc(jodit, insertValue);
      close();
    });
    container.appendChild(btn);
  });
  return container;
};

function QuestionType() {
  const { user } = useAuth(); 
  const joeditor = useRef(null);
  const [errors, setErrors] = useState({});
  const [question, setQuestion] = useState('');
  const [topicName, setTopicName] = useState('');
  const [selectedOption, setSelectedOption] = useState('');
  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const editor = useRef(null);
   
  const joditconfig = {
    readonly: false, 
    toolbarSticky: false,
    toolbarAdaptive: false,
    height: 350,
    extraButtons: [
        {
          name: "greek",
          icon: "<span>αβγ</span>",
          popup: (j, c, s, close) => createPopup(j, greekLetters, insertText, close)
        },
        {
          name: "relations",
          icon: "<span>= ≠ ≤</span>",
          popup: (j, c, s, close) => createPopup(j, relations, insertText, close)
        },
        {
          name: "operators",
          icon: "<span>Ops</span>",
          popup: (j, c, s, close) => createPopup(j, operators, insertText, close)
        },
        {
          name: "arrows",
          icon: "<span>→</span>",
          popup: (j, c, s, close) => createPopup(j, arrows, insertText, close)
        },
        {
          name: "functions",
          icon: "<span>ƒ(x)</span>",
          popup: (jodit, current, self, close) => {
            const container = jodit.create.div("symbol-grid");
            functions.forEach((func) => {
              const btn = jodit.create.element("button", { className: "dd-item" });
              btn.innerHTML = `<span class="prev">${func.preview}</span>`;
              btn.addEventListener("click", (e) => {
                e.preventDefault();
                insertEquation(jodit, func.name);
                close();
              });
              container.appendChild(btn);
            });
            return container;
          },
        },
      ],
    buttons: [
      'bold',
      'italic',
      'underline',
      'strikethrough',
      '|',
      'ul',
      'ol',
      '|',
      'outdent',
      'indent',
      'table',
      '|',
      'font',
      'fontsize',
      'brush',
      'paragraph',
      '|',
      'align',            
      '|',
      'undo',
      'redo',
      '|',
      'hr',
      'eraser',
      'copyformat',
      '|',
      // 'customImageUpload',
      // '|', 'fullsize', 'preview'
    ],
    askBeforePasteFromWord: false,
    processPasteFromWord: true,
    defaultActionOnPaste: 'insert_clear_html',
    cleanHTML: {
      cleanOnPaste: true,
      removeEmptyElements: false,
      fillEmptyParagraph: false,
    },
    // controls: {
    //   customImageUpload: {
    //     name: 'Insert Image',
    //     icon: 'image',
    //     exec: () => {
    //      // setShow(true);          
    //     },
    //   },
    // },
  };
useEffect(() => {    
    // joeditor 
    const editorInstance = joeditor.current?.editor;
    if (!editorInstance) return;
    const bindPasteHandler = () => {
      const container = editorInstance?.container;

      if (!container) return;

      const handlePaste = (event) => {
        const clipboardData = event.clipboardData || window.clipboardData;
        const html = clipboardData.getData("text/html");
        const text = clipboardData.getData("text/plain");

        event.preventDefault();

        if (html) {
          editorInstance.selection.insertHTML(html);
        } else {
          editorInstance.selection.insertHTML(text.replace(/\n/g, "<br>"));
        }
      };

      container.addEventListener("paste", handlePaste);

      // Cleanup
      return () => container.removeEventListener("paste", handlePaste);
    };

    const jodit = editorInstance;
    const root = jodit && jodit.editor;
    if (!root) return;

    // Classes whose element nodes must be preserved until empty
    const protectedClasses = [
      "radicand","fracnum","fracden","sum-upper","sum-lower",
      "int-lower","int-upper","int-content","subsup-sub","subsup-sup",
      "subsup-both-sub","subsup-both-sup","intersection-upper","intersection-lower",
      "union-upper","union-lower","product-upper","product-lower",
      "limit-lower","rad-exponent"
    ];

    // ZWSP detection and "empty with <br>" handling
    const ZWSP_REGEX = /\u200B/g;

    
    const isEffectivelyEmpty = (el) => {
      if (!el) return true;
      // If the element only contains a single <br> or is empty text, treat as empty
      const onlyBr =
        el.childNodes.length === 1 &&
        el.firstChild &&
        el.firstChild.nodeType === Node.ELEMENT_NODE &&
        el.firstChild.nodeName === "BR";

      const txt = (el.textContent || "").replace(ZWSP_REGEX, "").trim();
      return onlyBr || txt.length === 0;
    };

    const getRangeSafe = () => {
      const domSel = document.getSelection && document.getSelection();
      return (
        (jodit && jodit.selection && jodit.selection.range) ||
        (domSel && domSel.rangeCount ? domSel.getRangeAt(0) : null)
      );
    };

    const findNearestProtected = (start) => {
      let el = start;
      while (el && el !== root) {
        if (el.classList) {
          for (const cls of protectedClasses) {
            if (el.classList.contains(cls)) return el;
          }
        }
        el = el.parentElement;
      }
      return null;
    };

    // Allow normal text deletion; only block removal of a protected element if it is empty
    const keydownHandler = (ev) => {
      if (ev.key !== "Backspace" && ev.key !== "Delete") return;

      const rng = getRangeSafe();
      if (!rng) return;

      let node = rng.startContainer || null;
      if (!node) return;

      let startEl =
        node.nodeType === Node.TEXT_NODE
          ? (node.parentElement || null)
          : (node instanceof Element ? node : null);

      const protectedEl = findNearestProtected(startEl);
      if (!protectedEl) return;

      // If inner text is NOT empty, allow deletion of characters
      if (!isEffectivelyEmpty(protectedEl)) {
        return; // do nothing: let the key event proceed
      }

      // Inner text is empty: prevent deleting the element node itself
      // But still keep caret behavior pleasant: ensure a ZWSP is present for caret
      ev.preventDefault();
      ev.stopPropagation();
      

      // Maintain a ZWSP so caret can stay inside the empty protected element
      if ((protectedEl.textContent || "").replace(ZWSP_REGEX, "").length === 0) {
        if (protectedEl.innerHTML === "" || protectedEl.innerHTML === "<br>") {
          protectedEl.innerHTML = "\u200B";
        }
      }
    };

    // Keep empty protected leaves caret-friendly
    const ensurePlaceholders = () => {
      protectedClasses.forEach((cls) => {
        root.querySelectorAll(`.${cls}`).forEach((el) => {
          const txt = (el.textContent || "").replace(ZWSP_REGEX, "");
          if (txt.length === 0) {
            // Replace stray <br> with ZWSP to avoid browser auto-removal/merge
            if (el.innerHTML === "" || el.innerHTML === "<br>") {
              el.innerHTML = "\u200B";
            }
          }
        });
      });
    };

    root.addEventListener("keydown", keydownHandler, true); // capture early to beat default deletion
    root.addEventListener("input", ensurePlaceholders);
    root.addEventListener("keyup", ensurePlaceholders);

    // Also guard programmatic delete route if present
    const offFns = [];
    const evApi = jodit && jodit.events;
    if (evApi && evApi.on) {
      const offBeforeCommand = evApi.on("beforeCommand", (command) => {
        if (command !== "delete") return;
        const rng = getRangeSafe();
        if (!rng) return;
        let node = rng.startContainer || null;
        if (!node) return;
        let el =
          node.nodeType === Node.TEXT_NODE
            ? (node.parentElement || null)
            : (node instanceof Element ? node : null);
        const protectedEl = findNearestProtected(el);
        if (protectedEl && isEffectivelyEmpty(protectedEl)) {
          return false; // cancel delete command when protected element is empty
        }
      });
      if (typeof offBeforeCommand === "function") offFns.push(() => offBeforeCommand());
    }

    // Wait until Jodit's DOM is ready
    const timeout = setTimeout(() => {
      bindPasteHandler();
    }, 100); // or use requestAnimationFrame

    // Initial pass to normalize placeholders
    ensurePlaceholders();
    updateHighlight();


    return () => { 
      root.removeEventListener("keydown", keydownHandler, true);
      root.removeEventListener("input", ensurePlaceholders);
      root.removeEventListener("keyup", ensurePlaceholders);
      offFns.forEach((fn) => {
        try { fn(); } catch {}
      });
    };
  }, []);
  const navigator = useNavigate();  
  
  const [filter, setFilter] = useState({
    std: '',
    subject: '',    
  });


  const onSubmitHandler = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    const payload = {
      ...Object.fromEntries(formData),      
      subject: filter.subject,
      class: filter.std,
      tId: user.id,
      context: question,
      topicName: topicName,
      contextstatus: selectedOption
    };

   console.log(payload);

    const validateForm = (formData) => {
    
      const errors = {};

      if (!formData.subject) {
        errors.subject = 'Subject is required';
      }
      if (!formData.class) {
        errors.class = 'Class is required';
      }
      
      // Add more validation rules for other fields
      return errors;
    };

    const validationErrors = validateForm(payload);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      console.log(validationErrors);
      return;
    }
    console.log(payload);    

      const response = await queServices.createContext({ params: payload }); 
      if (response.status == 201 || response.status == 200) { 
       navigator('/questionGeneration/'+ response.data);
      }
    if (response.status == 500) {            
        setMessage('response.message')
        setShowMsg(true);  
        setMsgType('modal');
        setMsgVariant('danger')
        setRedirect('/question')
        setTextClose('Add More')
        setTextConfirm('Complete')    
      }
  };

const handleFiltersChange = (newFilters) => {
  setFilter((prev) => {
    const merged = {
      ...prev,
      ...newFilters,      
    };
    return JSON.stringify(prev) === JSON.stringify(merged) ? prev : merged;
  });
};
const handleChange = (e) => {
    setSelectedOption(e.target.value);
  };
// Highlighting logic remains the same
  const updateHighlight = () => {
    if (!editor.current) return;
    const editorRoot = editor.current.editor;
    editorRoot.querySelectorAll(".formula-highlight").forEach(el => el.classList.remove("formula-highlight"));
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    let node = sel.anchorNode;
    if (!node) return;
    let current = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    while (current && current !== editorRoot) {
      if (isFormulaElement(current)) {
        current.classList.add("formula-highlight");
        return;
      }
      current = current.parentElement;
    }
  };

  const isFormulaElement = (el) => {
    if (el.nodeType !== Node.ELEMENT_NODE) return false;
    const formulaClasses = ["root", "radicand", "rad-exponent", "exponent", "frac", "fracnum", "fracden", "summation", "sum-upper", "sum-lower", "sum-symbol", "integration", "int-lower", "int-upper", "int-symbol", "int-content", "paren", "paren-left", "paren-right", "paren-content", "subsup", "subsup-sub", "subsup-sup", "subsup-both", "subsup-both-sub", "subsup-both-sup", "xbar", "xhat", "intersection", "union", "product", "limit"];
    return formulaClasses.some(cls => el.classList.contains(cls));
  };

    const insertText = (jodit, text) => {
    if (!jodit) return;
    jodit.selection.insertHTML(text);
  };

  const insertEquation = (jodit, val) => {
    if (!jodit) return;
    let eqHTML = "";
    // Switch cases are identical to your original code
    switch (val) {
  case "cuberoot":
    eqHTML = `
    &#8203;
      <span class="root">
        <span class="rad-exponent">&#8203;n</span>
        <span class="radical">√</span>
        <span class="radicand">&#8203;n</span>
      </span>
    &#8203;`;
    break;

  case "fraction":
    eqHTML = `
    &#8203;
      <span class="frac" contenteditable="true">
        <span class="fracnum">&#8203;a</span>
        <span class="fracden">&#8203;b</span>
      </span>
      &#8203;`;
    break;

  case "summation":
    eqHTML = `
    &#8203;
      <span class="summation">
        <span class="sum-upper">&#8203;n</span>
        <span class="sum-symbol" contenteditable="true">∑</span>
        <span class="sum-lower">&#8203;i=1</span>
      </span>
      &#8203;`;
    break;

  case "integral":
    eqHTML = `
    &#8203;
      <span class="integration">
        <span class="int-symbol">∫</span>
        <span class="int-lower">&#8203;a</span>
        <span class="int-upper">&#8203;b</span>
        <span class="int-content">&#8203;f(x)dx</span>
      </span>
      &#8203;`;
    break;
    
  case "xbar":
    eqHTML = `&#8203;<span class="xbar">x</span>&#8203;`;
    break;

  case "xhat":
    eqHTML = `&#8203;<span class="xhat">x</span>&#8203;`;
    break;

  case "intersection":
    eqHTML = `
    &#8203;
      <span class="intersection">
        <span class="intersection-upper">&#8203;b</span>
        <span class="intersection-symbol">∩</span>
        <span class="intersection-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "union":
    eqHTML = `
    &#8203;
      <span class="union">
        <span class="union-upper">&#8203;b</span>
        <span class="union-symbol">∪</span>
        <span class="union-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "product":
    eqHTML = `
    &#8203;
      <span class="product">
        <span class="product-upper">&#8203;b</span>
        <span class="product-symbol">∏</span>
        <span class="product-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "contour":
    eqHTML = `
    &#8203;
      <span class="contour-integral">
        <span class="contour-upper">b</span>
        <span class="contour-symbol">∮</span>
        <span class="contour-lower">a</span>
      </span>
      <span class="contour-body"> f(x)dx</span>
      &#8203;`;
    break;

  case "limit":
    eqHTML = `
    &#8203; 
      <span class="limit">
        <span class="limit-symbol">lim</span>
        <span class="limit-lower">&#8203;x → 0</span>
      </span>
      &#8203; `;
    break;

  default:
    return;
}

    jodit.selection.insertHTML(eqHTML + "&nbsp;");
  };

  return (
    <>
      <div className="container-fluid" id="question-section">
        <div className='row'>
          <div className='col-md-12 bg-white'>
             <label className='font-weight-bold'>Select an Option</label>
      <div className="form-check-inline form-check ms-4">
        <input
          className="form-check-input"
          type="radio"
          name="contextstatus"
          id="option1"
          value="CONTEXT" 
          checked={selectedOption === 'CONTEXT'}
          onChange={handleChange}         
        />
        <label className="form-check-label" htmlFor="option1">
          Context
        </label>
      </div>
      <div className="form-check-inline form-check">
        <input
          className="form-check-input"
          type="radio"
          name="contextstatus"
          id="option2"
          value="NONECONTEXT"   
          checked={selectedOption === 'NONECONTEXT'}
          onChange={handleChange}       
        />
        <label className="form-check-label" htmlFor="option2">
          Without Context
        </label>
      </div>
            
          </div>
        </div>
        <GlobalFilters onFiltersChange={handleFiltersChange} selectedValues={filter} show={['subject', 'class']} />
        <div className='row'>
          <div className='col-md-12 bg-white'>
            <label className='h4'>Topic name</label>
            <input className='form-control form-control-sm me-3 border-dashed' type='text' value={topicName} onChange={(e)=> setTopicName(e.target.value)} />
          </div>
        </div>
        {selectedOption ==='CONTEXT' && (
        <div className="row">
          <div className="col-md-12 py-4">
            <JoditEditor
                ref={joeditor}
             value={question} config={joditconfig} onBlur={(content) => setQuestion(content)}
             onInit={(j) => {
                  // Placeholder logic remains the same
                  const protectedClasses = ["radicand", "fracnum", "fracden", "sum-upper", "sum-lower", "int-lower", "int-upper", "int-content", "subsup-sub", "subsup-sup", "subsup-both-sub", "subsup-both-sup", "intersection-upper", "intersection-lower", "union-upper", "union-lower", "product-upper", "product-lower", "limit-lower", "rad-exponent"];
                  const ensurePlaceholders = () => {
                    protectedClasses.forEach(cls => {
                      j.editor.querySelectorAll(`.${cls}`).forEach(el => {
                        if (el && el.textContent === "") {
                          el.innerHTML = "\u200B"; // zero-width space
                        }
                      });
                    });
                  };
                  j.events.on("keyup", ensurePlaceholders);
                  j.events.on("change", ensurePlaceholders);
                  ensurePlaceholders();
                }}  />
          </div>          
        </div>
         )}
          <div className="row">
            <div className="col-md-12 p-4 bg-white shadow-sm">
              <form className="form" onSubmit={onSubmitHandler} encType="multipart/form-data">                                       
                <div className="text-center mt-3">                
                  <button className="btn btn-primary" type="submit">
                    save
                  </button>
                </div>
              </form>            
            </div>
          </div>
          <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose} 
      textConfirm={textConfirm}
      textClose={textClose}
      onClose={() => setShowMsg(false)}
      onConfirm={() => {
        setShowMsg(false);
        navigator(redirect);
      }}
      />
        
      </div>      
    </>
  );
}
export default QuestionType;
