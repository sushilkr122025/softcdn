import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import './Question.css';
// import Toolbar from 'src/components/toolbar/Toolbar'
import { Modal, Button } from 'react-bootstrap';
import apiClient from '../../api/apiService';
import useAuth from '../../context/AuthContext';
import { BiImageAdd } from 'react-icons/bi';
import { FaImage } from 'react-icons/fa6';
import MultiServices from '../../api/MultiServices';
import { useNavigate } from 'react-router-dom';
import JoditEditor from 'jodit-react';
import 'jodit/es2021/jodit.min.css';
import GlobalFilters from '../../components/GlobalFilters';
import SimpleToast from '../../components/Toast';

function QuestionGeneration() {

  const [showToast, setShowToast] = useState(false);

  const apiUrl = import.meta.env.VITE_HOST;
  const [sparams] = useSearchParams();
  const joeditor = useRef(null);
  const editorInstance = useRef(null);
  const savedSelection = useRef(null);
  const [srcGallery, setSrcGallery] = useState(false);
   const handleRef = (wrapper) => {
    joeditor.current = wrapper;

    const waitForEditor = () => {
      const instance = wrapper?.editor;
      if (instance) {
        editorInstance.current = instance;
        console.log("✅ Editor initialized");
      } else {
        setTimeout(waitForEditor, 100);
      }
    };

    waitForEditor();
  };
  const joditconfig = {
    readonly: false, // all options from https://xdsoft.net/jodit/docs/
    toolbarSticky: false,
    toolbarAdaptive: false,
    height: 350,

    buttons: [
      'bold',
      'italic',
      'underline',
      'strikethrough',
      '|',
      'ul',
      'ol',
      '|',
      'outdent',
      'indent',
      'table',
      '|',
      'font',
      'fontsize',
      'brush',
      'paragraph',
      '|',
      'align',
      '|',
      'customImageUpload',
      '|',
      'undo',
      'redo',
      '|',
      'hr',
      'eraser',
      'copyformat',
      // '|', 'fullsize', 'preview'
    ],
    askBeforePasteFromWord: false,
    processPasteFromWord: true,
    defaultActionOnPaste: 'insert_clear_html',
    cleanHTML: {
      cleanOnPaste: true,
      removeEmptyElements: false,
      fillEmptyParagraph: false,
    },
    controls: {
      customImageUpload: {
        name: 'Insert Image',
        icon: 'image',
        exec: () => {
          const editor = editorInstance.current;
          if (editor?.selection?.save) {
              savedSelection.current = editor.selection.save(); // 👈 CALL it here
              console.log("✅ Selection saved outer", savedSelection.current);
            }
          setShow(true);
          setSrcGallery(true);
        },
      },
    },
  };

  const navigator = useNavigate();
  const { user } = useAuth();
  
  const [filter, setFilter] = useState({
    std: '',
    subject: '',
    subDomain: '',
    cg: '',
    competency: '',
    difficulty: '',
    quesType: '',
    cgtext: '',
    competencytext: '',
  });
  const { quesType, cgtext, competencytext } = filter;

  const [question, setQuestion] = useState('');
  const [Options, setOptions] = useState(['', '', '', '']);
  const [chapter, setChapter] = useState('');

  const [optionImages, setOptionImages] = useState({});
  const [activeOption, setActiveOption] = useState(null);

  const [show, setShow] = useState(false);
  const [preview, setPreview] = useState(false);
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState({});

  const [editData, setEditData] = useState({});
  

  // const [formData, setFormData] = useState([]);

  useEffect(() => {
    async function fetchImages() {
      const response = await MultiServices.getImages();
      setImages(response);
    }
    fetchImages();
    if (sparams.get('id')) {
      fetchQuestion();
    }

    // joeditor 
  const editorInstance = joeditor.current?.editor;
  if (!editorInstance) return;
  const bindPasteHandler = () => {
    const container = editorInstance?.container;

    if (!container) return;

    const handlePaste = (event) => {
      const clipboardData = event.clipboardData || window.clipboardData;
      const html = clipboardData.getData("text/html");
      const text = clipboardData.getData("text/plain");

      event.preventDefault();

      if (html) {
        editorInstance.selection.insertHTML(html);
      } else {
        editorInstance.selection.insertHTML(text.replace(/\n/g, "<br>"));
      }
    };

    container.addEventListener("paste", handlePaste);

    // Cleanup
    return () => container.removeEventListener("paste", handlePaste);
  };

  // Wait until Jodit's DOM is ready
  const timeout = setTimeout(() => {
    bindPasteHandler();
  }, 100); // or use requestAnimationFrame

  return () => clearTimeout(timeout);
    // joeditor 

  }, []);

  const insertImage = (url) => {
    const editor = editorInstance.current;
    console.log(editor?.selection?.restore , savedSelection.current)
    if (editor?.selection?.restore && savedSelection.current) {
      editor.selection.restore(savedSelection.current);
      editor.selection.insertHTML(`<img src="${url}" style="max-width: 100%;" />`);
      console.log("✅ Image inserted");
      savedSelection.current = null;
    } else {
      alert("Editor not ready or selection missing");
    }
    setShow(false);
  };

  const fetchQuestion = async () => {
    try {
      const response = await apiClient.get(`/school/getquestions?id=${sparams.get('id')}`);
      console.log('Fetched question:', response.data);
      const data = response.data;
      setEditData(data)
      if (response.data) {
        setFilter({
          std: data.class,
          subject: data.subject,
          cg: data.cg,
          competency: data.competency,
          difficulty: data.difficulty,
          quesType: data.quesType,
          subDomain: data.subDomain,
          cgtext: data.cgtext,
          competencytext: data.competencytext,
        });
        setQuestion(data.question);
        setChapter(data.chapter);

        setOptions([
          data.opt1 || '',
          data.opt2 || '',
          data.opt3 || '',
          data.opt4 || ''
        ]);

        setOptionImages({
          quesImg: data.image ? JSON.parse(data.image) : null,
          opt1img: data.opt1img ? JSON.parse(data.opt1img) : null,
          opt2img: data.opt2img ? JSON.parse(data.opt2img) : null,
          opt3img: data.opt3img ? JSON.parse(data.opt3img) : null,
          opt4img: data.opt4img ? JSON.parse(data.opt4img) : null,
        });

      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleClose = () => {
    setShow(false);
    setPreview(false);
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    const payload = {
      ...Object.fromEntries(formData),
      ...filter,
      tId: user.id,
      question: question,
      competencytext: competencytext,
      cgtext: cgtext,
      chapter: chapter,
      image: optionImages['quesImg'] ? JSON.stringify(optionImages['quesImg']) : '',
    };

   console.log(payload);

    const validateForm = (formData) => {
    
      const errors = {};

      if (!formData.subject) {
        errors.subject = 'Subject is required';
      }
      if (!formData.std) {
        errors.class = 'Class is required';
      }
      if (!formData.cg) {
        errors.cg = 'Curriculum Goal is required';
      }
      if (!formData.competency) {
        errors.competency = 'Competency is required';
      }
      if (!formData.difficulty) {
        errors.difficulty = 'Difficulty is required';
      }
      if (!formData.quesType) {
        errors.quesType = 'Type is required';
      }
      if (formData.questionType === 'oneWord' && formData.corrAns.trim().split(' ').length > 1) {
        errors.correctAnswer = 'Please enter only one word';
      }
      if (formData.questionType === 'oneWord' && !formData.corrAns) {
        errors.correctAnswer = 'Please enter one word';
      }
      if (formData.questionType === 'trueFalse' && !formData.corrAns) {
        errors.correctAnswer = 'Please select either true or false';
      }
      if (formData.questionType === 'multipleChoice' && !formData.corrAns) {
        errors.correctAnswer = 'Please select any one option';
      }
      // Add more validation rules for other fields
      return errors;
    };

    const validationErrors = validateForm(payload);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      console.log(validationErrors);
      return;
    }
    console.log(payload);
    
    // payload['canvas'] = localStorage.getItem('canvasState')

    try {
      const response = await apiClient.post('/school/questions', payload);
      if (response) {
        navigator('/question');
      }
    } catch (error) {
      console.error(error);
    }
  };

const handleFiltersChange = (newFilters) => {
  setFilter((prev) => {
    const merged = {
      ...prev,
      ...newFilters,
      subDomain: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.subDomain,
      cg: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.cg,
      competency: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.competency,
      difficulty: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.difficulty,
      quesType: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.quesType,
    };
    return JSON.stringify(prev) === JSON.stringify(merged) ? prev : merged;
  });
};



  return (
    <>
      <div className="container-fluid" id="question-section">
        <GlobalFilters onFiltersChange={handleFiltersChange} selectedValues={filter} show={['subject', 'class', 'subDomain', 'cg', 'competency', 'difficulty', 'quesType']} />
        <div className="row">
          <div className="col-md-12 py-4">
            <JoditEditor
                ref={handleRef}
            value={question} config={joditconfig} onBlur={(content) => setQuestion(content)} />
          </div>
          <div className="col-md-2 py-4 d-flex flex-column justify-content-between align-items-center d-none">
            <button
              className="btn w-100 h-100 p-0"
              style={{ border: '1px dashed #000' }}
              onClick={() => {
                setActiveOption(`quesImg`);
                setShow(true);
              }}
              type="button"
            >
              {!optionImages['quesImg'] && <BiImageAdd />}
              {optionImages['quesImg'] && <img src={`${apiUrl}/assets${optionImages['quesImg']['src']}`} alt={optionImages['quesImg']['label']} className="image-preview m-0 w-100 h-100" />}
            </button>
            {optionImages.quesImg && <div className="py-2">{optionImages.quesImg.label}</div>}
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 p-4 bg-white shadow-sm">
            <form className="form" onSubmit={onSubmitHandler} encType="multipart/form-data">
              <input type="hidden" name="editId" id="editId" defaultValue={editData?.id} />
              <div className="row mb-3">
                <div className="col-md-4 offset-md-4">
                  {filter.quesType === 'oneWord' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="textQuesAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <input
                            id="corrAns"
                            name="corrAns"
                            className="form-control"
                            type="text"
                            defaultValue={editData?.correctAns}
                            // onChange={(e) => setCorrectAnswer(e.target.value)}
                            placeholder="Enter the Correct Answer"
                          />
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {quesType === 'trueFalse' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="trueFalseAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select id="corrAns" name="corrAns" className="form-select" defaultValue={editData?.correctAns}>
                            <option value="">Select Correct Answer</option>
                            <option value="true">True</option>
                            <option value="false">false</option>
                          </select>
                          {errors.correctAnswer && <div className="error-message">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {quesType === 'multipleChoice' && (
                    <>
                      <div className="row">
                        {Options.map((opt, index) => {
                          const key = `opt${index + 1}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <div className="col-md-12 mb-3" key={index}>
                              <label htmlFor={key} className="form-label">
                                Option {index + 1}
                              </label>
                              <div className="d-flex">
                                <input
                                  className="form-control form-control-sm me-3"
                                  name={key}
                                  id={key}
                                  value={opt}
                                  type="text"
                                  onChange={(e) => {
                                    const newOptions = [...Options];
                                    newOptions[index] = e.target.value;
                                    setOptions(newOptions);
                                  }}
                                />
                                <input type="hidden" name={imgKey} id={imgKey} value={imgObj ? JSON.stringify(imgObj) : ''} />
                                <button
                                  className="btn"
                                  style={{ border: '1px dashed #000' }}
                                  onClick={() => {
                                    setShow(true);
                                    setActiveOption(`opt${index + 1}img`);
                                  }}
                                  type="button"
                                >
                                  <BiImageAdd />
                                </button>
                                {imgObj && (
                                  <>
                                    <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview ms-2" />
                                    <span className="ms-2">{imgObj.label}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="row pt-2">
                        <div className="col-md-12 mb-3">
                          <label className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select className="form-select form-rows" name="corrAns" id="corrAns" defaultValue={editData?.correctAns}>
                            <option value="">Select Correct Answer</option>
                            <option value="optA">Option 1</option>
                            <option value="optB">Option 2</option>
                            <option value="optC">Option 3</option>
                            <option value="optD">Option 4</option>
                          </select>
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  <div className="row mb-3">
                    <div className="col-12">
                      <label htmlFor="chapter" className="mb-2">
                        Chapter
                      </label>
                      <input type="text" name="chapter" id="chapter" className="form-control" defaultValue={chapter} onInput={(e) => setChapter(e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>
              <Modal show={show} onHide={handleClose} backdrop="static" size="xl">
                <Modal.Header closeButton>
                  <Modal.Title>Gallery</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="row">
                    {images.map((e, i) => {
                      return (
                        <div key={i} className="col-4">
                          <div
                            className="image-container"
                            onClick={() => {
                              if(srcGallery == false) {
                                setOptionImages((prev) => ({ ...prev, [activeOption]: { src: e.imageURL, label: e.name } }));
                                setShow(false);
                              }
                              if(srcGallery == true) {    
                                const editor = editorInstance.current;                                  
                                console.log("✅ Selection saved model");
                                if (editor?.selection?.save) {
                                  console.log("✅ Selection saved inner");
                                  savedSelection.current = editor.selection.save();
                                  insertImage(e.imageURL);
                                  console.log("✅ Selection saved model2");
                                }
                                setSrcGallery(false);
                              }                              
                            }}
                          >
                            <div className="d-flex justify-content-between w-100">
                              <div className="img-head px-3">
                                <div className=" d-flex align-items-center">
                                  <FaImage className="text-danger me-3" /> {e.name}
                                </div>
                              </div>
                              <div className="img-foot">
                                <div className="keyword">{e.keyword}</div>
                                <div className="keyword description" title="description">
                                  {e.description}
                                </div>
                              </div>
                            </div>
                            <div className="img">
                              <img src={`${apiUrl}/assets${e.imageURL}`} alt={e.name} className="img-fluid" />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                  <Button variant="primary">Save Changes</Button>
                </Modal.Footer>
              </Modal>

              <div className="text-center mt-3">
                <button className="btn btn-ghost me-3" type="button">
                  panel
                </button>
                <button className="btn btn-grey me-3" type="button" onClick={() => setPreview(true)}>
                  preview
                </button>
                <button className="btn btn-primary" type="submit">
                  save
                </button>
              </div>
            </form>
            <Modal show={preview} onHide={handleClose} backdrop="static" size="md">
              <Modal.Header closeButton>
                <Modal.Title>Preview Question</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <div dangerouslySetInnerHTML={{ __html: question }}></div>
                <div className="row mb-4">
                  <div className="col-8 offset-2">
                    <div className="row">
                      {quesType === 'multipleChoice' &&
                        Options.map((e, index) => {
                          const key = `opt${index + 1}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <div className="col-md-6 my-3 text-center" key={index}>
                              <span>
                                {index + 1}. &nbsp;{e}
                              </span>
                              {imgObj && <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview me-2" />}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </Modal.Body>
            </Modal>
          </div>
        </div>
      </div>
      <SimpleToast show={showToast} message="Question Created successfully !" variant="success" onClose={() => setShowToast(false)}
      />
    </>
  );
}
export default QuestionGeneration;
