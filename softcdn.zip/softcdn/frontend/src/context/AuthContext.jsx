import { createContext, useContext } from 'react'

export const Auth = createContext()

const useAuth = () => useContext(Auth)

export default useAuth


