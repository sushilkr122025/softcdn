import { useState } from 'react'
import AppFooter from './AppFooter'
import AppHeader from './AppHeader'
import { Outlet } from 'react-router-dom'
import Sidebar from './AppSidebar'
import '../../App.css'

const DefaultLayout = () => {
  const [propVisible, setPropVisible] = useState(true);
  const toggleSidebar = () => setPropVisible((v) => !v);
  return (
    <div className="maincontainer d-flex flex-column">
      <AppHeader toggleSidebar={toggleSidebar} />
      <div className='contentlayout'>
        <Sidebar propVisible={propVisible} setPropVisible={setPropVisible} />
        <div className={`rightArea w-auto d-flex flex-column ${propVisible ? "sidebar-open" : "sidebar-closed"}`}>
          <div className="flex-grow-1 d-flex flex-column">
            <Outlet />
          </div>
          <AppFooter />
        </div>
      </div>
    </div>
  );
}

export default DefaultLayout
