/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Injectable } from '@nestjs/common';
import * as cookie from 'cookie';
import { EncryptionService } from '../services/encryption.service';
import { LookupService } from '../services/lookup.service';
import { AuthService } from '../services/auth.service';
import { MessageService } from '../services/message.services';

@Injectable()
@WebSocketGateway({
  cors: { origin: true, credentials: true },
})
export class NotificationGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer() server: Server;
  private userSockets = new Map<string, string>(); // tenantId|userId -> socketId

  constructor(
    private readonly encryptionService: EncryptionService,
    private readonly lookupService: LookupService,
    private readonly authService: AuthService,
    private readonly messageService: MessageService,
  ) {}

  async handleConnection(client: Socket) {
    try {
      // Parse cookies from handshake
      console.log('New WS Connection');
      const rawCookie = client.handshake.headers.cookie || '';
      const cookies = cookie.parse(rawCookie);

      const companyToken = cookies['companyToken'];
      if (!companyToken) throw new Error('Missing company token');
      const tenantSlug = this.encryptionService.decrypt(companyToken);

      const company = await this.lookupService.findBySlug(tenantSlug);
      if (!company) throw new Error('Invalid tenant');
      const tenantId = company.school.tenantid;

      // 2. Verify auth token
      const authToken = cookies['token'];
      if (!authToken) throw new Error('Missing auth token');
      const uid: number = Number(authToken);
      const payload = await this.authService.findById(uid, tenantId);
      if (!payload) throw new Error('User not found');
      const userId = payload.id;

      // 3. Store socket
      const key = `${tenantId}|${userId}`;
      this.userSockets.set(key, client.id);

      client.data.tenantId = tenantId;
      client.data.userId = userId;

      console.log(`WS Connected: User ${userId} Tenant ${tenantId}`);
    } catch (err) {
      console.error(' WS Connection failed:', err.message);
      client.disconnect();
    }
  }

  async handleDisconnect(client: Socket) {
    for (const [key, socketId] of this.userSockets.entries()) {
      if (socketId === client.id) {
        this.userSockets.delete(key);
        console.log(`Disconnected: ${key}`);
        break;
      }
    }
  }

  //  Send notification to a specific user
  async sendToUser(tenantId: string, userId: number, message: string) {
    const key = `${tenantId}|${userId}`;
    const socketId = this.userSockets.get(key);
    if (socketId) {
      this.server.to(socketId).emit('notification', { message });
    }
  }

  //  Broadcast notification to all users in tenant
  async sendToTenant(tenantId: string, message: string) {
    for (const [key, socketId] of this.userSockets.entries()) {
      if (key.startsWith(`${tenantId}|`)) {
        this.server.to(socketId).emit('notification', { message });
      }
    }
  }

  @SubscribeMessage('send_message')
  async handleSendMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() msg: { qId: number; content: string }
  ) {
    console.log('Message from client:', msg);
    // const data = {
    //   tenantId: client.data.tenantId,
    //   userId: client.data.userId,
    //   qId: msg.qId,
    //   message: msg.message,
    // };
    // // Save message
    // const message = await this.messageService.createMessage(data);

    // Emit to all users in task room
    this.server
      .to(`${data.tenantId}|${data.qId}`)
      .emit('receive_message', message);
  }
}
