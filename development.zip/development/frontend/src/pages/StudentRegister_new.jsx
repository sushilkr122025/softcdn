import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Row, Col, Button, Form } from 'react-bootstrap'
import { formatDate } from '../utils/util'
import apiClient from '../api/apiService'
import { useNavigate } from 'react-router-dom'
// import '../App.css'

const StudentRegister = () => {
  const [sectionData, setSectionData] = useState([])
  const [classOptions, setClassOptions] = useState([])
  const [stateOptions, setStateOptions] = useState([])
  const [districtOptions, setDistrictOptions] = useState([])
  // const [state, setState] = useState('')

  const navigator = useNavigate()

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    mode: 'onChange',
  })

  const [userData] = useState()
  const parameters = new URLSearchParams(window.location.search)
  const updateId = parameters.get('id')

  const fetchUserData = async () => {
    if (updateId) {
      try {
        // Fetch data logic goes here
      } catch (error) {
        console.error(error.message)
      }
    }
  }

  useEffect(() => {
    fetchUserData()
  }, [updateId])

  useEffect(() => {
    apiClient
    .get('/store/section')
      .then((response) => {
        setSectionData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        setClassOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching classes:', error)
      })

    apiClient
      .get('/store/statesndistrict',{ params:{ stateId: '0' } })
      .then((response) => {
        setStateOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }, [])

  const handleState = (e) => {
    // setState(e.target.value)
    // console.log(e.target.value)

    apiClient
    .get('/store/statesndistrict',{ params:{ stateId: e.target.value }})
      .then((response) => {
        console.log(response.data)
        setDistrictOptions(response.data)
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }

  const onSubmit = async (data) => {
    console.log('Form Data:', data)
    try {
      if (data.id) {
        const response = apiClient.put(`/user/student/${data.id}`, data)

        if (response.status === 200) {
          navigator('/dashboard')
        } else {
          console.error('Failed to update data.')
        }
      } else {
        const response = await apiClient.post(`/user/student`, data)

        if (response.status === 200) {
          console.log('Data inserted successfully!')
          navigator('/dashboard')
        } else {
          console.error('Failed to insert data.')
        }
      }
    } catch (error) {
      console.error('An error occurred:', error)
    }
  }

  if (updateId && !userData) {
    return <div>Loading...</div>
  }

  // const Status = ['Permanent', 'Part Time', 'Internship', 'Bond based']
  // const Role = ['Admin', 'Teacher', 'co-ordinator']

  const handleselect = (e) => {
    const selectEl = e.target
    // selectEl.classList.remove('is-invalid')

    const formFloatingEl = selectEl.closest('.form-floating')
    if (selectEl && formFloatingEl) {
      formFloatingEl.querySelector('label').style.transform = 'scale(0.85) translateY(-3.1rem)'
    }
  }

  return (
    <div className="p-4">
      <div className="container-fluid">
        <div className="row h-85vh">
          <div className="col-12 mx-auto content-bg">
            <div className="row justify-content-center">
              <div className="col-12">
                <Form className="p-4" onSubmit={handleSubmit(onSubmit)}>
                  <div className="form-header mb-4 mt-3">
                    <h2>Student Registration</h2>
                  </div>
                  <Row className="form-grid">
                    <Col md={6}>
                      <Form.Group controlId="name" className="form-label">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                          type="text"
                          className={`form-control-sm ${errors.name ? 'is-invalid' : ''}`}
                          {...register('name', {
                            required: 'Name is required',
                            pattern: {
                              value: /^[A-Za-z\s]+$/,
                              message: 'Only alphabetic characters are allowed',
                            },
                          })}
                        />
                        {errors.Name && (
                          <div className="invalid-feedback d-block">{errors.name.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="RollNo" className="form-label">
                        <Form.Label>RollNo</Form.Label>
                        <Form.Control
                          type="text"
                          {...register('rollNo', { required: 'Roll Number is required' })}
                          className={`form-control-sm ${errors.rollNo ? 'is-invalid' : ''}`}
                        />
                        {errors.rollNo && (
                          <div className="invalid-feedback d-block">{errors.rollNo.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="className" className="form-label">
                        <Form.Label>Class</Form.Label>
                        <Form.Select
                          {...register('class', {
                            required: 'Class is required',
                            onChange: (e) => {
                              handleselect(e)
                            },
                          })}
                          // onChange={handleselect}
                          className={`form-select-sm ${errors.class ? 'is-invalid' : ''}`}
                        >
                          <option value="">Select Class</option>
                          {classOptions.map((e, i) => (
                            <option key={i} value={e.class}>
                              {e.class}
                            </option>
                          ))}
                        </Form.Select>
                        {errors.class && (
                          <div className="invalid-feedback d-block">{errors.class.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="section" className="form-label">
                        <Form.Label>Section</Form.Label>
                        <Form.Select
                          {...register('section', { required: 'Section is required' })}
                          // onChange={handleselect}
                          className={`form-select-sm ${errors.section ? 'is-invalid' : ''}`}
                        >
                          <option value="">Select Section</option>
                          {sectionData.map((e, i) => (
                            <option key={i} value={e.section}>
                              {e.section}
                            </option>
                          ))}
                        </Form.Select>
                        {errors.section && (
                          <div className="invalid-feedback d-block">{errors.section.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="gender" className="form-label">
                        <Form.Label>Gender</Form.Label>
                        <Form.Select
                          {...register('gender', { required: 'Gender is required' })}
                          onChange={handleselect}
                          className={`form-select-sm ${errors.Gender ? 'is-invalid' : ''}`}
                        >
                          <option value="">Select Gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="May not prefer">May Not Prefer</option>
                        </Form.Select>
                        {errors.gender && (
                          <div className="invalid-feedback d-block">{errors.gender.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="dob" className="form-label">
                        <Form.Label>Date of Birth</Form.Label>
                        <Form.Control
                          type="date"
                          {...register('dateOfBirth', { required: 'Date of Birth is required' })}
                          className={`form-control-sm ${errors.dateOfBirth ? 'is-invalid' : ''}`}
                          defaultValue={userData?.dob && formatDate(userData.dob)}
                        />
                        {errors.dateOfBirth && (
                          <div className="invalid-feedback d-block">{errors.dateOfBirth.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="EmailID" className="form-label">
                        <Form.Label>Email ID</Form.Label>
                        <Form.Control
                          type="email"
                          defaultValue={userData?.emailId}
                          {...register('emailId', { required: 'Email ID is required' })}
                          className={`form-control-sm ${errors.emailId ? 'is-invalid' : ''}`}
                        />

                        {errors.emailId && (
                          <div className="invalid-feedback d-block">{errors.emailId.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="FatherName" className="form-label">
                        <Form.Label>Father Name</Form.Label>
                        <Form.Control
                          type="text"
                          {...register('fatherName', {
                            required: 'Father Name is required',
                            pattern: {
                              value: /^[A-Za-z\s]+$/,
                              message: 'Only alphabetic characters are allowed',
                            },
                          })}
                          className={`form-control-sm ${errors.fatherName ? 'is-invalid' : ''}`}
                        />

                        {errors.fatherName && (
                          <div className="invalid-feedback d-block">{errors.fatherName.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="MotherName" className="form-label">
                        <Form.Label>MotherName</Form.Label>
                        <Form.Control
                          type="text"
                          {...register('motherName', {
                            required: 'Mother Name is required',
                            pattern: {
                              value: /^[A-Za-z\s]+$/,
                              message: 'Only alphabetic characters are allowed',
                            },
                          })}
                          className={`form-control-sm ${errors.motherName ? 'is-invalid' : ''}`}
                        />

                        {errors.motherName && (
                          <div className="invalid-feedback d-block">{errors.motherName.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="ContactNumber" className="form-label">
                        <Form.Label>Con. No.   </Form.Label>
                        <Form.Control
                          type="text"
                          maxLength={10}
                          {...register('contactNumber', {
                            required: 'Contact Number is required',
                            pattern: {
                              value: /^[0-9]{10}$/,
                              message: 'Number must be 10 digits and Numerical',
                            },
                          })}
                          className={`form-control-sm ${errors.contactNumber ? 'is-invalid' : ''}`}
                        />

                        {errors.ContactNumber && (
                          <div className="invalid-feedback d-block">{errors.contactNumber.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="AlternativeContactNumber" className="form-label">
                        <Form.Label>Alt. Con. No.</Form.Label>
                        <Form.Control
                          className='form-control-sm '
                          type="text"
                          maxLength={10}
                          {...register('alternativeContactNumber', {
                            pattern: {
                              value: /^[0-9]{10}$/,
                              message: 'Number must be 10 digits and numerical',
                            },
                          })}
                        />

                        {errors.alternativeContactNumber && (
                          <div className="invalid-feedback d-block">
                            {errors.alternativeContactNumber.message}
                          </div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={6}>
                      <Form.Group controlId="Address" className="form-label">
                        <Form.Label>Address</Form.Label>
                        <Form.Control
                          type="text"
                          {...register('address', { required: 'Address is required' })}
                          className={`form-control-sm ${errors.address ? 'is-invalid' : ''}`}
                        />
                        {errors.address && (
                          <div className="invalid-feedback d-block">{errors.address.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="State" className="form-label">
                        <Form.Label>State</Form.Label>
                        <Form.Select
                          as="select"
                          // onChange={handleState}
                          {...register('state', {
                            required: 'State is required',
                            onChange: (e) => {
                              handleState(e)
                            },
                          })}
                          className={`form-select-sm ${errors.state ? 'is-invalid' : ''}`}
                        >
                          <option value="">Select State</option>
                          {stateOptions.map((e, i) => (
                            <option key={i} value={e.id}>
                              {e.stateNConsti}
                            </option>
                          ))}
                        </Form.Select>

                        {errors.state && (
                          <div className="invalid-feedback d-block">{errors.state.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    <Col md={3}>
                      <Form.Group controlId="District" className="form-label">
                        <Form.Label>District</Form.Label>
                        <Form.Select
                          as="select"
                          {...register('district', { required: 'District is required' })}
                          className={`form-select-sm ${errors.district ? 'is-invalid' : ''}`}
                        >
                          <option value="">Select District</option>
                          {districtOptions.map((e, i) => (
                            <option key={i} value={e.id}>
                              {e.stateNConsti}
                            </option>
                          ))}
                        </Form.Select>

                        {errors.district && (
                          <div className="invalid-feedback d-block">{errors.district.message}</div>
                        )}
                      </Form.Group>
                    </Col>
                    {/* Submit Button */}
                    <div className="text-end mt-3">
                      <Button variant="secondary" size="sm" disabled={isSubmitting} type="submit">
                        {isSubmitting ? 'Submitting...' : 'Register'}
                      </Button>
                    </div>
                  </Row>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  )
}

export default StudentRegister
