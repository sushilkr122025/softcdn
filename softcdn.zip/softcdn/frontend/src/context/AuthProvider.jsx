import React, { useState, useEffect } from 'react'
// import { loginUser } from '../api/authService'
import apiClient from '../api/apiService'
import { Auth } from './AuthContext'
import { getLocal, setLocal, clearAll } from '../utils/storage'

function AuthProvider({ children }) {
  const [user, setUser] = useState()
  const [loading, setLoading] = useState(true)
  const [isAuth, setIsAuth] = useState(false)

  useEffect(() => {
    const logged = getLocal()

    const verify = async () => {
      try {
        if (logged) {
          const response = await apiClient.get('/auth/verify')
          const data = response.data

          setUser({
            id: data.id,
            name: data.name,
            role: data.role,
            rights: data.rights,
            // tenantId: data.tenantId,
            // license_key: data.license_key,
          })
          setIsAuth(true)
          setLoading(false)
          setLocal(true)
        } else {
          setIsAuth(false)
          clearAll()
          setLoading(false)
        }
      } catch (error) {
        setIsAuth(false)
        clearAll()
        setUser(null)
        console.log(error)
      } finally {
        setLoading(false)
      }
    }
    verify()
  }, [])

  // const login = async (email, password) => {
  //   try {
  //     const res = await loginUser(email, password)

  //     if (res.Status === 'Success') {
  //       setUser({
  //         id: res.id,
  //         name: res.name,
  //         role: res.role,
  //         rights: res.rights,
  //       })
  //       setIsAuth(true)
  //       localStorage.setItem('logged', true)
  //       return true
  //     }
  //   } catch (error) {
  //     console.log(error)
  //   } finally {
  //     setLoading(false)
  //   }
  // }

  const logout = () => {
    clearAll()
    setIsAuth(false)
    setUser(null)
  }

  const values = {
    user,
    setUser,
    // login,
    logout,
    isAuth,
    setIsAuth,
    loading,
  }

  return <Auth.Provider value={values}>{children}</Auth.Provider>
}

export default AuthProvider
