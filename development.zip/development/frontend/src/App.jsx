import React, { Suspense} from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import './App.css'
import PrivateRoute from './routes/PrivateRoute'
import routes from './routes/routes'
// import AuthProvider from './context/AuthProvider'
// import LicenseProvider from './context/LicenseProvider'
// import CompanyProvider from './context/CompanyContext'
import Loader from './components/Loader'
// import SectionReport from './pages/report/SectionReport'
import NotificationProvider from './context/NotificationContext'
import GlobalLoader from './components/GlobalLoader'
// import SchoolServices from './api/SchoolServices';
const DefaultLayout = React.lazy(() => import('./components/layout/DefaultLayout'))

const Login = React.lazy(() => import('./pages/Login'))
const Logout = React.lazy(() => import('./components/Logout'))
const Page404 = React.lazy(() => import('./components/Page404'))
const Page500 = React.lazy(() => import('./components/Page500'))
const ForgotPassword = React.lazy(() => import('./components/ForgotPassword'))
const Dashboard = React.lazy(() => import('./pages/Dashboard'))
const SchoolRegistration = React.lazy(() => import('./pages/schoolRegistration'))
const LookupPage = React.lazy(() => import('./pages/Lookup'))
const AuthLayout = React.lazy(() => import('./components/layout/AuthLayout'))

function App() {
  // useEffect(() => {
  //   const checkCsrfToken = async () => {
  //   const ctoken = localStorage.getItem('T-ACTION');   
  //  try {
  //    if (ctoken) {
  //      const res = await SchoolServices.loadCsrfToken();
  //       if(res){
  //         console.log('CSRF Token is valid');
  //       }       
  //    } else {
  //      console.log('No CSRF Token found in localStorage.');
  //    }
  //  } catch (error) {
  //    console.error('Error checking CSRF token:', error);
  //  }
  //   };
  //   checkCsrfToken();
  // }, [])
  return (
    <BrowserRouter>
      <GlobalLoader />

      <Suspense fallback={<Loader />}>
        <Routes>
          {/* ---------- PUBLIC ROUTES ---------- */}
          <Route path="/" element={<LookupPage />} />
          <Route path="/:schoolurl" element={<LookupPage />} />
          <Route path="/login" element={<Login />} />
          {/* ---------- PROTECTED ROOT ---------- */}
          <Route element={<AuthLayout />}>
            {routes.map((route, idx) => {
              const Element = route.element;

              return (
                <Route
                  key={idx}
                  element={<PrivateRoute allowedRoles={route.allowedRoles} />}
                >
                  <Route
                    element={
                      <NotificationProvider>
                        <DefaultLayout />
                      </NotificationProvider>
                    }
                  >
                    <Route path={route.path} element={<Element />} />
                    <Route path="/404" element={<Page404 />} />
                  </Route>
                </Route>
              );
            })}
          </Route>

          {/* Catch All */}
          <Route path="*" element={<Page404 />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App
