import React from 'react';
import { Outlet } from 'react-router-dom';
import CompanyProvider from '../../context/CompanyProvider';

const CompanyLayout = () => {
  return (
    <CompanyProvider>
      <Outlet />
    </CompanyProvider>
  );
};

export default CompanyLayout;
