import React, { useState, useEffect } from 'react';
import useAuth from '../context/AuthContext';
import { DataGrid } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';
import UserServices from '../api/UserServices';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import './admin.css';
import { PiFilePdfLight, PiMicrosoftWordLogoLight } from "react-icons/pi";
import { FaFileWord } from "react-icons/fa";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Document, Packer, Paragraph, Table, TableCell, TableRow, WidthType, TextRun } from "docx";
import { loaderStore } from '../LoaderStore';
import exporticon from '../assets/images/export.svg'
import { Popover, OverlayTrigger } from 'react-bootstrap';
import { FaPlus } from "react-icons/fa6";
import { IoSearchOutline } from "react-icons/io5";
import { BsThreeDotsVertical } from "react-icons/bs";
import ShowMessage from '../components/ShowMessage';
function Users() {
  const { user } = useAuth();
  const [userData, setUserData] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [pageSize, setPageSize] = useState(10);
  const [debouncedSearchText, setDebouncedSearchText] = useState('');
  const [columnVisibilityModel, setColumnVisibilityModel] = useState(() => JSON.parse(localStorage.getItem("userColumnVisibility")) || {});
  const [showAlert, setShowAlert] = useState(false);
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await UserServices.allUser()
        loaderStore.set(true)
        if (response) {
          setUserData(response)
          loaderStore.set(false)
        }
      } catch (error) {
        console.error(error)
        loaderStore.set(false)
      }
    }
    fetchUserData();
  }, [])

  const handleColumnVisibilityChange = (newModel) => {
    setColumnVisibilityModel(newModel);
    localStorage.setItem("userColumnVisibility", JSON.stringify(newModel));
  };

  const getVisibleColumns = () => {
    return columns.filter(col => {
      if (col.field === "action") return false;
      if (columnVisibilityModel && Object.prototype.hasOwnProperty.call(columnVisibilityModel, col.field)) {
        return !!columnVisibilityModel[col.field];
      }
      return true;
    });
  };

  const formatCellValue = (col, row) => {
    try {
      if (typeof col.valueGetter === "function") {
        const v = col.valueGetter({ row });
        return v == null ? "" : v;
      }
      if (typeof col.valueFormatter === "function") {
        const raw = row[col.field];
        const formatted = col.valueFormatter(raw);
        return formatted == null ? "" : formatted;
      }
      if (typeof col.renderCell === "function") {
        const raw = row[col.field];
        if (raw === 1) return "Active";
        if (raw === 0) return "Inactive";
        return raw == null ? "" : (typeof raw === "object" ? JSON.stringify(raw) : raw);
      }
      const v = row[col.field];
      if (v == null) return "";
      if (typeof v === "object") return JSON.stringify(v);
      return v;
    } catch (e) {
      console.log(e);
      return row[col.field] == null ? "" : String(row[col.field]);
    }
  };

  const handleExportExcel = () => {
     if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const visibleCols = getVisibleColumns();
    const aoa = [];
    const headerRow = visibleCols.map(col => col.headerName || col.field);
    aoa.push(headerRow);

    filteredRows.forEach(row => {
      const rowArr = visibleCols.map(col => {
        const value = formatCellValue(col, row);
        return value;
      });
      aoa.push(rowArr);
    });

    const worksheet = XLSX.utils.aoa_to_sheet(aoa);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Users");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(data, "Users.xlsx");
  };

  const handleExportPDF = () => {
    if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const doc = new jsPDF();
    doc.text("User List", 14, 10);

    const visibleCols = getVisibleColumns();
    const tableColumn = visibleCols.map(col => col.headerName || col.field);

    const tableRows = filteredRows.map(row =>
      visibleCols.map(col => {
        const val = formatCellValue(col, row);
        return String(val ?? "");
      })
    );

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save("Users.pdf");
  };

  const handleExportWord = async () => {
     if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const visibleCols = getVisibleColumns();

    const headerCells = visibleCols.map(col =>
      new TableCell({
        children: [new Paragraph({ text: col.headerName || col.field, bold: true })],
      })
    );

    const tableRows = [];
    tableRows.push(new TableRow({ children: headerCells }));

    filteredRows.forEach(row => {
      const cells = visibleCols.map(col => {
        const value = formatCellValue(col, row);
        return new TableCell({
          children: [new Paragraph(String(value ?? ""))],
        });
      });
      tableRows.push(new TableRow({ children: cells }));
    });

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [new TextRun({ text: "User List", bold: true, size: 28 })],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: tableRows,
          }),
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "Users.docx");
  };

  const columns = [
    { field: 'id', headerName: 'ID' },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'email', headerName: 'Email', flex: 1 },
    { field: 'mobileno', headerName: 'Contact', flex: 1 },
    { field: 'role', headerName: 'Role', flex: 1 },
    { field: 'designation', headerName: 'Designation', flex: 1 },
    { field: 'userid', headerName: 'User Id', flex: 1 },
    {
      field: 'createdate',
      headerName: 'Created At',
      flex: 1,
      valueFormatter: (params) => {
        const date = new Date(params);
        if (isNaN(date)) return '';
        return date.toLocaleDateString('en-GB', {
          year: 'numeric',
          month: 'short',
          day: '2-digit',
        });
      },
    },
    { field: 'lastlogin', headerName: 'Last Login', flex: 1 },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      filterable: false,
      renderCell: (params) => {
        const popover = (
          <Popover id={`popover-${params.row.id}`} className="custom-shadow border-0">
            <Popover.Body className="p-0">
              <ul className="list-unstyled mb-0 p-2" style={{ minWidth: '120px' }}>
                {params.row.id === user?.id ? (
                  <li>
                    <Link to={`/users/profile`} className="dropdown-item py-2 px-3">
                      View Profile
                    </Link>
                  </li>
                ) : (
                  <>
                    <li><Link to={`/users/${params.row.id}`} className="dropdown-item py-2 px-3">Edit Details</Link></li>
                    <li><Link to={`/users/assign/${params.row.id}`} className="dropdown-item py-2 px-3">Set Subjects & Classes</Link></li>
                    <li><Link to={`/users/roles/${params.row.id}`} className="dropdown-item py-2 px-3">Set Roles</Link></li>
                    <li><Link to={`/users/setrule/${params.row.id}`} className="dropdown-item py-2 px-3">Set Question Rule</Link></li>
                  </>
                )}
              </ul>
            </Popover.Body>
          </Popover>
        );
        return (
          <OverlayTrigger trigger="click" placement="left" rootClose overlay={popover}>
            <button type="button" className='btn btn-sm border-0 p-0'>
              <BsThreeDotsVertical className='btnclr pointer' size={20} />
            </button>
          </OverlayTrigger>
        );
      },
    },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchText(searchText);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchText]);

  const filteredRows = userData.filter((row) =>
    row?.name?.toLowerCase().includes(debouncedSearchText.toLowerCase())
  );

  const exportPopover = (
    <Popover id="popover-export" className="shadow border-0">
      <Popover.Body className="p-0">
        <div className="list-group list-group-flush p-2" style={{ minWidth: '150px' }}>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportPDF() }}
          >
            <PiFilePdfLight className='me-2' size={18} /> PDF
          </button>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportWord() }}
          >
            <FaFileWord className='me-2' size={18} /> Word
          </button>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportExcel() }}
          >
            <PiMicrosoftWordLogoLight className='me-2' size={18} /> Excel
          </button>
        </div>
      </Popover.Body>
    </Popover>
  );
  return (
    <div className="p-lg-4 mt-2">
      <div className="container-fluid">
        <div className="row h-80vh">
          <div className="col-12 p-lg-2 py-2">
            <div className="row align-items-center mb-4">
              <div className="col-4">
                <h4 className='mb-0 fw-bold pagetitle'>Users</h4>
              </div>
              <div className="col-8 d-flex justify-content-end align-items-center gap-3">
                <div className='position-relative w-35'>
                  <IoSearchOutline size={20} className='searchpositon' />
                  <input type="search" className="form-control h45" placeholder="Search..." value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                </div>
                <div>
                  <OverlayTrigger trigger="click" placement="bottom" rootClose overlay={exportPopover}>
                    <button className="btn btn-export h45" data-bs-toggle="dropdown" aria-expanded="false" type="button">
                      <span className='px-1 me-3'><img src={exporticon} alt="" className='img-fluid' style={{ width: "20px" }} /></span>
                      Export As
                    </button>
                  </OverlayTrigger>
                </div>
                <Link to="/users/add">
                  <button className='btn btn-primary h45'>
                    <span><FaPlus size={20} /></span>
                    Add user
                  </button>
                </Link>
              </div>
            </div>
            <div className='w-100 h-72vh'>
              <DataGrid
                className="custom-data-grid"
                rows={filteredRows}
                columns={columns}
                pageSize={pageSize}
                onPageSizeChange={(newSize) => setPageSize(newSize)}
                pageSizeOptions={[10, 25, 50, 100]}
                disableRowSelectionOnClick
                initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 }, } }}
                columnVisibilityModel={columnVisibilityModel}
                onColumnVisibilityModelChange={handleColumnVisibilityChange}
                getRowHeight={() => 60}
                columnHeaderHeight={50}
              />
            </div>
            <ShowMessage type="toast" show={showAlert} variant="danger" message='No Question Found' onClose={() => setShowAlert(false)} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Users;
