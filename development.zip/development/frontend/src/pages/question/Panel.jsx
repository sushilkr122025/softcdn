import { useEffect, useRef, useState } from "react";
import Modal from 'react-bootstrap/Modal'
import useAuth from '../../context/AuthContext';
import { BsFillChatSquareTextFill } from "react-icons/bs";
import { IoSend, IoReturnDownBack } from "react-icons/io5";
import { SlOptionsVertical } from "react-icons/sl";
import './Panel.css';
import QuestionServices from "../../api/QuestionServices";
import ShowMessage from '../../components/ShowMessage';
import { useNavigate, useParams } from "react-router-dom";
import { useNotification } from "../../context/NotificationContext";

const Panel = () => {
  const { pqid } = useParams();
  const menuRef = useRef(null);
  const { user } = useAuth()
  const { socket } = useNotification();
  const [messages, setMessages] = useState([]);
  const [unseenCount, setUnseenCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const [roomUser, setRoomUser] = useState([]);
  const [qId, setQId] = useState(null);
  const [input, setInput] = useState("");

  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [show, setShow] = useState(false)
  const [modalType, setModalType] = useState('')
  const [modelBg, setModalBg] = useState('')
  const [ISApprover, setISApprover] = useState(false)
  const outerMsgBox = useRef(null);
  const [status, setStatus] = useState(null);
  const isLocked = status === "APPROVED" || status === "REJECTED" || status === "REVISED";

  const navigator = useNavigate();

  const [item, setItem] = useState([]);
  const messagesEndRef = useRef(null);
  const options = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }]
  const qTypeConvert = { multipleChoice: 'Multiple Choice', trueFalse: 'True/False', oneWord: 'One Word', CR: 'Written Response', fillups: 'Fill in the Blanks', match: 'Match the Following' };
  const cleanHtml = (html) => {
    if (!html) return "";
    // html = html.replace(/\s*style="[^"]*"/gi, "");
    // html = html.replace(/<\/?p[^>]*>/gi, "");
    return html;
  };

  // const filteredMessages = messages.filter((msg) => {
  //   if (!searchQuery.trim()) return true;
  //   const q = searchQuery.toLowerCase();
  //   return msg.text.toLowerCase().includes(q) || msg.sender.toLowerCase().includes(q);
  // });

  // format time
  const formatTime = (iso) => {
    try {
      const d = new Date(iso);
      return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(d);
    } catch (e) {
      return "";
    }
  };

  const sameDay = (isoA, isoB) => {
    if (!isoA || !isoB) return false;
    const a = new Date(isoA);
    const b = new Date(isoB);
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  };

  const dateHeaderLabel = (iso) => {
    const d = new Date(iso);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (sameDay(iso, today.toISOString())) return "Today";
    if (sameDay(iso, yesterday.toISOString())) return "Yesterday";

    return new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(d);
  };

  useEffect(() => {
    const fetchQuestion = async () => {
      const response = await QuestionServices.getPanelHistoryById(pqid);   
      console.log('response', response)  ;
      if (response) {
        const updatedRoomUser = [
          ...response[0].approverId.split(',').map(Number),
          response[0].tId,
        ];

        if (!updatedRoomUser.includes(user.id) || response[0].status != 'PANELING') {
          setTextConfirm('Exit')
          setMsgType('modal');
          setRedirect('/question')
          setBtnConfirm(true)
          if(updatedRoomUser.includes(user.id) && response[0].status != 'PANELING') {
            setMessage('This question is not in paneling stage...');
          } else {
            setMessage('You are not authorized to view this area...');
          }          
          setShowMsg(true);
        } else {
          if (user.id != response[0].tId) {
            setISApprover(true)
          }
          setItem(response)
          setQId(response[0].id);
          setRoomUser(updatedRoomUser);
        }
      }else {
        setTextConfirm('Exit')
        setMsgType('modal');
        setRedirect('/question')
        setBtnConfirm(true)
        setMessage('Question not available for paneling');
        setShowMsg(true);
      }
    }
    fetchQuestion();
  }, []);

  // Load messages history when receiverId changes
  useEffect(() => {
    if (!socket || !user || !qId) return;
    socket.emit("join_room", { qId });

    socket.emit("load_messages", { qId: qId });

    socket.on("messages_history", (history) => {
      // console.log("Message history", history);
      setMessages(history);
    });

    return () => {
      socket.off("messages_history");
    };
  }, [socket, user, qId]);


  // Listen for real-time new messages
  useEffect(() => {
    if (!socket) return;
    socket.on("receive_message", (msg) => {
      // console.log("Received new message:", msg);        
      //if (msg.userId === user.id) {
      setMessages((prev) => [...prev, msg]);
      //}
    });

    return () => {
      socket.off("receive_message");
    };
  }, [socket, qId, user]);

  // Send message
  const sendMessage = () => {    
    if (!input.trim()) return;
    socket.emit("send_message", { qId, message: input, quesVersion: item[0].revision });
    setInput("");
  };

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const openmodel = (type, color) => {
    setModalType(type)
    setModalBg(color)
    setShow(true);

  }

  const handleClose = () => {
    if (outerMsgBox.current) {
      const value = outerMsgBox.current.value.trim();
      outerMsgBox.current.innerHTML = "";
    }
    setShow(false)
  }

  const handleOuterSubmit = () => {
    if (outerMsgBox.current) {
      const value = outerMsgBox.current.value.trim();
      if (!value) return;

      const labelColor =
        modalType === "Revise"
          ? "bg-warning"
          : modalType === "Approve"
            ? "bg-success"
            : modalType === "Reject"
              ? "bg-danger"
              : "bg-secondary";

      const borderColor =
        modalType === "Revise"
          ? "border-warning"
          : modalType === "Approve"
            ? "border-success"
            : modalType === "Reject"
              ? "border-danger"
              : "border-secondary";

      const messageHtml = `<div class="msg-with-label ${borderColor}">
        <span class="msg-label badge ${labelColor}">${modalType}</span>
        <div class="msg-text">${value}</div>
      </div>`.trim();

      socket.emit("send_message", { qId, message: messageHtml, msgType: modalType.toUpperCase(), quesVersion: item[0].revision });
      if (modalType === "Approve") {
        setStatus("APPROVED");
      } else if (modalType === "Reject") {
        setStatus("REJECTED");
      } else if (modalType === "Revise") {
        setStatus("REVISED");
      }
      outerMsgBox.current.value = "";
      setShow(false);
    }
  };


  return (
    <div className="p-lg-4">
      <div className="container-fluid">
        <div className="row h-85vh">
          <div className="col-12 mx-auto content-bg p-lg-4 py-4">
            <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose}
              textConfirm={textConfirm}
              textClose={textClose}
              onClose={() => setShowMsg(false)}
              onConfirm={() => {
                setShowMsg(false);
                navigator(redirect);
              }}
            />
            <div className="row">
              <div className="col-9 mb-3">                
                <div className="accordion" id="questionHistory">
                  {item.map((data, i) => (
                    <div className="accordion-item" key={i}>
                      <h2 className="accordion-header">
                        <button className={`accordion-button ${i == 0 ? '' : 'collapsed'}`} type="button" data-bs-toggle="collapse" data-bs-target={`#collapse${i}`} aria-expanded={i == 0 ? true : false} aria-controls={`#collapse${i}`}
                        > <span className="badge text-bg-warning me-2">Version {data?.revision}</span></button>
                      </h2>                     
                      <div id={`collapse${i}`} className={`accordion-collapse collapse ${i == 0 ? ' show' : ''}`} data-bs-parent="#questionHistory">
                        <div className="accordion-body">
                          <div className="text-dark p-2 mb-4">
                          <span className="border p-2">Subject - {data.subject}</span> 
                               <span className="border p-2"> Class - {data.class}</span>                            
                                <span className="border p-2 ">{data.cg}</span>
                                <span className="border p-2">{data.competency}</span>   
                                <span className="border p-2">{qTypeConvert[data.quesType]}</span>   
                                <span className="border p-2">{data.difficulty}</span>   
                                <span className="border p-2">Total Marks - {data.marks}</span>   

                           </div>
                           <div className="panelItme" dangerouslySetInnerHTML={{
                          __html: `${cleanHtml(data?.question) || "No content available"}`,
                        }}
                        />                                                   
                          {data.quesType === "multipleChoice" && (
                            <>
                          <h6>Options:</h6>
                          <ol className="list-group mt-3" type="A">
                            {options.map((key, i) => {
                              const option = data?.[key.optns];
                              const optionimg = data?.[key.images];
                              if (!option && !optionimg) return null;
                              const isCorrect = key.optns === data.correctAns;
                              return (
                                <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                                  <div className='d-flex justify-content-between align-items-center'>
                                    {option && (
                                      <div
                                        dangerouslySetInnerHTML={{ __html: option }}
                                      />
                                    )}
                                    {optionimg && <div><img src={optionimg} className='img-fluid' style={{ maxWidth: "100px" }} alt="" /></div>}
                                    {isCorrect && <div className="text-success fw-bold">✔</div>}
                                  </div>
                                </li>
                              );
                            })}
                          </ol>
                          </>
                          )}
                          {data?.markingScheme && (
                            <div className="mt-3 ">
                              <h6>Mark Scheme:</h6>    
                              <div className="table-responsive p-0">                          
                                <table className="table table-bordered border">
                                  <thead className="text-center">
                                    <tr>
                                      <th>Level</th>
                                      <th>Description</th>
                                      <th>Guidelines</th>
                                      <th>Marks</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {JSON.parse(data.markingScheme).map((ms, idx) => (
                                      <tr key={idx}>
                                        <td className="fw-semibold text-center">{ms.level}</td>
                                        <td>
                                          <div dangerouslySetInnerHTML={{ __html: ms.descriptiors }} />
                                        </td>
                                        <td>
                                          <div dangerouslySetInnerHTML={{ __html: ms.guidelines }} />
                                        </td>
                                        <td className="text-center">{ms.marks}  {ms.marksRange}</td>
                                      </tr>
                                    ))}                              
                                  </tbody>
                                </table>
                                </div>
                            </div>

                          )} 
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {roomUser && roomUser.includes(user.id) && (
                <div className="col-3 mb-3">
                  <div className="card w-100" style={{ height: "80vh" }}>
                    <div className="d-flex justify-content-between align-items-center p-3 bg-primary text-white fw-bold">
                      <div className="position-relative d-inline-flex align-items-center">
                        <BsFillChatSquareTextFill size={20} />
                        {unseenCount > 0 && (
                          <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                            {unseenCount}
                          </span>
                        )}
                      </div>

                      {/* <div className="position-relative" ref={menuRef}>
                        <span role="button" className="p-1" onClick={() => setOpen(!open)}>
                          <SlOptionsVertical size={20} />
                        </span>

                        {open && (
                          <div className="position-absolute end-0 mt-2 bg-white text-dark shadow rounded z-1">
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">
                              copy
                            </div>
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">edit</div>
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">pin</div>
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">info</div>
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">search</div>
                            <div className="px-3 py-1 border-bottom menu-item cursor-pointer">delete</div>
                          </div>
                        )}
                      </div> */}
                    </div>

                    <div style={{ flex: 1, overflowY: "auto", padding: "0 0.5rem 0 0.5rem" }}>
                      {messages.map((msg, idx) => {
                        return (
                          <div
                            key={msg.id}
                            className={`chat-row d-flex ${msg.userId === user.id
                              ? "justify-content-end"
                              : "justify-content-start"
                              }`}
                          >
                            <div className={`chat-bubble ${msg.userId === user.id ? "sent" : "received"}`}>
                              <div className="header"><span className="phone">{msg.userId === user.id ? "You" : msg.name != '' ? msg.name : user.id}</span></div>
                              <div className="body" dangerouslySetInnerHTML={{ __html: msg.message }} />
                              <div className="meta">
                                <small>{formatTime(msg.createdAt)}</small>
                              </div>
                            </div>
                          </div>
                        )
                      }
                      )}
                      <div ref={messagesEndRef} />
                    </div>                    
                    <div className="p-2 d-flex" style={{ flex: "0 0 auto" }}>
                      <input
                        type="text"
                        value={input}
                        disabled={isLocked}
                        onChange={(e) => setInput(e.target.value)}
                        className="form-control me-2"
                        placeholder="Type a message..."
                        onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                      />
                      <button className="btn border btn-secondary pt-1"
                        disabled={isLocked}
                        onClick={sendMessage}
                      >
                        <IoSend size={20} />
                      </button>
                    </div>
                    {ISApprover && (
                      <div className="p-2 w-100 w-sm-auto gap-1 text-center">
                        <button className="btn border btn-warning pt-1" disabled={isLocked} onClick={() => openmodel('Revise', 'warning')}>Revise</button>
                        <button className="btn border btn-success pt-1"disabled={isLocked} onClick={() => openmodel('Approve', 'success')}>Approve</button>
                        <button className="btn border btn-danger pt-1"disabled={isLocked} onClick={() => openmodel('Reject', 'danger')}>Reject</button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Modal
        size="small"
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
        contentClassName={`bg-${modelBg}`}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title className="h5">
            {modalType}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="bg-white p-2 rounded">
            <textarea rows="5" ref={outerMsgBox}></textarea>
            <button className="btn btn-dark" onClick={handleOuterSubmit}>{modalType}</button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Panel;
