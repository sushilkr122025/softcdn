import React from 'react'
import { Link } from 'react-router-dom'

const Page404 = () => {
  return (
    <div className="d-flex align-items-center justify-content-center flex-grow-1 bg-light">
      <div className="d-flex flex-column text-center">
        <h1 className="display-1 fw-bold text-primary">404</h1>
        <p className="fs-3">
          <span className="text-danger">Oops!</span> Page not found.
        </p>
        <p className="lead">The page yo're looking for doesn't exist or has been moved. </p>
        <Link to="/dashboard" className='mx-auto'>
          <button className="btn btn-primary h45">
            Go Home
          </button>
        </Link>
      </div>
    </div>
  )
}

export default Page404
