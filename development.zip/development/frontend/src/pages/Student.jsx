import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';
import { FaEllipsisVertical } from "react-icons/fa6";
import apiClient from '../api/apiService';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import './admin.css';
import { PiFilePdfLight, PiMicrosoftWordLogoLight } from "react-icons/pi";
import { FaFileWord } from "react-icons/fa";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Document, Packer, Paragraph, Table, TableCell, TableRow, WidthType, TextRun } from "docx";
import { IoSearchOutline } from "react-icons/io5";
import exporticon from '../assets/images/export.svg'
import { Popover, OverlayTrigger } from 'react-bootstrap';
import { FaPlus } from "react-icons/fa6";
import CustomDropdown from '../components/layout/CustomDropdown'
import ShowMessage from '../components/ShowMessage';
function Student() {
  const [userData, setUserData] = useState([]);
  const [classes, setClasses] = useState('');
  const [classData, setClassData] = useState([]);
  const [section, setSection] = useState('');
  const [sectionData, setSectionData] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [pageSize, setPageSize] = useState(10);
  const [openKey, setOpenKey] = useState("");
  const [debouncedSearchText, setDebouncedSearchText] = useState('');
  const [showAlert, setShowAlert] = useState(false);
  const [columnVisibilityModel, setColumnVisibilityModel] = useState(
    () => JSON.parse(localStorage.getItem("studentColumnVisibility")) || {}
  );

  const AllStudents = async () => {
    try {
      apiClient
        .get('/user/student', {
          params: {
            class: classes,
            section: section,
          }
        })
        .then((response) => {
          setUserData(response.data)
        })
        .catch((error) => {
          console.error(error)
        })
    } catch (error) {
      console.error('Error fetching sections:', error);
    }
  };

  useEffect(() => {
    AllStudents();
    apiClient.get('/store/classes').then((res) => setClassData(res.data)).catch((err) => console.error('Class fetch error', err));
    apiClient
      .get('/store/section')
      .then((response) => {
        // console.log(response.data);
        setSectionData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })
  }, [])

  const handleColumnVisibilityChange = (newModel) => {
    setColumnVisibilityModel(newModel);
    localStorage.setItem("studentColumnVisibility", JSON.stringify(newModel));
  };

  const handleExportPDF = () => {
    if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const doc = new jsPDF();

    doc.text("Student List", 14, 10);

    const tableColumn = columns
      .filter(col => col.field !== "action")
      .map(col => col.headerName);

    const tableRows = filteredRows.map(row =>
      columns
        .filter(col => col.field !== "action")
        .map(col => {
          if (col.valueGetter) return col.valueGetter({ row });
          if (col.renderCell) return row[col.field] === 1 ? "Active" : "Inactive";
          return row[col.field] || "";
        })
    );

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save("Student.pdf");
  };

  const handleExportWord = async () => {
    if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const tableRows = [];

    const headerCells = columns
      .filter(col => col.field !== "action")
      .map(col => new TableCell({
        children: [new Paragraph({ text: col.headerName, bold: true })],
      }));
    tableRows.push(new TableRow({ children: headerCells }));

    filteredRows.forEach(row => {
      const cells = columns
        .filter(col => col.field !== "action")
        .map(col => {
          let value = "";
          if (col.valueGetter) value = col.valueGetter({ row });
          else if (col.renderCell) value = row[col.field] === 1 ? "Active" : "Inactive";
          else value = row[col.field] || "";

          return new TableCell({
            width: { size: 100, type: WidthType.PERCENTAGE },
            children: [new Paragraph(String(value))],
          });
        });
      tableRows.push(new TableRow({ children: cells }));
    });

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [new TextRun({ text: "Student List", bold: true, size: 28 })],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: tableRows,
          }),
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "Students.docx");
  };

  const handleExportExcel = () => {
    if (userData.length === 0) {
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
      return;
    }
    const worksheet = XLSX.utils.json_to_sheet(userData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(data, "Students.xlsx");
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 1 },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'class', headerName: 'Class', flex: 1 },
    { field: 'section', headerName: 'Section', flex: 1 },
    { field: 'rollNo', headerName: 'Roll No', flex: 1 },
    {
      field: 'dateOfBirth',
      headerName: 'DOB',
      valueGetter: (params) => {
        if (!params?.row?.dateOfBirth) return 'N/A';
        return new Date(params.row.dateOfBirth).toLocaleDateString();
      }, flex: 1
    },
    { field: 'emailId', headerName: 'Email', flex: 1 },
    { field: 'contactNumber', headerName: 'Contact', flex: 1 },
    { field: 'gender', headerName: 'Gender', flex: 1 },
    {
      field: 'status',
      headerName: 'Status'
      , flex: 1,
      renderCell: (params) =>
        params.row.dmlType === 'I'
          ? <span className="badge-active rounded-pill">Active</span>
          : <span className="badge-inactive rounded-pill">Inactive</span>
    },
    {
      field: 'action',
      headerName: 'Action',
      sortable: false,
      filterable: false,
      renderCell: (params) => {
        const popover = (
          <Popover id={`popover-${params.row.id}`} className="custom-shadow border-0">
            <Popover.Body className="p-0">
              <ul className="list-unstyled mb-0 py-2 px-0 bg-white" style={{ minWidth: '150px' }}>
                <li> <Link to={`/UserRegistration/${params.row.id}`} className="dropdown-item py-2 px-3">Edit Details</Link></li>
                <li><Link to={`roles/${params.row.id}`} className="dropdown-item py-2 px-3"> Set Roles</Link></li>
              </ul>
            </Popover.Body>
          </Popover>
        );
        return (
          <OverlayTrigger trigger="click" placement="left" rootClose overlay={popover}>
            <button type="button" className="btn btn-sm border-0" onClick={(e) => e.stopPropagation()}><FaEllipsisVertical /> </button>
          </OverlayTrigger>
        );
      }

    },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchText(searchText);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchText]);

  const filteredRows = userData.filter((row) =>
    row?.name?.toLowerCase().includes(debouncedSearchText.toLowerCase())
  );

  const exportPopover = (
    <Popover id="popover-export" className="shadow border-0">
      <Popover.Body className="p-0">
        <div className="list-group list-group-flush p-2" style={{ minWidth: '150px' }}>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportPDF() }}
          >
            <PiFilePdfLight className='me-2' size={18} /> PDF
          </button>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportWord() }}
          >
            <FaFileWord className='me-2' size={18} /> Word
          </button>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { handleExportExcel() }}
          >
            <PiMicrosoftWordLogoLight className='me-2' size={18} /> Excel
          </button>
        </div>
      </Popover.Body>
    </Popover>
  );

  return (
    <div className="p-lg-4 mt-2">
      <div className="container-fluid">
        <div className="row h-80vh">
          <div className="col-12 p-lg-2 py-2">
            <div className="row align-items-center mb-4">
              <div className="col-4">
                <h4 className='mb-0 fw-bold pagetitle'>Student</h4>
              </div>

            </div>
            <div className="row mb-3">
              <div className="col-4">
                <div className='row'>
                  <div className="col">
                    <CustomDropdown
                      dropdownKey="class"
                      placeholder="Class"
                      value={classes}
                      openKey={openKey}
                      setOpenKey={setOpenKey}
                      options={classData.map((c) => ({
                        value: c.class,
                        label: c.class,
                      }))}
                      onChange={(val) => {
                        setClasses(val);
                        AllStudents();
                      }}
                    />
                  </div>
                  <div className="col">
                    <CustomDropdown
                      dropdownKey="section"
                      openKey={openKey}
                      setOpenKey={setOpenKey}
                      placeholder="Section"
                      value={section}
                      options={sectionData.map((s) => ({
                        value: s.section,
                        label: s.section,
                      }))}
                      onChange={(val) => {
                        setSection(val);
                        AllStudents();
                      }}
                    />
                  </div>
                </div>
              </div>
              <div className="col-8 d-flex justify-content-end align-items-center gap-3">
                <div className='position-relative w-35'>
                  <IoSearchOutline size={20} className='searchpositon' />
                  <input type="search" className="form-control h45" placeholder="Search..." value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                  />
                </div>
                <div>
                  <OverlayTrigger trigger="click" placement="bottom" rootClose overlay={exportPopover}>
                    <button className="btn btn-export h45" data-bs-toggle="dropdown" aria-expanded="false" type="button">
                      <span className='px-1 me-3'><img src={exporticon} alt="" className='img-fluid' style={{ width: "20px" }} /></span>
                      Export As
                    </button>
                  </OverlayTrigger>
                </div>
                <Link to="/StudentRegistration">
                  <button className='btn btn-primary h45'>
                    <span><FaPlus size={20} /></span>
                    Add Student
                  </button>
                </Link>
              </div>
            </div>

            <div className='w-100 h-67vh' >
              <DataGrid
                className="custom-data-grid"
                rows={filteredRows}
                columns={columns}
                getRowId={(row) => row.id || row.Id || row.studentId}
                pageSize={pageSize}
                onPageSizeChange={(newSize) => setPageSize(newSize)}
                pageSizeOptions={[10, 25, 50, 100]}
                // checkboxSelection
                disableRowSelectionOnClick
                initialState={{ pagination: { paginationModel: { pageSize: 25, page: 0 } } }}
                columnVisibilityModel={columnVisibilityModel}
                onColumnVisibilityModelChange={handleColumnVisibilityChange}
                getRowHeight={() => 60}
                columnHeaderHeight={50}
              />
            </div>
            <ShowMessage type="toast" show={showAlert} variant="danger" message='No Question Found' onClose={() => setShowAlert(false)} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Student;
