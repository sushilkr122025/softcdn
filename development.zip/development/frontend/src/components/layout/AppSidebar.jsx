import { useState, useEffect, useMemo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Sidebar.css';
import { TfiBarChartAlt } from "react-icons/tfi";
import { IoSettingsOutline, IoMenu } from 'react-icons/io5';
import { RiDashboardFill } from "react-icons/ri";
import { PiUsersThreeFill, PiBank } from "react-icons/pi";
import { LuGraduationCap } from "react-icons/lu";
import { BsFileEarmarkText } from "react-icons/bs";
import { RxCross2 } from "react-icons/rx";

const SIDEBAR_MENU = [
  { id: 'dashboard', label: 'Dashboard', to: '/dashboard', logo: <RiDashboardFill /> },
  { id: 'Alluser', label: 'User', to: '/users', logo: <PiUsersThreeFill /> },
  { id: 'AllStudent', label: 'Student', to: '/student', logo: <LuGraduationCap /> },
  { id: 'qbank', label: 'Question Bank', to: '/question', logo: <PiBank /> },
  {
    id: 'question',
    label: 'Assessment Dev.',
    logo: <BsFileEarmarkText />,
    children: [
      { id: 'q-create', label: 'Create a question', to: '/question/type' },
      { id: 'q-history', label: 'My question history', to: '/question/history' },
      { id: 'q-approval', label: 'Review questions', to: '/question/paneling' },
      { id: 'q-exam', label: 'Design test paper', to: '/QuestionPaper' },
      { id: 'q-ans', label: 'Answer sheet', to: '/AnswerSheet' },
      // { id: 'q-adpr', label: 'ADPR', to: '' },
    ],
  },
  {
    id: 'studentReport',
    label: 'Student Report',
    logo: <TfiBarChartAlt />,
    children: [
      { id: 'i-report', label: 'Individual Report', to: '/reportadmin' },
      { id: 'c-report', label: 'Class Report', to: '/reportadmin' },
      { id: 'm-report', label: 'Management Report', to: '/reportadmin' },
    ],
  },

  { id: 'managementReport', label: 'Setting', to: '/setting', logo: <IoSettingsOutline /> },
]

const Sidebar = ({ propVisible, setPropVisible }) => {
  const location = useLocation();

  const setVisible = setPropVisible;
  const sidebarVisible = propVisible;

  const { pathToId, parentOf } = useMemo(() => {
    const pathToId = {};
    const parentOf = {};
    SIDEBAR_MENU.forEach(item => {
      if (item.children) {
        parentOf[item.id] = null;
        item.children.forEach(child => {
          pathToId[child.to] = child.id;
          parentOf[child.id] = item.id;
        });
      } else if (item.to) {
        pathToId[item.to] = item.id;
        parentOf[item.id] = null;
      }
    });
    return { pathToId, parentOf };
  }, []);

  const [activeId, setActiveId] = useState(() => {
    const p = location.pathname;
    if (pathToId[p]) return pathToId[p];
    for (const [path, id] of Object.entries(pathToId)) if (p.startsWith(path)) return id;
    return null;
  });

  const [openParents, setOpenParents] = useState(() => {
    const m = {};
    SIDEBAR_MENU.forEach(item => { if (item.children) m[item.id] = false; });
    if (activeId && parentOf[activeId]) m[parentOf[activeId]] = true;
    return m;
  });


  useEffect(() => {
    const onResize = () => setVisible(window.innerWidth >= 800);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [setVisible]);

  const setSingleOpenParent = (parentId) => {
    setOpenParents(prev => {
      const next = Object.keys(prev).reduce((o, k) => ({ ...o, [k]: false }), {});
      if (parentId) next[parentId] = true;
      return next;
    });
  };

  const handleParentToggle = (parentId) => {
    setOpenParents(prev => {
      const isOpen = !!prev[parentId];
      const next = Object.keys(prev).reduce((o, k) => ({ ...o, [k]: false }), {});
      next[parentId] = !isOpen;
      return next;
    });
    setActiveId(parentId);
  };

  const handleLinkClick = (id) => {
    setActiveId(id);
    const parent = parentOf[id] || null;
    setSingleOpenParent(parent);
    if (window.innerWidth < 800) setVisible(false);
  };

  const isItemActive = (item) => {
    if (item.children) {
      if (activeId === item.id) return true;
      return item.children.some(c => c.id === activeId);
    }
    return activeId === item.id;
  };

  return (
    <nav className={`sidebar z-2 ${sidebarVisible ? 'show' : 'hide'}`} aria-label="Main navigation">
      <h4 className='mt-1 p-1 text-white'>Menu</h4>
      <hr className="border border-white border-1 rounded opacity-75 mt-2 w-100 mb-4" />
      <ul className="sidebar-list">
        {SIDEBAR_MENU.map(item => (
          <li key={item.id} className={`sidebar-item ${item.children ? 'has-sub' : ''} ${isItemActive(item) ? 'active-item' : ''}`}>
            {!item.children ? (
              <NavLink to={item.to} className={() => `sidebar-link ${isItemActive(item) ? 'active' : ''}`} onClick={() => handleLinkClick(item.id, item.to)}>
                {item.icon && <img src={item.icon} alt="" className="sidebar-icon" />}
                <span className="ps-3 sidebar-label"><span className='fs-5 me-2'>{item.logo}</span> {item.label} </span>
              </NavLink>
            ) : (
              <div className="sidebar-parent mb-2">
                <button
                  type="button"
                  className={`sidebar-link sidebar-parent-btn mb-0 ps-2 sidebarparent ${isItemActive(item) ? 'active' : ''}`}
                  aria-expanded={!!openParents[item.id]}
                  onClick={() => handleParentToggle(item.id)}
                >
                  {item.icon && <img src={item.icon} alt="" className="sidebar-icon" />}
                  <span className="sidebar-label ps-2"><span className='fs-5 me-2'>{item.logo}</span>{item.label}</span>
                  <span className='ms-auto'>{openParents[item.id] ? (<RxCross2 />) : (<IoMenu />)}</span>
                </button>

                <ul className={`submenu ${openParents[item.id] ? 'open' : ''}`}>
                  {item.children.map(child => (
                    <li key={child.id}>
                      <NavLink
                        to={child.to}
                        className={() => `sidebar-sublink ${activeId === child.id ? 'active' : ''}`}
                        onClick={() => handleLinkClick(child.id, child.to)}
                      ><span className='dot'></span>
                        <span>{child.label}</span>
                      </NavLink>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Sidebar;
