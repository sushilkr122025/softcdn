import { useState } from 'react';
import './Question.css';
import queServices from '../../api/QuestionServices';
import { Link } from 'react-router-dom';
import useAuth from '../../context/AuthContext';

const PanelItem = () => {
  const [data, setData] = useState();
  const { user } = useAuth();

  useState(() => {  
    const fetchData = async () => {
      const result = await queServices.getPanelItems();         
      setData(result);    
    };
    fetchData();
  }, []);

  return (
<div className="p-4">
<div className="container-fluid">
      <div className="row">
        <div className="col-12 mx-auto bg-white shadow-sm rounded p-4">
      <h1>Panel</h1>
      {data && 
      <table className='table table-bordered table-striped table-hover'>
        <thead>
          <tr>
            <th>Count</th>
            <th>Ref ID</th>
            <th>Question</th>
            <th>Created By</th>
            <th>Revision</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {data && data.map((item, i) => (
            <tr key={item.id}>
              <td>{i+1}</td>
              <td>{item.id}</td>
              <td  dangerouslySetInnerHTML={{ __html: item.question }} />             
              <td>{item.tId != user.id ? item.name : 'You' }</td>
              <td>{item.revision}</td>
              <td>{new Date(item.createdAt).toLocaleDateString()}</td>
              <td><Link to={`/question/panel/${item.id}`} className='btn btn-dark btn-sm' >Panel</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
      }
      {!data && <p>Data Not found</p>}
    </div>
    </div>
    </div>
    </div>
  )
}

export default PanelItem
