import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity({ name: 'studentbloomsummery'})
export class StudentBloomSummary {

  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  paperid!: number;

  @Column()
  studentid!: number;

  @Column()
  class!: string;

  @Column()
  section!: string;

  @Column()
  bloomLevel!: string;

  @Column('float')
  obtainedMarks!: number;

  @Column('float')
  maxMarks!: number;

  @Column('float')
  percentage!: number;
}