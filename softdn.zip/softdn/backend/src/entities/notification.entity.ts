import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('notifications')
export class Notification {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column()
  userId: number;

  @Column({ type: 'varchar', length: 20 })
  type: string;

  @Column()
  message: string;

  @Column({ default: false })
  isRead: boolean;

  @Column({ type: 'varchar', length: 5, default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;
}
