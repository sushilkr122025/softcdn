const KpiCard = ({ title, value }) => (
  <div className="col-md-3">
    <div className="card text-center p-3 shadow-sm">
      <h6>{title}</h6>
      <h3>{value ?? "-"}</h3>
    </div>
  </div>
);

export default KpiCard;