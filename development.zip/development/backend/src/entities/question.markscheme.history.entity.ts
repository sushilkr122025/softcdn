import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';
@Entity({ name: 'questionmarkschemehistory' }) // Question Marking Scheme History Entity
export class QuestionsMarkingSchemeHistory {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'int', nullable: true })
  qId!: number;

  @Column({ type: 'longtext', nullable: true })
  expectedFromat!: string;

  @Column({ type: 'json', nullable: true })
  markingScheme!: object | null;

  @Column({ type: 'int', nullable: true })
  revision!: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate!: Date;
}
