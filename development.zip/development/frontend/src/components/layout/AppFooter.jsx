import React from 'react'
import { FaQuestionCircle, FaRegCopyright } from 'react-icons/fa'

const AppFooter = () => {
  return (
    // <footer className="bg-light py-2 border-top border-dark">
    //   <div className="container">
    //     <div className="row">
    //       <div className="col">
    //         <span>&copy; Sanskrit-e-solutions</span>
    //       </div>
    //       <div className="col text-end">
    //         <FaQuestionCircle className="me-1" />
    //         <span>Help</span>
    //       </div>
    //     </div>
    //   </div>
    // </footer>
    <footer className="bg-white py-2 border-top">
      <div className="container">
        <div className="row">
          <div className="col d-flex align-items-center">
            <FaRegCopyright className="me-1 text-grey-400" />
            <span className='text-grey-400'>Sanskrit-e-solutions</span>
          </div>
          <div className="col d-flex align-items-center justify-content-end">
            <FaQuestionCircle className="me-1 text-grey-400" />
            <span className='text-grey-400'>Help</span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default React.memo(AppFooter)
