import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import apiClient from '../../api/apiService'
import useAuth from '../../context/AuthContext'

const UserQuestions = () => {
  const [data, setData] = useState([])
  const [expandedAccordions, setExpandedAccordions] = useState([])
  // const [navbarCollapsed, setNavbarCollapsed] = useState(true);
  const [filters, setFilters] = useState({
    type: '',
    subject: '',
    class: '',
    difficulty: '',
    skill: '',
    learningObjective: '',
  })

  const { user } = useAuth()

  useEffect(() => {
    const userId = user.id
    apiClient
      .get('/school/cordsQues', { params: { id: userId }})
      .then((response) => {
        setData(response.data)
        // console.log(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error)
      })
  }, [])

  const toggleAccordion = (accordionId) => {
    setExpandedAccordions((prevAccordions) =>
      prevAccordions.includes(accordionId)
        ? prevAccordions.filter((id) => id !== accordionId)
        : [...prevAccordions, accordionId]
    )
  }

  // const toggleNavbar = () => {
  //   setNavbarCollapsed((prevCollapsed) => !prevCollapsed);
  // };

  const handleFilterChange = (filterType, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterType]: value,
    }))
  }

  const filteredData = data.filter(
    (item) =>
      (!filters.type || item.type === filters.type) &&
      (!filters.subject || item.subject === filters.subject) &&
      (!filters.class || item.class === filters.class) &&
      (!filters.difficulty || item.difficulty === filters.difficulty) &&
      (!filters.skill || item.skill === filters.skill) &&
      (!filters.learningObjective || item.learningObjective === filters.learningObjective)
  )

  return (
    <div className="container-fluid">
      <div className="row flex-nowrap">
        <div className="col-auto px-0 border-end border-top">
          <div id="sidebar" className="collapse collapse-horizontal">
            <div id="sidebar-nav" className="list-group  rounded-0 text-sm-start ">
              <div className="form ps-3 pe-3 pt-3">
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="questionType" className="pb-2">
                      Type:
                      <select
                        className="form-select form-select-sm"
                        value={filters.type}
                        onChange={(e) => handleFilterChange('type', e.target.value)}
                      >
                        <option value="">Select Type</option>
                        <option value="multipleChoice">Multiple Choice</option>
                        <option value="trueFalse">True/False</option>
                        <option value="oneword">one word</option>
                        <option value="fillintheblank">fill in the blank</option>
                        <option value="textquestion">text question</option>
                        <option value="Matchthefollowing">Match the following</option>
                        <option value="unseenpassage">unseen passage</option>
                        <option value="imagebased">image based</option>
                        {/* ... options ... */}
                      </select>
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="subject" className="pb-2">
                      Subject:
                      <select
                        className="form-select form-select-sm"
                        value={filters.subject}
                        onChange={(e) => handleFilterChange('subject', e.target.value)}
                      >
                        <option value="">Select Subject</option>
                        <option value="Math">Math</option>
                        <option value="Science">Science</option>
                        <option value="Hindi">Hindi</option>
                        <option value="English">English</option>
                        <option value="SocialScience">Social Science</option>
                        <option value="Sanskrit">Sanskrit</option>
                        <option value="French">French</option>
                        {/* Add more subjects here */}
                      </select>
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="class" className="pb-2">
                      Class:
                      <select
                        className="form-select form-select-sm"
                        value={filters.class}
                        onChange={(e) => handleFilterChange('class', e.target.value)}
                      >
                        <option value="">Select Class Level</option>
                        <option value="class1">Class 1</option>
                        <option value="class2">Class 2</option>
                        <option value="class3">Class 3</option>
                        <option value="class4">Class 4</option>
                        <option value="class5">Class 5</option>
                        <option value="class6">Class 6</option>
                        <option value="class7">Class 7</option>
                        <option value="class8">Class 8</option>
                        <option value="class9">Class 9</option>
                        <option value="class10">Class 10</option>
                        <option value="class11">Class 11</option>
                        <option value="class12">Class 12</option>
                        {/* ... options ... */}
                      </select>
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="difficulty" className="pb-2">
                      Difficulty Level:
                      <select
                        className="form-select form-select-sm"
                        value={filters.difficulty}
                        onChange={(e) => handleFilterChange('difficulty', e.target.value)}
                      >
                        <option value="">Select Difficulty Level</option>
                        <option value="High">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                        {/* ... options ... */}
                      </select>
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="skill" className="pb-2">
                      Skill:
                      <select
                        className="form-select form-select-sm"
                        value={filters.skill}
                        onChange={(e) => handleFilterChange('skill', e.target.value)}
                      >
                        <option value="">Select Skill</option>
                        <option value="Memory">Memory</option>
                        <option value="Resoning">Reasoning</option>
                        <option value="Arithmatic">Arithmatic</option>
                        {/* ... options ... */}
                      </select>
                    </label>
                  </div>
                </div>
                <div className="row">
                  <div className="mb-3">
                    <label htmlFor="objective" className="pb-2">
                      Learning Objective:
                      <select
                        className="form-select form-select-sm"
                        value={filters.learningObjective}
                        onChange={(e) => handleFilterChange('learningObjective', e.target.value)}
                      >
                        <option value="">Select Learning objective</option>
                        <option value="Creating new knowledge">
                          Creating new knowledge (Cognitive)
                        </option>
                        <option value="Developing feelings and emotions">
                          Developing feelings and emotions (Affective)
                        </option>
                        <option value="Enhancing physical and manual skills">
                          Enhancing physical and manual skills (Psychomotor)
                        </option>
                        {/* ... options ... */}
                      </select>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <main className="col ps-md-2 pt-2">
          {/* <a href="#" data-bs-target="#sidebar" data-bs-toggle="collapse" className="border rounded-3 m-3 p-1 text-decoration-none">
            <i className="bi bi-funnel-fill bi-lg py-2 p-1" />
          </a> */}
          <div className="row">
            <div className="col-md-12">
              <div className="container-fluid pt-5">
                <div className="accordion" id="accordionExample">
                  {filteredData.map((item, index) => (
                    <div className="accordion-item" key={index}>
                      <h2 className="accordion-header" id={`heading${index}`}>
                        <div className="row">
                          <div className="col">
                            <button
                              className={`accordion-button ${
                                expandedAccordions.includes(index) ? '' : 'collapsed'
                              }`}
                              type="button"
                              onClick={() => toggleAccordion(index)}
                            >
                              Question Title: {item.quesType}
                            </button>
                          </div>
                        </div>
                      </h2>
                      <div
                        className={`accordion-collapse collapse ${
                          expandedAccordions.includes(index) ? 'show' : ''
                        }`}
                        aria-labelledby={`heading${index}`}
                      >
                        <div className="accordion-body ">
                          <div className="row">
                            <div className="col-4">
                              <p>Type: {item.quesType}</p>
                            </div>
                            <div className="col-4">
                              <p>Subject: {item.subject}</p>
                            </div>
                            <div className="col-4">
                              <p>Class Level: {item.class}</p>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-4">
                              <p>Difficulty: {item.difficulty}</p>
                            </div>
                            <div className="col-4">
                              <p>Skill: {item.skill}</p>
                            </div>
                            <div className="col-4">
                              <p>Learning Objective: {item.learnObj}</p>
                            </div>
                          </div>
                          <div className="row">
                            <div className="col-4">
                              <p>Question: {item.question}</p>
                            </div>
                          </div>
                          {/* <p>Status: {status || item.status}</p> */}
                          <Link to={`/Approval-B/${item.id}`}>
                            <div className="row">
                              <div className="col-12 text-end">
                                <button
                                  className="btn btn-primary"
                                  type="button"
                                  onClick={() => console.log('Clicked item:', item)}
                                >
                                  Highlight
                                </button>
                              </div>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
export default UserQuestions
