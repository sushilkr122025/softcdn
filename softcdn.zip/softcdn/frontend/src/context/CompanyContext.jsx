import { createContext, useContext } from 'react';

export const CompanyContext = createContext();

export const useCompany = () => useContext(CompanyContext);

export default useCompany;


