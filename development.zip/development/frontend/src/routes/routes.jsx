import React from 'react'

const QuestionType = React.lazy(() => import('../pages/question/QuestionType'))
const QuestionGenration = React.lazy(() => import('../pages/question/QuestionGeneration'))
const StudentInformation = React.lazy(() => import('../pages/StudentInformation'))
const UserRegistration = React.lazy(() => import('../pages/UserRegistration'))
const MakePaper1 = React.lazy(() => import('../pages/question/MakePaper-A'))
const Question = React.lazy(() => import('../pages/question/Question'))
const QuestionPreview = React.lazy(() => import('../pages/question/QuestionPreview'))
const PreviewContent = React.lazy(() => import('../pages/question/PreviewContent'))
const QuestionPaper = React.lazy(() => import('../pages/question/QuestionPaper'))
const Approval1 = React.lazy(() => import('../pages/question/Approval-A'))
const Manupliate = React.lazy(() => import('../pages/question/Manupliate'))
const Approval2 = React.lazy(() => import('../pages/question/Approval-B'))
const MakePaper2 = React.lazy(() => import('../pages/question/MakePaper-B'))
const admin = React.lazy(() => import('../pages/admin'))
const Answersheet = React.lazy(() => import('../pages/answer/AnswerSheet'))
const Grade = React.lazy(() => import('../pages/report/Grade'))
const AlertCriteria = React.lazy(() => import('../pages/report/Alertcreteria'))
const ReportAdmin = React.lazy(() => import('../pages/report/Reportadmin'))
const Registration = React.lazy(() => import('../pages/Registration'))
const ReportCard = React.lazy(() => import('../pages/report/Reportcard'))
const TeacherReport = React.lazy(() => import('../pages/report/TeacherReport'))
const Template = React.lazy(() => import('../components/question/Template'))
const Gallery = React.lazy(() => import('../pages/gallery/Gallery'))
const Canvas = React.lazy(() => import('../pages/gallery/Fabric'))
const StudentRegistration = React.lazy(() => import('../pages/StudentRegister'))
const Users = React.lazy(() => import('../pages/Users'))
const Student = React.lazy(() => import('../pages/Student'))
const SectionReport = React.lazy(() => import('../pages/report/SectionReport'))
const UserPermission = React.lazy(() => import('../pages/UserPermission'))
const Panel = React.lazy(() => import('../pages/question/Panel'))
const Panel2 = React.lazy(() => import('../pages/question/Panel copy'))
const RollBlock = React.lazy(() => import('../components/RollBlock'))
const Marksheet = React.lazy(()=> import('../components/marksheet'))
const SubjectClassAssign = React.lazy(()=> import('../pages/SubjectClassAssign'))
const UserApproval = React.lazy(()=> import('../pages/UserApproval'))
const PanelItem = React.lazy(()=> import('../pages/question/PanelItem'))
const UserProfile = React.lazy(()=> import('../pages/UserProfile'))
const GlobalSetting = React.lazy(()=> import('../components/setting/GlobalSetting'))
const QuestionMarkScheme = React.lazy(()=> import('../pages/question/QuestionMarkScheme'))
const QuestionHistory = React.lazy(()=> import('../pages/question/QuestionHistory'))
const QuesTemplate = React.lazy(()=> import('../components/question/QuesTemplate'))
const Dashboard = React.lazy(()=> import('../pages/Dashboard'))
const Report = React.lazy(()=> import('../pages/report/Report'))

const routes = [
  { path: '/question/paneling', name: 'PanelItem', element: PanelItem, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC']},
  { path: '/question/panel/:pqid', name: 'Panel', element: Panel, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/question/panel2', name: 'Panel', element: Panel2, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/question/type', name: 'Question Type', element: QuestionType, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/question/history', name: 'Question User', element: QuestionHistory, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/questionGeneration', name: 'Question Generation-A', element: QuestionGenration, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/questionPreview', name: 'Question Preview', element: QuestionPreview, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/PreviewContent/:paperId?', name: 'Question PreviewContent', element: PreviewContent, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/questionGeneration/:qid', name: 'Question Generation with context or update question', element: QuestionGenration, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/question/mkscheme/:qid', name: 'Question Marking Scheme with context or update question', element: QuestionMarkScheme, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/StudentInformation', name: 'StudentInformation', element: StudentInformation, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/users/:userid', name: 'UserRegistration', element: UserRegistration, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/users/profile/:userid', name: 'UserProfile', element: UserProfile, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/users/profile', name: 'UserProfile', element: UserProfile, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/Question', name: 'Question', element: Question, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/QuestionPaper', name: 'Question Paper', element: QuestionPaper, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/Manupilate', name: 'Manupilate', element: Manupliate, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/QuestionPaper/MakePaper-A', name: 'MakePaper-A', element: MakePaper1, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/MakePaper-B', name: 'MakePaper-B', element: MakePaper2, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/Approval-A', name: 'Approval-A', element: Approval1, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/Approval-B/:id', name: 'Approval-B', element: Approval2, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/AnswerSheet', name: 'Answer Sheet', element: Answersheet, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  // { path: '/sectionreport', name: 'Admin Report', element: SectionReport },
  { path: '/reportCard', name: 'Report Card', element: ReportCard, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/Template', name: 'Question Template', element: Template, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/gallery', name: 'Gallery', element: Gallery, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/canvas', name: 'Canvas', element: Canvas, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/users', name: 'ACADEMIC', element: Users, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/student', name: 'Student', element: Student, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/rollblock/:paperId/:section?', name: 'Roll Number', element: RollBlock, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/marksheet', name: 'Marksheet', element: Marksheet, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  { path: '/question/template/:paperId', name: 'Question Template', element: QuesTemplate, allowedRoles: ['ADMINISTRATIVE', 'ACADEMIC'] },
  
  { path: '/admin', name: 'ADMINISTRATIVE', element: admin, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/alertCriteria', name: 'Alert Criteria', element: AlertCriteria, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/grade', name: 'Grade', element: Grade, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/StudentRegistration', name: 'StudentInformation', element: StudentRegistration, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/users/add', name: 'UserRegistration', element: UserRegistration, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/users/roles/:userid', name: 'UserPermission', element: UserPermission, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/reportAdmin', name: 'Admin Report', element: ReportAdmin, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/users/assign/:userid', name: 'SubjectClassAssign', element: SubjectClassAssign, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/registration', name: 'Registration', element: Registration, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/users/setrule/:userid', name: 'UserApproval', element: UserApproval, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/teacherReport', name: 'Teacher Report', element: TeacherReport, allowedRoles: ['ADMINISTRATIVE'] },
  { path: '/setting', name: 'Global Setting', element: GlobalSetting, allowedRoles: ['ADMINISTRATIVE'] },
  { path: "/dashboard", name: 'Dashboard', element: Dashboard, allowedRoles: ["ADMINISTRATIVE", "ACADEMIC"]},
  { path: "/sectionreport", name: 'Reports', element: SectionReport, allowedRoles: ["ADMINISTRATIVE", "ACADEMIC"]},
  { path: "/report", name: 'Reports', element: Report, allowedRoles: ["ADMINISTRATIVE", "ACADEMIC"]},
]
export default routes
