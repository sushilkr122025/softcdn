import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Link } from 'react-router-dom';
import { FaEllipsisVertical } from "react-icons/fa6";
import apiClient from '../api/apiService';
import student from '../assets/images/student-grey.svg';
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import './admin.css';
import { PiFilePdfLight, PiMicrosoftWordLogoLight } from "react-icons/pi";
import { FaFileWord } from "react-icons/fa";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Document, Packer, Paragraph, Table, TableCell, TableRow, WidthType, TextRun } from "docx";

function Student() {
  const [userData, setUserData] = useState([]);
  const [classes, setClasses] = useState('');
  const [classData, setClassData] = useState([]);
  const [section, setSection] = useState('');
  const [sectionData, setSectionData] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [pageSize, setPageSize] = useState(10);
  const [debouncedSearchText, setDebouncedSearchText] = useState('');

  const [columnVisibilityModel, setColumnVisibilityModel] = useState(
    () => JSON.parse(localStorage.getItem("studentColumnVisibility")) || {}
  );

  const AllStudents = async () => {
    try {
      apiClient
        .get('/user/student', {
          params: {
            class: classes,
            section: section,
          }
        })
        .then((response) => {
          setUserData(response.data)
        })
        .catch((error) => {
          console.error(error)
        })
    } catch (error) {
      console.error('Error fetching sections:', error);
    }
  };

  useEffect(() => {
    AllStudents();
    apiClient.get('/store/classes').then((res) => setClassData(res.data)).catch((err) => console.error('Class fetch error', err));
    apiClient
      .get('/store/section')
      .then((response) => {
        // console.log(response.data);
        setSectionData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })
  }, [])

  const handleColumnVisibilityChange = (newModel) => {
    setColumnVisibilityModel(newModel);
    localStorage.setItem("studentColumnVisibility", JSON.stringify(newModel));
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();

    doc.text("Student List", 14, 10);

    const tableColumn = columns
      .filter(col => col.field !== "action")
      .map(col => col.headerName);

    const tableRows = filteredRows.map(row =>
      columns
        .filter(col => col.field !== "action")
        .map(col => {
          if (col.valueGetter) return col.valueGetter({ row });
          if (col.renderCell) return row[col.field] === 1 ? "Active" : "Inactive";
          return row[col.field] || "";
        })
    );

    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 20,
    });

    doc.save("Student.pdf");
  };

  const handleExportWord = async () => {
    const tableRows = [];

    const headerCells = columns
      .filter(col => col.field !== "action")
      .map(col => new TableCell({
        children: [new Paragraph({ text: col.headerName, bold: true })],
      }));
    tableRows.push(new TableRow({ children: headerCells }));

    filteredRows.forEach(row => {
      const cells = columns
        .filter(col => col.field !== "action")
        .map(col => {
          let value = "";
          if (col.valueGetter) value = col.valueGetter({ row });
          else if (col.renderCell) value = row[col.field] === 1 ? "Active" : "Inactive";
          else value = row[col.field] || "";

          return new TableCell({
            width: { size: 100, type: WidthType.PERCENTAGE },
            children: [new Paragraph(String(value))],
          });
        });
      tableRows.push(new TableRow({ children: cells }));
    });

    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [new TextRun({ text: "Student List", bold: true, size: 28 })],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: tableRows,
          }),
        ],
      }],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, "Students.docx");
  };

  const handleExportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(userData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], { type: "application/octet-stream" });
    saveAs(data, "Students.xlsx");
  };

  const columns = [
    { field: 'id', headerName: 'ID', flex: 1 },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'class', headerName: 'Class', flex: 1 },
    { field: 'section', headerName: 'Section', flex: 1 },
    { field: 'rollNo', headerName: 'Roll No', flex: 1 },
    {
      field: 'dateOfBirth',
      headerName: 'DOB',
      valueGetter: (params) => {
        if (!params?.row?.dateOfBirth) return 'N/A';
        return new Date(params.row.dateOfBirth).toLocaleDateString();
      }, flex: 1
    },
    { field: 'emailId', headerName: 'Email', flex: 1 },
    { field: 'contactNumber', headerName: 'Contact', flex: 1 },
    { field: 'gender', headerName: 'Gender', flex: 1 },
    {
      field: 'status',
      headerName: 'Status'
      , flex: 1,
      renderCell: (params) =>
        params.row.dmlType === 'I'
          ? <span className="badge-active rounded-pill">Active</span>
          : <span className="badge-inactive rounded-pill">Inactive</span>
    },
    {
      field: 'action',
      headerName: 'Action',
      flex: 1,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <div>
          <button type='button' className='btn btn-sm border-0' data-bs-toggle="dropdown" aria-expanded="false">
            <FaEllipsisVertical className='text-primary' />
          </button>
          <ul className='dropdown-menu p-2 bg-white'>
            <li><a href={`/UserRegistration?id=${params.row.id}`} className='dropdown-item'>Edit Details</a></li>
            <li><a href={`roles?id=${params.row.id}`} className='dropdown-item'>Set Roles</a></li>
          </ul>
        </div>
      ),
    },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchText(searchText);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchText]);

  const filteredRows = userData.filter((row) =>
    row?.name?.toLowerCase().includes(debouncedSearchText.toLowerCase())
  );

  return (
    <section id="admin">
      <div className="container-fluid">
        <div className="row align-items-center">
          <div className="col-6 py-3 d-flex align-items-center">
            <img src={student} alt="student" style={{ width: "25px" }} />
            <h5 className='text-grey-400 mb-0 ms-3'>Student</h5>
          </div>
          <div className="col-6 d-flex justify-content-end align-items-center">
            <Link to="/StudentRegistration">
              <button className='btn btn-sm btn-primary me-2'>Add Student</button>
            </Link>
            <div>
              <button className="btn btn-sm btn-primary border-0" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                Export
              </button>
              <ul className="dropdown-menu mt-2">
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportPDF}><PiFilePdfLight className='me-2' /><span>PDF</span></li>
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportWord}><FaFileWord className='me-2' /><span>Word</span></li>
                <li className='text-center dropdown-item d-flex align-items-center cursor-pointer' onClick={handleExportExcel}><PiMicrosoftWordLogoLight className='me-2' /><span>Excel</span></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-lg-2 col-md-3 col-sm-4 col-6 mb-2">
            <select id="class" className="form-select"
              onChange={(e) => { setClasses(e.target.value); AllStudents(); }}>
              <option value="">Class</option>
              {classData.map((c) => (
                <option key={c.id} value={c.class}>{c.class}</option>
              ))}
            </select>
          </div>
          <div className="col-lg-2 col-md-3 col-sm-4 col-6 mb-2">
            <select id="section" className="form-select"
              onChange={(e) => { setSection(e.target.value); AllStudents(); }}>
              <option value="">Section</option>
              {sectionData.map((s) => (
                <option key={s.id} value={s.section}>{s.section}</option>
              ))}
            </select>
          </div>
          <div className="col-12 col-md-2 ms-auto">
            <input
              type="text"
              className="form-control form-control-sm"
              placeholder="Search..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>
        </div>

        {/* DataGrid */}
        <div style={{ height: 600, width: '100%' }}>
          <DataGrid
            className="custom-data-grid"
            rows={filteredRows}
            columns={columns}
            getRowId={(row) => row.id || row.Id || row.studentId}
            pageSize={pageSize}
            onPageSizeChange={(newSize) => setPageSize(newSize)}
            pageSizeOptions={[10, 25, 50, 100]}
            // checkboxSelection
            disableRowSelectionOnClick
            initialState={{ pagination: { paginationModel: { pageSize: 10, page: 0 } } }}
            columnVisibilityModel={columnVisibilityModel}
            onColumnVisibilityModelChange={handleColumnVisibilityChange}
          />

        </div>
      </div>
    </section>
  );
}

export default Student;
