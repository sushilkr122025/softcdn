import React, { useState, useEffect } from 'react'
// import  blankDataImage from 'src/assets/images/questionPaper.png'
import { LuFileQuestion } from 'react-icons/lu'
import { useSearchParams } from 'react-router-dom'
import './AnswerSheet.css'
import apiClient from '../../api/apiService'
import useAuth from '../../context/AuthContext'

// import { useNavigate } from 'react-router-dom'
const QuestionPaper = () => {
  const [params] = useSearchParams()
  const id = params.get('updateid')

  const [edit, setEdit] = useState(id)
  const [editData, setEditData] = useState()

  const [classData, setClassData] = useState([])
  const [SubjectData, setSubjectData] = useState([])
  const [SubDomainData, setSubDomainData] = useState([])
  const [sectionNo, setSectionNo] = useState(0)

  const [data, setData] = useState()
  const [errors, setErrors] = useState({})

  useEffect(() => {
    if (edit !== null) {
      apiClient
        .post('/api/examDetails', { updateId: edit })
        .then((response) => {
          // console.log(response.data);
          setEditData(response.data)
        })
        .catch((error) => {
          console.error('Error fetching exam data:', error.response)
        })
    }

    apiClient
      .get('/store/subject')
      .then((response) => {
        // console.log(response.data);
        setSubjectData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        // console.log(response.data);
        setClassData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching class data:', error)
      })
  }, [])

  const handleSubject = (val) => {
    apiClient
      .post('/api/subDomain', { subject: val })
      .then((response) => {
        setSubDomainData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)

    const errors = validateForm(payload)
    if (Object.keys(errors).length > 0) {
      setErrors(errors)
      return
    }

    setData(payload)
  }

  const validateForm = (data) => {
    const errors = {}

    if (!data.examName) {
      errors.examName = 'Exam name is required'
    }

    if (!data.class) {
      errors.class = 'Class is required'
    }

    if (!data.subject) {
      errors.subject = 'Subject is required'
    }

    if (!data.examDate) {
      errors.examDate = 'Date is required'
    }

    if (!data.sectionNo || data.sectionNo < 1 || data.sectionNo > 8) {
      errors.sectionNo = 'Section no must be between 1 and 8'
    }

    // validate question sections
    for (let i = 1; i <= data.sectionNo; i++) {
      const quesType = data[`quesType${i}`]
      const questionSection = data[`questionSection${i}`]
      const marksSection = data[`marksSection${i}`]

      if (!quesType) {
        errors[`quesType${i}`] = 'Question type is required'
      }

      if (!questionSection || questionSection < 1 || questionSection > 50) {
        errors[`questionSection${i}`] = 'No. of questions must be between 1 and 10'
      }

      if (!marksSection || marksSection < 0 || marksSection > 10) {
        errors[`marksSection${i}`] = 'Marks for question must be between 1 and 10'
      }
    }

    console.log(errors)

    return errors
  }

  return (
    <>
      <section className="top-header sky">
        <div className="row mx-0 gx-3 align-items-center header">
          <div className="col-lg-7 col-md-12 col-sm-12 mb-3 mb-md-3 ">
            <div className="header-icon">
              <div className="breadcrumb-icon me-2">
                <LuFileQuestion />
              </div>
              <h5 className="mb-0 fw-normal pt-1 ">Answer Sheet</h5>
            </div>
          </div>
        </div>
      </section>
      {(data || editData) && (
        <AnsKeySet
          anskeyData={data}
          subjects={SubjectData}
          subdomains={SubDomainData}
          classes={classData}
          update={editData}
        />
      )}
      {!data && !editData && (
        <div className="container">
          <h5>Exam Details</h5>
          <form action="" method="post" autoComplete="off" onSubmit={handleSubmit}>
            <div className="row gx-3 align-items-center mb-3">
              <div className="col-8 col-md col-lg-2 mb-3">
                <label htmlFor="examName" className="form-label required">
                  Name
                </label>
                <input type="text" className="form-control" name="examName" id="examName" />
                {errors.examName && <div className="text-danger">{errors.examName}</div>}
              </div>
              <div className="col-8 col-md col-lg-2 mb-3">
                <label htmlFor="class" className="form-label required">
                  Class
                </label>
                <select className="form-select" name="class" id="class">
                  <option value="">Select</option>
                  {classData.map((row) => (
                    <option key={row.id} value={row.class}>
                      {row.class}
                    </option>
                  ))}
                </select>
                {errors.class && <div className="text-danger">{errors.class}</div>}
              </div>
              <div className="col-8 col-md col-lg-2 mb-3">
                <label htmlFor="subject" className="form-label required">
                  Subject
                </label>
                <select
                  className="form-select"
                  name="subject"
                  id="subject"
                  onChange={(e) => handleSubject(e.target.value)}
                >
                  <option value="">Select</option>
                  {SubjectData.map((row) => (
                    <option key={row.id} value={row.id}>
                      {row.subject}
                    </option>
                  ))}
                </select>
                {errors.subject && <div className="text-danger">{errors.subject}</div>}
              </div>
              <div className="col-8 col-md col-lg-2 mb-3">
                <label htmlFor="examDate" className="form-label">
                  Date
                </label>
                <input type="date" className="form-select" name="examDate" id="examDate" />
                {errors.examDate && <div className="text-danger">{errors.examDate}</div>}
              </div>
              <div className="col-8 col-md col-lg-2 mb-3">
                <label htmlFor="sectionNo" className="form-label">
                  Section
                </label>
                <div className="input-group">
                  <button
                    type="button"
                    className="btn lq-sky-color input-group-text"
                    onClick={() => setSectionNo(Math.max(0, sectionNo - 1))}
                  >
                    -
                  </button>
                  <input
                    type="text"
                    className="form-control text-center"
                    name="sectionNo"
                    id="sectionNo"
                    value={sectionNo}
                    onChange={(e) => setSectionNo(e.target.value)}
                  />
                  <button
                    type="button"
                    className="btn lq-sky-color input-group-text"
                    onClick={() => setSectionNo(Math.min(8, sectionNo + 1))}
                  >
                    +
                  </button>
                </div>
                {errors.sectionNo && <div className="text-danger">{errors.sectionNo}</div>}
              </div>
            </div>
            <div className="row">
              {Array.from({ length: sectionNo }, (_, index) => (
                <InputGroups subdomain={SubDomainData} key={index} i={index + 1} errors={errors} />
              ))}
            </div>
            <button type="submit" className="btn lq-sky-color">
              Submit
            </button>
          </form>
        </div>
      )}
    </>
  )
}
export default QuestionPaper

function InputGroups(data) {
  const [count, setCount] = useState(0)
  const [marks, setMarks] = useState(0)

  const sErrors = data.errors
  const marksError = sErrors[`marksSection${data.i}`]
  const quesError = sErrors[`questionSection${data.i}`]

  return (
    <div className="col-lg-6">
      <section className="bg-white p-3 mb-4 shadow-sm">
        <h5 className="mb-3">Section {data.i}</h5>
        <div className="row mb-3 align-items-center">
          <label htmlFor={`quesType${data.i}`} className="col-6 form-label mb-0">
            Question Type
          </label>
          <div className="col-6">
            <select
              name={`quesType${data.i}`}
              id={`quesType${data.i}`}
              className="form-select form-select-sm"
            >
              <option value="multipleChoice">MCQ</option>
              <option value="trueFalse">True / False</option>
              <option value="CR">Constructed Response</option>
            </select>
          </div>
        </div>
        <div className="row mb-3 align-items-center">
          <label htmlFor={`questionSection${data.i}`} className="col-6 form-label mb-0">
            No. of questions
          </label>
          <div className="col-6">
            <div className="input-group input-group-sm">
              <button
                type="button"
                className="btn lq-sky-color input-group-text"
                onClick={() => setCount(Math.max(0, count - 1))}
              >
                -
              </button>
              <input
                type="text"
                className="form-control text-center"
                name={`questionSection${data.i}`}
                id={`questionSection${data.i}`}
                value={count}
                onChange={(e) => setCount(e.target.value)}
              />
              <button
                type="button"
                className="btn lq-sky-color input-group-text"
                onClick={() => setCount(Math.min(50, count + 1))}
              >
                +
              </button>
            </div>
            {quesError && <div className="text-danger">{quesError}</div>}
          </div>
        </div>
        <div className="row mb-3 align-items-center">
          <label htmlFor={`marksSection${data.i}`} className="col-6 form-label mb-0">
            Marks for question
          </label>
          <div className="col-6">
            <div className="input-group input-group-sm">
              <button
                type="button"
                className="btn lq-sky-color input-group-text"
                onClick={() => setMarks(Math.max(0, marks - 1))}
              >
                -
              </button>
              <input
                type="text"
                className="form-control text-center"
                name={`marksSection${data.i}`}
                id={`marksSection${data.i}`}
                value={marks}
                onChange={(e) => setMarks(e.target.value)}
              />
              <button
                type="button"
                className="btn lq-sky-color input-group-text"
                onClick={() => setMarks(Math.min(20, marks + 1))}
              >
                +
              </button>
            </div>
            {marksError && <div className="text-danger">{marksError}</div>}
          </div>
        </div>
        {data.subdomain.length > 0 && (
          <div className="row mb-3 align-items-center">
            <label htmlFor={`subdomain${data.i}`} className="col-6 form-label mb-0">
              Sub Domain
            </label>
            <div className="col-6">
              <select
                name={`subdomain${data.i}`}
                id={`subdomain${data.i}`}
                className="form-select form-select-sm"
              >
                <option value="">Select</option>
                {data.subdomain.map((e, i) => (
                  <option key={i} value={e.id}>
                    {e.Subject}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}
      </section>
    </div>
  )
}

function AnsKeySet(data) {
  const { user } = useAuth()

  const [subDomData, setSubDomData] = useState([])
  const [classData, setClassData] = useState(data.classes)
  const [SubjectData, setSubjectData] = useState(data.subjects)
  const [subdomain, setSubdomain] = useState(data.subdomains)

  // const {user} = useAuth()

  const key = data.update ? data.update : data.anskeyData
  console.log(key)

  const subject = data.update ? key.examDetail.subject : key.subject
  useEffect(() => {
    apiClient
      .post('/api/subDomain', { subject: subject })
      .then((response) => {
        setSubDomData(response.data)
        // console.log(response.data);
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })
  }, [subject])

  // const navigator = useNavigate()

  const section = data.update
    ? Math.max(...data.update.questionData.map((e, i) => e.sectionNo))
    : key.sectionNo

  let content = []
  if (!data.update) {
    for (let i = 1; i <= section; i++) {
      content.push(<h5 key={i}>Section {i}</h5>)

      let qKey = `questionSection${i}`
      let tKey = `quesType${i}`
      let hasDomain = `subdomain${i}` in key
      let subdomainDefault = `subdomain${i}`
      let marksDefault = `marksSection${i}`

      let subDomainLoop

      for (let j = 1; j <= key[qKey]; j++) {
        if (hasDomain && subDomData.length > 0) {
          subDomainLoop = (
            <select
              name={`subdomain${i}${j}`}
              id={`subdomain${i}${j}`}
              className="form-select form-select-sm mb-3 w-auto subdomain"
              defaultValue={key[subdomainDefault]}
            >
              <option value="">Select</option>
              {subDomData.map((e, i) => (
                <option key={i} value={e.id}>
                  {e.Subject}
                </option>
              ))}
            </select>
          )
        }
        if (key[tKey] === 'multipleChoice') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-3">
                <span className="me-3">Q{j}</span>
                <input type="radio" id={`optionA${i}${j}`} name={`optMCQ${i}${j}`} value={'optA'} />
                <label htmlFor={`optionA${i}${j}`}>
                  <span className="circle">A</span>
                </label>
                <input type="radio" id={`optionB${i}${j}`} name={`optMCQ${i}${j}`} value={'optB'} />
                <label htmlFor={`optionB${i}${j}`}>
                  <span className="circle">B</span>
                </label>
                <input type="radio" id={`optionC${i}${j}`} name={`optMCQ${i}${j}`} value={'optC'} />
                <label htmlFor={`optionC${i}${j}`}>
                  <span className="circle">C</span>
                </label>
                <input type="radio" id={`optionD${i}${j}`} name={`optMCQ${i}${j}`} value={'optD'} />
                <label htmlFor={`optionD${i}${j}`}>
                  <span className="circle">D</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else if (key[tKey] === 'trueFalse') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-3">
                <span className="me-3">Q{j}</span>
                <input type="radio" id={`optionT${i}${j}`} name={`optTF${i}${j}`} value={'true'} />
                <label htmlFor={`optionT${i}${j}`}>
                  <span className="circle">T</span>
                </label>
                <input type="radio" id={`optionF${i}${j}`} name={`optTF${i}${j}`} value={'false'} />
                <label htmlFor={`optionF${i}${j}`}>
                  <span className="circle">F</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <span className="me-3 mb-3">Q{j}</span>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        }
      }
    }
  } else {
    for (let i = 1; i <= section; i++) {
      content.push(<h5 key={i}>Section {i}</h5>)

      let qKey = `questionSection${i}`
      let tKey = `quesType${i}`
      let hasDomain = `subdomain${i}` in key
      let subdomainDefault = `subdomain${i}`
      let marksDefault = `marksSection${i}`

      let subDomainLoop

      for (let j = 1; j <= key[qKey]; j++) {
        if (hasDomain && subDomData.length > 0) {
          subDomainLoop = (
            <select
              name={`subdomain${i}${j}`}
              id={`subdomain${i}${j}`}
              className="form-select form-select-sm mb-3 w-auto subdomain"
              defaultValue={key[subdomainDefault]}
            >
              <option value="">Select</option>
              {subDomData.map((e, i) => (
                <option key={i} value={e.id}>
                  {e.Subject}
                </option>
              ))}
            </select>
          )
        }
        if (key[tKey] === 'multipleChoice') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-3">
                <span className="me-3">Q{j}</span>
                <input type="radio" id={`optionA${i}${j}`} name={`optMCQ${i}${j}`} value={'optA'} />
                <label htmlFor={`optionA${i}${j}`}>
                  <span className="circle">A</span>
                </label>
                <input type="radio" id={`optionB${i}${j}`} name={`optMCQ${i}${j}`} value={'optB'} />
                <label htmlFor={`optionB${i}${j}`}>
                  <span className="circle">B</span>
                </label>
                <input type="radio" id={`optionC${i}${j}`} name={`optMCQ${i}${j}`} value={'optC'} />
                <label htmlFor={`optionC${i}${j}`}>
                  <span className="circle">C</span>
                </label>
                <input type="radio" id={`optionD${i}${j}`} name={`optMCQ${i}${j}`} value={'optD'} />
                <label htmlFor={`optionD${i}${j}`}>
                  <span className="circle">D</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else if (key[tKey] === 'trueFalse') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-3">
                <span className="me-3">Q{j}</span>
                <input type="radio" id={`optionT${i}${j}`} name={`optTF${i}${j}`} value={'true'} />
                <label htmlFor={`optionT${i}${j}`}>
                  <span className="circle">T</span>
                </label>
                <input type="radio" id={`optionF${i}${j}`} name={`optTF${i}${j}`} value={'false'} />
                <label htmlFor={`optionF${i}${j}`}>
                  <span className="circle">F</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <span className="me-3 mb-3">Q{j}</span>
              <input
                type="number"
                className="form-control form-control-sm w-auto mb-3 me-2 marks"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        }
      }
    }
  }

  const handleAnsKey = (e) => {
    e.preventDefault()

    const queryData = {}

    const row = data.anskeyData

    const tId = user.id
    // const tId = undefined;
    console.log(tId)

    const questionData = []

    const questions = document.querySelectorAll('.questionItem')

    let maxMarks = 0

    questions.forEach((element) => {
      const quesDataObj = {}
      quesDataObj['tId'] = tId
      quesDataObj['subject'] = row.subject
      quesDataObj['class'] = row.class
      quesDataObj['subdomain'] = element.querySelector('select.subdomain')
        ? element.querySelector('select.subdomain').value
        : null
      quesDataObj['marks'] = element.querySelector('input.marks').value
      quesDataObj['quesType'] = element.getAttribute('data-type')
      quesDataObj['sectionNo'] = element.getAttribute('data-section')
      quesDataObj['correctAns'] = element.querySelector('input[type="radio"]:checked')
        ? element.querySelector('input[type="radio"]:checked').value
        : null
      questionData.push(quesDataObj)
      maxMarks += Number(quesDataObj['marks'])
    })

    row['marks'] = maxMarks

    const { examName, subject, class: className, marks, examDate } = row
    const selectedObject = { examName, subject, className, marks, examDate }

    queryData['questionpaper'] = selectedObject
    queryData['questions'] = questionData

    console.log(queryData)

    apiClient
      .post('/school/anskey', queryData)
      .then((response) => {
        console.log(response)
        if (response.status === 200) {
          // navigator('/dashboard')
        }
      })
      .catch((error) => {
        console.error('Error submitting answer key:', error)
      })
  }

  return (
    <section className="container">
      <form action="" method="post" onSubmit={handleAnsKey}>
        <div className="row gx-3 align-items-center mb-3">
          <div className="col-8 col-md col-lg-2 mb-3">
            <label htmlFor="examName" className="form-label required">
              Name
            </label>
            <input
              type="text"
              className="form-control"
              name="examName"
              id="examName"
              defaultValue={key.examName}
              disabled
            />
            {/* {errors.examName && <div className="text-danger">{errors.examName}</div>} */}
          </div>
          <div className="col-8 col-md col-lg-2 mb-3">
            <label htmlFor="class" className="form-label required">
              Class
            </label>
            <select
              className="form-select"
              name="class"
              id="class"
              defaultValue={key.class}
              disabled
            >
              <option value="">Select</option>
              {classData.map((row) => (
                <option key={row.id} value={row.class}>
                  {row.class}
                </option>
              ))}
            </select>
            {/* {errors.class && <div className="text-danger">{errors.class}</div>} */}
          </div>
          <div className="col-8 col-md col-lg-2 mb-3">
            <label htmlFor="subject" className="form-label required">
              Subject
            </label>
            <select
              className="form-select"
              name="subject"
              id="subject"
              defaultValue={key.subject}
              disabled
            >
              <option value="">Select</option>
              {SubjectData.map((row) => (
                <option key={row.id} value={row.id}>
                  {row.Subject}
                </option>
              ))}
            </select>
            {/* {errors.subject && <div className="text-danger">{errors.subject}</div>} */}
          </div>
          <div className="col-8 col-md col-lg-2 mb-3">
            <label htmlFor="examDate" className="form-label">
              Date
            </label>
            <input
              type="date"
              className="form-select"
              name="examDate"
              id="examDate"
              defaultValue={key.examDate}
              disabled
            />
            {/* {errors.examDate && <div className="text-danger">{errors.examDate}</div>} */}
          </div>
        </div>
        <div className="row">
          <div className="keyBlock col-12 col-sm-6 col-lg-4 col-xl-6">{content}</div>
        </div>
        <button type="submit" className="btn btn-primary shadow">
          Submit
        </button>
      </form>
    </section>
  )
}
