import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('curriculumgoal')
export class CurriculumGoal {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 100 })
  stage: string;

  @Column({ type: 'varchar', length: 1000 })
  ccGoal: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  clause: string | null;

  @Column({ type: 'varchar', length: 100 })
  cgNo: string;

  @Column({ type: 'varchar', length: 150, nullable: true })
  domain: string | null;

  @Column({ type: 'int' })
  parentId: number;

  @Column({ type: 'int', default: 1 })
  status: number;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  cgDateTime: Date;
}
