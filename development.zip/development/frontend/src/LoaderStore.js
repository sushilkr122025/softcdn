let listeners = []
let loading = false

export const loaderStore = {
  get: () => loading,

  set: (v) => {
    loading = v
    listeners.forEach(l => l(loading))
  },

  subscribe: (fn) => {
    listeners.push(fn)
    return () => {
      listeners = listeners.filter(l => l !== fn)
    }
  }
}
