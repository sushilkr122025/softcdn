import apiClient from './apiService'

class AuthService {

  loginUser = async (email, password) => {
    try {
      const response = await apiClient.post('/auth/login', { email, password }) 
      return {
        status: response.status,
        data: response.data
      }      
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message: error.response?.data?.message.message || "Something went wrong",
      }
    }
  }

  logoutUser = async () => {  
    const response = await apiClient.get('/auth/logout')
    return response.data
  }
}

export default new AuthService()
