import { useState } from 'react'
import AppFooter from './AppFooter'
import AppHeader from './AppHeader'
import { Outlet } from 'react-router-dom'
import Sidebar from './AppSidebar'
import '../../App.css' // Ensure styles are imported

const DefaultLayout = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [collapseFully, setCollapseFully] = useState(false);
  return (
     <div className="d-flex maincontainer">
      <Sidebar
        isCollapsed={isCollapsed}
        setIsCollapsed={setIsCollapsed}
        collapseFully={collapseFully}
        setCollapseFully={setCollapseFully}
      />
      <div style={{minHeight:'100vh'}} className={`d-flex flex-column ${collapseFully ? 'rightsidefullyCollapsed' : isCollapsed ? 'rightSidebarcollapsed' : 'rightSidebardefault'}`}>
        <AppHeader setCollapseFully={setCollapseFully} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} collapseFully={collapseFully} />
        <div className="flex-grow-1">
          <Outlet />
        </div>
        <AppFooter />
      </div>
    </div>
  );
}

export default DefaultLayout
