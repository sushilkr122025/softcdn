import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { StateNConstituency } from '../entities/statenconstituencies.entity';
import { Subject } from '../entities/subject.entity';
import { ClassDto } from '../dto/class.dto';
import { SectionDto } from '../dto/section.dto';
import { SubjectDto } from '../dto/subject.dto';
import { Class } from '../entities/class.entity';
import { Section } from '../entities/section.entity';
import { CurriculumGoal } from '../entities/curriculum.goal.entity';
import { Roles } from '../entities/roles.entity';
import { Permissions } from 'src/entities/permissions.entity';

@Injectable()
export class HelperService {
  constructor(
    @InjectRepository(StateNConstituency)
    private readonly stateRepository: Repository<StateNConstituency>,
    @InjectRepository(Class)
    private readonly classRepository: Repository<Class>,
    @InjectRepository(Section)
    private readonly sectionRepository: Repository<Section>,
    @InjectRepository(Subject)
    private readonly subjectRepository: Repository<Subject>,
    @InjectRepository(CurriculumGoal)
    private readonly curriculumGoalRepository: Repository<CurriculumGoal>,
    @InjectRepository(Roles)
    private readonly rolesRepository: Repository<Roles>,
    @InjectRepository(Permissions)
    private readonly permissionRepository: Repository<Permissions>
  ) {}

  async getRoles(): Promise<any> {
    return await this.rolesRepository.find({
      select: ['rolename'],
      where: { dmlType: 'I', createdBy: 'SYSTEM' },
    });
  }

  async createUpdateClass(classDto: ClassDto): Promise<Class> {
    const id = classDto.id ? Number(classDto.id) : undefined;
    if (!id) {
      delete classDto.id;
      const newClass = this.classRepository.create(classDto);
      return await this.classRepository.save(newClass);
    }
    const existingClass = await this.classRepository.update({ id }, classDto);
    if (existingClass.affected === 0) {
      throw new Error(`Class with ID ${id} not found`);
    }
    const updatedClass = await this.classRepository.findOneBy({ id });
    if (!updatedClass) {
      throw new Error(`Class with ID ${id} not found after update`);
    }
    return updatedClass;
  }

  async getClass(): Promise<Class[]> {
    return await this.classRepository.find({
      where: { visible: 1 },
      select: ['id', 'class', 'status'],
    });
  }

  async createUpdateSection(sectionDto: SectionDto): Promise<Section> {
    const id = sectionDto.id ? Number(sectionDto.id) : undefined;
    if (!id) {
      delete sectionDto.id;
      const newClass = this.sectionRepository.create(sectionDto);
      return await this.sectionRepository.save(newClass);
    }
    const existingClass = await this.sectionRepository.update(
      { id },
      sectionDto
    );
    if (existingClass.affected === 0) {
      throw new Error(`Section with ID ${id} not found`);
    }
    const updatedClass = await this.sectionRepository.findOneBy({ id });
    if (!updatedClass) {
      throw new Error(`Section with ID ${id} not found after update`);
    }
    return updatedClass;
  }

  async getSection(): Promise<Section[]> {
    return await this.sectionRepository.find();
  }

  async createUpdateSubject(subjectDto: SubjectDto): Promise<Subject> {
    const id = subjectDto.id ? Number(subjectDto.id) : undefined;
    if (!id) {
      delete subjectDto.id;
      const newClass = this.subjectRepository.create(subjectDto);
      return await this.subjectRepository.save(newClass);
    }
    const existingClass = await this.subjectRepository.update(
      { id },
      subjectDto
    );
    if (existingClass.affected === 0) {
      throw new Error(`Subject with ID ${id} not found`);
    }
    const updatedClass = await this.subjectRepository.findOneBy({ id });
    if (!updatedClass) {
      throw new Error(`Subject with ID ${id} not found after update`);
    }
    return updatedClass;
  }

  async getSubject(parentId: number): Promise<Subject[]> {
    return await this.subjectRepository.find({
      where: { parentId },
      select: ['id', 'subject', 'parentId', 'status', 'book'],
    });
  }

  async getAllSubdomain(): Promise<any[]> {
    const dataSource = await this.subjectRepository
      .createQueryBuilder('s')
      .innerJoin('subject', 'sub', 's.parentId = sub.id')
      .select([
        's.id AS id',
        's.book AS book',
        's.status AS status',
        's.parentId AS parentId',
        's.subject AS subDomain',
        'sub.subject AS subject',
      ])
      .where('s.visible = :visible', { visible: 1 })
      .getRawMany();
    return dataSource;
  }

  async getSubdomain(parentId: number): Promise<Subject[]> {
    const dataSource = await this.subjectRepository.find({
      where: { parentId },
      select: ['id', 'subject', 'parentId', 'status', 'book'],
    });
    return dataSource;
  }

  async getStateNConstituency(stateId: string): Promise<StateNConstituency[]> {
    let idParent: string = '0';
    if (stateId != '0' && stateId != '') {
      idParent = stateId;
    }
    return await this.stateRepository.find({
      where: { idParent: idParent, status: true },
      order: { stateNConsti: 'ASC' },
    });
  }

  async getCG(stage: string, domain: string): Promise<CurriculumGoal[]> {
    return await this.curriculumGoalRepository.find({
      where: { stage: stage, domain: domain, parentId: 0 },
    });
  }

  async getCompetency(parentId: number): Promise<CurriculumGoal[]> {
    return await this.curriculumGoalRepository.find({ where: { parentId } });
  }
}
