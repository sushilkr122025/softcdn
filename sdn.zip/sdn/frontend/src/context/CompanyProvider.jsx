import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SchoolServices from '../api/SchoolServices';
import { CompanyContext } from './CompanyContext';


const CompanyProvider = ({ children }) => {
  const [school, setSchool] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    const lookupVerify= async () => {
        try {
            const data = await SchoolServices.getLookupVerify();               
            setSchool(data);
            // console.log("school data", data);
            } catch (err) {
                console.error("Verify failed:", err);
                navigate('/');
            } finally {
              setLoading(false);
            }; 
       }
      lookupVerify();
  }, []);

  const values = {
    school,
    setSchool    
  };
  
  return (
    <CompanyContext.Provider value={values}>
       {loading ? <div className="text-center py-5">Loading company provider...</div> : children}
    </CompanyContext.Provider>
  );
};

export default CompanyProvider;