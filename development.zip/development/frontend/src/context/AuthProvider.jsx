import { useState, useEffect, useRef,  useMemo } from 'react';
import { Auth } from './AuthContext';
import apiClient from '../api/apiService';
import { clearAll, getLocal } from '../utils/storage';

function AuthProvider({ children }) {

  const [reqerror, setReQError] = useState(null);
  const [user, setUser] = useState(null);
  const [isAuth, setIsAuth] = useState(false);
  const [loading, setLoading] = useState(true);  
  const [appSetting, setAppSetting] = useState(null);  
  const socketRef = useRef(null);

    const login = async (email, password) => {
          console.time("AUTH_login_TOTAL");
    try {
      console.time("login_API");
      const response = await apiClient.post('/auth/login', { email, password });
      console.timeEnd("login_API");
      const data = response.data;      
      if(data.authorize===true){  
        setUser(data);
        setIsAuth(true);        
      }else {
        clearAll();
        setReQError(data.message || 'Login failed');
      }
      setLoading(false);                
      console.timeEnd("AUTH_login_TOTAL");   
      return true;
    } catch (error) {
      clearAll();
      setReQError(error?.response?.data?.message || 'Login failed');
      setLoading(false);
      console.timeEnd("AUTH_login_TOTAL");
      return false;
    }
  };

    const logout = async () => {
    try {
      const response = await apiClient.get('/auth/logout');
      if (response) {
        clearAll();
        setIsAuth(false);
        setUser(null);        
      }
    } catch (err) {
      console.error('Logout API error:', err.message);      
    }

    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    setIsAuth(false);
  
  };

  const verifyUser = async () => {
    try {   
      const user = await apiClient.get('/auth/verify');
      if(user.data.authorize === true){
        const finalUser = { 
          ...user.data.user, 
          permission: user.data.permission
        };          
        // console.log('User permissions:', finalUser);
        setUser(finalUser);
        setIsAuth(true);
        getAppSetting();
      }else{
        logout();
      }
      setLoading(false);
    } catch (err) {
      console.error('Auth verify failed:', err.message);
      setReQError(err?.response?.data?.message || 'Session expired. Please log in again.');       
      setUser(null);
      setIsAuth(false);      
      setLoading(false);        
    }
  };

  const getAppSetting = async () => {
    try {   
      const setting = await apiClient.get('/auth/appsetting');      
      if(setting.data.authorize === true){
        setAppSetting(setting.data.setting);
      }
    } catch (err) {
      console.error('Failed to get app setting:', err.message);
    }
  };
        
  useEffect(() => {      
      verifyUser();     
  }, []); 

  const value = useMemo(() => ({
  user,
  setUser,
  isAuth,
  loading,
  logout,
  login,
  reqerror,
  appSetting,
}), [user, isAuth, reqerror, loading]);

  return <Auth.Provider value={value}>{children}</Auth.Provider>;
}

export default AuthProvider;