import { FiEdit2, FiDownload } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

const QuestionPaperBlock = ({ info }) => {
  const navigate = useNavigate();
  console.log(info);
  

  const handleEdit = (id) => {
    navigate(`/AnswerSheet?updateid=${id}`);
  };

  const handleDownload = (tq) => {
    navigate(`/QuesTemplate?totalQuestions=${tq}`);
  };

  const openModal = () => {
    navigate(`/rollblock/${info.paperId}`, {state: {examDetails: info}});
  };

  function toRoman(num) {
    if (isNaN(num)) return '';
    const romanNumerals = [
      { value: 1000, numeral: 'M' },
      { value: 900, numeral: 'CM' },
      { value: 500, numeral: 'D' },
      { value: 400, numeral: 'CD' },
      { value: 100, numeral: 'C' },
      { value: 90, numeral: 'XC' },
      { value: 50, numeral: 'L' },
      { value: 40, numeral: 'XL' },
      { value: 10, numeral: 'X' },
      { value: 9, numeral: 'IX' },
      { value: 5, numeral: 'V' },
      { value: 4, numeral: 'IV' },
      { value: 1, numeral: 'I' },
    ];
    let romanNumeral = '';
    for (let i = 0; i < romanNumerals.length; i++) {
      while (num >= romanNumerals[i].value) {
        romanNumeral += romanNumerals[i].numeral;
        num -= romanNumerals[i].value;
      }
    }
    return romanNumeral;
  }

  return (
    <div className="col-12 col-md-6 col-lg-4 mb-4 quesBlock">
      <div className="d-flex justify-content-end mb-1">
        <div className="icons" onClick={() => handleDownload(info.totalQuestion)}>
          <FiDownload />
        </div>
        <div className="icons" onClick={() => handleEdit(info.id)}>
          <FiEdit2 />
        </div>
      </div>
      <div
        className="p-3 bg-body shadow-sm fw-normal quesData"
        onClick={openModal} // Just navigate
      >
        <div className="d-flex justify-content-between">
          <h5>{info.name}</h5>
          <p className="text-end text-muted">
            <strong>{info.examCode}</strong>
          </p>
        </div>
        <div className="d-flex justify-content-between">
          <div className="text-muted">Class - {toRoman(info.class)}</div>
          <div className="text-muted">Time allowed - {info.totalTime}</div>
        </div>
        <div className="d-flex justify-content-between">
          <div className="text-muted">Subject - {info.subject}</div>
          <div className="text-muted">Max marks - {info.maxMarks}</div>
        </div>
        <p className="mt-3">Total Questions - {info.totalQuestion}</p>
        <div className="quesType">
          <span className="me-2">Types</span>
          <span className="badge rounded-pill text-bg-primary me-2">MCQ</span>
          <span className="badge rounded-pill text-bg-success me-2">True False</span>
          <span className="badge rounded-pill text-bg-secondary">One Word</span>
        </div>
      </div>
    </div>
  );
};

export default QuestionPaperBlock;
