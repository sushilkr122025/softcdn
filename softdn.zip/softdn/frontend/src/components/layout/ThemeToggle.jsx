import { useTheme } from "./ThemeContext";
import { IoIosColorPalette } from "react-icons/io";

const themes = [
  { name: "blue", label: " Blue" },
  { name: "green", label: " Green" },
  { name: "purple", label: " Purple" },
  // { name: "orange", label: " Orange" },
];

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="dropdown">
      <button
       className="btn border-0 text-white btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false" 
       title="Theme"
      >
        <IoIosColorPalette style={{ fontSize: "25px" }}/>
      </button>
      <ul className="dropdown-menu py-2">
        {themes.map((t) => (
          <li key={t.name}>
            <button
              className={`dropdown-item ${theme === t.name ? "active" : ""}`}
              onClick={() => setTheme(t.name)}
            >
              {t.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ThemeToggle;
