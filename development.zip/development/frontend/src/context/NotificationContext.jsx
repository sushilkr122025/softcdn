import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import apiClient from '../api/apiService';
import useAuth from './AuthContext';
import config from '../config/config';

const SOCKET_URL = config.sockethost;

const NotificationContext = createContext();
export const useNotification = () => useContext(NotificationContext);

export default function NotificationProvider({ children }) {
  const { user, isAuth } = useAuth();

  const [notifications, setNotifications] = useState([]);
  const [socket, setSocket] = useState(null);
  const isProd = import.meta.env.PROD;

  useEffect(() => {
    if (!isAuth || !user) return;

    // console.log('Creating socket connection...');

    const newSocket = io(SOCKET_URL, {
      path: '/api/socketcontext',
      withCredentials: true,
      upgrade: isProd,
      secure: isProd,
      // transports: ['websocket'], // Important for stable connection
      auth: { userId: user.id },
    });

    setSocket(newSocket);

    // -------------------------------
    // Socket Events
    // -------------------------------
    newSocket.on('connect', () => {
      // console.log('Socket connected:', newSocket.id);

      // Fetch unread notifications
      apiClient
        .get('/notifications/unread')
        .then(res => setNotifications(res.data))
        .catch(err =>
          console.error('Failed to load unread notifications:', err.message)
        );
    });

    newSocket.on('notification', data => {      
      const notification = data.notify ?? data;
      console.log('notification', notification);
      setNotifications(prev => [notification, ...prev]);
    });

    newSocket.on('disconnect', reason => {
      // console.warn('Socket disconnected:', reason);
    });

    newSocket.on('connect_error', err => {
      console.error('Socket connection error:', err.message);
    });

    // -------------------------------
    // Cleanup on unmount/logout
    // -------------------------------
    return () => {
      // console.log('Disconnecting socket...');
      newSocket.disconnect();
      setSocket(null);
    };
  }, [isAuth, user]);

  // -------------------------------
  // Mark notification as read
  // -------------------------------
  const markAsRead = useCallback(async (id) => {
    try {
      await apiClient.post(`/notifications/read/${id}`);
      setNotifications(prev => prev.filter(n => n.id !== id));
    } catch (err) {
      console.error('Failed to mark notification as read:', err.message);
    }
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        markAsRead,
        socket,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}