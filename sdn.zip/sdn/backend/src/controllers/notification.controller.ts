import { Controller, Get, Param, Post, Req, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "src/auth/jwt-auth.guard";
import { NotificationService } from "src/services/notification.services";

// notification.controller.ts
@Controller('notifications')
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  // @Post('instant')
  //   async sendInstant(@Body() body: { message: string }) {
  //     return this.notificationService.sendNow(body.message);
  //   }

  //   @Post('schedule')
  //   async schedule(@Body() body: { message: string; delayMs: number }) {
  //     return this.notificationService.scheduleSend(
  //       `job-${Date.now()}`,
  //       body.delayMs,
  //       body.message,
  //     );
  //   }
  @Get('unread')
  @UseGuards(JwtAuthGuard)
  async getUnread(@Req() req) {
    return this.notificationService.getUnread(req.user.id);
  }

  @Post('read/:id')
  @UseGuards(JwtAuthGuard)
  async markRead(@Param('id') id: number) {
    return this.notificationService.markAsRead(id);
  }
}
