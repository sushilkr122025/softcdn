import { useState, useEffect, useMemo } from 'react';
import GlobalFilters from '../../components/GlobalFilters';
import './Question.css';
import jsPDF from "jspdf";
import { VscPreview } from "react-icons/vsc";
import { useLocation } from 'react-router-dom';
import { Document, Packer, Paragraph, TextRun, Header, Footer, PageNumber, AlignmentType } from "docx";
import { saveAs } from "file-saver";
import { useNavigate } from "react-router-dom";
import Forbidden from '../../components/Page403';
import usePermission from '../../hooks/usePermission';
import { DataGrid } from '@mui/x-data-grid';
import ShowMessage from '../../components/ShowMessage';
import QuestionServices from '../../api/QuestionServices';
import { IoSearchOutline } from "react-icons/io5";
import exporticon from '../../assets/images/export.svg'
import { Popover, OverlayTrigger } from 'react-bootstrap';
import { PiFilePdfLight } from "react-icons/pi";
import { FaFileWord } from "react-icons/fa";

const Question = () => {
  const [permissionData, setPermissionData] = useState();
  const [showAlert, setShowAlert] = useState(false);
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState({ std: '', subject: '', cg: '', competency: '', difficulty: '', quesType: '', subDomain: '', });
  const [lastSectionReceived, setLastSectionReceived] = useState(null);
  const [activeSectionIndex, setActiveSectionIndex] = useState(null);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedQuestion, setSelectedQuestion] = useState([]);
  const [excludedIds, setExcludedIds] = useState(new Set());
  const options = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }];
  const [previewQuestion, setPreviewQuestion] = useState(null);
  const { canRead, readScope } = usePermission('BANK');
  const maxcheckQuestion = 40;
  const [searchText, setSearchText] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [paperinfo, setpaperinfo] = useState()
  const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 25 });
  const [meta, setMeta] = useState({ total: 0, page: 1, limit: 25, totalPages: 0, });
  const [loading, setLoading] = useState(false);
  const [alertMessage, setAlertMessage] = useState(null)
  const [columnVisibilityModel, setColumnVisibilityModel] = useState(() => JSON.parse(localStorage.getItem("questionColumnVisibility")) || {});
  const [itemselectedlength, setSelectedlength] = useState();
  const qTypeConvert = { multipleChoice: 'Multiple Choice', trueFalse: 'True/False', oneWord: 'One Word', CR: 'Written Response', fillups: 'Fill in the Blanks', match: 'Match the Following' };

  const stripHtml = (html) => {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || "";
  };

  function extractSectionFromSectionObj(secObj, fallbackIndex) {
    if (!secObj) return null;
    const idStr = String(secObj.id ?? secObj.section ?? '');
    const m = idStr.match(/(\d+)$/);
    if (m) return m[1];
    if (secObj.section) return String(secObj.section);
    return fallbackIndex != null ? String(fallbackIndex) : (secObj.id ? String(secObj.id) : null);
  }
  const currentSectionStr = useMemo(() => {
    if (typeof activeSectionIndex === "number") {
      return String(Number(activeSectionIndex) + 1);
    }
    return lastSectionReceived ? String(lastSectionReceived) : null;
  }, [activeSectionIndex, lastSectionReceived]);

  const visibleRows = useMemo(() => {
    return data.filter((q) => !excludedIds.has(q.id));
  }, [data, excludedIds]);

  const currentSectionSelectedQuestion = useMemo(() => {
    if (!currentSectionStr) return selectedQuestion;
    return selectedQuestion.filter((q) => String(q.section) === String(currentSectionStr));
  }, [selectedQuestion, currentSectionStr]);

  const currentSectionSelectedIds = useMemo(() => {
    return new Set(currentSectionSelectedQuestion.map((q) => q.id));
  }, [currentSectionSelectedQuestion]);

  useEffect(() => {
    const cleaned = selectedQuestion.filter((e) => !excludedIds.has(e.id));
    setSelectedlength(cleaned.length);
  }, [selectedQuestion, excludedIds]);

  useEffect(() => {
    if (canRead) {
      setPermissionData(readScope)
    }
  }, [canRead, readScope])

  useEffect(() => {
    const { std, subject, context, subDomain, difficulty, cg, competency, marks } = filter;
    if (!std || !subject) return;
    const fetchQuestions = async () => {
      setLoading(true);
      try {
        const res = await QuestionServices.questionFromBank({
          class: std,
          subject,
          subDomain,
          difficulty,
          cg,
          competency,
          marks,
          contextstatus: context,
          table: 'questions',
          page: paginationModel.page + 1,
          limit: paginationModel.pageSize,
        });
        if (res) {
          console.log('res.data', res);
          setData(res.data || []);
          setMeta(res.meta || {
            total: 0,
            page: paginationModel.page + 1,
            limit: paginationModel.pageSize,
            totalPages: 0,
          });
        }
      } finally {
        setLoading(false);
      }
    };
    fetchQuestions();
  }, [filter, paginationModel.page, paginationModel.pageSize]);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchText);
      setPaginationModel((prev) => ({ ...prev, page: 0 }));
    }, 300);
    return () => clearTimeout(handler);
  }, [searchText]);

  // const filteredData = data.filter((q) => {
  //   if (filter.subDomain && q.subDomain !== filter.subDomain) return false;
  //   if (filter.cg && q.cg !== filter.cg) return false;
  //   if (filter.competency && q.competency !== filter.competency) return false;
  //   if (filter.difficulty && q.difficulty !== filter.difficulty) return false;
  //   if (filter.quesType && q.quesType !== filter.quesType) return false;
  //   return true;
  // })
  //   .filter((q) => q.customId?.toLowerCase().includes(debouncedSearch.toLowerCase()))
  //   .filter((q) => !excludedIds.has(q.id));

  const handleFiltersChange = (newFilters) => {
    setPaginationModel((prev) => ({ ...prev, page: 0 }));
    setFilter((prev) => {
      const classChanged = prev.std !== newFilters.std
      const subjectChanged = prev.subject !== newFilters.subject
      const updatecase = location.state?.previouslySelected
      if ((classChanged || subjectChanged) && !updatecase) {
        setSelectedQuestion([]);
      }
      return {
        ...prev,
        ...newFilters,
        cg: classChanged || subjectChanged ? '' : newFilters.cg,
        competency: classChanged || subjectChanged ? '' : newFilters.competency,
        difficulty: classChanged || subjectChanged ? '' : newFilters.difficulty,
        quesType: classChanged || subjectChanged ? '' : newFilters.quesType,
        subDomain: classChanged || subjectChanged ? '' : newFilters.subDomain,
        context: classChanged || subjectChanged ? '' : newFilters.context,
        marks: classChanged || subjectChanged ? '' : newFilters.marks,
      }
    })
  }

  const handleRowClick = (question) => {
    setShowPreviewModal(true);
    const isSelected = selectedQuestion.some((q) => q.id == question.id)
    const sectionwisepreview = selectedQuestion.filter((e) => !excludedIds.has(e.id))
    if (isSelected) {
      setPreviewQuestion([...sectionwisepreview]);
    } else {
      setPreviewQuestion([question])
    }
  };

  const exportToWord = () => {
    if (itemselectedlength === 0) {
      setAlertMessage('Please Select at least one Question')
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
        setAlertMessage(null)
      }, 2000);
      return;
    }

    const paragraphs = selectedQuestion.map((item, idx) => [
      new Paragraph({
        children: [
          new TextRun({ text: `Q${idx + 1} (ID: ${item.customId})`, bold: true }),
        ],
        spacing: { after: 200 },
      }),
      new Paragraph({ text: `Q: ${stripHtml(item.question) || 'Question not found.'}` }),
      new Paragraph(""),
    ]).flat();

    const header = new Header({
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "ABCD SCHOOL", bold: true })],
        }),
      ],
    });

    const footer = new Footer({
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun("Sanskrit e Solutions & Services Pvt. Ltd.")],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun("Page "),
            new TextRun({ children: [PageNumber.CURRENT] }),
            new TextRun(" of "),
            new TextRun({ children: [PageNumber.TOTAL_PAGES] }),
          ],
        }),
      ],
    });

    const doc = new Document({
      sections: [
        {
          headers: { default: header },
          footers: { default: footer },
          children: paragraphs,
        },
      ],
    });

    Packer.toBlob(doc).then((blob) => {
      saveAs(blob, `selected-questions.docx`);
    });
  };

  const exportToPDF = () => {
    if (itemselectedlength === 0) {
      setAlertMessage('Please Select at least one Question')
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
        setAlertMessage(null)
      }, 2000);
      return;
    }

    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const pageHeight = doc.internal.pageSize.getHeight();
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 10;
    let y = margin;
    const lineHeight = 7;

    const addFooter = (pageNum, totalPages) => {
      doc.setFontSize(10);
      doc.text("Sanskrit e Solutions & Services Pvt. Ltd.", pageWidth / 2, pageHeight - 10, { align: 'center' });
      doc.text(`Page ${pageNum} of ${totalPages}`, pageWidth / 2, pageHeight - 5, { align: 'center' });
    };

    const addHeader = () => {
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("ABCD SCHOOL", pageWidth / 2, y, { align: "center" });
      y += lineHeight + 2;
    };

    const renderQuestion = (question, index) => {
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(`Q${index + 1} (ID: ${question.customId})`, margin, y);
      y += lineHeight;

      doc.setFont("helvetica", "normal");
      const cleanQuestion = stripHtml(question.question);
      const splitText = doc.splitTextToSize(`Q: ${cleanQuestion}`, pageWidth - margin * 2);
      splitText.forEach(line => {
        doc.text(line, margin, y);
        y += lineHeight;
      });
      y += lineHeight;
    };

    const totalPages = Math.ceil(itemselectedlength / 4);
    let currentPage = 1;

    addHeader();
    selectedQuestion.forEach((item, idx) => {
      if (y + 40 > pageHeight - 20) {
        addFooter(currentPage, totalPages);
        doc.addPage();
        currentPage++;
        y = margin;
        addHeader();
      }
      renderQuestion(item, idx);
    });

    addFooter(currentPage, totalPages);
    doc.save(`selected-questions.pdf`);
  };

  const handleChange = (item) => {
    const contextId = item.contextId;
    const sameContextRows = data.filter((q) => q.contextId === contextId);
    const isContextSelected = sameContextRows.every((row) => selectedQuestion.some((q) => q.id === row.id));
    const sectionToAttach = lastSectionReceived || (activeSectionIndex !== null ? String(activeSectionIndex + 1) : null);
    if (sameContextRows.length > 1 && !isContextSelected) {
      setAlertMessage(`All context group selected of this question`);
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
        setAlertMessage(null)
      }, 2000);
    }
    setSelectedQuestion((prev) => {
      let updated = [...prev];
      if (isContextSelected) {
        updated = updated.filter((q) => q.contextId !== contextId);
        return updated;
      }
      const existingIds = new Set(updated.map((q) => q.id));
      for (let row of sameContextRows) {
        if (updated.length >= maxcheckQuestion) {
          setAlertMessage(`You can select a maximum of ${maxcheckQuestion} questions only.`)
          setShowAlert(true);
          setTimeout(() => {
            setShowAlert(false);
            setAlertMessage(null)
          }, 2000);
          break;
        }

        if (!existingIds.has(row.id)) {
          const rowWithSection = sectionToAttach ? { ...row, section: sectionToAttach } : { ...row };
          updated.push(rowWithSection);
          existingIds.add(row.id);
        }
      }
      return updated;
    });
  };

  const cleanHtml = (html) => {
    if (!html) return "";
    html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
    html = html.replace(/font-size\s*:\s*[^;"]+;?/gi, "");
    html = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
    return html;
  };

  const goToPreview = () => {
    if (itemselectedlength > 0) {
      const loc = location.state || {};
      const previouslyAll = loc.allPreviouslySelected || null;
      let merged = [...(selectedQuestion || [])];
      if (Array.isArray(previouslyAll) && previouslyAll.length > 0) {
        const byId = new Map(merged.map(i => [i.id, i]));
        for (const it of previouslyAll) {
          byId.set(it.id, it);
        }
        merged = Array.from(byId.values());
      }
      if (Array.isArray(loc.previouslySelected) && loc.previouslySelected.length > 0) {
        const byId = new Map(merged.map(i => [i.id, i]));
        for (const it of loc.previouslySelected) {
          byId.set(it.id, it);
        }
        merged = Array.from(byId.values());
      }

      const questionsData = merged.map((q) => ({
        ...(q.id && { id: q.id }),
        ...(q.sequence && { sequence: q.sequence }),
        ...(q.section && { section: q.section }),
        ...(q.connector && { connector: q.connector }),
        ...(q.isSub && { isSub: q.isSub }),
        ...(q.subOf && { subOf: q.subOf }),
        ...(q.contextLabel && { contextLabel: q.contextLabel }),
        ...(q.queslabel && { queslabel: q.queslabel }),
        ...(q.ui && {
          ui: {
            ...(q.ui.align && { align: q.ui.align }),
            ...(q.ui.fontSize && { fontSize: q.ui.fontSize }),
            ...(q.ui.imageSizes && { imageSizes: q.ui.imageSizes }),
            ...(q.ui.optionIdType && { optionIdType: q.ui.optionIdType }),
            ...(q.ui.optionLayout && { optionLayout: q.ui.optionLayout }),
            ...(q.ui.selectedImageKeys && { selectedImageKeys: q.ui.selectedImageKeys })
          }
        })
      }));
      navigate("/questionPreview", { state: { selectedQuestion: questionsData, filter, paperinfo: paperinfo } });
    } else {
      setAlertMessage('Please Select at least one Question')
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
        setAlertMessage(null)
      }, 2000);
    }
  }

  useEffect(() => {
    const loc = location.state;
    if (!loc) return;
    let gd = loc.generaldetail ?? null;
    setpaperinfo(gd);
    if (typeof loc.activeSectionIndex === "number") {
      setActiveSectionIndex(Number(loc.activeSectionIndex));
      setLastSectionReceived(String(Number(loc.activeSectionIndex) + 1));
    } else {
      let sect = null;
      if (Array.isArray(gd?.sectionsData) && gd.sectionsData.length > 0) {
        const lastIndex = gd.sectionsData.length - 1;
        const last = gd.sectionsData[lastIndex];
        sect = extractSectionFromSectionObj(last, lastIndex + 1);
      } else if (gd?.section) {
        sect = String(gd.section);
      }
      setLastSectionReceived(sect);
    }

    if (loc.previousFilter) {
      setFilter(loc.previousFilter);
    }
    if (loc.previouslySelected || loc.allPreviouslySelected) {
      const allPrev = Array.isArray(loc.allPreviouslySelected) ? loc.allPreviouslySelected : Array.isArray(loc.previouslySelectedAll) ? loc.previouslySelectedAll
        : Array.isArray(loc.previouslySelectedGlobal) ? loc.previouslySelectedGlobal : Array.isArray(loc.previouslySelected) ? loc.previouslySelected : [];

      const normalizedPrev = allPrev.map(q => {
        if (!q) return q;
        if (q.section) return q;
        if (loc.activeSectionIndex != null) return { ...q, section: String(Number(loc.activeSectionIndex) + 1) };
        return q;
      });

      setSelectedQuestion((cur) => {
        const byId = new Map(cur.map(i => [i.id, i]));
        for (const it of normalizedPrev) {
          if (it && it.id !== undefined) byId.set(it.id, it);
        }
        return Array.from(byId.values());
      });
      const currentSectionStr = (typeof loc.activeSectionIndex === "number") ? String(Number(loc.activeSectionIndex) + 1) : (lastSectionReceived || null);
      const excluded = new Set();
      normalizedPrev.forEach((q) => {
        if (!q || q.id === undefined) return;
        if (currentSectionStr && String(q.section) !== String(currentSectionStr)) {
          excluded.add(q.id);
        }
      });

      if (Array.isArray(loc.allPreviouslySelected) && loc.allPreviouslySelected.length > 0) {
        loc.allPreviouslySelected.forEach(q => {
          if (!q || q.id === undefined) return;
          if (currentSectionStr && String(q.section) === String(currentSectionStr)) {
            return;
          }
          excluded.add(q.id);
        });
      }

      setExcludedIds(excluded);
    } else {
      setExcludedIds(new Set());
    }
  }, [location.state]);

  const handleColumnVisibilityChange = (newModel) => {
    setColumnVisibilityModel(newModel);
    localStorage.setItem("questionColumnVisibility", JSON.stringify(newModel));
  };

  if (!canRead) return <Forbidden />

  const columns = [
    {
      field: 'select',
      headerName: '-',
      width: 50,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <input
          type="checkbox"
          id={params.row.id}
          className="form-check-input"
          checked={currentSectionSelectedIds.has(params.row.id)}
          onChange={() => handleChange(params.row)}
        />
      ),
    },
    {
      field: 'customId',
      headerName: 'Unique Id',
      flex: 1,
      renderCell: (params) => (
        <span className='cursor-pointer' onClick={() => handleRowClick(params.row)}>{params.row.customId}</span>
      ),
    },
    // { field: 'class', headerName: 'Class', flex: 0.7 }, 
    {
      field: 'contextstatus', headerName: 'Ques. Type', flex: 0.7,
      renderCell: (params) => {
        return params.row.contextstatus === 'CONTEXT' ? (
          <span>Context</span>
        ) : (
          <span>Non Context</span>
        );
      },
    },
    { field: 'contextId', headerName: 'Context Ref', flex: 0.7 },
    { field: 'subDomain', headerName: 'Sub Domain', flex: 0.7 },
    { field: 'difficulty', headerName: 'Difficulty', flex: 0.7 },
    { field: 'cgText', headerName: 'CG', flex: 0.7 },
    { field: 'competencyText', headerName: 'Competency', flex: 0.7 },
    {
      field: 'quesType', headerName: 'Ques. Format', flex: 0.7,
      renderCell: (params) => (qTypeConvert[params.row.quesType])
    },
    { field: 'marks', headerName: 'Marks', flex: 0.7 },
  ];

  const exportPopover = (
    <Popover id="popover-export" className="shadow border-0">
      <Popover.Body className="p-0">
        <div className="list-group list-group-flush p-2" style={{ minWidth: '150px' }}>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { exportToPDF() }}
          >
            <PiFilePdfLight className='me-2' size={18} /> PDF
          </button>
          <button
            className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
            onClick={() => { exportToWord() }}
          >
            <FaFileWord className='me-2' size={18} /> Word
          </button>
          {paperinfo && (
            <button
              className='list-group-item dropdown-item list-group-item-action border-0 d-flex align-items-center pdfwordexcel'
              onClick={() => { goToPreview() }}
            >
              <VscPreview className='me-2' size={18} /> Make paper & Preview
            </button>
          )}

        </div>
      </Popover.Body>
    </Popover>
  );
  return (
    <div className="p-lg-4 mt-2">
      <div className="container-fluid">
        <div className="row h-80vh" >
          <div className="col-12 p-lg-2 py-2">
            <div className="row align-items-center">
              <div className="col-6">
                <h5 className='mb-4 fw-bold pagetitle'>Question Bank</h5>
              </div>
              <ShowMessage type="toast" show={showAlert} variant="danger" message={alertMessage} onClose={() => setShowAlert(false)} />
            </div>
            <GlobalFilters onFiltersChange={handleFiltersChange} selectedValues={filter} show={['subject', 'class', 'context', 'subDomain', 'cg', 'competency', 'difficulty', 'quesType', 'marks']} permissions={permissionData} />
            <main>
              <div className="d-flex justify-content-between align-items-center">
                {itemselectedlength > 0 && <div className='btn btn-primary h45'>Selected {itemselectedlength} of {maxcheckQuestion}</div>}
                <div className="d-flex align-items-center mb-3 ms-auto gap-2">
                  <div className='position-relative'>
                    <IoSearchOutline size={20} className='searchpositon' />
                    <input type="search" className="form-control h45" placeholder="Search by Unique ID..." value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                    />
                  </div>
                  <div>
                    <OverlayTrigger trigger="click" placement="bottom" rootClose overlay={exportPopover}>
                      <button className="btn btn-export h45" data-bs-toggle="dropdown" aria-expanded="false" type="button">
                        <span className='px-1 me-3'><img src={exporticon} alt="" className='img-fluid' style={{ width: "20px" }} /></span>
                        Export As
                      </button>
                    </OverlayTrigger>
                  </div>
                </div>
              </div>
              <div className='w-100 h-67vh'>
                <DataGrid
                  className="custom-data-grid"
                  rows={visibleRows}
                  columns={columns}
                  getRowId={(row) => row.id}
                  loading={loading}
                  pagination
                  paginationMode="server"
                  rowCount={meta.total}
                  paginationModel={paginationModel}
                  onPaginationModelChange={setPaginationModel}
                  pageSizeOptions={[10, 25, 50, 100]}
                  disableRowSelectionOnClick
                  columnVisibilityModel={columnVisibilityModel}
                  onColumnVisibilityModelChange={handleColumnVisibilityChange}
                  getRowHeight={() => 60}
                  columnHeaderHeight={50}
                />
              </div>
            </main>
            {showPreviewModal && previewQuestion && (
              <>
                <div className="modal fade show d-block" tabIndex="-1" role="dialog" >
                  <div className="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div className="modal-content bg-white border-0 rounded-0 shadow p-3 py-4">
                      <div className='d-flex justify-content-end'>
                        <button type="button" className="btn-close" onClick={() => {
                          setShowPreviewModal(false);
                          setPreviewQuestion(null);
                        }}></button>
                      </div>
                      <div className="modal-body">
                        {previewQuestion.map((previewQuestions, idx) => (
                          <div key={idx} className="mb-4">
                            <h4 className="questionprevhead mb-3">Ques. ID: {previewQuestions?.customId}</h4>
                            {previewQuestions?.context &&
                              (idx === 0 ||
                                previewQuestions.contextId !== previewQuestion[idx - 1]?.contextId) && (
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html: cleanHtml(previewQuestions?.context),
                                  }}
                                />
                              )}
                            <div className="d-flex justify-content-between">
                              <div className="d-flex">
                                <span className='ps-2 me-3'>Q-</span>
                                <div
                                  style={{ maxWidth: "580px" }}
                                  className="qustionPreviewcontainer d-flex flex-wrap flex-grow-1 justify-content-between align-items-start"
                                  dangerouslySetInnerHTML={{
                                    __html: cleanHtml(previewQuestions?.question) || "No content available",
                                  }}
                                />
                              </div>
                              <div>{previewQuestions?.marks} Marks</div>
                            </div>
                            <ol className="list-group mt-3" type="A">
                              {options.map((key, i) => {
                                const option = previewQuestions?.[key.optns];
                                const optionimg = previewQuestions?.[key.images];
                                if (!option && !optionimg) return null;
                                const isCorrect = key.optns === previewQuestions.correctAns;
                                return (
                                  <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                                    <div className='d-flex justify-content-between align-items-center prevoptioncontainer'>
                                      {option && (
                                        <div dangerouslySetInnerHTML={{ __html: cleanHtml(option) }} />
                                      )}
                                      {isCorrect && <div className="text-success fw-bold">✔</div>}
                                    </div>
                                  </li>
                                );
                              })}
                            </ol>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="modal-backdrop fade show"></div>
              </>
            )}
          </div>
        </div>
      </div >
    </div >
  );
};

export default Question;
