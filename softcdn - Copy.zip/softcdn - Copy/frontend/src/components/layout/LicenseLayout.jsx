import React from 'react';
import { Outlet } from 'react-router-dom';
import LicenseProvider from '../../context/LicenseProvider';

const AuthLayout = () => {
  return (
    <LicenseProvider>
      <Outlet />
    </LicenseProvider>
  );
};

export default AuthLayout;
