import { Module, Global } from '@nestjs/common';
import { NotificationController } from '../controllers/notification.controller';
import { NotificationService } from '../services/notification.services';
import { NotificationGateway } from '../gateway/notification.gateway';
import { Notification } from '../entities/notification.entity';
import { EncryptionService } from '../services/encryption.service';
import { LookupService } from '../services/lookup.service';
import { School } from '../entities/school.entity';
import { LookupSchool } from '../entities/lookup.school.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthService } from '../services/auth.service';
import { Login } from '../entities/login.entity';
import { LoginActivity } from '../entities/login.activity';
import { UserAgentService } from '../services/user-agent.service';
import { JwtService } from '@nestjs/jwt';
import { Message } from '../entities/message.entity';
import { MessageService } from '../services/message.services';
import { CommonModule } from './common.module';
import { UserPermission } from '../entities/user.permissions.entity';
import { SchoolSetting } from '../entities/school.setting.entity';
@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      Notification,
      School,
      Login,
      LoginActivity,
      LookupSchool,
      Message,
      UserPermission,
      SchoolSetting,
    ]),
    CommonModule,
  ],
  controllers: [NotificationController],
  providers: [
    AuthService,
    NotificationService,
    NotificationGateway,
    EncryptionService,
    LookupService,
    UserAgentService,
    JwtService,
    MessageService,
  ],
  exports: [NotificationService, NotificationGateway],
})
export class NotificationModule {}
