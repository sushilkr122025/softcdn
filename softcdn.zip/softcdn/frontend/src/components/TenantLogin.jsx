import React from 'react'
import Cookies from 'js-cookie'

const Login = () => {
    const schoolID = Cookies.get('schoolID')
    const logo = Cookies.get('logo')
    console.log(schoolID, logo);
    
  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
      <div className="login-container text-center">
        <img src={logo} alt="Logo" className="logo mb-3" />
        <h4 className="mb-3">Login</h4>
        <form>
          <div className="mb-3 text-start">
            <label htmlFor="email" className="form-label">
              Email address
            </label>
            <input type="email" className="form-control" id="email" placeholder="Enter email" />
          </div>
          <div className="mb-3 text-start">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <input type="password" className="form-control" id="password" placeholder="Password" />
          </div>
          <button type="submit" className="btn btn-primary w-100">
            Login
          </button>
        </form>
      </div>
    </div>
  )
}

export default Login
