import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'studentsubjectsummary' })
export class StudentSubjectSummary {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  paperid!: number;

  @Column()
  class!: string;

  @Column()
  section!: string;

  @Column()
  subdomain!: string;

  @Column('float')
  avgPercentage!: number;

  @Column('float')
  avgMarks!: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;
}
