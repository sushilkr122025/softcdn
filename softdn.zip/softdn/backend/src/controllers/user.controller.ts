import {
  Controller,
  Get,
  Param,
  NotFoundException,
  UseGuards,
  Req,
  Post,
  Body,
  Query,
} from '@nestjs/common';
import { UserService } from '../services/user.service';
import { Login } from '../entities/login.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { LoginDto } from '../dto/login.dto';
import { EncryptionService } from '../services/encryption.service';
import { Request } from 'express';
import { StudentInformationDto } from '../dto/student.information.dto';

@UseGuards(JwtAuthGuard)
@Controller('user')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly encryptionService: EncryptionService
  ) {}

  @Post('adduser')
  async addUser(@Req() req: Request, @Body() dto: LoginDto): Promise<any> {
    console.log('req company', req['company']);
    const token = req['company'] as string;
    const loginDto = {
      ...dto,
      tenantid: token,
    };
    return this.userService.createUser(loginDto);
  }

  @Post('updateuser')
  async updateUser(@Body() dto: LoginDto): Promise<any> {
    console.log('dto', dto);
    const loginDto = {
      ...dto,
    };
    return this.userService.updateUser(loginDto);
  }

  @Get('all')
  async findAllUsers(@Req() req: Request): Promise<any[]> {
    const userId = (req.user as { id: number }).id;
    const lookupid = req['company'] as string;
    const users = await this.userService.findAll(lookupid, userId);
    if (!users) {
      throw new NotFoundException('No users found');
    }
    return users;
  }

  @Get('details')
  async UpdateUser(@Req() req: Request, @Query('id') id: number): Promise<any> {
    const data = {
      tenantid: req['company'] as string,
      id: id,
    };
    const user = await this.userService.finsUserDetails(data);
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  @Get('id/:id')
  async findUserById(@Param('id') id: number): Promise<Login> {
    const user = await this.userService.findById(id);
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  @Post('student')
  async addStudent(
    @Req() req: Request,
    @Body() dto: StudentInformationDto
  ): Promise<any> {
    console.log('req company', req['company']);
    const token = req['company'] as string;
    const studentDto = {
      ...dto,
      tenantid: token,
    };
    return await this.userService.createStudent(studentDto);
  }

  @Get('student')
  async findAllStudent(@Req() req: Request, @Query() query): Promise<any[]> {
    // console.log('req', query.class);
    const lookupid = req['company'] as string;
    const users = await this.userService.findAllStudent(lookupid, query);
    if (!users) {
      throw new NotFoundException('No users found');
    }
    return users;
  }

  @Post('addPermissions')
  async addPermissions(
    @Req() req: Request,
    @Body() permissions: any
  ): Promise<any> {
    const tenantid = req['company'] as string;
    const createdBy = (req.user as { id: number }).id; // Assuming user ID is in the request
    const permission = await this.userService.addUserPermissions(
      createdBy,
      permissions,
      tenantid
    );
    if (!permission) {
      throw new NotFoundException('Permission not found');
    }
    return permission;
  }

  @Get('findTeacher')
  async findTeacherByClassAndSubject(
    @Query() query: Record<string, any>
  ): Promise<any> {
    // console.log('classIds', query.classIds, 'subjectId', query.subjectId);
    const teachers = await this.userService.findTeacherByClassAndSubject(
      query.classIds,
      query.subjectId
    );
    if (!teachers) {
      throw new NotFoundException('No teachers found');
    }
    return teachers;
  }

  @Post('createRule')
  async createQuestionRule(
    @Body() data: any,
    @Req() req: Request
  ): Promise<any> {
    const createdBy = (req.user as { id: number }).id;
    const rule = await this.userService.createQuestionRule(data, createdBy);
    if (!rule) {
      throw new NotFoundException('No rule created');
    }
    return rule;
  }
}
