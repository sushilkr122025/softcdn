import { useState, useEffect, useMemo } from 'react'
import { useParams } from 'react-router-dom'
import arucoTL from "../../assets/images/aruco_markers/marker_0.png";
import arucoTR from "../../assets/images/aruco_markers/marker_1.png";
import arucoBL from "../../assets/images/aruco_markers/marker_2.png";
import arucoBR from "../../assets/images/aruco_markers/marker_3.png";
import { BsLayoutSplit } from "react-icons/bs";
import { IoTabletPortraitOutline } from "react-icons/io5";
// ─── Layout Constants ──────────────────────────────────────────────────────────
const BOX       = 45    // answer box size (px)
const ROW_GAP   = 10    // vertical gap between rows
const COL_GAP   = 14    // horizontal gap between columns
const ARUCO     = 52    // aruco marker size (portrait)
const ARUCO_L   = 40    // aruco marker size (landscape half)

// A4 at 96dpi
const A4_W = 794
const A4_H = 1123

// ── Portrait ──
// Usable body height for questions after header (~160px) and aruco padding (56px top+bottom)
const P_PAD        = 32    // page outer padding
const P_HEADER_H   = 168   // approx header + student info table
const P_ARUCO_PAD  = 58    // padding inside aruco zone (each side)
const P_BODY_H     = A4_H - P_PAD * 2 - P_HEADER_H - P_ARUCO_PAD * 2
const P_MAX_ROWS   = Math.floor(P_BODY_H / (BOX + ROW_GAP))  // rows per column per page
const P_MAX_COLS   = 5
const P_PAGE_CAP   = P_MAX_ROWS * P_MAX_COLS

// ── Landscape ──
// Landscape page = A4_H wide x A4_W tall; each half = A4_H/2 wide
const L_HALF_W     = Math.floor(A4_H / 2)  // 561
const L_PAGE_H     = A4_W                   // 794
const L_HALF_PAD   = 20   // half inner padding
const L_HEADER_H   = 168
const L_ARUCO_PAD  = 44
const L_BODY_H     = L_PAGE_H - L_HALF_PAD * 2 - L_HEADER_H - L_ARUCO_PAD * 2
const L_MAX_ROWS   = Math.floor(L_BODY_H / (BOX + ROW_GAP))
const L_MAX_COLS   = 4
const L_HALF_CAP   = L_MAX_ROWS * L_MAX_COLS  // ≈ 40

// ─── Utilities ────────────────────────────────────────────────────────────────

/** Distribute questions into N columns, filling top→bottom left→right */
const toColumns = (questions, colCount) => {
  const n = Math.max(1, colCount)
  const rowsPerCol = Math.ceil(questions.length / n)
  const cols = []
  for (let c = 0; c < n; c++) {
    const slice = questions.slice(c * rowsPerCol, c * rowsPerCol + rowsPerCol)
    if (slice.length) cols.push(slice)
  }
  return cols
}

/**
 * Auto-calculate column count so questions fill the page as evenly as possible.
 * Caps at maxCols, ensures no column exceeds maxRows.
 */
const calcColCount = (total, maxRows, maxCols) => {
  const cols = Math.min(maxCols, Math.ceil(total / maxRows))
  return Math.max(1, cols)
}

/** Split questions into portrait pages */
const toPortraitPages = (questions) => {
  const pages = []
  let rem = [...questions]
  while (rem.length) {
    const pageQs = rem.splice(0, P_PAGE_CAP)
    const colCount = calcColCount(pageQs.length, P_MAX_ROWS, P_MAX_COLS)
    pages.push({ questions: pageQs, colCount })
  }
  return pages
}

/** Split questions into landscape pages (each page = 2 halves) */
const toLandscapePages = (questions) => {
  const pages = []
  const total = questions.length

  if (total <= L_HALF_CAP) {
    // Duplicate: both halves show the same questions
    const colCount = calcColCount(total, L_MAX_ROWS, L_MAX_COLS)
    pages.push({ left: questions, right: questions, duplicate: true, leftCols: colCount, rightCols: colCount })
  } else {
    let rem = [...questions]
    while (rem.length) {
      const left  = rem.splice(0, L_HALF_CAP)
      const right = rem.splice(0, L_HALF_CAP)
      pages.push({
        left,
        right,
        duplicate: false,
        leftCols:  calcColCount(left.length,  L_MAX_ROWS, L_MAX_COLS),
        rightCols: right.length ? calcColCount(right.length, L_MAX_ROWS, L_MAX_COLS) : 0,
      })
    }
  }
  return pages
}

// ─── Sub-components ───────────────────────────────────────────────────────────

const AnswerBox = () => (
  <div style={{ width: BOX, height: BOX, border: '2px solid #000', flexShrink: 0 }} />
)

const QuestionRow = ({ q }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
    <span style={{ minWidth: 46, fontWeight: 600, fontSize: '0.78rem', whiteSpace: 'nowrap' }}>
      {q.queslabel}:
    </span>
    <AnswerBox />
  </div>
)

const QuestionColumns = ({ questions, colCount }) => {
  const cols = toColumns(questions, colCount)
  return (
    <div style={{ display: 'flex', gap: COL_GAP, width: '100%', justifyContent: 'space-between' }}>
      {cols.map((col, ci) => (
        <div key={ci} style={{ display: 'flex', flexDirection: 'column', gap: ROW_GAP, flex: 1 }}>
          {col.map(q => <QuestionRow key={q.id} q={q} />)}
        </div>
      ))}
    </div>
  )
}

const ArucoCorners = ({ size }) => {
  const s = { width: size, height: size, position: 'absolute' }
  return (
    <>
      <img src={arucoTL} alt="tl" style={{ ...s, top: 0, left: 0 }} />
      <img src={arucoTR} alt="tr" style={{ ...s, top: 0, right: 0 }} />
      <img src={arucoBL} alt="bl" style={{ ...s, bottom: 0, left: 0 }} />
      <img src={arucoBR} alt="br" style={{ ...s, bottom: 0, right: 0 }} />
    </>
  )
}

const SheetHeader = () => (
  <div style={{ marginBottom: 8 }}>
    <div style={{ textAlign: 'center', marginBottom: 6 }}>
      <div style={{ fontWeight: 700, fontSize: '1rem', lineHeight: 1.3 }}>ABCD Govt. School</div>
      <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>MARKSHEET</div>
    </div>
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.78rem' }}>
      <tbody>
        <tr>
          <td colSpan={3} style={{ border: '1px solid #000', padding: '3px 6px', height: 26 }}>
            <strong>Student Name:</strong>
          </td>
        </tr>
        <tr>
          <td style={{ border: '1px solid #000', padding: '3px 6px', height: 24, width: '33%' }}><strong>Class:</strong></td>
          <td style={{ border: '1px solid #000', padding: '3px 6px', width: '33%' }}><strong>Sec:</strong></td>
          <td style={{ border: '1px solid #000', padding: '3px 6px', width: '34%' }}><strong>Roll No:</strong></td>
        </tr>
        <tr>
          <td colSpan={3} style={{ border: '1px solid #000', padding: '3px 6px', height: 24 }}>
            <strong>Subject:</strong>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
)

/** One complete sheet (header + aruco zone + questions) */
const Sheet = ({ questions, colCount, arucoSize, arucoPad }) => (
  <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%' }}>
    <SheetHeader />
    <div style={{ position: 'relative', flex: 1, padding: arucoPad }}>
      <ArucoCorners size={arucoSize} />
      <QuestionColumns questions={questions} colCount={colCount} />
    </div>
  </div>
)

// ─── Portrait Page ─────────────────────────────────────────────────────────────
const PortraitPage = ({ questions, colCount }) => (
  <div
    className="print-page"
    style={{
      width: A4_W, minHeight: A4_H,
      padding: P_PAD,
      boxSizing: 'border-box',
      backgroundColor: '#fff',
    }}
  >
    <Sheet
      questions={questions}
      colCount={colCount}
      arucoSize={ARUCO}
      arucoPad={P_ARUCO_PAD}
    />
  </div>
)

// ─── Landscape Page ────────────────────────────────────────────────────────────
const LandscapePage = ({ left, right, duplicate, leftCols, rightCols }) => (
  <div
    className="print-page"
    style={{
      width: A4_H, minHeight: A4_W,
      display: 'flex', flexDirection: 'row',
      backgroundColor: '#fff',
      boxSizing: 'border-box',
    }}
  >
    {/* Left half */}
    <div style={{
      width: L_HALF_W, padding: L_HALF_PAD,
      boxSizing: 'border-box',
      borderRight: '1px dashed #bbb',
      display: 'flex',
    }}>
      <Sheet
        questions={left}
        colCount={leftCols}
        arucoSize={ARUCO_L}
        arucoPad={L_ARUCO_PAD}
      />
    </div>

    {/* Right half */}
    <div style={{
      width: L_HALF_W, padding: L_HALF_PAD,
      boxSizing: 'border-box',
      display: 'flex',
    }}>
      {(right && right.length > 0) || duplicate ? (
        <Sheet
          questions={duplicate ? left : right}
          colCount={duplicate ? leftCols : rightCols}
          arucoSize={ARUCO_L}
          arucoPad={L_ARUCO_PAD}
        />
      ) : (
        <div style={{ flex: 1 }} />
      )}
    </div>
  </div>
)

// ─── Main ──────────────────────────────────────────────────────────────────────
const QuesTemplate = () => {
  const { paperId } = useParams()
  const [questions, setQuestions] = useState([])
  const [loading, setLoading]     = useState(false)
  const [error, setError]         = useState(null)
  const [mode, setMode]           = useState('landscape')

  // useEffect(() => {
  //   const fetchData = async () => {
  //     try {
  //       setLoading(true)
  //       const res = await QuestionServices.GetStudentByClass({ paperId })
  //       setQuestions(res?.questions || res || [])
  //     } catch (err) {
  //       console.error('Failed to fetch questions:', err)
  //       setError('Failed to load questions.')
  //     } finally {
  //       setLoading(false)
  //     }
  //   }
  //   fetchData()
  // }, [paperId])

      useEffect(() => {
        setQuestions([
          { id: 15, sequence: 1, quesType: "multipleChoice", queslabel: "Q1" },
          { id: 18, sequence: 2, quesType: "multipleChoice", queslabel: "Q2" },
          { id: 22, sequence: 3, quesType: "multipleChoice", queslabel: "Q2a" },
          { id: 61, sequence: 4, quesType: "multipleChoice", queslabel: "Q2b" },
          { id: 67, sequence: 5, quesType: "multipleChoice", queslabel: "Q3" },
          { id: 79, sequence: 6, quesType: "multipleChoice", queslabel: "Q4" },
          { id: 97, sequence: 7, quesType: "multipleChoice", queslabel: "Q5a" },
          { id: 98, sequence: 8, quesType: "multipleChoice", queslabel: "Q5b" },
          {id: 112, sequence: 9, quesType: "multipleChoice", queslabel: "Q5c" },
          {id: 115, sequence: 10, quesType: "multipleChoice", queslabel: "Q6" },
          { id: 335, sequence: 11, quesType: "trueFalse", queslabel: "Q7" },
          { id: 336, sequence: 12, quesType: "trueFalse", queslabel: "Q8" },
          { id: 509, sequence: 13, quesType: "trueFalse", queslabel: "Q9" },
          { id: 510, sequence: 14, quesType: "trueFalse", queslabel: "Q10" },
          { id: 511, sequence: 15, quesType: "trueFalse", queslabel: "Q11" },
          { id: 512, sequence: 16, quesType: "trueFalse", queslabel: "Q12" },
          { id: 513, sequence: 17, quesType: "trueFalse", queslabel: "Q13" },
          { id: 514, sequence: 18, quesType: "trueFalse", queslabel: "Q14" },
          { id: 515, sequence: 19, quesType: "trueFalse", queslabel: "Q15" },
          { id: 516, sequence: 20, quesType: "trueFalse", queslabel: "Q16" },
          { id: 10, sequence: 21, quesType: "CR", queslabel: "Q17" },
          { id: 17, sequence: 22, quesType: "CR", queslabel: "Q18" },
          { id: 20, sequence: 23, quesType: "CR", queslabel: "Q19A" },
          { id: 26, sequence: 24, quesType: "CR", queslabel: "Q19B" },
          { id: 28, sequence: 25, quesType: "CR", queslabel: "Q20" },
          { id: 55, sequence: 26, quesType: "CR", queslabel: "Q21" },
          { id: 59, sequence: 27, quesType: "CR", queslabel: "Q22" },
          { id: 82, sequence: 28, quesType: "CR", queslabel: "Q23" },
          { id: 83, sequence: 29, quesType: "CR", queslabel: "Q24" },
          { id: 90, sequence: 30, quesType: "CR", queslabel: "Q25" },

          {id: 600, sequence: 31, quesType: "multipleChoice", queslabel: "Q26", },
          {id: 601, sequence: 32, quesType: "multipleChoice", queslabel: "Q27", },
          {id: 602, sequence: 33, quesType: "multipleChoice", queslabel: "Q28", },
          {id: 603, sequence: 34, quesType: "multipleChoice", queslabel: "Q29", },
          {id: 604, sequence: 35, quesType: "multipleChoice", queslabel: "Q30", },
          {id: 605, sequence: 36, quesType: "multipleChoice", queslabel: "Q31", },
          {id: 606, sequence: 37, quesType: "multipleChoice", queslabel: "Q32", },
          {id: 607, sequence: 38, quesType: "multipleChoice", queslabel: "Q33", },
          {id: 608, sequence: 39, quesType: "multipleChoice", queslabel: "Q34", },
          {id: 609, sequence: 40, quesType: "multipleChoice", queslabel: "Q35", },
          {id: 610, sequence: 41, quesType: "multipleChoice", queslabel: "Q36", },
          {id: 611, sequence: 42, quesType: "multipleChoice", queslabel: "Q37", },
          {id: 612, sequence: 43, quesType: "multipleChoice", queslabel: "Q38", },
          {id: 613, sequence: 44, quesType: "multipleChoice", queslabel: "Q39", },
          {id: 614, sequence: 45, quesType: "multipleChoice", queslabel: "Q40", },

          { id: 615, sequence: 46, quesType: "trueFalse", queslabel: "Q41" },
          { id: 616, sequence: 47, quesType: "trueFalse", queslabel: "Q42" },
          { id: 617, sequence: 48, quesType: "trueFalse", queslabel: "Q43" },
          { id: 618, sequence: 49, quesType: "trueFalse", queslabel: "Q44" },
          { id: 619, sequence: 50, quesType: "trueFalse", queslabel: "Q45" },
          { id: 620, sequence: 51, quesType: "trueFalse", queslabel: "Q46" },
          { id: 621, sequence: 52, quesType: "trueFalse", queslabel: "Q47" },
          { id: 622, sequence: 53, quesType: "trueFalse", queslabel: "Q48" },
          { id: 623, sequence: 54, quesType: "trueFalse", queslabel: "Q49" },
          { id: 624, sequence: 55, quesType: "trueFalse", queslabel: "Q50" },
          { id: 625, sequence: 56, quesType: "trueFalse", queslabel: "Q51" },
          { id: 626, sequence: 57, quesType: "trueFalse", queslabel: "Q52" },
          { id: 627, sequence: 58, quesType: "trueFalse", queslabel: "Q53" },
          { id: 628, sequence: 59, quesType: "trueFalse", queslabel: "Q54" },
          { id: 629, sequence: 60, quesType: "trueFalse", queslabel: "Q55" },
          { id: 630, sequence: 61, quesType: "trueFalse", queslabel: "Q56" },
          { id: 631, sequence: 62, quesType: "trueFalse", queslabel: "Q57" },
          { id: 632, sequence: 63, quesType: "trueFalse", queslabel: "Q58" },
          { id: 633, sequence: 64, quesType: "trueFalse", queslabel: "Q59Ac" },
          { id: 634, sequence: 65, quesType: "trueFalse", queslabel: "Q60" },

          // { id: 635, sequence: 66, quesType: "CR", queslabel: "Q61" },
          // { id: 636, sequence: 67, quesType: "CR", queslabel: "Q62" },
          // { id: 637, sequence: 68, quesType: "CR", queslabel: "Q63" },
          // { id: 638, sequence: 69, quesType: "CR", queslabel: "Q64" },
          // { id: 639, sequence: 70, quesType: "CR", queslabel: "Q65" },
          // { id: 640, sequence: 71, quesType: "CR", queslabel: "Q66" },
          // { id: 641, sequence: 72, quesType: "CR", queslabel: "Q67" },
          // { id: 642, sequence: 73, quesType: "CR", queslabel: "Q68" },
          // { id: 643, sequence: 74, quesType: "CR", queslabel: "Q69" },
          // { id: 644, sequence: 75, quesType: "CR", queslabel: "Q70" },
          // { id: 645, sequence: 76, quesType: "CR", queslabel: "Q71" },
          // { id: 646, sequence: 77, quesType: "CR", queslabel: "Q72" },
          // { id: 647, sequence: 78, quesType: "CR", queslabel: "Q73" },
          // { id: 648, sequence: 79, quesType: "CR", queslabel: "Q74" },
          // { id: 649, sequence: 80, quesType: "CR", queslabel: "Q75" },
          // { id: 650, sequence: 81, quesType: "CR", queslabel: "Q76" },
          // { id: 651, sequence: 82, quesType: "CR", queslabel: "Q77" },
          // { id: 652, sequence: 83, quesType: "CR", queslabel: "Q78" },
          // { id: 653, sequence: 84, quesType: "CR", queslabel: "Q79" },
          // { id: 654, sequence: 85, quesType: "CR", queslabel: "Q80" },
        ]);
      }, []);

  const sorted         = useMemo(() => [...questions].sort((a, b) => a.sequence - b.sequence), [questions])
  const portraitPages  = useMemo(() => toPortraitPages(sorted),  [sorted])
  const landscapePages = useMemo(() => toLandscapePages(sorted), [sorted])

  const handlePrint = () => {
    const printRoot = document.getElementById('ques-print-root')
    if (!printRoot) return

    const printWindow = window.open('', '_blank', 'width=1200,height=900')
    if (!printWindow) {
      alert('Pop-up blocked. Please allow pop-ups for this site and try again.')
      return
    }

    const styles = Array.from(document.querySelectorAll('link[rel="stylesheet"], style'))
      .map(el => el.outerHTML)
      .join('\n')

    const pageSize = mode === 'landscape' ? 'A4 landscape' : 'A4 portrait'

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Print</title>
          ${styles}
          <style>
            * { box-sizing: border-box; }
            body { margin: 0; padding: 0; background: #fff; }
            @page { size: ${pageSize}; margin: 0; }
            .print-page { page-break-after: always; box-shadow: none !important; }
            .print-page:last-child { page-break-after: auto; }
            .no-print { display: none !important; }
          </style>
        </head>
        <body>
          ${printRoot.innerHTML}
        </body>
      </html>
    `)

    printWindow.document.close()

    printWindow.onload = () => {
      const images = printWindow.document.images
      if (images.length === 0) {
        printWindow.focus()
        printWindow.print()
        printWindow.close()
        return
      }
      let loaded = 0
      const onImageLoad = () => {
        loaded++
        if (loaded === images.length) {
          printWindow.focus()
          printWindow.print()
          printWindow.close()
        }
      }
      Array.from(images).forEach(img => {
        if (img.complete) {
          onImageLoad()
        } else {
          img.onload = onImageLoad
          img.onerror = onImageLoad
        }
      })
    }
  }

  const pageCount = mode === 'landscape' ? landscapePages.length : portraitPages.length

  return (
    <div style={{ background: '#d0d0d0', minHeight: '100vh', padding: 24 }}>

      {/* ── Toolbar ── */}
      <div
        className="no-print"
        style={{
          display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24, marginLeft: 'auto', marginRight: 'auto',
          background: '#fff', padding: '10px 18px', borderRadius: 8,
          boxShadow: '0 1px 6px rgba(0,0,0,0.14)', width: 'fit-content',
        }}
      >
        <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#333' }}>Preview Mode:</span>

        {/* Toggle buttons */}
        <div style={{ display: 'flex', border: '1.5px solid #1a1a2e', borderRadius: 6, overflow: 'hidden' }}>
          {[
            { key: 'portrait',  label: 'Portrait', icon: <IoTabletPortraitOutline />, },
            { key: 'landscape', label: 'Landscape', icon: <BsLayoutSplit />, },
          ].map(({ key, label, icon }) => (
            <button
              key={key}
              onClick={() => setMode(key)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '6px 18px', border: 'none', cursor: 'pointer',
                fontWeight: 600,
                background: mode === key ? '#1a1a2e' : '#fff',
                color: mode === key ? '#fff' : '#1a1a2e',
                fontSize: '0.82rem', transition: 'all 0.25s',
              }}
            >
              {icon} {label}
            </button>
          ))}
        </div>

        <button
          onClick={handlePrint}
          style={{
            padding: '7px 22px', background: '#1a1a2e', color: '#fff',
            border: 'none', borderRadius: 6, cursor: 'pointer',
            fontWeight: 700, fontSize: '0.82rem',
          }}
        >
          🖨 Print
        </button>

        {!loading && (
          <span style={{ fontSize: '0.78rem', color: '#666' }}>
            {sorted.length} questions · {pageCount} page{pageCount !== 1 ? 's' : ''}
            {mode === 'landscape' && sorted.length <= L_HALF_CAP ? ' (duplicated)' : ''}
          </span>
        )}
      </div>

      {/* ── Print Root ── */}
      <div id="ques-print-root">
        {loading && (
          <div style={{ textAlign: 'center', padding: 60, color: '#555' }}>Loading questions…</div>
        )}
        {error && (
          <div style={{ background: '#fee', padding: 16, borderRadius: 8, color: '#c00' }}>{error}</div>
        )}
        {!loading && !error && sorted.length === 0 && (
          <div style={{ textAlign: 'center', padding: 60, color: '#888' }}>No questions found.</div>
        )}

        {!loading && !error && sorted.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 32 }}>

            {mode === 'portrait' && portraitPages.map((page, pi) => (
              <div key={pi} style={{ boxShadow: '0 3px 16px rgba(0,0,0,0.20)' }}>
                <PortraitPage questions={page.questions} colCount={page.colCount} />
              </div>
            ))}

            {mode === 'landscape' && landscapePages.map((page, pi) => (
              <div key={pi} style={{ boxShadow: '0 3px 16px rgba(0,0,0,0.20)' }}>
                <LandscapePage
                  left={page.left}
                  right={page.right}
                  duplicate={page.duplicate}
                  leftCols={page.leftCols}
                  rightCols={page.rightCols}
                />
              </div>
            ))}

          </div>
        )}
      </div>
    </div>
  )
}

export default QuesTemplate
