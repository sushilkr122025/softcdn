import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_APIHOST

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
})

// Response Interceptor (Global error handling)
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // console.error('API Error:', error.response?.data?.message || error.message)
    return Promise.reject(error)
  }
)

// for globally handling logout

// apiClient.interceptors.response.use(
//   (response) => response,
//   (error) => {
//     if (error.response?.status === 401) {
//       localStorage.removeItem('token')
//       window.location.href = '/login' // or use navigation if inside React Router
//     }
//     return Promise.reject(error)
//   }
// )

export default apiClient
