import { createContext, useContext } from 'react'

export const LicenseContext = createContext()

const useLicense = () => useContext(LicenseContext)

export default useLicense