import { useEffect, useState } from 'react';
import './Question.css';
import queServices from '../../api/QuestionServices';
import { Link } from 'react-router-dom';
import useAuth from '../../context/AuthContext';
import { loaderStore } from '../../LoaderStore';
import { DataGrid } from '@mui/x-data-grid';
import { MdPreview } from "react-icons/md";

const PanelItem = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const { user } = useAuth();
  const qTypeConvert = { multipleChoice: 'Multiple Choice', trueFalse: 'True/False', oneWord: 'One Word', CR: 'Written Response', fillups: 'Fill in the Blanks', match: 'Match the Following' };

  useEffect(() => {
    const fetchData = async () => {
      try {
        loaderStore.set(true);
        const result = await queServices.getPanelItems();
        // console.log('Panel Items Data:', result);
        setData(result.data || []);
      } catch (err) {
        console.error(err);
        setError('Failed to load panel items');
      } finally {
        setLoading(false);
        loaderStore.set(false);
      }
    };

    fetchData();
  }, []);

  const columns = [
    {
      field: "srNo",
      headerName: "SR No",
      renderCell: (params) => params.api.getRowIndexRelativeToVisibleRows(params.id) + 1
    },
    {
      field: "id",
      headerName: "Que. Id",
    },
    {
      field: "question",
      headerName: "Question",
      flex: 1,
      renderCell: (params) => (
        <div
          dangerouslySetInnerHTML={{
            __html: params.row.question
          }}
        />
      )
    },
    {
      field: 'subject',
      headerName: 'Subject',
      renderCell: (params) => (
        params.row.subject
      ),
    },
    {
      field: 'class',
      headerName: 'Class',
      renderCell: (params) => (
        params.row.class
      ),
    },
    {
      field: "name",
      headerName: "Author",
      renderCell: (params) =>
        params.row.tId !== user?.id ? params.row.name : "You"
    },
    {
      field: "revision",
      headerName: "Version",
      width: 100
    },
    {
      field: 'quesType',
      headerName: 'Type',
      renderCell: (params) => (
        qTypeConvert[params.row.quesType]
      ),
    },
    {
      field: "createdAt",
      headerName: "Date",
      width: 140,
      valueFormatter: (params) => {
        const date = new Date(params);
        if (isNaN(date)) return '';
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear().toString().slice(-2);
        return `${day}-${month}-${year}`;
      },
    },
    {
      field: "action",
      headerName: "Action",
      width: 140,
      sortable: false,
      renderCell: (params) => (
        <Link
          to={`/question/panel/${params.row.id}`}
          
        >
          <button className="btn btn-secondary btn-sm">
            <MdPreview className='me-3' />
            Review
          </button>
        </Link>
      )
    }
  ];

  if (loading) {
    return <p className="text-center">Loading...</p>;
  }

  if (error) {
    return <p className="text-center text-danger">{error}</p>;
  }

  return (
    <div className="p-lg-4">
      <div className="container-fluid">
        <div className="row h-80vh">
          <div className="col-12 mx-auto content-bg p-lg-4 py-4">
            <div className="row">

              <div className="col-12 py-3 d-flex align-items-end">
                <h5 className="headingmain mb-0">Review Assessment</h5>
              </div>

              <div className="col-12">
                {data.length === 0 ? (
                  <p className="text-center">Data not found</p>
                ) : (
                  <div className="w-100 h-72vh">
                    <DataGrid
                      className="custom-data-grid"
                      rows={data}
                      columns={columns}
                      loading={loading}
                      getRowId={(row) => row.id}
                      disableRowSelectionOnClick
                      pageSizeOptions={[25, 50, 100]}
                      initialState={{
                        pagination: {
                          paginationModel: { pageSize: 25, page: 0 }
                        }
                      }}
                      getRowHeight={() => 43}
                      columnHeaderHeight={45}
                    />
                  </div>
                )}
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PanelItem;