import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({ name: 'canvasimage' })
export class CanvasImage {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: '50' })
  tenantId: string;

  @Column({ type: 'json' })
  rawImage: object | null;

  @Column({
    type: 'char',
    length: 5,
    default: 'I',
  })
  dmlType: string;

  @CreateDateColumn({ type: 'datetime' })
  createDateTime: Date;

  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt: Date;
}
