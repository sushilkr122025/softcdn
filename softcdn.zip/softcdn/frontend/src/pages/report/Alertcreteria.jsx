import React, { useEffect, useState } from 'react'
import MultiServices from '../../api/MultiServices'
import useAuth from '../../context/AuthContext'

const Alertcreteria = () => {
  const { user } = useAuth()

  const [formData, setFormData] = useState({
    class: '',
    section: '',
    subject: '',
    subdomain: '',
    criteria: '',
    type: '',
    createdby: user.id,
  })
  const [classes, setClasses] = useState([])
  const [sections, setSections] = useState([])
  const [subjects, setSubjects] = useState([])
  const [subdomains, setSubdomains] = useState([])

  const [alertlist, setAlertlist] = useState([])

  useEffect(() => {
    async function fetchClass() {
      const response = await MultiServices.ClassList()
      setClasses(response)
    }
    fetchClass()
    async function fetchSection() {
      const response = await MultiServices.SectionList()
      setSections(response)
    }
    fetchSection()
    async function fetchSubject() {
      const response = await MultiServices.SubjectList()
      setSubjects(response)
    }
    fetchSubject()
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }
  const handleSubject = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    async function fetchSubdomain() {
      const response = await MultiServices.SubdomainList(value)
      setSubdomains(response)
    }
    fetchSubdomain()
  }

  const handelFetch = async () => {
    const response = await MultiServices.AertConditionList()
    setAlertlist(response.result)
  }
  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await MultiServices.AertCondition(formData)
      setFormData({
        class: '',
        section: '',
        subject: '',
        subdomain: '',
        criteria: '',
        type: '',
        createdby: user.id,
      })
      handelFetch()
    } catch (error) {
      console.log(error)
    }
  }

  // useEffect(()=>{
  //   handelFetch();
  //   },[])
  // let formatDate = (datestr) =>{
  //   const str = datestr.split('T')
  //   const [year, month, day] = str[0].split('-')
  //   let newDate = `${day}-${month}-${year}`
  //   return newDate
  // }
  let formatDate = (datestr) => {
    const newDate = new Date(datestr)
      .toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
      })
      .replace(/\//g, '-')
      .replace(/,/g, '')
      .replace(/am|pm/gi, (match) => match.toUpperCase())
    return newDate
  }

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-12">
          <h1 className="mb-4">Alert Criteria/threshold</h1>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <input
                type="hidden"
                value={formData.createdby}
                id="createdby"
                name="createdby"
                onChange={handleChange}
              />
              <label htmlFor="criteria" className="form-label">
                Alert Criteria/threshold in % <span className="text-danger">*</span>
              </label>
              <input
                type="text"
                id="criteria"
                name="criteria"
                className="form-control"
                value={formData.criteria}
                onChange={handleChange}
                required
              />
            </div>

            <div className="mb-3">
              <label htmlFor="type" className="form-label">
                Type <span className="text-danger">*</span>
              </label>
              <select
                id="type"
                name="type"
                className="form-control"
                value={formData.type}
                onChange={handleChange}
                required
              >
                <option value="">Please Select</option>
                <option value="<">Lower</option>
                <option value="=">Equal</option>
              </select>
            </div>
            <div className="mb-3">
              <label htmlFor="class" className="form-label">
                Class
              </label>
              <select
                id="class"
                name="class"
                className="form-control"
                value={formData.class}
                onChange={handleChange}
              >
                <option value="">Select</option>
                {classes.map((e, i) => (
                  <option key={i} value={e.id}>
                    {e.class}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label htmlFor="section" className="form-label">
                Section
              </label>
              <select
                className="form-select"
                name="section"
                id="section"
                value={formData.section}
                onChange={handleChange}
              >
                <option value="">Select</option>
                {sections.map((e, i) => (
                  <option value={e.section} key={i}>
                    {e.section}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label htmlFor="subject" className="form-label">
                Subject
              </label>
              <select
                id="subject"
                name="subject"
                className="form-control"
                value={formData.subject}
                onChange={handleSubject}
              >
                <option value="">Select</option>
                {subjects.map((e, i) => (
                  <option key={i} value={e.id}>
                    {e.Subject}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label htmlFor="subdomain" className="form-label">
                Subdomain
              </label>
              <select
                type="text"
                id="subdomain"
                name="subdomain"
                className="form-control"
                value={formData.subdomain}
                onChange={handleChange}
              >
                <option value="">Select</option>
                {subdomains.map((e, i) => (
                  <option key={i} value={e.Subject}>
                    {e.Subject}
                  </option>
                ))}
              </select>
            </div>

            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </form>
        </div>
      </div>
      {alertlist.length > 0 && (
        <div className="row">
          <div className="col-md-12">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Criteria %</th>
                  <th>Type of</th>
                  <th>Class</th>
                  <th>Subject</th>
                  <th>Created By</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {alertlist.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td>{item.id}</td>
                      <td>{item.criteria}</td>
                      <td>{item.typeof}</td>
                      <td>
                        {item.class} {item.section}
                      </td>
                      <td>
                        {item.subject} {item.subdomain}
                      </td>
                      <td>{item.createdby}</td>
                      <td>{formatDate(item.createdate)}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}

export default Alertcreteria
