import apiClient from './apiService'

export const validateLicense = async (tenantId, licenseKey) => {
  console.log(`Validating license for tenantId: ${tenantId}, licenseKey: ${licenseKey}`);
  
  try {
    const res = await apiClient.post('/api/validate-license', { tenantId, licenseKey })
    const data = res.data
    if (data.valid) {
      return { success: true, license: data.license }
    } else {      
      return { success: false, reason: data.reason }
    }
  } catch (error) {
    console.log(error);
    return { success: false, reason: error.response.data }
  }
}
