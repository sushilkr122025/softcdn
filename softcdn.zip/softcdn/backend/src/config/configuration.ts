export default () => ({
  keybcrypt: process.env.KEY_SECRET,
  app: {
    port: parseInt(process.env.APP_PORT || '3000', 10),
    origin: process.env.CORS_ORIGIN,
    ckey: process.env.OPTIONAL_PLUGIN_NAME,
    typeiv: process.env.OPTIONAL_PLUGIN,
  },
  database: {
    type: process.env.DATABASE_TYPE,
    host: process.env.DATABASE_HOST,
    port: parseInt(process.env.DATABASE_PORT || '3306', 10),
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
  },
  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || '1h',
  },
  message: {
    startapp: 'Education backend starting...',
    stopapp: 'Stopping Education application...',
    appstarted: (port: string) => `Application started successfully on port ${port}`,
    appstopped: 'Application stopped',
    appfailed: 'Application failed to start',
    appconfig: 'Application configuration loaded successfully',
    appconfigfailed: 'Application configuration failed to load',
  },
  uploadloc: process.env.CUSTOM_LOC || `'..', '..', '..'`,
});
