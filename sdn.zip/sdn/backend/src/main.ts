import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import * as cookieParser from 'cookie-parser';
import { WinstonModule } from 'nest-winston';
import { winstonLoggerOptions } from './config/winston.logger';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {
    logger: WinstonModule.createLogger(winstonLoggerOptions),
  });
  app.setGlobalPrefix('api');
  app.use(cookieParser());
  const configService = app.get(ConfigService);
  const port = configService.get<string>('app.port') || '3000';
  app.enableCors({
    origin: configService.get<string>('app.origin'),
    credentials: true,
  });
  await app.listen(port, '0.0.0.0');
  // await app.listen(8081, '0.0.0.0');
}
void bootstrap();
