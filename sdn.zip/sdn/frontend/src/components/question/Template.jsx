import React, { useState } from 'react'
import { IoImageOutline } from 'react-icons/io5'
import { useNavigate } from 'react-router-dom'

const Template = () => {
const [activeTemplate, setActiveTemplate] = useState(null)
const [tempData, setTempData] = useState()

const navigate = useNavigate();

const handleRadioChange = (templateId) => {
  setActiveTemplate(templateId)

  switch (templateId) {
    case 'template1':
      setTempData({question: 'withImage', options: 'both'});
      break;
    case 'template2':
      setTempData({question: 'withImage', options: 'text'});
      break;
    case 'template3':
      setTempData({question: 'withImage', options: 'image'});
      break;
    case 'template4':
      setTempData({question: 'withoutImage', options: 'both'});
      break;
    case 'template5':
      setTempData({question: 'withoutImage', options: 'text'});
      break;
    case 'template6':
      setTempData({question: 'withoutImage', options: 'image'});
      break;
    default:
      setTempData({question: '', options: ''});
  }
}

  return (

    <div className="container mb-5">
      <div className="row">
        <div className="col-md-12 text-center p-3">
          <h4>Choose Template for Create Question</h4>
        </div>
      </div>
      <div className="row mb-3 justify-content-center">
        <div className="col-3 text-center">
          <div
            className={`ques-temp ${activeTemplate === 'template1' ? 'active' : ''}`}
            onClick={() => handleRadioChange('template1')}
          >
            <div className="skeleton"><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton-Lgimage">
              <IoImageOutline />
            </div>
            <div className="options">
              <div className="options-skeleton">
                <span className='skeleton-ques'>option1...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
                <span className='skeleton-ques'>option2...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option3...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option4...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
          </div>
        </div>
        <div className="col-3 text-center">
          <div
            className={`ques-temp ${activeTemplate === 'template2' ? 'active' : ''}`}
            onClick={() => handleRadioChange('template2')}
          >
            <div className="skeleton"  ><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton-Lgimage">
              <IoImageOutline />
            </div>
            <div className="options mb-4 mt-4">
              <div className="options-skeleton">
                <span className='skeleton-ques'>option1...</span>
              </div>
            </div>
            <div className="options mb-4">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option2...</span>
              </div>
            </div>
            <div className="options mb-4">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option3...</span>
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option4...</span>
              </div>
            </div>
          </div>
        </div>
        <div className="col-3 text-center">
          <div className={`ques-temp ${activeTemplate === 'template3' ? 'active' : ''}`}
          onClick={() => handleRadioChange('template3')}
          >
            <div className="skeleton"  ><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton-Lgimage">
              <IoImageOutline />
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row justify-content-center">
        <div className="col-3 text-center">
          <div className={`ques-temp ${activeTemplate === 'template4' ? 'active' : ''}`}
           onClick={() => handleRadioChange('template4')}
          >
            <div className="skeleton"><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="options mt-3">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option2...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option2...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option4...</span>
              </div>
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
          </div>
        </div>
        <div className="col-3 text-center">
          <div className={`ques-temp ${activeTemplate === 'template5' ? 'active' : ''}`}
            onClick={() => handleRadioChange('template5')}
          >
            <div className="skeleton"><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="options mb-4 mt-4">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option1...</span>
              </div>
            </div>
            <div className="options mb-4">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option2...</span>
              </div>
            </div>
            <div className="options mb-4">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option3...</span>
              </div>
            </div>
            <div className="options">
              <div className="options-skeleton">
              <span className='skeleton-ques'>option4...</span>
              </div>
            </div>
          </div>
        </div>
        <div className="col-3 text-center">
          <div className={`ques-temp ${activeTemplate === 'template6' ? 'active' : ''}`}
            onClick={() => handleRadioChange('template6')}
          >
            <div className="skeleton"><span className='skeleton-ques'>Question...</span></div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="skeleton">&zwnj;</div>
            <div className="options mt-3">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
            <div className="options">
              <div className="skeleton-image">
                <IoImageOutline />
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 text-center mt-5">
            <button className='btn btn-lg lq-blue-color' onClick={() => navigate('/questionGeneration', {state : {templateData: tempData}})}>Use this for create question</button>
        </div>
      </div>
    </div>

  )
}
export default Template
