import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('statenconstituencies')
export class StateNConstituency {
  @PrimaryGeneratedColumn({ name: 'Id' })
  id: number;

  @Column({ type: 'varchar', length: 100 })
  stateNConsti: string;

  @Column({ type: 'varchar', length: 3 })
  idParent: string;

  @Column({ type: 'tinyint', width: 1 })
  status: boolean;

  @Column({ type: 'datetime' })
  createdatetime: Date;
}
