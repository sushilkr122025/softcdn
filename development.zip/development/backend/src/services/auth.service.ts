import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Login } from '../entities/login.entity';
import { LoginDto } from '../dto/login.dto';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { LoginActivity } from '../entities/login.activity';
import { UserAgentService } from './user-agent.service';
import { EncryptionService } from './encryption.service';
import { UserPermission } from '../entities/user.permissions.entity';
import {
  SchoolSetting,
  SchoolSettingDto,
} from 'src/entities/school.setting.entity';
interface Log {
  loginId: string;
  tenantId: string;
  userAgent: string;
  logType: string;
  logDetail: string;
}
@Injectable()
export class AuthService {
  private readonly keybrcyt: string;
  constructor(
    @InjectRepository(Login)
    private loginRepository: Repository<Login>,
    @InjectRepository(LoginActivity)
    private logsRepository: Repository<LoginActivity>,
    @InjectRepository(UserPermission)
    private userPermissionRepo: Repository<UserPermission>,
    @InjectRepository(SchoolSetting)
    private schoolSettingRepository: Repository<SchoolSetting>,
    private readonly userAgentService: UserAgentService,
    private readonly configuration: ConfigService,
    private jwtService: JwtService,
    private readonly encryptionService: EncryptionService
  ) {
    this.keybrcyt = this.configuration.get<string>('keybcrypt') || 'education';
  }

  async findAll(): Promise<Login[]> {
    return this.loginRepository.find();
  }

  findByEmail(email: string): Promise<Login | null> {
    return this.loginRepository.findOne({ where: { email } });
  }

  async findById(id: number, tenantid: string): Promise<any> {
    const user = await this.loginRepository.findOne({
      where: { id, tenantid },
    });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    
    // const _date = this.encryptionService.encrypt(String(user.id));
    // const data = {
    //   id: user.id,
    //   name: user.name,
    //   role: user.role,
    //   _date: _date,
    // };

    return user;
  }

  async findUserAndPermission(id: number, tenantid: string): Promise<any | null> {
    const user = await this.loginRepository.findOne({
      where: { id, tenantid },
    });
    if (!user) {
      return null;
    }
    
    const _date = this.encryptionService.encrypt(String(user.id));
    const data = {
      id: user.id,
      name: user.name,
      role: user.role,
      _date: _date,
    };
    const permission = await this.userPermissionRepo.find({
        where: { userId: user.id },
      });

    return { user: data, permission: permission };
  }
  //partial also use for create by like create(user: Partial<User>): Promise<User>

  async createUser(loginDto: LoginDto): Promise<Login> {
    const user = new Login();
    Object.assign(user, loginDto);
    user.password = user.password + this.keybrcyt;
    await user.hashPassword();
    return this.loginRepository.save(user);
  }

  async update(id: number, login: Login): Promise<Login | null> {
    await this.loginRepository.update(id, login);
    return this.loginRepository.findOne({ where: { id } });
  }

  async validateUser(
    email: string,
    plainPassword: string,
    tenantid: string,
    userAgent: string
  ): Promise<{
    access_token: any;
    user: { id: number; name: string; role: string; _date: string };
    permission: UserPermission[];
  }> {
    const userAgentInfo = this.userAgentService.parse(userAgent);
    const user = await this.loginRepository.findOne({
      where: [
        { email: email, tenantid: tenantid },
        { userid: email, tenantid: tenantid },
        { mobileno: email, tenantid: tenantid },
      ],
    });
    if (!user) {
      const lookupData: Log = {
        loginId: email,
        tenantId: tenantid,
        userAgent: JSON.stringify(userAgentInfo),
        logType: 'Failed',
        logDetail: 'Invalid credentials',
      };
      const log = this.logsRepository.create(lookupData);
      await this.logsRepository.save(log);
      throw new NotFoundException('Invalid credentials');
    }

    const isMatch = await user.comparePassword(plainPassword + this.keybrcyt);
    if (!isMatch) {
      const lookupData: Log = {
        loginId: email,
        tenantId: tenantid,
        userAgent: JSON.stringify(userAgentInfo),
        logType: 'Failed',
        logDetail: 'Invalid credentials',
      };
      const log = this.logsRepository.create(lookupData);
      await this.logsRepository.save(log);
      throw new UnauthorizedException('Invalid credentials');
    }
    const lookupData: Log = {
      loginId: user.id.toString(),
      tenantId: tenantid,
      userAgent: JSON.stringify(userAgentInfo),
      logType: 'Success',
      logDetail: 'Login',
    };
    const log = this.logsRepository.create(lookupData);
    await this.logsRepository.save(log);
    user.updatedDate = new Date();
    await this.loginRepository.save(user);
    const permission = await this.userPermissionRepo.find({
      where: { userId: user.id },
    });
    const payload = { id: user.id, name: user.name, role: user.role };
    const access_token = this.jwtService.sign(payload);
    const encrypt_token = access_token; //this.encryptionService.encrypt(String(access_token));
    const _date = this.encryptionService.encrypt(String(user.id));
    // console.log('Encrypted date:', _date);
    return {
      access_token: encrypt_token,
      user: {
        id: user.id,
        name: user.name,
        role: user.role,
        _date: _date,
      },
      permission: permission,
    };
  }

  async findAppSetting(tenantid: string): Promise<SchoolSettingDto[] | null> {
    const setting = await this.schoolSettingRepository.find({
      select: ['id', 'settingName', 'settingValue'],
      where: { tenantid },
    });
    if (!setting) {
      return null;
    }
    return setting;
  }
}
