import React, { useEffect, useState } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { Row, Col, Form, Container, Card, Button, Spinner } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import { formatDate } from '../utils/util'
import apiClient from '../api/apiService'
import CustomDropdown from '../components/layout/CustomDropdown'

const StudentRegistration = () => {
  const navigator = useNavigate()
  const parameters = new URLSearchParams(window.location.search)
  const updateId = parameters.get('id')
  const { register, handleSubmit, reset, control, formState: { errors, isSubmitting }, } = useForm({ mode: 'onChange', })
  const [studentData, setStudentData] = useState(null)
  const [sectionData, setSectionData] = useState([])
  const [classOptions, setClassOptions] = useState([])
  const [stateOptions, setStateOptions] = useState([])
  const [districtOptions, setDistrictOptions] = useState([])
  const [openKey, setOpenKey] = useState("");
  const [isLoading, setIsLoading] = useState(false)
  const fetchUserData = async () => {
    if (updateId) {
      try {
        // Fetch data logic goes here
      } catch (error) {
        console.error(error.message)
      }
    }
  }

  useEffect(() => {
    fetchUserData()
  }, [updateId])

  useEffect(() => {
    apiClient
      .get('/store/section')
      .then((response) => {
        setSectionData(response.data || [])
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        setClassOptions(response.data || [])
      })
      .catch((error) => {
        console.error('Error fetching classes:', error)
      })

    apiClient
      .get('/store/statesndistrict', { params: { stateId: '0' } })
      .then((response) => {
        setStateOptions(response.data || [])
      })
      .catch((error) => {
        console.error('Error fetching state:', error)
      })
  }, [])

  const fetchDistricts = async (stateId) => {
    try {
      const response = await apiClient.get('/store/statesndistrict', {
        params: { stateId },
      })
      setDistrictOptions(response.data || [])
    } catch (error) {
      console.error('Error fetching district data:', error)
    }
  }

  const fetchStudentData = async () => {
    if (!updateId) return

    try {
      setIsLoading(true)
      const response = await apiClient.get(`/user/student/${updateId}`)
      const data = response?.data || response?.userdata || response?.studentData || {}

      setStudentData(data)
      reset({
        ...data,
        dateOfBirth: data?.dateOfBirth ? formatDate(data.dateOfBirth) : '',
      })

      if (data?.state) {
        await fetchDistricts(data.state)
      }
    } catch (error) {
      console.error('Error fetching student data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchStudentData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [updateId])

  const onSubmit = async (data) => {
    console.log('Form Data:', data)
    try {
      if (updateId || data.id) {
        const response = await apiClient.put(`/user/student/${data.id || updateId}`, data)

        if (response.status === 200) {
          navigator('/dashboard')
        } else {
          console.error('Failed to update data.')
        }
      } else {
        const response = await apiClient.post('/user/student', data)

        if (response.status === 200 || response.status === 201) {
          navigator('/dashboard')
        } else {
          console.error('Failed to insert data.')
        }
      }
    } catch (error) {
      console.error('An error occurred:', error)
    }
  }

  if (updateId && isLoading && !studentData) {
    return <div>Loading...</div>
  }

  return (
    <div className="position-relative h-80vh d-flex flex-column">
      <div className="useraddbanner"></div>

      <div className="d-flex flex-grow-1">
        <Container className="my-5">
          <Row className="justify-content-center mt-5 pt-xxl-5">
            <Col lg={10} xl={9}>
              <Card className="border-0 custom-shadow">
                <Card.Body className="p-4 p-md-5">
                  <Form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
                    <div className="mb-4 row">
                      <div className="col-9">
                        <h4 className="fw-bold usertext mb-1">
                          Student Registration
                        </h4>
                        <hr className="border border-primary border-2 rounded opacity-100 mt-0 w-25" />
                      </div>
                    </div>

                    <Row className="g-3">
                      {updateId && (
                        <Form.Control
                          type="hidden"
                          defaultValue={studentData?.id || updateId}
                          {...register('id')}
                        />
                      )}

                      <Col md={6} lg={4}>
                        <Form.Group controlId="name">
                          <Form.Label className="text-muted small fw-bold">
                            Name
                          </Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Student Name.."
                             autoComplete="new-password"
                            {...register('name', {
                              required: 'Name is required',
                              pattern: {
                                value: /^[A-Za-z\s]+$/,
                                message: 'Only alphabetic characters are allowed',
                              },
                            })}
                            className={`py-2 ${errors.name ? 'is-invalid' : ''}`}
                          />
                          {errors.name && (
                            <div className="invalid-feedback small">
                              {errors.name.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="rollNo">
                          <Form.Label className="text-muted small fw-bold">
                            Roll No
                          </Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Roll No.."
                            {...register('rollNo', {
                              required: 'Roll Number is required',
                            })}
                            className={`py-2 ${errors.rollNo ? 'is-invalid' : ''}`}
                          />
                          {errors.rollNo && (
                            <div className="invalid-feedback small">
                              {errors.rollNo.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="class">
                          <Form.Label className="text-muted small fw-bold">
                            Class
                          </Form.Label>
                          <Controller
                            name="class"
                            control={control}
                            rules={{ required: 'Class is required' }}
                            defaultValue=""
                            render={({ field }) => (
                              <CustomDropdown
                                dropdownKey="class"
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                placeholder="Please Select"
                                value={field.value}
                                error={!!errors.class}
                                options={(classOptions || []).map((item) => ({
                                  value: item.class,
                                  label: item.class,
                                }))}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.class && (
                            <div className="invalid-feedback small d-block">
                              {errors.class.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="section">
                          <Form.Label className="text-muted small fw-bold">
                            Section
                          </Form.Label>
                          <Controller
                            name="section"
                            control={control}
                            rules={{ required: 'Section is required' }}
                            defaultValue=""
                            render={({ field }) => (
                              <CustomDropdown
                                dropdownKey="section"
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                placeholder="Please Select"
                                value={field.value}
                                error={!!errors.section}
                                options={(sectionData || []).map((item) => ({
                                  value: item.section,
                                  label: item.section,
                                }))}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.section && (
                            <div className="invalid-feedback small d-block">
                              {errors.section.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="gender">
                          <Form.Label className="text-muted small fw-bold">
                            Gender
                          </Form.Label>
                          <Controller
                            name="gender"
                            control={control}
                            rules={{ required: 'Gender is required' }}
                            defaultValue=""
                            render={({ field }) => (
                              <CustomDropdown
                                dropdownKey="gender"
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                placeholder="Please Select"
                                value={field.value}
                                error={!!errors.gender}
                                options={[
                                  { value: 'Male', label: 'Male' },
                                  { value: 'Female', label: 'Female' },
                                  { value: 'May not prefer', label: 'May Not Prefer' },
                                ]}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.gender && (
                            <div className="invalid-feedback small d-block">
                              {errors.gender.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="dateOfBirth">
                          <Form.Label className="text-muted small fw-bold">
                            Date of Birth
                          </Form.Label>
                          <Form.Control
                            type="date"
                            defaultValue={
                              studentData?.dateOfBirth
                                ? formatDate(studentData.dateOfBirth)
                                : ''
                            }
                            {...register('dateOfBirth', {
                              required: 'Date of Birth is required',
                            })}
                            className={`py-2 ${errors.dateOfBirth ? 'is-invalid' : ''}`}
                          />
                          {errors.dateOfBirth && (
                            <div className="invalid-feedback small">
                              {errors.dateOfBirth.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="emailId">
                          <Form.Label className="text-muted small fw-bold">
                            Email ID
                          </Form.Label>
                          <Form.Control
                            type="email"
                             autoComplete="new-password"
                            placeholder="name@gmail.com"
                            defaultValue={studentData?.emailId || ''}
                            {...register('emailId', {
                              required: 'Email ID is required',
                              pattern: {
                                value:
                                  /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                message: 'Invalid email address',
                              },
                            })}
                            className={`py-2 ${errors.emailId ? 'is-invalid' : ''}`}
                          />
                          {errors.emailId && (
                            <div className="invalid-feedback small">
                              {errors.emailId.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="fatherName">
                          <Form.Label className="text-muted small fw-bold">
                            Father Name
                          </Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Father Name.."
                            {...register('fatherName', {
                              required: 'Father Name is required',
                              pattern: {
                                value: /^[A-Za-z\s]+$/,
                                message: 'Only alphabetic characters are allowed',
                              },
                            })}
                            className={`py-2 ${errors.fatherName ? 'is-invalid' : ''
                              }`}
                          />
                          {errors.fatherName && (
                            <div className="invalid-feedback small">
                              {errors.fatherName.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="motherName">
                          <Form.Label className="text-muted small fw-bold">
                            Mother Name
                          </Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Mother Name.."
                            {...register('motherName', {
                              required: 'Mother Name is required',
                              pattern: {
                                value: /^[A-Za-z\s]+$/,
                                message: 'Only alphabetic characters are allowed',
                              },
                            })}
                            className={`py-2 ${errors.motherName ? 'is-invalid' : ''
                              }`}
                          />
                          {errors.motherName && (
                            <div className="invalid-feedback small">
                              {errors.motherName.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="contactNumber">
                          <Form.Label className="text-muted small fw-bold">
                            Contact No.
                          </Form.Label>
                          <Form.Control
                            type="text"
                            maxLength={10}
                            placeholder="10-digit mobile"
                            {...register('contactNumber', {
                              required: 'Contact Number is required',
                              pattern: {
                                value: /^[0-9]{10}$/,
                                message: 'Number must be 10 digits and numerical',
                              },
                            })}
                            className={`py-2 ${errors.contactNumber ? 'is-invalid' : ''
                              }`}
                          />
                          {errors.contactNumber && (
                            <div className="invalid-feedback small">
                              {errors.contactNumber.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="alternativeContactNumber">
                          <Form.Label className="text-muted small fw-bold">
                            Alt. Contact No.
                          </Form.Label>
                          <Form.Control
                            type="text"
                            maxLength={10}
                            placeholder="Alternate mobile"
                            {...register('alternativeContactNumber', {
                              pattern: {
                                value: /^[0-9]{10}$/,
                                message: 'Number must be 10 digits and numerical',
                              },
                            })}
                            className={`py-2 ${errors.alternativeContactNumber ? 'is-invalid' : ''
                              }`}
                          />
                          {errors.alternativeContactNumber && (
                            <div className="invalid-feedback small">
                              {errors.alternativeContactNumber.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={8}>
                        <Form.Group controlId="address">
                          <Form.Label className="text-muted small fw-bold">
                            Address
                          </Form.Label>
                          <Form.Control
                           autoComplete="new-password"
                            type="text"
                            placeholder="Address.."
                            {...register('address', {
                              required: 'Address is required',
                            })}
                            className={`py-2 ${errors.address ? 'is-invalid' : ''}`}
                          />
                          {errors.address && (
                            <div className="invalid-feedback small">
                              {errors.address.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="state">
                          <Form.Label className="text-muted small fw-bold">
                            State
                          </Form.Label>
                          <Controller
                            name="state"
                            control={control}
                            rules={{ required: 'State is required' }}
                            defaultValue=""
                            render={({ field }) => (
                              <CustomDropdown
                                dropdownKey="state"
                                placeholder="Please Select"
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                value={field.value}
                                error={!!errors.state}
                                options={(stateOptions || []).map((item) => ({
                                  value: item.id,
                                  label: item.stateNConsti,
                                }))}
                                onChange={(val) => {
                                  field.onChange(val)
                                  fetchDistricts(val)
                                }}
                              />
                            )}
                          />
                          {errors.state && (
                            <div className="invalid-feedback small d-block">
                              {errors.state.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>

                      <Col md={6} lg={4}>
                        <Form.Group controlId="district">
                          <Form.Label className="text-muted small fw-bold">
                            District
                          </Form.Label>
                          <Controller
                            name="district"
                            control={control}
                            rules={{ required: 'District is required' }}
                            defaultValue=""
                            render={({ field }) => (
                              <CustomDropdown
                                dropdownKey="district"
                                placeholder="Please Select"
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                value={field.value}
                                error={!!errors.district}
                                options={(districtOptions || []).map((item) => ({
                                  value: item.id,
                                  label: item.stateNConsti,
                                }))}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.district && (
                            <div className="invalid-feedback small d-block">
                              {errors.district.message}
                            </div>
                          )}
                        </Form.Group>
                      </Col>
                    </Row>

                    <div className="d-flex justify-content-end gap-3 mt-4">
                      <button
                        type="button"
                        className="px-5 fw-bold btn btn-export h45 shadow-sm"
                        onClick={() => navigator('/dashboard')}
                      >
                        Back
                      </button>

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="px-5 btn btn-primary h45"
                      >
                        {isSubmitting ? (
                          <>
                            <Spinner size="sm" className="me-2" />
                            Saving...
                          </>
                        ) : updateId ? (
                          'Update Student'
                        ) : (
                          'Register Student'
                        )}
                      </Button>
                    </div>
                  </Form>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  )
}

export default StudentRegistration