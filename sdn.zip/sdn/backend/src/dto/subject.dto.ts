import { IsInt, IsOptional, IsString, MaxLength } from 'class-validator';
import { Transform } from 'class-transformer';

export class SubjectDto {
  @Transform(({ value }) => {
    const n = Number(value);
    return value === '' || isNaN(n) || n === 0 ? undefined : n;
  })
  @IsOptional()
  @IsInt()
  id?: number;

  @IsString()
  @MaxLength(200)
  subject: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  book?: string;

  @IsInt()
  parentId?: number;

  @IsOptional()
  @IsInt()
  status?: number;

  @IsOptional()
  @IsInt()
  visible?: number;
}
