export const principalDashboardConfig = [
  {
    type: "kpi",
    key: "kpis",
    items: [
      { label: "Total Students", field: "totalStudents" },
      { label: "Avg %", field: "avgPercentage" },
      { label: "Top Section", field: "topSection" },
      { label: "Weak Section", field: "weakSection" }
    ]
  },

  {
    type: "chart",
    title: "Section Performance",
    chartType: "bar",
    dataKey: "sectionChart"
  },

  {
    type: "chart",
    title: "Bloom Taxonomy",
    chartType: "stackedBar",
    dataKey: "bloomChart",
    options: {
      indexAxis: "y",
      stacked: true
    }
  },

  {
    type: "table",
    title: "Bloom Analysis",
    dataKey: "bloomTable",
    columns: [
      { label: "Section", field: "section" },
      { label: "Bloom", field: "bloomLevel" },
      { label: "Obtained", field: "obtainedMarks" },
      { label: "Max", field: "maxMarks" },
      { label: "%", field: "percentage" }
    ]
  },

  {
    type: "table",
    title: "Subdomain Performance",
    dataKey: "subdomainTable",
    columns: [
      { label: "Section", field: "section" },
      { label: "Subject", field: "subdomain" },
      { label: "Avg Marks", field: "avgMarks" },
      { label: "%", field: "percentage" }
    ]
  }
];