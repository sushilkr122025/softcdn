import React, { useEffect, useState } from 'react'

const Settings = ({canvas}) => {
    const [selectedObject, setSelectedObject] = useState()
    const [width, setWidth] = useState("")
    const [height, setHeight] = useState()
    const [diameter, setDiameter] = useState("")
    const [color, setColor] = useState("")
    const [strokColor, setStrokColor] = useState("")
    
    useEffect(()=>{
        if(canvas){
            canvas.on("selection:created", (event)=>{
                handleObjectSelection(event.selected[0])
            });
            canvas.on("selection:updated", (event)=>{
                handleObjectSelection(event.selected[0])
            });
            canvas.on("selection:cleared", ()=>{
                setSelectedObject(null)
                clearSettings()
            });
            canvas.on("object:modified", (event)=>{
                handleObjectSelection(event.target)
            });
            canvas.on("object:scaling", (event)=>{
                handleObjectSelection(event.target)
            });
        }
    },[canvas])

    const handleObjectSelection = (object) =>{
        if(!object) return

        setSelectedObject(object)

        if(object.type === 'rect'){
            setWidth(Math.round(object.width * object.scaleX))
            setHeight(Math.round(object.height * object.scaleY))
            setColor(object.fill)
            setDiameter("")
        } else if (object.type === 'circle'){
            setDiameter(Math.round(object.radius * 2 * object.scaleX))
            setColor(object.fill)
            setWidth("")
            setHeight("")
        }else if (object.type === 'triangle'){
            setWidth(Math.round(object.width * object.scaleX))
            setHeight(Math.round(object.height * object.scaleY))    
            setColor(object.fill)
            setDiameter("")        
        }
    }
    const clearSettings = ()=>{
        setDiameter("")
        setWidth("")
        setHeight("")
        setColor("")
    }

    // const handleWidthChange = (e)=>{
    //     const value = e.target.value.replace(/,/g,"")
    //     const intValue = parseInt(value, 10)

    //     setWidth(intValue)

    //     if(selectedObject && selectedObject.type === "rect" && intValue >= 0){
    //         selectedObject.set({width: intValue / selectedObject.scaleX})
    //         canvas.renderAll();
    //     }

    // }
    // const handleHeightChange = (e)=>{
    //     const value = e.target.value.replace(/,/g,"")
    //     const intValue = parseInt(value, 10)
    //     setHeight(intValue)
    //     if(selectedObject && selectedObject.type === "rect" && intValue >= 0){
    //         selectedObject.set({height: intValue / selectedObject.scaleY})
    //         canvas.renderAll();
    //     }
    // }
    // const handleDiameterChange = (e)=>{
    //     const value = e.target.value.replace(/,/g,"")
    //     const intValue = parseInt(value, 10)
    //     setDiameter(intValue)

    //     if(selectedObject && selectedObject.type === "circle" && intValue >= 0){
    //         selectedObject.set({radius: intValue / 2 / selectedObject.scaleY})
    //         canvas.renderAll();
    //     }
    // }
    const handleColorChange =(e)=>{
        const value = e.target.value
        setColor(value)
        if(selectedObject){
            selectedObject.set({fill: value})
            canvas.renderAll();
        }
    }
    const handleStrokeColorChange =(e)=>{
        const value = e.target.value
        setStrokColor(value)
        if(selectedObject){
            selectedObject.set({stroke: value})
            canvas.renderAll();
        }
    }
    const rotateRight = () => {
        if (selectedObject) {          
          selectedObject.rotate(selectedObject.angle + 45); 
          canvas.renderAll(); 
        }
      };
      const rotateLeft = () => {
        if (selectedObject) {          
          selectedObject.rotate(selectedObject.angle - 45); 
          canvas.renderAll(); 
        }
      };
    
      const flipShapeHorizontal = () => {
        if (selectedObject) {
            console.log("horizontal");
            selectedObject.set('flipX', !selectedObject.flipX); 
          canvas.renderAll(); 
        }
      };
    
      
      const flipShapeVertical = () => {
        if (selectedObject) {
            console.log("vertical");            
            selectedObject.set('flipY', !selectedObject.flipY); 
          canvas.renderAll(); 
        }
      };
      const duplicateShape = () => {
        if (selectedObject) {
          // Clone the rectangle (creates a new instance with the same properties)
          selectedObject.clone((clonedRect) => {
            // Offset the new rectangle so it doesn't overlap with the original
            clonedRect.set({
              left: selectedObject.left + 120, // Position it to the right of the original
              top: selectedObject.top + 120,   // Position it lower than the original
            });
    
            // Add the cloned shape to the canvas
            canvas.add(clonedRect);
            canvas.renderAll(); // Re-render the canvas to show the new shape
          });
        }
      };
//|| selectedObject.type === "circle" || selectedObject.type === "triangle"  selectedObject.type === "rect" &&
  return (
    <div>
      {selectedObject && (    
         <>
        {/* {width && (           
            <input type='text' value={width} onChange={handleWidthChange} />            
        )}
        {height && (           
            <input type='text' value={height} onChange={handleHeightChange} />          
        )}
        
        {diameter && (           
            <input type='text' value={diameter} onChange={handleDiameterChange} />
        )} */}
        <input type="color" className="form-control form-control-color" value={color} onChange={handleColorChange} />     
        <input type="color" className="form-control form-control-color" value={strokColor} onChange={handleStrokeColorChange} />     
        <button className="btn" onClick={rotateLeft}><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 106 106" fill="none">
<path d="M50.3202 15.3266L70.3364 36.1276L78.3425 8.39255L50.3202 15.3266Z" fill="black"/>
<path d="M27.4711 25.5263C21.2634 31.2945 17.1924 38.995 15.9215 47.373C14.6506 55.7511 16.2547 64.3125 20.4724 71.6622C24.69 79.0118 31.2727 84.7163 39.1474 87.846C47.0221 90.9757 55.7247 91.346 63.8368 88.8966C71.949 86.4472 78.9924 81.3225 83.8192 74.3577C88.646 67.3929 90.9715 58.9986 90.4169 50.543C89.8623 42.0873 86.4602 34.0687 80.765 27.794C75.0698 21.5194 67.4174 17.3586 59.0548 15.9898" stroke="black" style={{strokeWidth:5}}/>
</svg></button>
        <button className="btn" onClick={rotateRight}><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 106 106" fill="none">
<path d="M53.753 15.8813L33.7368 36.6823L25.7306 8.94726L53.753 15.8813Z" fill="black"/>
<path d="M78.5236 25.5263C84.7313 31.2945 88.8023 38.995 90.0732 47.373C91.3441 55.7511 89.74 64.3125 85.5223 71.6622C81.3046 79.0118 74.722 84.7163 66.8473 87.846C58.9726 90.9757 50.27 91.346 42.1578 88.8966C34.0457 86.4472 27.0023 81.3225 22.1755 74.3577C17.3487 67.3929 15.0231 58.9986 15.5778 50.543C16.1324 42.0873 19.5345 34.0687 25.2297 27.794C30.9249 21.5194 38.5773 17.3586 46.9399 15.9898" stroke="black"  style={{strokeWidth:5}}/>
</svg></button>
        <button className="btn" onClick={flipShapeHorizontal}><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 61 61" fill="none">
<path d="M33.15 59.848V0.686276L60.7644 59.8699L33.15 59.848Z" stroke="black" strokeWidth="0.3"/>
<path d="M28.1833 59.848L28.1833 0.686276L0.568929 59.8699L28.1833 59.848Z" fill="#515151" stroke="#515151" strokeWidth="0.3"/>
</svg></button>
        <button className="btn" onClick={flipShapeVertical}><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 70 52" fill="none">
<path d="M69.8242 23.854H0.899857L69.8498 0.210089L69.8242 23.854Z" stroke="black" strokeWidth="0.3"/>
<path d="M69.8242 28.1547H0.899857L69.8498 51.7986L69.8242 28.1547Z" fill="#515151" stroke="#515151" strokeWidth="0.3"/>
</svg></button> 
        <button onClick={duplicateShape}>Duplicate Shape</button>      
        </>
      )
      }
    </div>
  )
}

export default Settings
