import { Injectable } from '@nestjs/common';

@Injectable()
export class UserAgentService {
  parse(userAgent: string): {
    browser: string;
    version: string;
    os: string;
    architecture: '32-bit' | '64-bit' | 'Unknown';
    device: string;
  } {
    let browser = 'Unknown';
    let version = '';
    let os = 'Unknown';
    let architecture: '32-bit' | '64-bit' | 'Unknown' = 'Unknown';
    let device = 'Desktop';

    // OS detection
    if (userAgent.includes('Windows NT 10.0')) os = 'Windows 10';
    else if (userAgent.includes('Windows NT 6.1')) os = 'Windows 7';
    else if (userAgent.includes('Mac OS X')) os = 'macOS';
    else if (userAgent.includes('Android')) {
      os = 'Android';
      device = 'Mobile';
    } else if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
      os = 'iOS';
      device = 'Mobile';
    } else if (userAgent.includes('Linux')) os = 'Linux';

    // Architecture detection
    if (userAgent.match(/x64|x86_64|Win64|amd64/i)) {
      architecture = '64-bit';
    } else if (userAgent.match(/i686|i386|x86/i)) {
      architecture = '32-bit';
    }

    // Browser detection (Edge first!)
    if (userAgent.includes('Edg/')) {
      browser = 'Edge';
      version = userAgent.match(/Edg\/([\d.]+)/)?.[1] ?? '';
    } else if (userAgent.includes('Chrome/')) {
      browser = 'Chrome';
      version = userAgent.match(/Chrome\/([\d.]+)/)?.[1] ?? '';
    } else if (userAgent.includes('Safari/') && !userAgent.includes('Chrome')) {
      browser = 'Safari';
      version = userAgent.match(/Version\/([\d.]+)/)?.[1] ?? '';
    } else if (userAgent.includes('Firefox/')) {
      browser = 'Firefox';
      version = userAgent.match(/Firefox\/([\d.]+)/)?.[1] ?? '';
    } else if (userAgent.includes('MSIE') || userAgent.includes('Trident/')) {
      browser = 'Internet Explorer';
      version = userAgent.match(/(MSIE |rv:)([\d.]+)/)?.[2] ?? '';
    }

    return { browser, version, os, architecture, device };
  }
}
