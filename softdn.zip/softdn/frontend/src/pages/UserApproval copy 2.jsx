import React, { useEffect, useState, useCallback } from "react";
import { MdRemoveCircleOutline, MdAddCircleOutline } from "react-icons/md";
import { AiOutlineCloseCircle } from "react-icons/ai";
import UserServices from "../api/UserServices";
import apiClient from "../api/apiService";
import { useParams } from "react-router-dom";

const UserApproval = () => {
  const [subjectData, setSubjectData] = useState([]);
  const [rowData, setRowData] = useState([]);
  const [teacherData, setTeacherData] = useState([]);
  const [rows, setRows] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [activeRow, setActiveRow] = useState(null);
  const [selectedTeachers, setSelectedTeachers] = useState([]);

  const { userid } = useParams();
  const updateId = userid || null;

  const makeEmptyRow = useCallback(
    () => ({
      classId: "",
      subjectId: "",
      teacherIds: [],
      availableTeacher: []
    }),
    []
  );

  // Load all base data
  useEffect(() => {
    const loadAll = async () => {
      const [userRes, subjectRes] = await Promise.all([
        UserServices.getUser({ params: { id: updateId } }),
        apiClient.get("/store/subject"),
      ]);

      const teacherSubjects = userRes.teacherSubject || [];
      const shaped = teacherSubjects.map((s) => ({
        subjectId: parseFloat(s.subjectId),
        classIds: s.classIds.map(Number),
        teachers: [],
        availableTeacher: []
      }));
      setRowData(shaped);
      console.log("Loaded data:", shaped);

      const filteredSubjects = subjectRes.data.filter((s) =>
        teacherSubjects.some((t) => parseFloat(t.subjectId) === s.id)
      );
      setSubjectData(filteredSubjects);

      // Dummy teacher data (replace with API later)
      const teachers = [
        { id: "t1", name: "Mr. Smith", subjectId: "1" },
        { id: "t2", name: "Ms. Johnson", subjectId: "1" },
        { id: "t3", name: "Dr. Adams", subjectId: "2" },
        { id: "t4", name: "Ms. Lee", subjectId: "2" },
        { id: "t19", name: "Ms. Lewis", subjectId: "10" },
        { id: "t22", name: "Ms. Martinez", subjectId: "11" },
      ];
      setTeacherData(teachers);

      setRows([makeEmptyRow()]);      
           
    };
    loadAll();
  }, [makeEmptyRow, updateId]);

  // Handle subject selection
  const handleSubjectChange = (rowIndex, subjectId) => {
    setRows((prev) =>
      prev.map((row, i) =>
        i === rowIndex
          ? { ...row, subjectId, classId: "", teacherIds: [] }
          : row
      )
    );
  };

  // Handle class selection → open modal
  const handleClassSelect = (rowIndex, classId) => {
    const updated = rows.map((row, i) =>
      i === rowIndex ? { ...row, classId } : row
    );
    setRows(updated);

    const subjectId = updated[rowIndex].subjectId;
    if (subjectId && classId) {
      setActiveRow(rowIndex);
      const availableTeachers = teacherData.filter(
        (t) => t.subjectId === String(subjectId)
      );
      setSelectedTeachers(updated[rowIndex].teacherIds || []);
      setShowModal(true);
    }
  };

  // Save teacher selection from modal
  const handleSaveTeachers = () => {
    if (activeRow !== null) {
      setRows((prev) =>
        prev.map((row, i) =>
          i === activeRow ? { ...row, teacherIds: selectedTeachers } : row
        )
      );
    }
    setShowModal(false);
    setActiveRow(null);
  };

  // Remove a teacher from a row
  const handleRemoveTeacher = (rowIndex, teacherId) => {
    setRows((prev) =>
      prev.map((row, i) =>
        i === rowIndex
          ? { ...row, teacherIds: row.teacherIds.filter((t) => t !== teacherId) }
          : row
      )
    );
  };

  return (
    <div className="container-fluid py-4">
      <div className="row ms-5">
        <div className="col-12 col-lg-11 ms-5 bg-white shadow-sm rounded p-4">
          <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
            <h3 className="fw-bold text-primary">User Approval</h3>
          </div>

          <table className="table table-bordered align-middle text-center">
            <thead className="table-light">
              <tr>
                <th style={{ width: "30%" }}>Subject</th>
                <th style={{ width: "30%" }}>Class</th>
                <th style={{ width: "40%" }}>Teacher</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const subjectClasses =
                  rowData.find((d) => d.subjectId === +row.subjectId)
                    ?.classIds || [];

                const selectedTeacherObjects = teacherData.filter((t) =>
                  row.teacherIds.includes(t.id)
                );

                return (
                  <tr key={i}>
                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.subjectId}
                        onChange={(e) =>
                          handleSubjectChange(i, e.target.value)
                        }
                      >
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.classId}
                        onChange={(e) =>
                          handleClassSelect(i, e.target.value)
                        }
                      >
                        <option value="">Select Class</option>
                        {subjectClasses.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="text-start">
                      {selectedTeacherObjects.length > 0 ? (
                        selectedTeacherObjects.map((t) => (
                          <span
                            key={t.id}
                            className="badge bg-primary me-2 p-2 d-inline-flex align-items-center"
                          >
                            {t.name}
                            <AiOutlineCloseCircle
                              className="ms-1"
                              style={{ cursor: "pointer" }}
                              onClick={() => handleRemoveTeacher(i, t.id)}
                            />
                          </span>
                        ))
                      ) : (
                        <span className="text-muted">No teacher selected</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>

            <tfoot>
              <tr>
                <td colSpan={3}>
                  <span
                    className="me-4 text-danger fs-5"
                    onClick={() => rows.length > 1 && setRows(rows.slice(0, -1))}
                    style={{ cursor: "pointer" }}
                  >
                    <MdRemoveCircleOutline />
                  </span>
                  <span
                    className="text-success fs-5"
                    onClick={() => setRows([...rows, makeEmptyRow()])}
                    style={{ cursor: "pointer" }}
                  >
                    <MdAddCircleOutline />
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Teacher Selection Modal */}
      {showModal && (
        <div
          className="modal fade show"
          style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Select Teachers</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                {teacherData
                  .filter(
                    (t) =>
                      t.subjectId ===
                      String(rows[activeRow]?.subjectId || "")
                  )
                  .map((teacher) => (
                    <div key={teacher.id} className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id={teacher.id}
                        checked={selectedTeachers.includes(teacher.id)}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setSelectedTeachers((prev) =>
                            checked
                              ? [...prev, teacher.id]
                              : prev.filter((t) => t !== teacher.id)
                          );
                        }}
                      />
                      <label
                        className="form-check-label"
                        htmlFor={teacher.id}
                      >
                        {teacher.name}
                      </label>
                    </div>
                  ))}
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
                <button
                  className="btn btn-primary"
                  onClick={handleSaveTeachers}
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserApproval;
