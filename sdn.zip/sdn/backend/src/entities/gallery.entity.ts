import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'gallery' })
export class Gallery {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: '50' })
  tenantId: string;

  @Column()
  userId: number;

  @Column({ default: 0 })
  canvasId: number;

  @Column({ length: 50 })
  name: string;

  @Column({ length: 100 })
  keyword: string;

  @Column({ length: 200, default: null })
  description?: string;

  @Column({ length: 50 })
  visibility: string;

  @Column({ length: 50 })
  source: string;

  @Column({ length: 125 })
  imageURL: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  createDateTime: Date;
}
