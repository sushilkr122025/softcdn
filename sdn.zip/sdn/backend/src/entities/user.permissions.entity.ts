import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'userpermissions' })
export class UserPermission {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  userId: number;

  @Column({ length: 20 })
  scope: string;

  @Column({ type: 'json' })
  permissions: object | null;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;
}
