import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('result')
export class Result {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 50 })
  paperid: string;

  @Column({ length: 50 })
  studentid: string;

  @Column({ length: 10 })
  studentclass: string;

  @Column({ length: 50 })
  studentsection: string;

  @Column({ length: 50 })
  rollno: string;

  @Column({ length: 200 })
  studentname: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  studentpercentage: string | null;

  @Column({ type: 'varchar', length: 20, nullable: true })
  studentgrade: string | null;

  @Column({ type: 'varchar', length: 20, nullable: true })
  studentpercentile: string | null;

  @Column({ type: 'json', nullable: true })
  questiondata: object | null;

  @Column({ type: 'json', nullable: true })
  subdomandata: object | null;

  @Column({ type: 'int', default: 1 })
  status: number;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  createdate: Date;
}
