import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'studentsectionsummary' })
export class StudentSectionSummary {
  @PrimaryGeneratedColumn()
  id?: number;

  @Column()
  paperid?: number;

  @Column()
  class?: string;

  @Column()
  section?: string;

  @Column('float')
  avgPercentage?: number;

  @Column('float')
  avgMarks?: number;

  @Column()
  studentCount?: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;
}
