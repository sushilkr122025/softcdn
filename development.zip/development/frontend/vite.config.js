import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import fs from "fs";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd());

  return {
    server: {
      host: '0.0.0.0',
      // host: true,
      port: env.VITE_PORT ? parseInt(env.VITE_PORT, 10) : 3001,
      allowedHosts: ['sushilpc'],
    },
    plugins: [
      react(),
      {
      name: "serve-assets",
      configureServer(server) {
        server.middlewares.use("/assets", (req, res, next) => {

          const filePath = path.join(
            __dirname,
            "../uploads/assets",
            req.url
          );

          if (fs.existsSync(filePath)) {
            const stream = fs.createReadStream(filePath);
            stream.pipe(res);
            return;
          }

          next();
        });
      },
    },

    ],
  };
});
