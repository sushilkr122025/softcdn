import { useEffect, useRef, useState } from "react";
import useAuth from '../../context/AuthContext';
import { BsFillChatSquareTextFill } from "react-icons/bs";
import { IoSend, IoReturnDownBack } from "react-icons/io5";
import { SlOptionsVertical } from "react-icons/sl";
import './Panel.css';
import QuestionServices from "../../api/QuestionServices";
import ShowMessage from '../../components/ShowMessage';
import { useNavigate, useParams } from "react-router-dom";

const Panel = () => {
  const { pqid } = useParams();
  const menuRef = useRef(null);
  const { socket, user } = useAuth()  
  const [messages, setMessages] = useState([]);
  const [unseenCount, setUnseenCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const [roomUser , setRoomUser] = useState([]); 
  const [qId, setQId] = useState(null);  
  const [input, setInput] = useState("");

  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const navigator = useNavigate();

  const [item, setItem] = useState([]);
  const messagesEndRef = useRef(null);
  const options = [{ optns: "optA", images: "optAimg" }, { optns: "optB", images: "optBimg" }, { optns: "optC", images: "optCimg" }, { optns: "optD", images: "optDimg" }]
  const cleanHtml = (html) => {
    if (!html) return "";
    html = html.replace(/\s*style="[^"]*"/gi, "");
    html = html.replace(/<\/?p[^>]*>/gi, "");
    return html;
  };

  // const filteredMessages = messages.filter((msg) => {
  //   if (!searchQuery.trim()) return true;
  //   const q = searchQuery.toLowerCase();
  //   return msg.text.toLowerCase().includes(q) || msg.sender.toLowerCase().includes(q);
  // });

  // format time
  const formatTime = (iso) => {
    try {
      console.log(iso);
      const d = new Date(iso);
      return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(d);
    } catch (e) {
      return "";
    }
  };

  const sameDay = (isoA, isoB) => {
    if (!isoA || !isoB) return false;
    const a = new Date(isoA);
    const b = new Date(isoB);
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  };

  const dateHeaderLabel = (iso) => {
    const d = new Date(iso);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (sameDay(iso, today.toISOString())) return "Today";
    if (sameDay(iso, yesterday.toISOString())) return "Yesterday";

    return new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(d);
  };

  useEffect(() => {
    const fetchQuestion = async () => {      
      const response = await QuestionServices.getPanelItemById(pqid);
      if(response){                            
        const updatedRoomUser = [
          ...response.approverId.split(',').map(Number),
          response.tId,
        ];        

        if (!updatedRoomUser.includes(user.id)) {
          setTextConfirm('Exit')
          setMsgType('modal');         
          setRedirect('/question')
          setBtnConfirm(true)
          setMessage('You are not authorized to view this area...');
          setShowMsg(true);
        }else{
          setItem(response)
          setQId(response.id);
          setRoomUser(updatedRoomUser);
        }        
      }
    }
    fetchQuestion();
  }, []);

  // Load messages history when receiverId changes
  useEffect(() => {
    if (!socket || !qId) return;
    socket.emit("join_room", { qId });
    
    socket.emit("load_messages", { qId: qId });

    socket.on("messages_history", (history) => {   
      console.log("Message history");   
      setMessages(history);
    });

    return () => {
      socket.off("messages_history");
    };
  }, [socket, qId]);

  // Listen for real-time new messages
  useEffect(() => {
    if (!socket) return;
    socket.on("receive_message", (msg) => {    
      // console.log("Received new message:", msg);        
      //if (msg.userId === user.id) {
        setMessages((prev) => [...prev, msg]);
      //}
    });

    return () => {
      socket.off("receive_message");
    };
  }, [socket, qId, user]);

  // Send message
  const sendMessage = () => {      
    if (!input.trim()) return;
    socket.emit("send_message", { qId, message: input });
    setInput("");
  };

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);


  return (
    <div className="p-4">
<div className="container-fluid p-0">      
        <div className="col-12 mx-auto bg-white shadow-sm rounded p-4">
      <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose} 
            textConfirm={textConfirm}
            textClose={textClose}
            onClose={() => setShowMsg(false)}
            onConfirm={() => {
              setShowMsg(false);
              navigator(redirect);
            }}
            />
      <div className="row">
        
      <div className="col-9 mb-3">              
                      <h4 className="questionprevhead mb-3">Ques. ID: {item?.customId}</h4>                      
                      <div className="d-flex">
                        <span className='ps-2 me-3'>Q-</span>
                        <div
                          style={{maxWidth: "580px"}}
                          className="qustionPreviewcontainer d-flex flex-wrap flex-grow-1 justify-content-between align-items-start"
                          dangerouslySetInnerHTML={{
                            __html: `${cleanHtml(item?.question) || "No content available"}`,
                          }}
                        />
                      </div>
                      <ol className="list-group mt-3" type="A">
                        {options.map((key, i) => {
                          const option = item?.[key.optns];
                          const optionimg = item?.[key.images];
                          if (!option && !optionimg) return null;
                          const isCorrect = key.optns === item.correctAns;
                          return (
                            <li key={i} className={`list-group-item ${isCorrect ? "list-group-item-success" : "bg-white"}`}>
                              <div className='d-flex justify-content-between align-items-center'>
                                {option && (
                                  <div
                                    dangerouslySetInnerHTML={{ __html: option }}
                                  />
                                )}
                                {optionimg && <div><img src={optionimg} className='img-fluid' style={{ maxWidth: "100px" }} alt="" /></div>}
                                {isCorrect && <div className="text-success fw-bold">✔</div>}
                              </div>
                            </li>
                          );
                        })}
                      </ol>
                    
      </div>
      {roomUser && roomUser.includes(user.id) && (       
      <div className="col-3 mb-3">
    <div className="card w-100" style={{ height: "80vh" }}>
      <div className="d-flex justify-content-between align-items-center p-3 bg-primary text-white fw-bold">
                <div className="position-relative d-inline-flex align-items-center">
                  <BsFillChatSquareTextFill size={20} />
                  {unseenCount > 0 && (
                    <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                      {unseenCount}
                    </span>
                  )}
                </div>
      
                <div className="position-relative" ref={menuRef}>
                  <span role="button" className="p-1" onClick={() => setOpen(!open)}>
                    <SlOptionsVertical size={20} />
                  </span>
      
                  {open && (
                    <div className="position-absolute end-0 mt-2 bg-white text-dark shadow rounded z-1">
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">
                        copy
                      </div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">edit</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">pin</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">info</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">search</div>
                      <div className="px-3 py-1 border-bottom menu-item cursor-pointer">delete</div>
                    </div>
                  )}
                </div>
              </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "0 0.5rem 0 0.5rem" }}>
        {messages.map((msg, idx) => {                 
        return (
          <div
            key={msg.id}
            className={`chat-row d-flex ${
              msg.userId === user.id
                ? "justify-content-end"
                : "justify-content-start"
            }`}
          >            
            <div className={`chat-bubble ${msg.userId === user.id ? "sent" : "received"}`}>
              <div className="header"><span className="phone">{msg.userId === user.id ? "You" : msg.name !='' ? msg.name : user.id }</span></div>
            <div className="body">{msg.message}</div>
            <div className="meta">
              <small>{formatTime(msg.createdAt)}</small>
            </div>
            </div>
          </div>
        )}
      )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-2 d-flex" style={{ flex: "0 0 auto" }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="form-control me-2"
          placeholder="Type a message..."
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
        />
         <button className="btn border btn-primary pt-1"
          onClick={sendMessage}
        >
          <IoSend size={20} />
          </button>
      </div>
    </div>
    </div>       
      )}
    </div>
    </div>
    </div>
    </div>
  );
};

export default Panel;
