import { Transform } from 'class-transformer';
import { IsInt, IsOptional, Min } from 'class-validator';

export class ClassDto {
  // @Transform(({ value }) => (value === '' ? undefined : Number(value)))
  @Transform(({ value }) => {
    const n = Number(value);
    return value === '' || isNaN(n) || n === 0 ? undefined : n;
  })
  @IsOptional()
  @IsInt()
  id?: number;

  @IsInt()
  @Min(1)
  class?: number;

  @IsOptional()
  @IsInt()
  visible?: number;
}
