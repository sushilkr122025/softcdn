class Shape {
    constructor(x, y, width, height) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.isDragging = false;
      this.isSelected = false;
    }
    draw(ctx) {}
    isPointInside(x, y) {}
    updateDimensions(x, y) {}
    updatePosition(dx, dy) {
      this.x += dx;
      this.y += dy;
    }
  }
  
  export class Rectangle extends Shape {
    draw(ctx) {
      ctx.beginPath();
      ctx.rect(this.x, this.y, this.width, this.height);
      ctx.strokeStyle = 'black';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  
    isPointInside(x, y) {
      return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
    }
  
    updateDimensions(x, y) {
      this.width = x - this.x;
      this.height = y - this.y;
    }
  }

  export class Circle extends Shape {
    constructor(x, y, radius) {
        super(x, y, radius * 2, radius * 2);
        this.radius = radius;
    }

    draw(ctx) {
        ctx.beginPath();
        ctx.arc(this.x + this.radius, this.y + this.radius, this.radius, 0, 2 * Math.PI);
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.closePath();

        if (this.isSelected) {
            this.drawResizeHandle();
        }

        console.warn('draw method not implemented');
    }

    isPointInside(x, y) {
       
        const dx = x - (this.x + this.radius);
        const dy = y - (this.y + this.radius);
       
        return dx * dx + dy * dy <= this.radius * this.radius;
    }

    drawResizeHandle(ctx) {
        const handleSize = 10;
        const handleX = this.x + this.radius * 2 - handleSize / 2;
        const handleY = this.y + this.radius * 2 - handleSize / 2;
        ctx.beginPath();
        ctx.arc(handleX, handleY, handleSize / 2, 0, 2 * Math.PI);
        ctx.fillStyle = 'lightgrey';
        ctx.fill();
        ctx.closePath();
    }
}
  
export class Triangle extends Shape {
   

    draw(ctx) {
        ctx.beginPath();
        ctx.moveTo(this.x, this.y + this.height);
        ctx.lineTo(this.x + this.width / 2, this.y);
        ctx.lineTo(this.x + this.width, this.y + this.height);
        ctx.closePath();
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
        ctx.stroke();

        if (this.isSelected) {
            this.drawResizeHandle();
        }
    }

    isPointInside(x, y) {
        // Simple bounding box check for triangle
        return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
    }

    drawResizeHandle(ctx) {
        const handleSize = 10;
        ctx.beginPath();
        ctx.rect(this.x + this.width - handleSize, this.y + this.height - handleSize, handleSize, handleSize);
        ctx.fillStyle = 'lightgrey';
        ctx.fill();
        ctx.closePath();
    }
}

export class Arrow extends Shape {
  
    draw(ctx) {
        const angle = Math.atan2(this.height, this.width);
        const headLength = 10;

        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(this.x + this.width, this.y + this.height);

        ctx.lineTo(
            this.x + this.width - headLength * Math.cos(angle - Math.PI / 6),
            this.y + this.height - headLength * Math.sin(angle - Math.PI / 6)
        );
        ctx.moveTo(this.x + this.width, this.y + this.height);
        ctx.lineTo(
            this.x + this.width - headLength * Math.cos(angle + Math.PI / 6),
            this.y + this.height - headLength * Math.sin(angle + Math.PI / 6)
        );

        ctx.strokeStyle = 'black';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.closePath();

        if (this.isSelected) {
            this.drawResizeHandle();
        }
    }

    isPointInside(x, y) {
        return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
    }

    drawResizeHandle(ctx) {
        const handleSize = 10;
        ctx.beginPath();
        ctx.rect(this.x + this.width - handleSize, this.y + this.height - handleSize, handleSize, handleSize);
        ctx.fillStyle = 'lightgrey';
        ctx.fill();
        ctx.closePath();
    }
}
  