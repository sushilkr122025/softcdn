import React from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import useAuth from '../context/AuthContext'
import Loader from '../components/Loader'

const PrivateRoute = () => {
  const { isAuth, loading } = useAuth()
  // console.log('PrivateRoute', isAuth, loading);
  
  if (loading) return <Loader />
  return isAuth ? <Outlet /> : <Navigate to="/login" />
}
export default PrivateRoute
