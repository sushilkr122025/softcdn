/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { School } from '../entities/school.entity';
import { Questions } from '../entities/questions.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { DataSource } from 'typeorm';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { Subject } from '../entities/subject.entity';
import { Gallery } from '../entities/gallery.entity';
import { CanvasImage } from '../entities/canvasimage.entity';
import { QuestionContext } from '../entities/question.context.entity';
import { NotificationService } from './notification.services';
import { QuestionsHistory } from '../entities/questions.history.entity';
import { QuestionRule } from '../entities/question.rule.entity';

@Injectable()
export class SchoolService {
  constructor(
    private readonly notificationService: NotificationService,
    @InjectRepository(School)
    private schoolRepository: Repository<School>,
    @InjectRepository(Questions)
    private questionRepository: Repository<Questions>,
    @InjectRepository(Gallery)
    private galleryRepository: Repository<Gallery>,
    @InjectRepository(CanvasImage)
    private canvasRepository: Repository<CanvasImage>,
    @InjectRepository(QuestionContext)
    private questionContextRepository: Repository<QuestionContext>,
    @InjectRepository(QuestionsHistory)
    private questionHistoryRepository: Repository<QuestionsHistory>,
    @InjectRepository(QuestionRule)
    private questionRuleRepository: Repository<QuestionRule>,
    private dataSource: DataSource
  ) {}
  findById(id: number): Promise<School | null> {
    return this.schoolRepository.findOne({ where: { id } });
  }

  async getQuestion(data: Questions): Promise<Questions[]> {
    const question = await this.questionRepository.find({
      where: { subject: data.subject, class: data.class, createdBy: 'bank' },
    });
    if (!question) {
      throw new NotFoundException('Question not found');
    }
    return question;
  }

  async getQuestionPaper(formData: any): Promise<any[]> {
    const query = this.dataSource
      .createQueryBuilder()
      .select([
        'qp.id AS id',
        'qp.subject AS subject',
        'qp.class AS class',
        'eq.paperId AS paperId',
        'COUNT(eq.questionId) AS totalQuestion',
      ])
      .from(QuestionPaper, 'qp')
      .innerJoin(ExamQuestion, 'eq', 'qp.id = eq.paperId')
      .where('qp.subject = :subject', { subject: formData.subject })
      .andWhere('qp.class = :class', { class: formData.class });

    if (formData.data) {
      query.andWhere('qp.createdFrom = :createdFrom', {
        createdFrom: formData.data,
      });
    }
    query.groupBy('eq.paperId');
    return await query.getRawMany();
  }

  async setAnsKeyManual(data: any, tenantId: string): Promise<any> {
    return this.dataSource.transaction(async (manager) => {
      const paperData = data.questionpaper;
      const questionPaper = manager.create(QuestionPaper, {
        name: paperData.examName,
        class: paperData.className,
        subject: paperData.subject,
        maxMarks: paperData.marks,
        createdFrom: 'manual',
        examDate: paperData.examDate,
        tenantid: tenantId,
      });
      const savedPaper = await manager.save(questionPaper);
      savedPaper.examCode = `EX${savedPaper.id}-${savedPaper.class}-${savedPaper.subject}`;
      await manager.save(savedPaper);
      const questions = data.questions.map((q) =>
        manager.create(Questions, {
          tId: q.tId,
          subject: q.subject,
          class: q.class,
          subDomain: q.subdomain,
          quesType: q.quesType,
          correctAns: q.correctAns,
          createdBy: 'manual',
          tenantid: tenantId,
        })
      );
      const savedQuestions = await manager.save(questions);
      const examQuestions = savedQuestions.map((question, i) =>
        manager.create(ExamQuestion, {
          paperId: savedPaper.id,
          questionId: question.id,
          sequence: i + 1,
          marks: data.questions[i].marks,
          sectionNo: data.questions[i].sectionNo,
          paperFrom: 'manual',
        })
      );
      await manager.save(examQuestions);
      return { message: 'Saved all data with transaction' };
    });
  }

  async createContext(data: any): Promise<string> {
    const context = this.questionContextRepository.create({
      subject: data?.subject,
      tId: data.tId,
      class: data.class,
      topicName: data.topicName,
      contextstatus: data.contextstatus,
      context: data.context,
      tenantid: data.tenantid,
    });
    const result = await this.questionContextRepository.save(context);
    if (!result) {
      throw new NotFoundException('Context creation failed');
    }
    return result?.shortUuid;
  }

  async getContextByShortUuid(data: any): Promise<any> {
    // console.log('data', data);
    const result = await this.questionContextRepository.findOneBy({
      shortUuid: data.shortuuid,
      tenantid: data.tenantid,
      dmlType: 'I',
    });
    if (!result) {
      throw new NotFoundException('Question Context not found');
    }
    return {
      id: result.id,
      shortuuid: result.shortUuid,
      subject: result.subject,
      class: result.class,
      context: result.context,
      topicName: result.topicName,
      contextstatus: result.contextstatus,
    };
  }

  async saveQuestion(q: any): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }

        const trackerRepo = manager.getRepository(QuestionIdTracker);
        const questionRepo = manager.getRepository(Questions);
        const subjectRepo = manager.getRepository(Subject);

        const getsubject = await subjectRepo.findOne({
          where: { id: q.subject },
        });

        if (!getsubject) {
          throw new NotFoundException('Subject not found');
        }
        let shortsubject = getsubject.subject.substring(0, 2).toUpperCase();
        if (getsubject.subject === 'Social Science') {
          shortsubject = 'SS';
        }

        const cgtext = q.cgtext;
        const competencytext = q.competencytext;

        const year = new Date().getFullYear();
        const subject = q.subject;
        const className = q.std;
        const tenantId = q.tenantid;

        let tracker = await trackerRepo.findOne({
          where: {
            tenantId,
            subject,
            class: className,
            year,
            cg: q.cg,
            competency: q.competency,
          },
        });

        if (!tracker) {
          tracker = trackerRepo.create({
            tenantId,
            subject,
            class: className,
            cg: q.cg,
            competency: q.competency,
            year,
            currentCounter: 1,
          });
        } else {
          tracker.currentCounter += 1;
        }

        const paddedCounter = String(tracker.currentCounter).padStart(4, '0');
        const customId = `${year} ${shortsubject} G${className} ${cgtext} ${competencytext} #${paddedCounter}`;

        await trackerRepo.save(tracker);

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          contextid: q.contextid,
          contextstatus: q.contextstatus,
          subject,
          class: className,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          tenantid: tenantId,
          createdBy: 'bank',
          customId,
          // file paths could go here
        };
        // const newQuestion = questionRepo.create(Qdata);
        // await this.notificationService.sendToUser(tenantId, userId, {
        //     type: 'ORDER_PLACED',
        //     message: `Your order #${orderData.id} has been placed successfully.`,
        //   });
        return await questionRepo.upsert(Qdata, ['id']);
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async createQuestion(q: any): Promise<any> {
    try {
      return await this.dataSource.transaction(async (manager) => {
        if (!q.subject || !q.std || !q.question || !q.tenantid) {
          throw new Error('Missing required question fields');
        }

        const Qdata = {
          ...(q.editId && { id: q.editId }),
          tId: q.tId,
          contextid: q.contextid,
          contextstatus: q.contextstatus,
          subject: q.subject,
          class: q.std,
          subDomain: q.subdomain,
          difficulty: q.difficulty,
          cg: q.cg,
          competency: q.competency,
          quesType: q.quesType,
          question: q.question,
          correctAns: q.corrAns,
          optA: q.optA,
          optB: q.optB,
          optC: q.optC,
          optD: q.optD,
          optAimg: q.optAimg,
          optBimg: q.optBimg,
          optCimg: q.optCimg,
          optDimg: q.optDimg,
          image: q.image,
          chapter: q.chapter,
          revision: 1,
          trailId: 0,
          createdBy: 'bank',
        };
        const result = await this.questionHistoryRepository.upsert(Qdata, [
          'id',
        ]);
        if (!result) {
          throw new NotFoundException('Failed to create question history');
        }
        // Qdata['historyId'] = result.identifiers[0]?.id;
        const qid = result.identifiers[0]?.id;
        const getApprovalIds = await this.questionRuleRepository.findOneBy({
          userId: q.user,
          subjectId: String(q.subject),
          classId: String(q.std),
          dmlType: 'I',
        });
        if (getApprovalIds && getApprovalIds.teachersId) {
          const setapprovers = await this.questionHistoryRepository.findOneBy({
            id: qid,
          });
          if (setapprovers) {
            setapprovers.approverId = getApprovalIds.teachersId;
            await this.questionHistoryRepository.save(setapprovers);
          }
        }
        return `Approval request sent successfully to approver(s) with Question ID: ${qid}`;
      });
    } catch (error) {
      // Optionally: delete uploaded files if necessary
      // You can also use a logger here
      console.error('Error saving question:', error);
      throw new Error('Failed to save question. Please check inputs or retry.');
    }
  }

  async getPanels(userId: number): Promise<any> {
    const query = `
    SELECT 
      q.id AS id, q.question AS question, q.createdAt AS createdAt, q.tId as tId, q.revision AS revision,
      l.id AS userId, l.name AS name
    FROM questionshistory q
    LEFT JOIN login l ON l.id = q.tId
    WHERE q.tId = ? AND q.trailId = 0

    UNION

    SELECT 
      q.id AS id, q.question AS question, q.createdAt AS createdAt, q.tId as tId, q.revision AS revision,
      l.id AS userId, l.name AS name
    FROM questionshistory q
    LEFT JOIN login l ON l.id = q.tId
    WHERE FIND_IN_SET(?, q.approverId) > 0 AND q.trailId = 0
  `;

    const panels = await this.dataSource.query(query, [userId, userId]);

    if (!panels || panels.length === 0) {
      throw new NotFoundException('No Question found for paneling');
    }
    return panels;
  }

  /*async getPanels(userId: number): Promise<any> {
    const qb = this.questionHistoryRepository
      .createQueryBuilder('q')
      .leftJoinAndSelect('login', 'u', 'u.id = q.tId')
      .select([
        'q.id AS id',
        'q.question AS question',
        'q.revision AS revision',
        'q.tId AS tId',
        'q.createdAt AS createdAt',
        'u.id AS userId',
        'u.name AS name',
      ])
      .where('FIND_IN_SET(:userId, q.approverId) > 0', { userId })
      .orWhere('q.tId = :userId', { userId })
      .andWhere('q.trailId = :trailId', { trailId: 0 });

    const [sql, params] = qb.getQueryAndParameters();
    console.log('SQL:', sql);
    console.log('Params:', params);
    const panels = await qb.getRawMany();

    if (!panels || panels.length === 0) {
      throw new NotFoundException('No Question found for paneling');
    }
    return panels;
  }
*/
  async getQuestionByUser(approverId: number): Promise<Questions[]> {
    const question = (await this.questionRepository.query(
      `SELECT * FROM questions WHERE FIND_IN_SET(?, approverId) > 0`,
      [approverId]
    )) as Questions[];
    if (!question || question.length === 0) {
      throw new NotFoundException('Question not found');
    }
    return question;
  }

  async getGallery(): Promise<Gallery[]> {
    const gallery = await this.galleryRepository.find();
    if (!gallery) {
      throw new NotFoundException('Question not found');
    }
    return gallery;
  }

  async createGallery(
    files: Express.Multer.File[],
    galleryData: any
  ): Promise<any> {
    const fileDetails = files?.length
      ? files.map((file) => ({
          fileName: file.filename,
          filePath: `/${galleryData.folderName}/${file.filename}`,
        }))
      : [];

    const gallery = this.galleryRepository.create({
      ...galleryData,
      imageURL: fileDetails[0]?.filePath || undefined,
    });
    // console.log(gallery);
    const res = await this.galleryRepository.save(gallery);
    // console.log(res);
    return res;
  }

  async createCanvasImage(data: any): Promise<any> {
    const create = await this.canvasRepository.insert(data);
    if (create) {
      console.log('create', create);
      const gallerydata: any = {
        userId: data.user,
        tenantId: data.tenantId,
        canvasId: create.identifiers[0]?.id,
        name: data.name,
        keyword: data.keyword,
        description: data.description,
        visibility: data.visibility,
        source: data.source,
        imageURL: `/${data.folderName}/${data.allFiles[0].filename}`,
      };
      // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
      const gallery = this.galleryRepository.create(gallerydata);
      // console.log(gallery);
      const res = await this.galleryRepository.save(gallery);

      // console.log('canvasImage', res);
      return res;
    } else {
      throw new NotFoundException('Canvas image creation failed');
    }
  }

  async getQuestionById(id: number): Promise<Questions> {
    const question = await this.questionRepository.findOne({
      where: { id },
    });
    if (!question) {
      throw new NotFoundException('Canvas image not found');
    }
    return question;
  }

  async getQuestionByUserId(id: number): Promise<QuestionsHistory> {
    const question = await this.questionHistoryRepository.findOne({
      where: { id },
    });
    if (!question) {
      throw new NotFoundException('Question image not found');
    }
    return question;
  }
}
