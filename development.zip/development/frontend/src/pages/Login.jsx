import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router'
import SchoolServices from '../api/SchoolServices'
import logo from '../assets/images/alignlogotext.png'
import illustration from '../assets/images/illustration.png'
import './Login.css'

const Login = () => {
  const navigator = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const [loginError, setLoginError] = useState('');
  const [showLoginError, setShowLoginError] = useState(false);
  const imgsrc = useRef()

  useEffect(() => {
    const validateCompany = async () => {
      try {
        const res = await SchoolServices.getLookupVerify();
        if (res.status == 200) {
          imgsrc.current.src = `/assets/` + res.data?.schoollogo;
        } else {
          navigator('/');
        }
      } catch (err) {
        console.error(err)
        navigator('/');
      }
    };
    validateCompany();
  }, [])

  const validate = () => {
    const errors = {};

    const emailError = validateField('email', email);
    const passwordError = validateField('password', password);

    if (emailError) errors.email = emailError;
    if (passwordError) errors.password = passwordError;

    return errors;
  };

  const validateField = (name, value) => {
    if (name === 'email') {
      const trimmed = value.trim();
      if (!trimmed) return 'Email / Mobile / User ID is required';

      const isEmail = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(trimmed);
      const isMobile = /^[6-9][0-9]{9}$/.test(trimmed);
      const isUserId = /^(?=.*[A-Za-z])[A-Za-z0-9_-]{3,}$/.test(trimmed);

      if (!isEmail && !isMobile && !isUserId) {
        return /^[0-9]+$/.test(trimmed)
          ? 'Mobile number must be exactly 10 digits and start with 6–9'
          : 'Enter a valid Email, Mobile number, or User ID';
      }
    }

    if (name === 'password') {
      if (!value) return 'Password is required';
      if (value.length < 6) return 'Password must be at least 6 characters';
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault()
    const validationErrors = validate()
    setErrors(validationErrors)

    if (Object.keys(validationErrors).length === 0) {
      try {
        const response = await SchoolServices.userLogin({ email, password })
        if (response.data?.authorize === true) {
          navigator('/dashboard', { replace: true })
        } else {
          setLoginError(response.data?.message || 'Login failed. Please check credentials.')
          setShowLoginError(true)
        }
      } catch (err) {
        setLoginError(err?.message || 'Something went wrong. Please try again.')
        setShowLoginError(true)
      }
    } else {
      setShowLoginError(false)
    }
  }

  return (
    <div className="login-page d-flex">
      <div className="login-left d-flex flex-column">
        <div className="login-logos d-flex align-items-center justify-content-between">
          <img src={logo} alt="Logo left" className="login-align-logo" />
          <img ref={imgsrc} alt="Logo right" className="login-align-logo" />
        </div>
        <div className="login-form-container w-100 my-0 mx-auto">
          <h2 className="login-heading text-center">Login into your account</h2>
          <form onSubmit={handleSubmit} className="login-form">
            <div className="login-field">
              <label className="login-label">Email address</label>
              <div className="login-input-wrapper">
                <input
                  type="text"
                  autoComplete="off"
                  placeholder="Enter Email / Mobile / User ID"
                  name="email"
                  className={`login-input ${errors.email ? 'is-invalid' : ''}`}
                  value={email}
                  onChange={(e) => {
                    const v = e.target.value;
                    setEmail(v);
                    setShowLoginError(false);
                  }}
                  autoFocus
                />
                <span className="login-input-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="4" width="20" height="16" rx="2" />
                    <path d="M22 7l-10 7L2 7" />
                  </svg>
                </span>
              </div>
              {errors.email && <div className="error-text">{errors.email}</div>}
            </div>
            <div className="login-field">
              <label className="login-label">Password</label>
              <div className="login-input-wrapper">
                <input
                  type="password"
                  placeholder="Password"
                  name="password"
                  className={`login-input ${errors.password ? 'is-invalid' : ''}`}
                  value={password}
                  onChange={(e) => {
                    const v = e.target.value;
                    setPassword(v);
                    setShowLoginError(false);
                  }}
                />
                <span className="login-input-icon">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                </span>
              </div>
              {errors.password && <div className="error-text">{errors.password}</div>}
            </div>
            {showLoginError && (
              <div className="alert alert-danger py-2 small mb-3 d-flex justify-content-between align-items-center">
                <span>{loginError}</span>
                <button type="button" className="btn-close small" aria-label="close" onClick={() => setShowLoginError(false)}></button>
              </div>
            )}
            <button type="submit" className="login-btn">Login now</button>

            {/* <div className="login-divider">
              <span className="login-divider-line"></span>
              <span className="login-divider-text">OR</span>
              <span className="login-divider-line"></span>
            </div> 

            <div className="signup-link-btn">Signup now</div>*/}
          </form>
        </div>
      </div>
      <div className="login-right">
        <h1 className="login-right-heading">
          Transforming learning to <br />
          <span style={{ whiteSpace: 'nowrap' }}>ALIGN with competency-based</span> <br />
          education
        </h1>
        <div className="login-right-img-wrapper">
          <img src={illustration} alt="Illustration" className="login-right-img" />
        </div>
      </div>
    </div>
  )
}

export default Login
