/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable prettier/prettier */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Injectable, HttpException, HttpStatus, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, In } from 'typeorm';
import { Repository, DataSource } from 'typeorm';
import { Result } from '../entities/result.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { Answer } from '../entities/answer.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { Questions } from '../entities/questions.entity';
import { Grade } from '../entities/grade.entity';
import { Alert } from '../entities/alerts.entity';
import { Subject } from '../entities/subject.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
import { ConfigService } from '@nestjs/config';
import { OpenAI } from "openai";
import { OpenAIResult } from '../entities/openai.result.entity';
import { log } from 'winston';
import { StudentQuestionResult } from '../entities/student.question.result.entity';
import { StudentResult } from '../entities/student.result.entity';
import { StudentSubdomainResult } from '../entities/student.subdomain.result.entity';
import { StudentBloomSummary } from '../entities/student.bloom.summary.entity';
interface SubdomainData {
  subdomain: string;
  percentage: number;
  grade: string;
}

interface QuestionItem {
  seq: any;
  id: number;
  subdomain: string;
  data: number;
}

interface ResultRow {
  id: number;
  paperid: number;
  studentid: number;
  studentclass: string;
  studentsection: string;
  rollno: string;
  studentname: string;
  studentpercentage: number;
  studentgrade: string;
  studentpercentile: number;
  questiondata: QuestionItem[];
}

@Injectable()
export class ResultService {
  private readonly openapikey: string;
  constructor(
    private readonly configuration: ConfigService,
    private readonly dataSource: DataSource,
    @InjectRepository(Result)
    private readonly resultRepository: Repository<Result>,
    @InjectRepository(StudentInformation)
    private readonly studentRepository: Repository<StudentInformation>,
    @InjectRepository(QuestionPaper)
    private readonly questionPaperRepository: Repository<QuestionPaper>,
    @InjectRepository(Answer)
    private readonly answerRepository: Repository<Answer>,
    @InjectRepository(ExamQuestion)
    private readonly examQuestionRepository: Repository<ExamQuestion>,
    @InjectRepository(Questions)
    private readonly questionRepository: Repository<Questions>,
    @InjectRepository(Grade)
    private readonly gradeRepository: Repository<Grade>,
    @InjectRepository(Alert)
    private readonly alertRepository: Repository<Alert>,
    @InjectRepository(OpenAIResult)
    private readonly openAiRepository: Repository<OpenAIResult>
  ) {
    this.openapikey =
      this.configuration.get<string>('app.openapikey') || 'no-key';
  }
  async getGradeAll(): Promise<Grade[]> {
    const grades = await this.gradeRepository.find({ where: { status: 1 } });
    if (!grades || grades.length === 0) {
      throw new NotFoundException('No grades found');
    }
    return grades;
  }
  
  public formatPercent(value: number): number {
  if (Number.isInteger(value)) {
    return value;
  }

  const decimals = value.toString().split('.')[1]?.length || 0;

  if (decimals <= 2) {
    return value;
  }

  return Number(value.toFixed(2));
}

async createResult(paperid: string, cls: string, section?: string) {
  return this.dataSource.transaction(async (manager) => {
    const scope = 'SECTION';

    // ===== CHECK EXISTING =====
    const existsQuery = manager
      .createQueryBuilder(StudentResult, "r")
      .select("1")
      .where("r.paperid = :paperid", { paperid })
      .andWhere("r.class = :cls", { cls })
      .andWhere("r.scope = :scope", { scope });

    if (section) {
      existsQuery.andWhere("r.section = :section", { section });
    }

    const exists = await existsQuery.limit(1).getRawOne();

    if (exists) {
      return {
        message: "Result already available",
        success: "Result Present"
      };
    }

    // ===== PAPER =====
    const paperData = await manager.findOne(QuestionPaper, {
      where: { id: Number(paperid) }
    });

    if (!paperData) {
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    // ===== QUERY (UPDATED) =====
    let whereClause = `
      WHERE an.dmlType = 'I'
      AND an.paperid = ?
      AND eq.paperid = ?
      AND an.class = ?
    `;
    const params: any[] = [paperid, paperid, cls];

    if (section) {
      whereClause += ` AND an.section = ?`;
      params.push(section);
    }

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,

        eq.sequence,

        q.id AS qid,
        q.quesType,
        q.marks AS qmarks,
       
        sub.subject AS subdomain,
        q.cg AS skill,		

        bt.taxonomy AS bloomLevel,

        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank') THEN
              CASE
                WHEN an.uanswer IS NOT NULL
                      AND an.canswer IS NOT NULL
                      AND an.uanswer = an.canswer
                THEN q.marks
                ELSE 0
              END
          ELSE COALESCE(an.marks, 0)
        END AS score

      FROM answer an

      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id

      LEFT JOIN subject sub ON sub.id = q.subdomain
      LEFT JOIN curriculumgoal cg ON cg.id = q.cg
      LEFT JOIN bloom bt ON bt.id = q.bloomTaxonomy

      ${whereClause}

      ORDER BY an.section, an.studentid, eq.sequence`,
      params
    );

    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    const studentMap = new Map();
    const analyticsRows: any[] = [];
    const resultRows: any[] = [];
    const subdomainInsertRows: any[] = [];
    const bloomInsertRows: any[] = []; // ✅ NEW

    // ===== PROCESS LOOP =====
    for (const row of rows) {

      if (!studentMap.has(row.studentid)) {
        studentMap.set(row.studentid, {
          studentid: row.studentid,
          studentname: row.studentname,
          section: row.section,
          rollno: row.rollno,
          questiondata: [],
          totalScore: 0,
          subdomain: {},
          bloom: {} // ✅ NEW
        });
      }

      const student = studentMap.get(row.studentid);

      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      student.totalScore += score;

      // ===== SUBDOMAIN =====
      if (row.subdomain) {
        if (!student.subdomain[row.subdomain]) {
          student.subdomain[row.subdomain] = { sum: 0, max: 0 };
        }
        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;
      }

      // ===== BLOOM (NEW) =====
      if (row.bloomLevel) {
        if (!student.bloom[row.bloomLevel]) {
          student.bloom[row.bloomLevel] = { sum: 0, max: 0 };
        }
        student.bloom[row.bloomLevel].sum += score;
        student.bloom[row.bloomLevel].max += maxMarks;
      }

      // ===== ANALYTICS TABLE =====
      analyticsRows.push({
        paperid,
        studentid: row.studentid,
        class: cls,
        section: row.section,
        qid: row.qid,
        sequence: row.sequence,
        subject: row.subdomain,
        subdomain: row.subdomain,
        skill: row.skill,
        bloomLevel: row.bloomLevel, // ✅ NEW
        questionType: row.quesType,
        studentAnswer: row.uanswer,
        correctAnswer: row.canswer,
        score,
        maxScore: maxMarks
      });
    }

    // ===== STUDENT SUMMARY =====
    for (const student of studentMap.values()) {

      const percentage = Number(
        ((student.totalScore * 100) / paperData.maxMarks).toFixed(2)
      );

      const grade =
        grades.find(g =>
          percentage > g.markstart - 1 &&
          percentage <= g.markend
        )?.grade || "F";

      // ===== SUBDOMAIN INSERT =====
      Object.entries(student.subdomain).forEach(([subdomain, stats]: any) => {

        const subPercent = Number(((stats.sum * 100) / stats.max).toFixed(2));

        subdomainInsertRows.push({
          paperid,
          studentid: student.studentid,
          class: cls,
          section: student.section,
          subdomain,
          obtainedMarks: stats.sum,
          maxMarks: stats.max,
          percentage: subPercent
        });
      });

      // ===== BLOOM INSERT (NEW) =====
      Object.entries(student.bloom).forEach(([level, stats]: any) => {

        const percent = Number(((stats.sum * 100) / stats.max).toFixed(2));

        bloomInsertRows.push({
          paperid,
          studentid: student.studentid,
          class: cls,
          section: student.section,
          bloomLevel: level,
          obtainedMarks: stats.sum,
          maxMarks: stats.max,
          percentage: percent
        });
      });

      resultRows.push({
        paperid,
        studentid: student.studentid,
        class: cls,
        section: student.section,
        scope,
        totalScore: student.totalScore,
        maxScore: paperData.maxMarks,
        percentage,
        grade,
        percentile: 0
      });
      
    }

    // ===== INSERT =====
    await manager.createQueryBuilder().insert().into(StudentQuestionResult).values(analyticsRows).execute();
    await manager.createQueryBuilder().insert().into(StudentResult).values(resultRows).execute();
    await manager.createQueryBuilder().insert().into(StudentSubdomainResult).values(subdomainInsertRows).execute();
    await manager.createQueryBuilder().insert().into(StudentBloomSummary).values(bloomInsertRows).execute();

    // ===== BLOOM SUMMARY (NEW) =====
    await manager.query(`DELETE FROM bloomsummary WHERE paperid = ? AND class = ?`, [paperid, cls]);

    await manager.query(`
    INSERT INTO bloomsummary (paperid, class, section, bloomLevel, obtainedMarks, maxMarks, avgPercentage)
    SELECT 
    paperid,
    class,
    section,
    bloomLevel,
    SUM(obtainedMarks),
    SUM(maxMarks),
    ROUND((SUM(obtainedMarks) * 100) / SUM(maxMarks), 2)
    FROM studentbloomsummery
      WHERE paperid = ? AND class = ?
      GROUP BY section, bloomLevel
    `, [paperid, cls]);

    // ===== SECTION SUMMARY (ADD BACK) =====
    await manager.query(
      `DELETE FROM studentsectionsummary WHERE paperid = ? AND class = ?`,
      [paperid, cls]
    );

    await manager.query(`
      INSERT INTO studentsectionsummary 
        (paperid, class, section, avgPercentage, avgMarks, studentCount)
      SELECT 
        paperid,
        class,
        section,
        ROUND(AVG(percentage),2),
        ROUND(AVG(totalScore),2),
        COUNT(*)
      FROM studentresult
      WHERE paperid = ? AND class = ?
      GROUP BY section
    `, [paperid, cls]);

    await manager.query(
      `DELETE FROM studentsubjectsummary WHERE paperid = ? AND class = ?`,
      [paperid, cls]
    );

    await manager.query(`
      INSERT INTO studentsubjectsummary (paperid, class, section, subdomain, avgPercentage, avgMarks)
      SELECT 
        paperid,
        class,
        section,
        subdomain,
        ROUND(AVG(percentage),2),
        ROUND(AVG(obtainedMarks),2)
      FROM studentsubdomainresult
      WHERE paperid = ? AND class = ?
      GROUP BY section, subdomain
    `, [paperid, cls]);

    return {
      message: "Result generated successfully with Bloom analytics",
      success: true
    };
  });
}

/*
async createResult(paperid: string, cls: string, section?: string) {
  return this.dataSource.transaction(async (manager) => {
    const scope = 'SECTION';

    // ===== CHECK EXISTING =====
    const existsQuery = manager
      .createQueryBuilder(StudentResult, "r")
      .select("1")
      .where("r.paperid = :paperid", { paperid })
      .andWhere("r.class = :cls", { cls })
      .andWhere("r.scope = :scope", { scope });

    if (section) {
      existsQuery.andWhere("r.section = :section", { section });
    }

    const exists = await existsQuery.limit(1).getRawOne();

    if (exists) {
      return {
        message: "Result already available",
        success: "Result Present"
      };
    }

    // ===== PAPER =====
    const paperData = await manager.findOne(QuestionPaper, {
      where: { id: Number(paperid) }
    });

    if (!paperData) {
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    // ===== QUERY =====
    let whereClause = `
      WHERE an.dmlType = 'I'
      AND an.paperid = ?
      AND eq.paperid = ?
      AND an.class = ?
    `;
    const params: any[] = [paperid, paperid, cls];

    if (section) {
      whereClause += ` AND an.section = ?`;
      params.push(section);
    }

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,

        eq.sequence,

        q.id AS qid,
        q.quesType,
        q.marks AS qmarks,
       
        sub.subject AS subdomain,
        q.cg AS skill,

        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank') THEN
              CASE
                WHEN an.uanswer IS NOT NULL
                      AND an.canswer IS NOT NULL
                      AND an.uanswer = an.canswer
                THEN q.marks
                ELSE 0
              END
          ELSE COALESCE(an.marks, 0)
        END AS score

      FROM answer an

      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id

      LEFT JOIN subject sub ON sub.id = q.subdomain
      LEFT JOIN curriculumgoal cg ON cg.id = q.cg

      ${whereClause}

      ORDER BY an.section, an.studentid, eq.sequence`,
      params
    );

    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    const studentMap = new Map();
    const analyticsRows: any[] = [];
    const resultRows: any[] = [];
    const subdomainInsertRows: any[] = []; // ✅ NEW TABLE DATA

    // ===== PROCESS LOOP =====
    for (const row of rows) {

      if (!studentMap.has(row.studentid)) {
        studentMap.set(row.studentid, {
          studentid: row.studentid,
          studentname: row.studentname,
          section: row.section,
          rollno: row.rollno,
          questiondata: [],
          totalScore: 0,
          subdomain: {}
        });
      }

      const student = studentMap.get(row.studentid);

      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      // QUESTION DATA
      student.questiondata.push({
        id: row.qid,
        seq: row.sequence,
        subject: row.subdomain,
        subdomain: row.subdomain,
        skill: row.skill,
        data: score,
        answered: row.uanswer
      });

      student.totalScore += score;

      // SUBDOMAIN AGGREGATION
      if (row.subdomain) {
        if (!student.subdomain[row.subdomain]) {
          student.subdomain[row.subdomain] = {
            sum: 0,
            max: 0
          };
        }

        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;
      }

      // ANALYTICS TABLE
      analyticsRows.push({
        paperid,
        studentid: row.studentid,
        class: cls,
        section: row.section,

        qid: row.qid,
        sequence: row.sequence,

        subject: row.subdomain,
        subdomain: row.subdomain,
        skill: row.skill,

        questionType: row.quesType,
        studentAnswer: row.uanswer,
        correctAnswer: row.canswer,

        score,
        maxScore: maxMarks
      });
    }

    // ===== STUDENT SUMMARY =====
    for (const student of studentMap.values()) {

      const percentage = Number(
        ((student.totalScore * 100) / paperData.maxMarks).toFixed(2)
      );

      const grade =
        grades.find(
          g =>
            percentage > g.markstart - 1 &&
            percentage <= g.markend
        )?.grade || "F";

      let subdomandata: any[] = [];

      if (Object.keys(student.subdomain).length > 0) {
        subdomandata = Object.entries(student.subdomain).map(
          ([subdomain, stats]: any) => {

            const subPercent = Number(
              ((stats.sum * 100) / stats.max).toFixed(2)
            );

            const subGrade =
              grades.find(
                g =>
                  subPercent > g.markstart - 1 &&
                  subPercent <= g.markend
              )?.grade || "F";

            // ✅ INSERT ROW FOR NEW TABLE
            subdomainInsertRows.push({
              paperid,
              studentid: student.studentid,
              class: cls,
              section: student.section,
              subdomain,
              obtainedMarks: stats.sum,
              maxMarks: stats.max,
              percentage: subPercent,
              grade: subGrade
            });

            return {
              subdomain,
              obtainedMarks: stats.sum,
              maxMarks: stats.max,
              percentage: subPercent,
              grade: subGrade
            };
          }
        );
      }

      resultRows.push({
        paperid,
        studentid: student.studentid,
        class: cls,
        section: student.section,
        scope,

        totalScore: student.totalScore,
        maxScore: paperData.maxMarks,

        percentage,
        grade,
        percentile: 0,

        subdomainData: JSON.stringify(subdomandata)
      });
    }

    // ===== BULK INSERT =====
    if (analyticsRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentQuestionResult)
        .values(analyticsRows)
        .execute();
    }

    if (resultRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentResult)
        .values(resultRows)
        .execute();
    }

    // ✅ INSERT SUBDOMAIN TABLE
    if (subdomainInsertRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentSubdomainResult)
        .values(subdomainInsertRows)
        .execute();
    }

    // ===== PERCENTILE =====
    let percentileFilter = `
      WHERE paperid = ? AND class = ? AND scope = ?
    `;
    const percentileParams: any[] = [paperid, cls, scope];

    if (section) {
      percentileFilter += ` AND section = ?`;
      percentileParams.push(section);
    }

    await manager.query(
      `
      UPDATE studentresult r
      JOIN (
        SELECT
          studentid,
          paperid,
          PERCENT_RANK() OVER (ORDER BY totalScore) * 100 AS percentile
        FROM studentresult
        ${percentileFilter}
      ) p
      ON r.studentid = p.studentid
      AND r.paperid = p.paperid
      SET r.percentile = ROUND(p.percentile,2)
      `,
      percentileParams
    );

    await manager.query(
      `DELETE FROM studentsectionsummary WHERE paperid = ? AND class = ?`,
      [paperid, cls]
    );

    await manager.query(`
    INSERT INTO studentsectionsummary (paperid, class, section, avgPercentage, avgMarks, studentCount)
    SELECT 
      paperid,
      class,
      section,
      ROUND(AVG(percentage),2),
      ROUND(AVG(totalScore),2),
      COUNT(*)
    FROM studentresult
    WHERE paperid = ? AND class = ?
    GROUP BY section
  `, [paperid, cls]);

    await manager.query(
      `DELETE FROM studentsubjectsummary WHERE paperid = ? AND class = ?`,
      [paperid, cls]
    );

    await manager.query(`
      INSERT INTO studentsubjectsummary (paperid, class, section, subdomain, avgPercentage, avgMarks)
      SELECT 
        paperid,
        class,
        section,
        subdomain,
        ROUND(AVG(percentage),2),
        ROUND(AVG(obtainedMarks),2)
      FROM studentsubdomainresult
      WHERE paperid = ? AND class = ?
      GROUP BY section, subdomain
    `, [paperid, cls]);

    return {
      message: "Result generated successfully",
      success: true
    };
  });
}
*/
/*
async createResult(paperid: string, cls: string, section?: string) {
  return this.dataSource.transaction(async (manager) => {
    const scope = 'SECTION';

    // ===== CHECK EXISTING =====
    const existsQuery = manager
      .createQueryBuilder(StudentResult, "r")
      .select("1")
      .where("r.paperid = :paperid", { paperid })
      .andWhere("r.class = :cls", { cls })
      .andWhere("r.scope = :scope", { scope });

    if (section) {
      existsQuery.andWhere("r.section = :section", { section });
    }

    const exists = await existsQuery.limit(1).getRawOne();

    if (exists) {
      return {
        message: "Result already available",
        success: "Result Present"
      };
    }

    // ===== PAPER =====
    const paperData = await manager.findOne(QuestionPaper, {
      where: { id: Number(paperid) }
    });

    if (!paperData) {
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    // ===== QUERY =====
    let whereClause = `
      WHERE an.dmlType = 'I'
      AND an.paperid = ?
      AND eq.paperid = ?
      AND an.class = ?
    `;
    const params: any[] = [paperid, paperid, cls];

    if (section) {
      whereClause += ` AND an.section = ?`;
      params.push(section);
    }

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,

        eq.sequence,

        q.id AS qid,
        q.quesType,
        q.marks AS qmarks,
       
        sub.subject AS subdomain,
        q.cg AS skill,

        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank')
               AND an.uanswer = an.canswer
          THEN q.marks
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank')
          THEN 0
          ELSE COALESCE(an.marks,0)
        END AS score

      FROM answer an

      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id

      LEFT JOIN subject sub ON sub.id = q.subdomain
      LEFT JOIN curriculumgoal cg ON cg.id = q.cg

      ${whereClause}

      ORDER BY an.section, an.studentid, eq.sequence`,
      params
    );

    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    const studentMap = new Map();
    const analyticsRows: any[] = [];
    const resultRows: any[] = [];
    const subdomainInsertRows: any[] = []; // ✅ NEW TABLE DATA

    // ===== PROCESS LOOP =====
    for (const row of rows) {

      if (!studentMap.has(row.studentid)) {
        studentMap.set(row.studentid, {
          studentid: row.studentid,
          studentname: row.studentname,
          section: row.section,
          rollno: row.rollno,
          questiondata: [],
          totalScore: 0,
          subdomain: {}
        });
      }

      const student = studentMap.get(row.studentid);

      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      // QUESTION DATA
      student.questiondata.push({
        id: row.qid,
        seq: row.sequence,
        subject: row.subdomain,
        subdomain: row.subdomain,
        skill: row.skill,
        data: score,
        answered: row.uanswer
      });

      student.totalScore += score;

      // SUBDOMAIN AGGREGATION
      if (row.subdomain) {
        if (!student.subdomain[row.subdomain]) {
          student.subdomain[row.subdomain] = {
            sum: 0,
            max: 0
          };
        }

        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;
      }

      // ANALYTICS TABLE
      analyticsRows.push({
        paperid,
        studentid: row.studentid,
        class: cls,
        section: row.section,

        qid: row.qid,
        sequence: row.sequence,

        subject: row.subdomain,
        subdomain: row.subdomain,
        skill: row.skill,

        questionType: row.quesType,
        studentAnswer: row.uanswer,
        correctAnswer: row.canswer,

        score,
        maxScore: maxMarks
      });
    }

    // ===== STUDENT SUMMARY =====
    for (const student of studentMap.values()) {

      const percentage = Number(
        ((student.totalScore * 100) / paperData.maxMarks).toFixed(2)
      );

      const grade =
        grades.find(
          g =>
            percentage > g.markstart - 1 &&
            percentage <= g.markend
        )?.grade || "F";

      let subdomandata: any[] = [];

      if (Object.keys(student.subdomain).length > 0) {
        subdomandata = Object.entries(student.subdomain).map(
          ([subdomain, stats]: any) => {

            const subPercent = Number(
              ((stats.sum * 100) / stats.max).toFixed(2)
            );

            const subGrade =
              grades.find(
                g =>
                  subPercent > g.markstart - 1 &&
                  subPercent <= g.markend
              )?.grade || "F";

            // ✅ INSERT ROW FOR NEW TABLE
            subdomainInsertRows.push({
              paperid,
              studentid: student.studentid,
              class: cls,
              section: student.section,
              subdomain,
              obtainedMarks: stats.sum,
              maxMarks: stats.max,
              percentage: subPercent,
              grade: subGrade
            });

            return {
              subdomain,
              obtainedMarks: stats.sum,
              maxMarks: stats.max,
              percentage: subPercent,
              grade: subGrade
            };
          }
        );
      }

      resultRows.push({
        paperid,
        studentid: student.studentid,
        class: cls,
        section: student.section,
        scope,

        totalScore: student.totalScore,
        maxScore: paperData.maxMarks,

        percentage,
        grade,
        percentile: 0,

        subdomainData: JSON.stringify(subdomandata)
      });
    }

    // ===== BULK INSERT =====
    if (analyticsRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentQuestionResult)
        .values(analyticsRows)
        .execute();
    }

    if (resultRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentResult)
        .values(resultRows)
        .execute();
    }

    // ✅ INSERT SUBDOMAIN TABLE
    if (subdomainInsertRows.length > 0) {
      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentSubdomainResult)
        .values(subdomainInsertRows)
        .execute();
    }

    // ===== PERCENTILE =====
    let percentileFilter = `
      WHERE paperid = ? AND class = ? AND scope = ?
    `;
    const percentileParams: any[] = [paperid, cls, scope];

    if (section) {
      percentileFilter += ` AND section = ?`;
      percentileParams.push(section);
    }

    await manager.query(
      `
      UPDATE studentresult r
      JOIN (
        SELECT
          studentid,
          paperid,
          PERCENT_RANK() OVER (ORDER BY totalScore) * 100 AS percentile
        FROM studentresult
        ${percentileFilter}
      ) p
      ON r.studentid = p.studentid
      AND r.paperid = p.paperid
      SET r.percentile = ROUND(p.percentile,2)
      `,
      percentileParams
    );

    return {
      message: "Result generated successfully",
      success: true
    };
  });
}*/

/* forth function
async createResult(paperid: string, cls: string, section?: string) {
  // adfadsf
  console.log('paperid:',paperid, ' cls:',cls, ' section:', section)
  return this.dataSource.transaction(async (manager) => {
    const scope = 'SECTION';
    const existsQuery = manager
      .createQueryBuilder(StudentResult, "r")
      .select("1")
      .where("r.paperid = :paperid", { paperid })
      .andWhere("r.class = :cls", { cls })
      .andWhere("r.scope = :scope", { scope });

      if (section) {        
        existsQuery.andWhere("r.section = :section", { section });
      }

    const exists = await existsQuery.limit(1).getRawOne();

    if (exists) {
      return {
        message: "Result already available",
        success: "Result Present"
      };
    }

    const paperData = await manager.findOne(QuestionPaper, {
      where: { id: Number(paperid) }
    });

    if (!paperData) {
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    let whereClause = `
      WHERE an.dmlType = 'I'
      AND an.paperid = ?
      AND eq.paperid = ?
      AND an.class = ?
    `;
    const params: any[] = [paperid, paperid, cls];
    
    if (section) {
      whereClause += ` AND an.section = ?`;
      params.push(section);
    }

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,

        eq.sequence,
        q.id AS qid,
        q.quesType,
        q.marks AS qmarks,
       
        sub.subject AS subdomain,

        q.cg AS skill,

        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank')
               AND an.uanswer = an.canswer
          THEN q.marks
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse','fillblank')
          THEN 0
          ELSE COALESCE(an.marks,0)
        END AS score

      FROM answer an

      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id

      LEFT JOIN subject sub ON sub.id = q.subdomain
      LEFT JOIN curriculumgoal cg ON cg.id = q.cg

      ${whereClause}

      ORDER BY an.section, an.studentid, eq.sequence`,
      params
    );
   
    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    const studentMap = new Map();

    const analyticsRows: any[] = [];
    const resultRows: any[] = [];

    for (const row of rows) {

      if (!studentMap.has(row.studentid)) {

        studentMap.set(row.studentid, {
          studentid: row.studentid,
          studentname: row.studentname,
          section: row.section,
          rollno: row.rollno,
          questiondata: [],
          totalScore: 0,
          subdomain: {}
        });

      }

      const student = studentMap.get(row.studentid);

      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      student.questiondata.push({
        id: row.qid,
        seq: row.sequence,
        subject: row.subject,
        subdomain: row.subdomain,
        skill: row.skill,
        data: score,
        answered: row.uanswer
      });

      student.totalScore += score;

      // subdomain aggregation
      if (row.subdomain) {

        if (!student.subdomain[row.subdomain]) {

          student.subdomain[row.subdomain] = {
            sum: 0,
            max: 0
          };

        }

        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;

      }

      // analytics row
      analyticsRows.push({

        paperid,
        studentid: row.studentid,
        class: cls,
        section: row.section,

        qid: row.qid,
        subject: row.subject,
        subdomain: row.subdomain,
        skill: row.skill,

        questionType: row.quesType,
        studentAnswer: row.uanswer,
        correctAnswer: row.canswer,

        score,
        maxScore: maxMarks

      });

    }

    // ===== STUDENT SUMMARY =====

    for (const student of studentMap.values()) {

      const percentRaw =
        (student.totalScore * 100) / paperData.maxMarks;

      const percentage =
        Number.isInteger(percentRaw)
          ? percentRaw
          : Number(percentRaw.toFixed(2));

      const grade =
        grades.find(
          g =>
            percentage > g.markstart - 1 &&
            percentage <= g.markend
        )?.grade || "F";

      let subdomandata: any[] = [];

      if (Object.keys(student.subdomain).length > 0) {

        subdomandata = Object.entries(student.subdomain).map(
          ([subdomain, stats]: any) => {

            const raw = (stats.sum * 100) / stats.max;

            const subPercent =
              Number.isInteger(raw)
                ? raw
                : Number(raw.toFixed(2));

            const subGrade =
              grades.find(
                g =>
                  subPercent > g.markstart - 1 &&
                  subPercent <= g.markend
              )?.grade || "F";

            return {
              subdomain,
              percentage: subPercent,
              grade: subGrade
            };

          }
        );

      }

      resultRows.push({

        paperid,
        studentid: student.studentid,
        class: cls,
        section: student.section,
        scope,

        totalScore: student.totalScore,
        maxScore: paperData.maxMarks,

        percentage,
        grade,

        percentile: 0,

        subdomainData: JSON.stringify(subdomandata)

      });

    }

    // ===== BULK INSERT =====

    if (analyticsRows.length > 0) {

      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentQuestionResult)
        .values(analyticsRows)
        .execute();

    }

    if (resultRows.length > 0) {

      await manager
        .createQueryBuilder()
        .insert()
        .into(StudentResult)
        .values(resultRows)
        .execute();

    }

    // ===== PERCENTILE CALCULATION =====

    // await manager.query(
    //   `
    //   UPDATE studentresult r
    //   JOIN (
    //     SELECT
    //       studentid,
    //       paperid,
    //       PERCENT_RANK() OVER (ORDER BY totalScore) * 100 AS percentile
    //     FROM studentresult
    //     WHERE paperid = ?
    //   ) p
    //   ON r.studentid = p.studentid
    //   AND r.paperid = p.paperid
    //   SET r.percentile = ROUND(p.percentile,2)
    //   `,
    //   [paperid]
    // );

    // ===== PERCENTILE =====
    let percentileFilter = `
      WHERE paperid = ? AND class = ? AND scope = ?
    `;

    const percentileParams: any[] = [paperid, cls, scope];

    if (section) {
      percentileFilter += ` AND section = ?`;
      percentileParams.push(section);
    }
    // if (scope === 'SECTION') {
    //   percentileFilter += ` AND section = ?`;
    //   percentileParams.push(section);
    // }

    await manager.query(
      `
      UPDATE studentresult r
      JOIN (
        SELECT
          studentid,
          paperid,
          PERCENT_RANK() OVER (ORDER BY totalScore) * 100 AS percentile
        FROM studentresult
        ${percentileFilter}
      ) p
      ON r.studentid = p.studentid
      AND r.paperid = p.paperid
      SET r.percentile = ROUND(p.percentile,2)
      `,
      percentileParams
    );

    return {
      message: "Result generated successfully",
      success: true
    };

  });

}
*/
/* third function
async createResult(paperid: string, section: string | null, cls: string) {
  return this.dataSource.transaction(async (manager) => {

    const paperData = await this.questionPaperRepository.findOne({
      where: { id: Number(paperid) },
    });

    if (!paperData) {
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    // ---------------- SECTION FILTER ---------------- 

    let sectionFilter = "";
    const params: any[] = [paperid, paperid, cls];

    if (section) {
      sectionFilter = "AND an.section = ?";
      params.push(section);
    }

    // ---------------- FETCH ANSWERS ---------------- 

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,
        eq.sequence,
        q.id AS qid,
        sub.subject AS subdomain,
        q.quesType,
        q.marks AS qmarks,
        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse')
               AND an.uanswer = an.canswer
          THEN q.marks
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse')
          THEN 0
          ELSE COALESCE(an.marks,0)
        END AS score

      FROM answer an
      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id
      LEFT JOIN subject sub ON sub.id = q.subdomain

      WHERE an.dmlType='I'
      AND an.paperid=?
      AND eq.paperid=?
      AND an.class=?
      ${sectionFilter}

      ORDER BY an.section, an.studentid, eq.sequence`,
      params
    );

    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    // ---------------- DATA STRUCTURES ---------------- 

    const analyticsRows: any[] = [];
    const sectionMap = new Map();
    const questionStats: any = {};

    // ---------------- PROCESS ANSWERS ---------------- 

    for (const row of rows) {

      if (!sectionMap.has(row.section)) {
        sectionMap.set(row.section, new Map());
      }

      const studentMap = sectionMap.get(row.section);

      if (!studentMap.has(row.studentid)) {
        studentMap.set(row.studentid, {
          paperid,
          studentid: row.studentid,
          studentclass: cls,
          studentsection: row.section,
          rollno: row.rollno,
          studentname: row.studentname,
          questiondata: [],
          totalScore: 0,
          subdomain: {}
        });
      }

      const student = studentMap.get(row.studentid);

      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      student.totalScore += score;

      student.questiondata.push({
        id: row.qid,
        seq: row.sequence,
        subdomain: row.subdomain,
        data: score
      });

      // ---------- SUBDOMAIN ANALYTICS ---------- 

      if (row.subdomain) {

        if (!student.subdomain[row.subdomain]) {
          student.subdomain[row.subdomain] = { sum: 0, max: 0 };
        }

        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;
      }

      // ---------- QUESTION ANALYTICS ---------- 

      if (!questionStats[row.qid]) {
        questionStats[row.qid] = {
          attempts: 0,
          correct: 0,
          totalScore: 0,
          max: maxMarks
        };
      }

      questionStats[row.qid].attempts++;
      questionStats[row.qid].totalScore += score;

      if (score === maxMarks) {
        questionStats[row.qid].correct++;
      }

    }

    // ---------------- BUILD FINAL RESULTS ---------------- 

    const finalResults: any = {};

    for (const [sectionName, studentMap] of sectionMap.entries()) {

      const students = [...studentMap.values()];

      // ----- SORT FOR RANKING ----- 

      students.sort((a, b) => b.totalScore - a.totalScore);

      // ----- SECTION AVERAGE ----- 

      const sectionTotal = students.reduce((s, x) => s + x.totalScore, 0);
      const sectionAverage = sectionTotal / students.length;

      const sectionResults = students.map((student, index) => {

        const percentage = (
          student.totalScore * 100 / paperData.maxMarks
        );

        const grade =
          grades.find(
            g =>
              percentage > g.markstart - 1 &&
              percentage <= g.markend
          )?.grade || "F";

        // ----- PERCENTILE ----- 

        const percentile =
          ((students.length - index) / students.length * 100);

        // ----- SUBDOMAIN RESULT ----- 

        const subdomandata = Object.entries(student.subdomain).map(
          ([subdomain, stats]: any) => {

            const subPercent = ((stats.sum / stats.max) * 100);

            const subGrade =
              grades.find(
                g =>
                  subPercent > g.markstart - 1 &&
                  subPercent <= g.markend
              )?.grade || "F";

            return {
              subdomain,
              percentage: this.formatPercent(subPercent),
              grade: subGrade
            };

          }
        );

        return {
          ...student,
          studentpercentage: this.formatPercent(percentage),
          studentgrade: grade,
          studentpercentile: percentile,
          subdomandata
        };

      });

      finalResults[sectionName] = {
        sectionAverage: sectionAverage.toFixed(2),
        totalStudents: students.length,
        students: sectionResults
      };

    }

    // ---------------- QUESTION DIFFICULTY ---------------- 

    const difficulty = Object.entries(questionStats).map(
      ([qid, stat]: any) => {

        const difficultyIndex =
          ((stat.correct / stat.attempts) * 100).toFixed(2);

        return {
          qid,
          attempts: stat.attempts,
          difficultyIndex
        };

      }
    );

    return {
      message: "Transaction completed successfully",
      success: "success",
      sections: finalResults,
      questionAnalytics: difficulty
    };

  });
}
*/
/*second update functin
  async createResult(paperid: string, section: string, cls: string) {
  return this.dataSource.transaction(async (manager) => {

    // FAST existence check
    const exists = await manager
      .createQueryBuilder(Result, "r")
      .select("1")
      .where("r.paperid = :paperid", { paperid })
      .andWhere("r.studentclass = :cls", { cls })
      .andWhere("r.studentsection = :section", { section })
      .limit(1)
      .getRawOne();

    if (exists) {
      return {
        message: "Result already available",
        success: "Result Present"
      };
    }
    const paperData = await this.questionPaperRepository.findOne({
        where: { id: Number(paperid) },
    });
    if(!paperData){
      throw new HttpException("Paper Not found", HttpStatus.NOT_FOUND);
    }

    const rows = await manager.query(
      `SELECT 
        si.Id AS studentid,
        si.Name AS studentname,
        si.RollNo AS rollno,
        an.section,
        eq.sequence,
        q.id AS qid,
        sub.subject AS subdomain,
        q.quesType,
        q.marks AS qmarks,
        an.uanswer,
        an.canswer,
        an.marks AS amarks,

        CASE
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse')
               AND an.uanswer = an.canswer
          THEN q.marks
          WHEN q.quesType IN ('multipleChoice','oneword','truefalse')
          THEN 0
          ELSE COALESCE(an.marks,0)
        END AS score

      FROM answer an
      JOIN studentinformation si ON an.studentid = si.Id
      JOIN examquestion eq ON an.qid = eq.questionId
      JOIN questions q ON eq.questionId = q.id
      LEFT JOIN subject sub ON sub.id = q.subdomain

      WHERE an.dmlType = 'I'
      AND an.paperid = ?
      AND eq.paperid = ?
      AND an.class = ?
      AND an.section = ?

      ORDER BY an.studentid, eq.sequence`,
      [paperid, paperid, cls, section]
    );

    if (!rows.length) {
      throw new HttpException("No answers found", HttpStatus.NOT_FOUND);
    }

    const grades = await manager.find(Grade, { where: { status: 1 } });

    const studentMap = new Map();

    for (const row of rows) {

      if (!studentMap.has(row.studentid)) {
        studentMap.set(row.studentid, {
          paperid,
          studentid: row.studentid,
          studentclass: cls,
          studentsection: section.toUpperCase(),
          rollno: row.rollno,
          studentname: row.studentname,
          questiondata: [],
          totalScore: 0,
          subdomain: {}
        });
      }

      const student = studentMap.get(row.studentid);
      const score = Number(row.score);
      const maxMarks = Number(row.qmarks);

      student.questiondata.push({
        id: row.qid,
        seq: row.sequence,
        subdomain: row.subdomain,
        data: Number(row.score),
        answered:
          ['multipleChoice','oneword','truefalse'].includes(row.quesType)
            ? row.uanswer
            : ''
      });

      student.totalScore += Number(row.score);

      // subdomain aggregation
      if (row.subdomain) {

        if (!student.subdomain[row.subdomain]) {

          student.subdomain[row.subdomain] = {
            sum: 0,
            max: 0
          };

        }

        student.subdomain[row.subdomain].sum += score;
        student.subdomain[row.subdomain].max += maxMarks;

      }
    }

    const results:any = [];

    for (const student of studentMap.values()) {
      const percentage = (
        student.totalScore * 100 / paperData?.maxMarks
      ).toFixed(2);     
      const grade =
        grades.find(
          g =>
            parseFloat(percentage) > g.markstart - 1 &&
            parseFloat(percentage) <= g.markend
        )?.grade || "F";

         let subdomandata: any[] = [];

        if (Object.keys(student.subdomain).length > 0) {

          subdomandata = Object.entries(student.subdomain).map(
            ([subdomain, stats]: any) => {

              const subPercent = ((stats.sum / stats.max) * 100).toFixed(2);

              const subGrade =
                grades.find(
                  g =>
                    parseFloat(subPercent) > g.markstart - 1 &&
                    parseFloat(subPercent) <= g.markend
                )?.grade || "F";

              return {
                subdomain,
                percentage: subPercent,
                grade: subGrade
              };

            }
          );

        }

      results.push({
        studentpercentage: percentage,
        studentgrade: grade,
        studentpercentile: "",
        subdomandata,
        ...student,
      });
    }

    return {
      message: "Transaction completed successfully",
      success: "success",
      results
    };
  });
}
*/

/*
  async createResult(paperid: string, section: string, cls: string) {
    return await this.dataSource.transaction(async (manager) => {
      try {
        const existingResults = await manager.find(Result, {
          where: { paperid, studentclass: cls, studentsection: section },
        });
        if (existingResults.length > 0) {
          return {
            message: 'Result already available',
            success: 'Result Present',
          };
        }
        const answers = await manager.query(
          `SELECT si.Id as studentid, si.Name as studentname, si.RollNo as rollno, an.section as section,
              GROUP_CONCAT(eq.questionId ORDER BY eq.sequence ASC) AS qid,
              GROUP_CONCAT(COALESCE(an.uanswer,0) ORDER BY eq.sequence ASC) AS uanswer,
              GROUP_CONCAT(COALESCE(an.canswer,0) ORDER BY eq.sequence ASC) AS canswer,
              GROUP_CONCAT(COALESCE(an.marks, 'NA') ORDER BY eq.sequence ASC) AS amarks,
              GROUP_CONCAT(sub.subject ORDER BY eq.sequence ASC) AS subdomain,
              GROUP_CONCAT(q.quesType ORDER BY eq.sequence ASC) AS quesType,
              GROUP_CONCAT(q.marks ORDER BY eq.sequence ASC) AS qmarks
        FROM answer as an 
        LEFT JOIN studentinformation si ON an.studentid = si.Id  
        LEFT JOIN examquestion eq ON an.qid = eq.questionId 
        LEFT JOIN questions q ON eq.questionId = q.id 
        LEFT JOIN subject sub ON sub.id=q.subdomain
        WHERE an.dmlType = 'I' AND an.paperid = ? AND eq.paperid = ? AND an.class = ? AND an.section = ? 
        GROUP BY an.section, an.studentid 
        ORDER BY an.studentid, eq.sequence ASC;
      `,
          [paperid, paperid, cls, section]
        );

        if (!answers.length) {
          throw new HttpException('No answers found', HttpStatus.NOT_FOUND);
        }

        const grades = await manager.find(Grade, { where: { status: 1 } });

        const resultsData = answers.map((answer) => {
          const questionIds = (answer.qid ?? '').split(',');
          const studentAnswers = (answer.uanswer ?? '').split(',');
          const correctAnswers = (answer.canswer ?? '').split(',');
          const subdomains = (answer.subdomain ?? '').split(',');
          const quesType = answer.quesType.split(",");
          const qmarks = answer.qmarks.split(",");
          const amarks = answer.amarks.split(",");

          const scoreData = questionIds.map((qid: string, i: number) => ({
            id: parseInt(qid),
            seq: i + 1,
            subdomain: subdomains[i],
            // data: studentAnswers[i] === correctAnswers[i] ? 1 : 0,
            data: quesType[i] === "multipleChoice"
              ? (studentAnswers[i] === correctAnswers[i] ? Number(qmarks[i] || 0) : 0)
              : Number(amarks[i] || 0),
            answered: quesType[i] === "multipleChoice" ? studentAnswers[i] : '',
          }));
          console.log('i: ', scoreData);
          const subdomainStats = this.sumDataBySubdomain(scoreData);
          const subdomandata = Object.entries(subdomainStats).map(
            ([subdomain, statsRaw]) => {
              const stats = statsRaw as { sum: number; count: number };
              const subPercent = (stats.sum / stats.count) * 100;
              const subGrade =
                grades.find(
                  (g) => subPercent > g.markstart - 1 && subPercent <= g.markend
                )?.grade || 'F';
              return {
                subdomain,
                percentage: subPercent.toFixed(2),
                grade: subGrade,
              };
            }
          );
          const percentage = (
            (scoreData.reduce((a, b) => a + b.data, 0) / scoreData.length) *
            100
          ).toFixed(2);
          const grade =
            grades.find(
              (g) =>
                parseFloat(percentage) > g.markstart - 1 &&
                parseFloat(percentage) <= g.markend
            )?.grade || 'F';
          return {
            paperid,
            studentid: answer.studentid,
            studentclass: cls,
            studentsection: section.toUpperCase(),
            rollno: answer.rollno,
            studentname: answer.studentname,
            studentpercentage: percentage,
            studentgrade: grade,
            studentpercentile: '',
            questiondata: scoreData,
            subdomandata: subdomandata,
          };
        });
        // console.log('resultsData', resultsData);
        // await manager.insert(Result, resultsData);
        // const insertResult = await manager.insert(Result, resultsData);
        // await this.alertCheck(manager, insertResult.identifiers[0].id, insertResult.raw.affectedRows, cls, section);

        return {
          message: 'Transaction completed successfully',
          success: 'success',
          results: resultsData,          
        };
      } catch (error) {
        console.error('Error in createResult transaction:', error);
      }
    });
  }
*/
  public sumDataBySubdomain(dataList) {
    return dataList.reduce((acc, item) => {
      if (!acc[item.subdomain]) {
        acc[item.subdomain] = { sum: 0, count: 0 };
      }
      acc[item.subdomain].sum += item.data;
      acc[item.subdomain].count += 1;
      return acc;
    }, {});
  }

  private async alertCheck(
    manager,
    insertId: number,
    affectedRows: number,
    cls: string,
    section: string
  ) {
    const firstId = insertId;
    const lastId = firstId + affectedRows - 1;

    const results = await manager.find(Result, {
      where: { id: Between(firstId, lastId) },
    });
    const alertData = results
      .filter((result) => result.studentpercentage <= 35)
      .map((result) => ({
        id: result.studentid,
        rollno: result.rollno,
        name: result.studentname,
        percentage: result.studentpercentage,
        grade: result.studentgrade,
      }));

    if (alertData.length > 0) {
      const existingAlerts = await manager.find(Alert, {
        where: {
          alertpaperid: results[0].paperid,
          alertclass: cls,
          alertsection: section,
        },
      });

      if (existingAlerts.length === 0) {
        await manager.insert(Alert, {
          alertpaperid: results[0].paperid,
          alertclass: cls,
          alertsection: section,
          alertstype: 'STUDENTPERFORMANCE',
          alertdetails: JSON.stringify(alertData),
        });
      }
    }
  }
  // open ai integration openAiIntegration
  async getReportAnalyzer(data: any) {
    //open ai api call here
    // console.log('data', data);
    const check = true
    //  await this.openAiRepository.findOne({
    //   where: { paperId: String(data.paperid) },
    // });
    if (check) {
      console.log('openai result form db');

      return {
        message: 'OpenAI analysis already exists',
        // analysis: check.response,
      };
    } else {
      try {
        const openai = new OpenAI({
          apiKey: this.openapikey, // store your key in environment variable
        });
        const graphData = {
          section: data.sections,
          answer: data.answer,
        }; // JSON like the one you shared

        // Create the prompt dynamically
        const systemMessage = `
          SYSTEM PROMPT:

You are an educational performance analyst specializing in interpreting exam-grade distributions from structured JSON data.  
Your task is to produce short, structured HTML summaries suitable for dashboards and reports.  

Each summary must be factual, reproducible, and based strictly on quantitative grade distribution — not subjective interpretation.

-----------------------------------------------------------
STRUCTURE TO FOLLOW
-----------------------------------------------------------
For each section in the JSON, output exactly this block:

<div class="section-summary" data-section="X">
  <h4>Section X</h4>
  <p>[2–3 lines comparing this section’s performance to other sections]</p>
  <p>[Reasoning for above comparison — 1–2 lines]</p>
  <p>[Performance insights and observations for this section — 2–3 lines]</p>
</div>

Replace letters (A, B, C, D) with numbers (1, 2, 3, 4).

Wrap all section blocks inside:
<div class="graph-summaries"> ... </div>

-----------------------------------------------------------
GRADE DEFINITIONS
-----------------------------------------------------------
Use the following grade scale:

A+ = 90–100  
A  = 80–90  
B+ = 70–80  
B  = 60–70  
C+ = 50–60  
C  = 40–50  
D  = 33–40  
E  = 0–33

-----------------------------------------------------------
PERFORMANCE GROUPS
-----------------------------------------------------------
To make objective comparisons, group grades as follows:

1. **Top Grades** → A+, A, B+  
   Represents high academic performance and strong concept mastery.  
   Indicates students performing above the expected standard.

2. **Mid Grades** → B, C+, C  
   Represents average or satisfactory performance.  
   Indicates students meeting expectations with room for improvement.

3. **Low Grades** → D, E  
   Represents underperformance or at-risk students.  
   Indicates the need for academic support and targeted intervention.

-----------------------------------------------------------
COMPARISON LOGIC
-----------------------------------------------------------
- Compute the total number of students in each group (Top, Mid, Low) per section.  
- Determine relative performance using the **Top-to-Low ratio** (Top ÷ Low).  
- Higher Top-to-Low ratio → stronger section performance.  
- If ratios are similar, treat sections as comparable in performance.

-----------------------------------------------------------
WRITING GUIDELINES
-----------------------------------------------------------
- Be concise, factual, and objective (no emotional or subjective terms).  
- Always include:
  - One comparison sentence referencing other sections.
  - One reasoning paragraph explaining *why* (based on grade counts or ratios).
  - One insight paragraph summarizing trends and next steps.  
- Mention grade names (A+, A, B+, etc.) explicitly when relevant.  
- Do not mention mean or percentage scores.  
- Output only valid HTML — no markdown, JSON, or commentary.

-----------------------------------------------------------
CHAIN-OF-THOUGHT INSTRUCTION (INTERNAL ONLY)
-----------------------------------------------------------
- Internally analyze grade counts to identify top, mid, and low totals.
- Rank sections by Top-to-Low ratio.
- Use these internal rankings to write consistent comparisons.
- Never reveal raw calculations; instead, produce readable factual reasoning.
- Ensure that phrasing and structure are consistent across sections.
- Prioritize clarity, brevity, and objectivity in all outputs.

END SYSTEM PROMPT

        `;

        const prompt = `
        Analyze the following JSON exam data and produce the HTML summaries as described in the system prompt.

Now analyze and summarize this JSON data:
${JSON.stringify(graphData, null, 2)}
          `;

        // Send request to OpenAI API
        // const completion = null;
        const completion = await openai.chat.completions.create({
          model: 'gpt-4o', // use gpt-4o or gpt-5 depending on your access
          messages: [
            { role: 'system', content: systemMessage },
            { role: 'user', content: prompt },
          ],
          max_tokens: 1000,
          temperature: 0.6,
        });

        const analysis =
          completion.choices?.[0]?.message?.content?.trim() ||
          'No analysis available';
        // const analysis = "open ai call perform";
        // console.log('open ai end', analysis);
        const openAiResult = new OpenAIResult();
        openAiResult.paperId = data.paperid || 'multiple';
        openAiResult.paperDate = Date.now();
        openAiResult.response = analysis;
        await this.openAiRepository.save(openAiResult);
        console.log('open ai call performed');
        return { analysis: analysis };
      } catch (error) {
        console.log('openai error', error);
      }
    }
  }

  //-------
  async getReportData(
    studentClass: string,
    paperId?: string,
    subdomain?: string
  ) {
    // console.log('studentClass', studentClass, 'paperId', paperId, 'subdomain', subdomain);

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const paperQuery = await this.questionPaperRepository
        .createQueryBuilder('p')
        .innerJoin(Subject, 's', 's.id = p.subject')
        .select([
          'p.id AS id',
          'p.class AS class',
          's.subject AS subject', // Adjust if your Subject entity uses 'subjectname'
        ])
        .where((qb) => {
          const subQuery = qb
            .subQuery()
            .select('DISTINCT r.paperid')
            .from(Result, 'r')
            .where('r.status = 1')
            .andWhere('r.studentclass = :studentClass', { studentClass })
            .groupBy('DATE_FORMAT(r.createdate, "%Y-%m")')
            .getQuery();
          return 'p.id IN ' + subQuery;
        })
        .setParameter('studentClass', studentClass)
        .getRawMany();

      const papers = paperQuery;
      // console.log('papers', papers.length);
      if (papers.length === 0) {
        throw new HttpException('No Result found', HttpStatus.NOT_FOUND);
      }
      const paperIds = papers.map((p) => p.id);

      const grades = await this.gradeRepository.find({ where: { status: 1 } });

      const means = grades.map((g) => {
        const len = g.markend - (g.markstart - 2);
        const numbers = Array.from(
          { length: len },
          (_, i) => g.markstart - 1 + i
        );
        return numbers.reduce((sum, val) => sum + val, 0) / numbers.length;
      });
      const mean = means.slice(0, means.length - 1);

      const resultConditions: any = {
        status: 1,
        studentclass: studentClass,
      };

      if (paperId) {
        resultConditions.paperid = Number(paperId);
      } else {
        resultConditions.paperid = paperIds.length > 0 ? paperIds : -1;
      }

      const results = await this.resultRepository.find({
        where: resultConditions,
        //relations: ['questiondata'],
      });

      const sections = Array.from(
        new Set(results.map((r) => r.studentsection))
      );

      const quesid = {};
      const answerData: { paperid: number; data: Record<string, any> }[] = [];

      for (const p of papers) {
        const sectionData = {};
        const qids: number[] = [];

        for (const section of sections) {
          const countGrade = {};
          grades.forEach((g) => (countGrade[g.grade] = 0));

          const filteredResults = results.filter(
            (r) =>
              Number(r.paperid) === Number(p.id) && r.studentsection === section
          );

          for (let i = 0; i < filteredResults.length; i++) {
            const r = filteredResults[i];
            let correct = 0;
            let totalQuestions = 0;

            const questionData = Array.isArray(r.questiondata)
              ? r.questiondata
              : typeof r.questiondata === 'string'
                ? JSON.parse(r.questiondata || '[]')
                : [];
            for (const q of questionData) {
              const match = !subdomain || subdomain === q.subdomain;
              if (match) {
                correct += q.data;
                totalQuestions++;
                if (i === 0 && !qids.includes(q.id)) qids.push(q.id);
              }
            }

            let percent = (correct * 100) / totalQuestions;
            const grade = grades.find(
              (g) => percent >= g.markstart && percent <= g.markend
            );
            if (grade) countGrade[grade.grade]++;
          }

          const total: any = Object.values(countGrade).reduce(
            (a, b) => (a as number) + (b as number),
            0 as number
          );
          const percentGrades = Object.entries(countGrade).map(([_, count]) =>
            ((Number(count) * 100) / total).toFixed(2)
          );

          let meanPercent = 0;
          Object.values(countGrade).forEach((count, i) => {
            if (i < mean.length) {
              meanPercent += (count as number) * mean[i];
            }
          });

          sectionData[section] = {
            count: Object.values(countGrade),
            percent: percentGrades,
            meanpercent: (meanPercent / total).toFixed(2),
          };
        }

        answerData.push({ paperid: p.id, data: sectionData });
        quesid[p.id] = qids;
      }

      await queryRunner.commitTransaction();

      return {
        message: 'Transaction completed successfully',
        section: sections,
        paper: papers,
        answer: answerData,
        quesid,
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async getStudentByClass(
    studentClass: string,
    paperId?: string,
    section?: string
  ) {
    const where: any = {};
    where.class = studentClass;
    if (section && section !== 'undefined') {
      where.section = section;
    }
    const result1 = await this.studentRepository.find({
      where: where,
      select: ['Id', 'rollNo', 'section', 'name'],
    });

    if (!result1 || result1.length === 0) {
      throw new NotFoundException(
        'No students found for the given class erro 1'
      );
    }

    const result2 = await this.examQuestionRepository
      .createQueryBuilder('eq')
      .innerJoin('questions', 'q', 'q.id = eq.questionId')
      .where('eq.paperId = :paperId', { paperId })
      .orderBy('eq.sequence', 'ASC')
      .select([
        'q.id AS id',
        'eq.sequence AS sequence',
        'q.quesType AS quesType',
        'q.correctAns AS correctAns',
        'eq.marks AS marks',
      ])
      .getRawMany();

    if (!result2 || result2.length === 0) {
      throw new NotFoundException(
        'No students found for the given class and paper erro 2'
      );
    }
    return {
      message: 'Students found successfully',
      studentData: result1,
      questionData: result2,
    };
  }

  async getPartialQuestion(data: any): Promise<any[]> {
    const result2 = await this.examQuestionRepository
      .createQueryBuilder('eq')
      .innerJoin('questions', 'q', 'q.id = eq.questionId')
      .where('eq.paperId = :paperId', { paperId: data.paperId })
      .orderBy('eq.sequence', 'ASC')
      .select([
        'q.id AS id',
        'eq.sequence AS sequence',
        'eq.sequence AS sequence',
        'eq.queslabel AS queslabel',
        // 'q.correctAns AS correctAns',
        // 'eq.marks AS marks',
      ])
      .getRawMany();

    if (!result2 || result2.length === 0) {
      throw new NotFoundException(
        'No students found for the given class and paper erro 2'
      );
    }
    return result2;
  }

  /*
async getStudentByClass(studentClass: string, paperId?: string, section?: string) {
    const where: any = {};
    where.class = studentClass;    
    if (section && section !== 'undefined') {
      where.section = section;
    }
    const result1 = await this.studentRepository.find({
      where: where,      
    });
    
    if (!result1 || result1.length === 0) {
      throw new NotFoundException('No students found for the given class');
    }

    const queryBuilder = this.examQuestionRepository
    .createQueryBuilder('eq')
    .innerJoin('questions', 'q', 'q.id = eq.questionId')
    .where('eq.paperId = :paperId', { paperId })
    .orderBy('eq.sequence', 'ASC')
    .select([
      'q.id AS id',
      'eq.sequence AS sequence',
      'q.quesType AS quesType',
      'q.correctAns AS correctAns',
      'eq.marks AS marks',
    ]);
    const result2 = await queryBuilder.getRawMany();

    if (!result2 || result2.length === 0) {
      throw new NotFoundException('No students found for the given class and paper');
    }
    return {
      message: 'Students found successfully',
      studentData: result1,
      questionData: result2,
    }
 }
    */

  /*
  async getResultList(query: any) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const subdomain = query.subdomain;
      const qarr = [];
      const rowsection = [];
      const subdomainlist = [];
      const result = [];

      const resultSql = `
        SELECT * FROM result 
        WHERE paperid = ? AND studentclass = ? AND studentsection = ?
      `;
      const result1 = await queryRunner.query(resultSql, [
        query.paperid,
        query.class,
        query.section,
      ]);
      
      if (!result1.length) {
        await queryRunner.rollbackTransaction();
        return { message: 'no data' };
      }

      const grades = await queryRunner.query(
        `SELECT grade, markstart, markend FROM grade WHERE status = 1`,
      );

      const countgrade = {};
      const percentile = {};

      grades.forEach((item) => {
        countgrade[item.grade] = 0;
      });

      result1[0].subdomandata.forEach((item) => {
        subdomainlist.push(item.subdomain);
      });

      result1[0].questiondata.forEach((ques) => {
        if (!subdomain || subdomain === ques.subdomain) {
          qarr.push(ques.id);
        }
      });

      result1.forEach((ques) => {
        let data = [];
        let quesdata = [];
        let percentage = ques.studentpercentage;
        let grade = ques.studentgrade;

        if (subdomain) {
          ques.subdomandata.forEach((item) => {
            if (item.subdomain === subdomain) {
              percentage = item.percentage;
              grade = item.grade;
              countgrade[grade]++;
              percentile[percentage] = (percentile[percentage] || 0) + 1;
            }
          });
        } else {
          countgrade[grade]++;
          percentile[percentage] = (percentile[percentage] || 0) + 1;
        }

        ques.questiondata.forEach((idata) => {
          if (!subdomain || subdomain === idata.subdomain) {
            data.push(idata.data);
            quesdata.push(idata);
          }
        });

        result.push({
          id: ques.id,
          paperid: ques.paperid,
          studentid: ques.studentid,
          studentclass: ques.studentclass,
          studentsection: ques.studentsection,
          rollno: ques.rollno,
          studentname: ques.studentname,
          studentpercentage: percentage,
          studentgrade: grade,
          studentpercentile: ques.studentpercentile,
          questiondata: quesdata,
        });

        rowsection.push({ data });
      });

      const studentcount = rowsection.length;
      let avg = [];
      let vsum = [];

      rowsection.forEach((item, index) => {
        if (index === 0) {
          vsum = item.data;
        } else {
          vsum = vsum.map((val, i) => val + item.data[i]);
        }
      });

      avg = vsum.map((val) =>
        parseFloat(((val * 100) / studentcount).toFixed(2).replace(/[.,]00$/, '')),
      );

      await queryRunner.commitTransaction();

      return {
        message: 'data',
        qid: qarr,
        result: result,
        avg: avg,
        subDomain: subdomainlist,
        countgrade: countgrade,
        percentile: percentile,
      };
    } catch (err) {
      console.log('Error in getResultList:', err);
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }
*/

  async getResultList(data: any) {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const subdomain = data.subdomain;
      const qarr: any[] = [];
      const rowsection: { data: number[] }[] = [];
      const subdomainlist: string[] = [];
      const result: ResultRow[] = [];
      const avg: number[] = [];
      let vsum: number[] = [];

      const result1 = await queryRunner.query(
        `SELECT * FROM result WHERE paperid = ? AND studentclass = ? AND studentsection = ?`,
        [data.paperid, data.class, data.section]
      );

      if (!result1.length) {
        await queryRunner.rollbackTransaction();
        return { message: 'no data adf' };
      }

      const grades = await queryRunner.query(
        `SELECT grade, markstart, markend FROM grade WHERE status = 1`
      );

      const countgrade: Record<string, number> = {};
      const percentile: Record<number, number> = {};

      grades.forEach((item: any) => {
        countgrade[item.grade] = 0;
      });

      result1[0].subdomandata.forEach((item: SubdomainData) => {
        subdomainlist.push(item.subdomain);
      });

      result1[0].questiondata.forEach((ques: QuestionItem) => {
        if (!subdomain || subdomain === ques.subdomain) {
          qarr.push({ id: ques.id, seq: ques?.seq });
          // console.log('seq', ques.seq);
        }
      });

      result1.forEach((ques: any) => {
        const data: number[] = [];
        const quesdata: QuestionItem[] = [];

        let percentage = ques.studentpercentage;
        let grade = ques.studentgrade;

        if (subdomain) {
          ques.subdomandata.forEach((item: SubdomainData) => {
            if (item.subdomain === subdomain) {
              percentage = item.percentage;
              grade = item.grade;

              countgrade[grade]++;
              percentile[percentage] = (percentile[percentage] || 0) + 1;
            }
          });
        } else {
          countgrade[grade]++;
          percentile[percentage] = (percentile[percentage] || 0) + 1;
        }

        ques.questiondata.forEach((idata: QuestionItem) => {
          if (!subdomain || subdomain === idata.subdomain) {
            data.push(idata.data);
            quesdata.push(idata);
          }
        });

        const inresult: ResultRow = {
          id: ques.id,
          paperid: ques.paperid,
          studentid: ques.studentid,
          studentclass: ques.studentclass,
          studentsection: ques.studentsection,
          rollno: ques.rollno,
          studentname: ques.studentname,
          studentpercentage: percentage,
          studentgrade: grade,
          studentpercentile: ques.studentpercentile,
          questiondata: quesdata,
        };

        result.push(inresult);
        rowsection.push({ data });
      });

      const studentcount = rowsection.length;

      rowsection.forEach((item, index) => {
        if (index === 0) {
          vsum = [...item.data];
        } else {
          vsum = vsum.map((val, i) => val + item.data[i]);
        }
      });

      const avgResult = vsum.map((val) =>
        parseFloat(
          ((val * 100) / studentcount).toFixed(2).replace(/[.,]00$/, '')
        )
      );

      await queryRunner.commitTransaction();

      return {
        message: 'data',
        qid: qarr,
        result: result,
        avg: avgResult,
        subDomain: subdomainlist,
        countgrade: countgrade,
        percentile: percentile,
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }
  /* modifyed getAvg function
  async getAvg(query: any): Promise<any> {
  console.log('getAvg query');

  const questions = await this.questionRepository.findOne({
    where: { id: query.qid, dmlType: 'I' },
  });

  const answerMap: Record<string, string> = { A: 'A', B: 'B', C: 'C', D: 'D' };

  try {
    const canswer = answerMap[questions?.correctAns?.toUpperCase() || ''] || '';

    const queryBuilder = this.resultRepository
      .createQueryBuilder('result')
      .where(`JSON_CONTAINS(result.questiondata, CAST(:jsonData AS JSON), '$')`)
      .andWhere('result.paperid = :paperid', { paperid: query.paperid })
      .andWhere('result.studentclass = :studentclass', { studentclass: query.class })
      .setParameters({
        jsonData: JSON.stringify({ id: Number(query.qid) }),
      })
      .addOrderBy('result.studentsection', 'ASC');

    const rows = await queryBuilder.getMany();

    // Group answers by section and option
    const grouped: Record<string, Record<string, number>> = {};

    for (const row of rows) {
      if (!row.questiondata) continue;

      let questions: any[] = [];
      if (typeof row.questiondata === 'string') {
        questions = JSON.parse(row.questiondata);
      } else if (Array.isArray(row.questiondata)) {
        questions = row.questiondata;
      } else continue;

      const q = questions.find((q: any) => q.id === Number(query.qid));
      if (q && q.answered) {
        const section = row.studentsection?.toUpperCase() || 'UNKNOWN';
        const answer = q.answered;

        if (!grouped[section]) grouped[section] = {};
        grouped[section][answer] = (grouped[section][answer] || 0) + 1;
      }
    }

    const rdata: Record<string, any[]> = {};
    const selectedSection = query.section?.toUpperCase();

    // --- Selected Section ---
    if (selectedSection && grouped[selectedSection]) {
      const sectionAnswers = grouped[selectedSection];
      const total = Object.values(sectionAnswers).reduce((a, b) => a + b, 0);

      rdata[selectedSection] = Object.entries(sectionAnswers).map(
        ([uanswer, count]) => ({
          qid: Number(query.qid),
          uanswer,
          canswer,
          count,
          tval: ((count * 100) / total).toFixed(2).replace(/[.,]00$/, ''),
        }),
      );
    }

    // --- Combined Other Sections ---
    const combined: Record<string, number> = {};

    for (const [section, answers] of Object.entries(grouped)) {
      if (section === selectedSection) continue;

      for (const [uanswer, count] of Object.entries(answers)) {
        combined[uanswer] = (combined[uanswer] || 0) + count;
      }
    }

    const combinedTotal = Object.values(combined).reduce((a, b) => a + b, 0);

    if (combinedTotal > 0) {
      rdata['OTHERS'] = Object.entries(combined)
        .map(([uanswer, count]) => ({
          qid: Number(query.qid),
          uanswer,
          canswer,
          count,
          tval: ((count * 100) / combinedTotal)
            .toFixed(2)
            .replace(/[.,]00$/, ''),
        }))
        .sort((a, b) => a.uanswer.localeCompare(b.uanswer));
    }

    // Sort selected section too (A–D order)
    if (rdata[selectedSection]) {
      rdata[selectedSection].sort((a, b) =>
        a.uanswer.localeCompare(b.uanswer),
      );
    }

    // console.log('rdata', rdata);
    return rdata;
  } catch (error) {
    console.error('Error in getAvg:', error);
    throw new NotFoundException('Error retrieving questions');
  }
}
*/
  async getAvgOlD(query: any): Promise<any> {
    console.log('getAvg query', query);
    const questions = await this.questionRepository.findOne({
      where: { id: query.qid, dmlType: 'I' },
    });
    const answerMap: Record<string, string> = {
      A: 'optA',
      B: 'optB',
      C: 'optC',
      D: 'optD',
    };
    try {
      const canswer =
        answerMap[questions?.correctAns?.toLocaleUpperCase() || ''] || '';
      console.log('canswer', canswer);
      // console.log('query', query);
      const queryBuilder = this.resultRepository
        .createQueryBuilder('result')
        .where(
          `JSON_CONTAINS(result.questiondata, CAST(:jsonData AS JSON), '$')`
        )
        .andWhere('result.paperid = :paperid', { paperid: query.paperid })
        .andWhere('result.studentclass = :studentclass', {
          studentclass: query.class,
        })
        .setParameters({
          jsonData: JSON.stringify({ id: Number(query.qid) }),
        })
        .addOrderBy('result.studentsection', 'ASC');

      if (query?.section) {
        queryBuilder.andWhere('result.studentsection = :section', {
          section: query.section,
        });
      }
      const rows = await queryBuilder.getMany();

      const grouped: Record<string, number> = {};

      for (const row of rows) {
        if (!row.questiondata) continue;

        let questions: any[] = [];
        if (typeof row.questiondata === 'string') {
          questions = JSON.parse(row.questiondata);
        } else if (Array.isArray(row.questiondata)) {
          questions = row.questiondata;
        } else {
          continue;
        }

        const q = questions.find((q: any) => q.id === Number(query.qid));
        if (q && q.answered) {
          const key = `${q.answered}`; // can include more keys if needed
          grouped[key] = (grouped[key] || 0) + 1;
        }
      }
      console.log('grouped', grouped);
      const allstudent = Object.values(grouped).reduce((a, b) => a + b, 0);

      const result = Object.entries(grouped).map(([uanswer, count]) => {
        const percent: any = ((count * 100) / allstudent)
          .toFixed(2)
          .replace(/[.,]00$/, '');

        return {
          // section: (query.section).toUpperCase(),
          // studentsection,
          qid: Number(query.qid),
          uanswer,
          canswer: canswer,
          count,
          tval: percent,
        };
      });

      const sortedResult = result.sort((a, b) => {
        return a.uanswer.localeCompare(b.uanswer);
      });

      const rdata: Record<string, any[]> = {};
      rdata[query.section] = sortedResult;
      console.log('rdata', rdata);
      return rdata;
    } catch (error) {
      console.error('Error in findQuestions:', error);
      throw new NotFoundException('Error retrieving questions');
    }
  }

  async getAvgAnother(query: any): Promise<any> {
    console.log('getAvg query');

    const questions = await this.questionRepository.findOne({
      where: { id: query.qid, dmlType: 'I' },
    });

    const answerMap: Record<string, string> = {
      A: 'A',
      B: 'B',
      C: 'C',
      D: 'D',
    };

    try {
      const canswer =
        answerMap[questions?.correctAns?.toUpperCase() || ''] || '';

      const queryBuilder = this.resultRepository
        .createQueryBuilder('result')
        .where(
          `JSON_CONTAINS(result.questiondata, CAST(:jsonData AS JSON), '$')`
        )
        .andWhere('result.paperid = :paperid', { paperid: query.paperid })
        .andWhere('result.studentclass = :studentclass', {
          studentclass: query.class,
        })
        .andWhere('result.status = 1')
        .setParameters({
          jsonData: JSON.stringify({ id: Number(query.qid) }),
        })
        .addOrderBy('result.studentsection', 'ASC');

      const rows = await queryBuilder.getMany();
      console.log('rows', rows);

      // Group answers by section and option
      const grouped: Record<string, Record<string, number>> = {};

      for (const row of rows) {
        if (!row.questiondata) continue;

        let questions: any[] = [];
        if (typeof row.questiondata === 'string') {
          questions = JSON.parse(row.questiondata);
        } else if (Array.isArray(row.questiondata)) {
          questions = row.questiondata;
        } else continue;

        const q = questions.find((q: any) => q.id === Number(query.qid));
        // console.log('q', q);
        if (q && q.answered) {
          const section = row.studentsection?.toUpperCase() || 'UNKNOWN';
          const answer = q.answered?.toUpperCase();
          // console.log('section, answer', section, answer);

          if (!grouped[section]) grouped[section] = {};
          grouped[section][answer.toUpperCase()] =
            (grouped[section][answer.toUpperCase()] || 0) + 1;
        }
      }
      // console.log('grouped', grouped);
      const selectedSection = query.section?.toUpperCase();
      const rdata: Record<string, any[]> = {};

      // --- Helper to build A–D structure ---
      const buildAnswerArray = (
        data: Record<string, number>,
        total: number
      ) => {
        const allOptions = ['A', 'B', 'C', 'D'];
        return allOptions.map((opt) => {
          const count = data[opt.toUpperCase()] || 0;
          const percent =
            total > 0
              ? ((count * 100) / total).toFixed(2).replace(/[.,]00$/, '')
              : '0';
          return {
            qid: Number(query.qid),
            uanswer: opt,
            canswer,
            count,
            tval: percent,
          };
        });
      };

      // --- Selected Section ---
      if (selectedSection && grouped[selectedSection]) {
        const sectionAnswers = grouped[selectedSection];
        const total = Object.values(sectionAnswers).reduce((a, b) => a + b, 0);
        rdata[selectedSection] = buildAnswerArray(sectionAnswers, total);
      } else {
        // If selected section has no data

        rdata[selectedSection] = buildAnswerArray({}, 0);
      }

      // --- Combined Other Sections ---
      // const combined: Record<string, number> = {};
      // for (const [section, answers] of Object.entries(grouped)) {
      //   if (section === selectedSection) continue;
      //   for (const [uanswer, count] of Object.entries(answers)) {
      //     console.log('uanswer', uanswer, 'answer', answers);

      //     combined[uanswer] = (combined[uanswer] || 0) + count;
      //   }
      // }
      // console.log("GROUPED FINAL =", JSON.stringify(grouped, null, 2));
      // console.log("SELECTED SECTION =", selectedSection);
      const combined: Record<string, number> = {};

      for (const [section, answers] of Object.entries(grouped)) {
        if (section === selectedSection) continue;

        for (const [uanswer, count] of Object.entries(answers)) {
          // Convert A/B/C/D → optA/optB/optC/optD
          const optKey = answerMap[uanswer] || '';
          if (!optKey) continue;

          combined[optKey.toUpperCase()] =
            (combined[optKey.toUpperCase()] || 0) + count;
        }
      }

      const combinedTotal = Object.values(combined).reduce((a, b) => a + b, 0);
      rdata['OTHERS'] = buildAnswerArray(combined, combinedTotal);

      // console.log('rdata', rdata);
      return rdata;
    } catch (error) {
      console.error('Error in getAvg:', error);
      throw new NotFoundException('Error retrieving questions');
    }
  }

  async getAvg(query: any): Promise<any> {
    console.log('getAvg query', query);

    // Get question for correct answer
    const question = await this.questionRepository.findOne({
      where: { id: query.qid, dmlType: 'I' },
    });

    const correctAnswer = question?.correctAns?.toUpperCase() || '';

    try {
      // Run query
      const rows = await this.resultRepository
        .createQueryBuilder('result')
        .where(
          `JSON_CONTAINS(result.questiondata, JSON_OBJECT('id', :qid), '$')`
        )
        .andWhere('result.paperid = :paperid', { paperid: query.paperid })
        .andWhere('result.studentclass = :cls', { cls: query.class })
        .andWhere('result.status = 1')
        .orderBy('result.studentsection', 'ASC')
        .setParameters({ qid: Number(query.qid) })
        .getMany();

      // --------------------------------------------------
      // GROUP BY SECTION
      // --------------------------------------------------

      const grouped: Record<string, Record<string, number>> = {};

      for (const row of rows) {
        let qlist: any[] = [];

        if (typeof row.questiondata === 'string') {
          qlist = JSON.parse(row.questiondata);
        } else if (Array.isArray(row.questiondata)) {
          qlist = row.questiondata;
        } else {
          continue;
        }

        const q = qlist.find((x) => x.id === Number(query.qid));
        if (!q || !q.answered) continue;

        const section = row.studentsection?.toUpperCase() || 'UNKNOWN';

        // normalize "optA" → "A"
        let raw = q.answered.toUpperCase();
        const answer = raw.startsWith('OPT') ? raw.replace('OPT', '') : raw;

        if (!grouped[section]) grouped[section] = {};
        grouped[section][answer] = (grouped[section][answer] || 0) + 1;
      }

      // console.log("GROUPED =", grouped);

      // --------------------------------------------------
      // BUILD RESULT
      // --------------------------------------------------

      const selectedSection = query.section?.toUpperCase();
      const rdata: Record<string, any[]> = {};

      const buildAnswerArray = (
        data: Record<string, number>,
        total: number
      ) => {
        const options = ['A', 'B', 'C', 'D'];
        return options.map((opt) => ({
          qid: Number(query.qid),
          uanswer: opt,
          canswer: correctAnswer,
          count: data[opt] || 0,
          tval: total > 0 ? (((data[opt] || 0) * 100) / total).toFixed(2) : '0',
        }));
      };

      // ----------------------
      // SELECTED SECTION
      // ----------------------

      if (selectedSection && grouped[selectedSection]) {
        const total = Object.values(grouped[selectedSection]).reduce(
          (a, b) => a + b,
          0
        );
        rdata[selectedSection] = buildAnswerArray(
          grouped[selectedSection],
          total
        );
      } else {
        rdata[selectedSection] = buildAnswerArray({}, 0);
      }

      // ----------------------
      // OTHER SECTIONS
      // ----------------------

      const combined: Record<string, number> = {};

      for (const [section, answers] of Object.entries(grouped)) {
        if (section === selectedSection) continue;

        for (const [ans, count] of Object.entries(answers)) {
          combined[ans] = (combined[ans] || 0) + count;
        }
      }

      const combinedTotal = Object.values(combined).reduce((a, b) => a + b, 0);

      rdata['OTHERS'] = buildAnswerArray(combined, combinedTotal);

      console.log('FINAL AVG =', rdata);

      return rdata;
    } catch (error) {
      console.error('Error in getAvg:', error);
      throw new NotFoundException('Error retrieving questions');
    }
  }

  /* previous getAvg function
  async getAvg(query: any): Promise<any> {
    console.log('getAvg query');
    // console.log('getAvg query', query);
    const questions = await this.questionRepository.findOne({
      where: { id: query.qid, dmlType: 'I' }
      });
      const answerMap: Record<string, string> = {
        A: 'A',
        B: 'B',
        C: 'C',
        D: 'D',
      };
      try {
      const canswer = answerMap[questions?.correctAns?.toLocaleUpperCase() || ''] || '';

    // console.log('query', query);
    const queryBuilder = this.resultRepository
    .createQueryBuilder('result')
    .where(`JSON_CONTAINS(result.questiondata, CAST(:jsonData AS JSON), '$')`)
    .andWhere('result.paperid = :paperid', { paperid: query.paperid })
    .andWhere('result.studentclass = :studentclass', { studentclass: query.class })
    .setParameters({
      jsonData: JSON.stringify({ id: Number(query.qid) }),
    })
    .addOrderBy('result.studentsection', 'ASC')    

  if (query?.section) {
      queryBuilder.andWhere('result.studentsection = :section', { section: query.section });
    }        
  const rows = await queryBuilder.getMany();

  const grouped: Record<string, number> = {};

  for (const row of rows) {
    if (!row.questiondata) continue;

    let questions: any[] = [];
    if (typeof row.questiondata === 'string') {
      questions = JSON.parse(row.questiondata);
    } else if (Array.isArray(row.questiondata)) {
      questions = row.questiondata;
    } else {
      continue;
    }

    const q = questions.find((q: any) => q.id === Number(query.qid));
    if (q && q.answered) {
      const key = `${q.answered}`; // can include more keys if needed
      grouped[key] = (grouped[key] || 0) + 1;
    }
  }
  // console.log('grouped', grouped);
  const allstudent = Object.values(grouped).reduce((a, b) => a + b, 0);

  const result = Object.entries(grouped).map(([uanswer, count]) => {
  const percent: any = ((count * 100) / allstudent)
    .toFixed(2)
    .replace(/[.,]00$/, "");

  return {
    // section: (query.section).toUpperCase(),
    // studentsection,    
    qid: Number(query.qid),
    uanswer,
    canswer: canswer,
    count,
    tval: percent
    };
  });

  const sortedResult = result.sort((a, b) => {
  return a.uanswer.localeCompare(b.uanswer);
});

  const rdata: Record<string, any[]> = {};
  rdata[query.section] = sortedResult;    
  console.log('rdata', rdata);
  
  return rdata ;
  } catch (error) {
    console.error('Error in findQuestions:', error);
    throw new NotFoundException('Error retrieving questions');
  }
}
*/
  async findQuestions(qids: string): Promise<any> {
    if (!qids) {
      throw new NotFoundException('ID is required');
    }
    const ids = qids.split(',').map((id) => parseInt(id, 10));
    if (ids.some(isNaN)) {
      throw new NotFoundException('Invalid question IDs provided');
    }
    console.log('ids', Array.isArray(ids));

    const questions = await this.questionRepository.find({
      where: { id: In(ids), dmlType: 'I' },
    });

    if (!questions || questions.length === 0) {
      throw new NotFoundException('No questions found for this paper');
    }
    return questions;
  }

  async saveAnswer(data: any): Promise<any> {
    const existingUser = await this.answerRepository.find({
      where: {
        paperid: data.answers[0].paperid,
        studentid: data.answers[0].studentid,
      },
    });

    if (existingUser && existingUser.length > 0) {
      return {
        statusCode: 409,
        message: 'Student already answered',
      };
    } else {
      const answer: Answer[] = data.answers.map((a: any) => ({
        paperid: a.paperid,
        studentid: a.studentid,
        class: a.class,
        section: a.section,
        qid: a.qid,
        uanswer: a.uanswer,
        canswer: a.canswer,
        marks: a.marks,
        sequence: a.sequence,
      }));
      const savedAnswers = await this.answerRepository.save(answer);
      if (savedAnswers.length === 0) {
        throw new NotFoundException('Failed to save answers');
      }
      return {
        statusCode: 201,
        message: 'Student answer saved successfully',
      };
    }
  }

  async getStudentAnswered(data: any): Promise<any> {
    // console.log('Incoming data:', data);
    const { paperId, studentid, class: cls, section } = data;
    if (!paperId || !studentid || !cls || !section) {
      return {
        statusCode: 400,
        message: 'Missing required fields',
      };
    }
    const anserCheck = await this.answerRepository.find({
      where: {
        paperid: data.paperId,
        studentid: data.studentid,
        class: data.class,
        section: data.section,
        dmlType: 'I',
      },
    });
    if (anserCheck && anserCheck.length > 0) {
      return {
        statusCode: 409,
        message: 'Student already answered',
      };
    }

    return {
      statusCode: 404,
      message: 'No answers found for the student',
    };
  }

  async getStudentAnsweredCheck(data: any): Promise<any> {
    const anserCheck = await this.answerRepository
      .createQueryBuilder('answer')
      .select('answer.studentid', 'id')
      .where('answer.paperid = :paperid', { paperid: data.paperId })
      .andWhere('answer.dmlType = :dmlType', { dmlType: 'I' })
      .groupBy('answer.studentid')
      .getRawMany();

    return anserCheck;
  }

  async getAnalytics(paperId: string, cls: string, section?: string) {

  const params: any[] = [paperId, cls];
  let sectionFilter = "";

  const isAllSection = !section || section === "ALL";

  if (!isAllSection) {
    sectionFilter = "AND sqr.section = ?";
    params.push(section);
  }

  // 🔁 Helper: group into multi-bar datasets
  const groupBySection = (rows: any[], labelKey: string, valueKey: string) => {

    const labelsSet = new Set<string>();
    const sectionMap: Record<string, Record<string, number>> = {};

    rows.forEach(r => {

      const sec = isAllSection ? r.section : (section as string);

      labelsSet.add(String(r[labelKey]));

      if (!sectionMap[sec]) {
        sectionMap[sec] = {};
      }

      sectionMap[sec][r[labelKey]] = Number(r[valueKey]);
    });

    const labels = Array.from(labelsSet);

    const datasets = Object.keys(sectionMap).map(sec => ({
      label: sec,
      data: labels.map(l => sectionMap[sec][l] || 0)
    }));

    return { labels, datasets };
  };

  // =========================
  // 1️⃣ Section Performance
  // =========================
  const sectionPerformance = await this.dataSource.query(
    `
    SELECT sqr.section,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.section
    `,
    params
  );

  // =========================
  // 2️⃣ Subject Performance (UPDATED)
  // =========================
  const subjectRows = await this.dataSource.query(
    `
    SELECT sqr.section, sqr.subject,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.section, sqr.subject
    `,
    params
  );

  const subjectChart = groupBySection(subjectRows, "subject", "avg");

  // =========================
  // 3️⃣ Question Type (UPDATED)
  // =========================
  const typeRows = await this.dataSource.query(
    `
    SELECT sqr.section, sqr.questionType AS type,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.section, sqr.questionType
    `,
    params
  );

  const questionTypeChart = groupBySection(typeRows, "type", "avg");

  // =========================
  // 4️⃣ Question Difficulty (UPDATED)
  // =========================
  const difficultyRows = await this.dataSource.query(
    `
    SELECT sqr.section, sqr.qid,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS accuracy
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.section, sqr.qid
    ORDER BY sqr.qid
    `,
    params
  );

  const difficultyChart = groupBySection(difficultyRows, "qid", "accuracy");

  // =========================
  // 5️⃣ Score Distribution (UPDATED MULTI-SECTION)
  // =========================
  let studentParams: any[] = [paperId, cls];
  let studentSectionFilter = "";

  if (!isAllSection) {
    studentSectionFilter = "AND sr.section = ?";
    studentParams.push(section);
  }

  const distributionRows = await this.dataSource.query(
    `
    SELECT sr.section, sr.percentage
    FROM studentresult sr
    WHERE sr.paperid = ?
    AND sr.class = ?
    ${studentSectionFilter}
    `,
    studentParams
  );

  const buckets = ["0-20", "21-40", "41-60", "61-80", "81-100"];
  const sectionMap: Record<string, number[]> = {};

  distributionRows.forEach(r => {

    const sec = isAllSection ? r.section : (section as string);

    if (!sectionMap[sec]) {
      sectionMap[sec] = [0, 0, 0, 0, 0];
    }

    const p = Number(r.percentage);

    if (p <= 20) sectionMap[sec][0]++;
    else if (p <= 40) sectionMap[sec][1]++;
    else if (p <= 60) sectionMap[sec][2]++;
    else if (p <= 80) sectionMap[sec][3]++;
    else sectionMap[sec][4]++;
  });

  const scoreDistribution = {
    labels: buckets,
    datasets: Object.keys(sectionMap).map(sec => ({
      label: sec,
      data: sectionMap[sec]
    }))
  };

  // =========================
  // 6️⃣ Top Students (UNCHANGED)
  // =========================
  const topStudents = await this.dataSource.query(
    `
    SELECT 
      st.name AS name,
      st.rollNo AS rollno,
      sr.percentage AS percentage,
      sr.grade AS grade,
      sr.section
    FROM studentresult sr
    LEFT JOIN studentinformation st
    ON sr.studentid = st.studentId
    WHERE sr.paperid = ?
    AND sr.class = ?
    ${studentSectionFilter}
    ORDER BY sr.percentage DESC
    LIMIT 10
    `,
    studentParams
  );

  // =========================
  // 7️⃣ MCQ Distribution (UNCHANGED)
  // =========================
  const mcqDistribution = await this.dataSource.query(
    `
    SELECT 
      sqr.section,
      sqr.qid,
      sqr.studentAnswer,
      COUNT(*) as count
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    AND sqr.questionType IN ('multipleChoice','truefalse','oneword')
    ${sectionFilter}
    GROUP BY sqr.section, sqr.qid, sqr.studentAnswer
    `,
    params
  );
  // =========================
  // 8 Student Performance 
  // =========================
  const bandRows = await this.dataSource.query(
  `
  SELECT 
    t.section,
    t.band,
    COUNT(*) AS count
  FROM (
    SELECT 
      sr.section,
      CASE 
        WHEN sr.percentage >= 81 THEN 'excellent'
        WHEN sr.percentage >= 61 THEN 'sufficient'
        WHEN sr.percentage >= 41 THEN 'adequate'
        ELSE 'need improvement'
      END AS band
    FROM studentresult sr
    WHERE sr.paperid = ?
    AND sr.class = ?
    ${studentSectionFilter}
  ) t
  GROUP BY t.section, t.band
  `,
  studentParams
);
const sections = [...new Set(bandRows.map(r => r.section))];

const bandLabels = [
  "need improvement",
  "adequate",
  "sufficient",
  "excellent",
];

const datasets = bandLabels.map(label => ({
  label: label,
  data: sections.map(section => {
    const rows = bandRows.filter(r => r.section === section);
    const total = rows.reduce((sum, r) => sum + Number(r.count), 0);

    const found = rows.find(r => r.band === label);
    const value = found ? (found.count / total) * 100 : 0;

    return Number(value.toFixed(2));
  }),
}));

const performanceBandChart = {
  labels: sections,
  datasets,
};
  // =========================
  // FINAL RESPONSE
  // =========================
  return {
    sectionPerformance, // simple bar
    subjectChart,       // multi-bar
    questionTypeChart,  // multi-bar
    difficultyChart,    // multi-bar
    scoreDistribution,  // multi-bar
    topStudents,
    mcqDistribution,
    performanceBandChart
  };
}

  async getAnalytics_bk(paperId: string, cls: string, section?: string) {
//  console.log('paperId:',paperId, 'cls:',cls, 'section:',section)
  const params: any[] = [paperId, cls];
  let sectionFilter = "";

  if (section && section !== "ALL") {
    sectionFilter = "AND sqr.section = ?";
    params.push(section);
  }
  // console.log('sectionFilter = ',sectionFilter, 'params= ', params)

  // 1️⃣ Section Performance
  const sectionPerformance = await this.dataSource.query(
    `
    SELECT sqr.section,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.section
    `,
    params
  );

  // 2️⃣ Subject Performance
  const subjectPerformance = await this.dataSource.query(
    `
    SELECT sqr.subject,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.subject
    `,
    params
  );

  // 3️⃣ Question Type Performance
  const questionTypePerformance = await this.dataSource.query(
    `
    SELECT sqr.questionType AS type,
    ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS avg
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.questionType
    `,
    params
  );

  // 4️⃣ Question Difficulty (Accuracy)
  const questionDifficulty = await this.dataSource.query(
    `
    SELECT 
      sqr.qid,
      ROUND(AVG((sqr.score / sqr.maxScore) * 100), 2) AS accuracy
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    ${sectionFilter}
    GROUP BY sqr.qid
    ORDER BY sqr.qid
    `,
    params
  );

  // 5️⃣ Score Distribution (from student_result)
  let studentParams: any[] = [paperId, cls];
  let studentSectionFilter = "";

  if (section && section !== "ALL") {
    studentSectionFilter = "AND sr.section = ?";
    studentParams.push(section);
  }
// console.log('studentSectionFilter = ',studentSectionFilter, 'studentParams= ', studentParams)
  const students = await this.dataSource.query(
    `
    SELECT sr.percentage AS percentage
    FROM studentresult sr
    WHERE sr.paperid = ?
    AND sr.class = ?
    ${studentSectionFilter}
    `,
    studentParams
  );

  // Buckets
  const buckets = [0, 0, 0, 0, 0];

  for (const s of students) {
    const p = Number(s.percentage);

    if (p <= 20) buckets[0]++;
    else if (p <= 40) buckets[1]++;
    else if (p <= 60) buckets[2]++;
    else if (p <= 80) buckets[3]++;
    else buckets[4]++;
  }

  const scoreDistribution = {
    labels: ["0-20", "21-40", "41-60", "61-80", "81-100"],
    values: buckets,
  };

  // 6️⃣ Top Students
  const topStudents = await this.dataSource.query(
    `
    SELECT 
      st.name AS name,
      st.rollNo AS rollno,
      sr.percentage AS percentage,
      sr.grade AS grade
    FROM studentresult sr
    LEFT JOIN studentinformation st
    ON sr.studentid = st.studentId
    WHERE sr.paperid = ?
    AND sr.class = ?
    ${studentSectionFilter}
    ORDER BY sr.percentage DESC
    LIMIT 10
    `,
    studentParams
  );

  // 7️⃣ MCQ Answer Distribution (Optional Advanced)
  const mcqDistribution = await this.dataSource.query(
    `
    SELECT 
      sqr.qid,
      sqr.studentAnswer,
      COUNT(*) as count
    FROM studentquestionresult sqr
    WHERE sqr.paperid = ?
    AND sqr.class = ?
    AND sqr.questionType IN ('multipleChoice','truefalse','oneword')
    ${sectionFilter}
    GROUP BY sqr.qid, sqr.studentanswer
    `,
    params
  );

  return {
    sectionPerformance,
    subjectPerformance,
    questionTypePerformance,
    questionDifficulty,
    scoreDistribution,
    topStudents,
    mcqDistribution
  };
}
/*
async getPrincipalAnalytics(params: any) {
    const { paperid, cls, level, section, subject } = params;

    // =========================
    // LEVEL 1 → SECTION AVG
    // =========================
    if (level === 'overall') {
      const rows = await this.dataSource.query(
        `
        SELECT section, avgPercentage
        FROM studentsectionsummary
        WHERE paperid = ? AND class = ?
        ORDER BY section
        `,
        [paperid, cls]
      );

      return {
        labels: rows.map(r => r.section),
        datasets: [
          {
            label: 'Section Average %',
            data: rows.map(r => Number(r.avgPercentage))
          }
        ]
      };
    }

    // =========================
    // LEVEL 2 → SUBJECT AVG (BY SECTION)
    // =========================
    if (level === 'section' && section) {
      const rows = await this.dataSource.query(
        `
        SELECT subdomain, avgPercentage
        FROM studentsubjectsummary
        WHERE paperid = ? AND class = ? AND section = ?
        ORDER BY subdomain
        `,
        [paperid, cls, section]
      );

      return {
        labels: rows.map(r => r.subdomain),
        datasets: [
          {
            label: `${section} - Subject Average %`,
            data: rows.map(r => Number(r.avgPercentage))
          }
        ]
      };
    }

    // =========================
    // LEVEL 3 → STUDENT LIST (OPTIONAL)
    // =========================
    if (level === 'subject' && section && subject) {
      const rows = await this.dataSource.query(
        `
        SELECT 
          sr.studentid,
          si.Name as studentname,
          ssr.percentage
        FROM studentsubdomainresult ssr
        JOIN studentinformation si ON si.Id = ssr.studentid
        JOIN studentresult sr ON sr.studentid = ssr.studentid AND sr.paperid = ssr.paperid
        WHERE ssr.paperid = ? 
          AND ssr.class = ?
          AND ssr.section = ?
          AND ssr.subdomain = ?
        ORDER BY ssr.percentage DESC
        `,
        [paperid, cls, section, subject]
      );

      return {
        labels: rows.map(r => r.studentname),
        datasets: [
          {
            label: `${subject} - Student Performance`,
            data: rows.map(r => Number(r.percentage))
          }
        ]
      };
    }

    return {
      labels: [],
      datasets: []
    };
  }
    */
/*
  async getPrincipalAnalytics(params: any) {
  const { paperid, cls, level, section, subject } = params;

  // =========================
  // LEVEL 1 → OVERALL (SECTION AVG + KPI)
  // =========================
  if (level === 'overall') {

    // Section chart data
    const rows = await this.dataSource.query(
      `
      SELECT section, avgPercentage
      FROM studentsectionsummary
      WHERE paperid = ? AND class = ?
      ORDER BY section
      `,
      [paperid, cls]
    );

    // KPI → total students + avg %
    const kpiResult = await this.dataSource.query(
      `
      SELECT 
        COUNT(*) as totalStudents,
        ROUND(AVG(percentage),2) as avgPercentage
      FROM studentresult
      WHERE paperid = ? AND class = ?
      `,
      [paperid, cls]
    );

    // KPI → section ranking
    const sectionStats = await this.dataSource.query(
      `
      SELECT section, avgPercentage
      FROM studentsectionsummary
      WHERE paperid = ? AND class = ?
      `,
      [paperid, cls]
    );

    let topSection = null;
    let weakSection = null;

    if (sectionStats.length > 0) {
      const sorted = sectionStats.sort(
        (a, b) => Number(b.avgPercentage) - Number(a.avgPercentage)
      );

      topSection = sorted[0]?.section || null;
      weakSection = sorted[sorted.length - 1]?.section || null;
    }

    return {
      labels: rows.map(r => r.section),
      datasets: [
        {
          label: 'Section Average %',
          data: rows.map(r => Number(r.avgPercentage))
        }
      ],
      kpis: {
        totalStudents: Number(kpiResult[0]?.totalStudents || 0),
        avgPercentage: Number(kpiResult[0]?.avgPercentage || 0),
        topSection,
        weakSection
      }
    };
  }

  // =========================
  // LEVEL 2 → SECTION (SUBJECT AVG)
  // =========================
  if (level === 'section' && section) {

    const rows = await this.dataSource.query(
      `
      SELECT subdomain, avgPercentage
      FROM studentsubjectsummary
      WHERE paperid = ? AND class = ? AND section = ?
      ORDER BY subdomain
      `,
      [paperid, cls, section]
    );

    return {
      labels: rows.map(r => r.subdomain),
      datasets: [
        {
          label: `${section} - Subject Average %`,
          data: rows.map(r => Number(r.avgPercentage))
        }
      ]
    };
  }

  // =========================
  // LEVEL 3 → SUBJECT (STUDENT PERFORMANCE)
  // =========================
  if (level === 'subject' && section && subject) {

    const rows = await this.dataSource.query(
      `
      SELECT 
        si.Name AS studentname,
        ssr.percentage
      FROM studentsubdomainresult ssr
      JOIN studentinformation si ON si.Id = ssr.studentid
      WHERE ssr.paperid = ?
        AND ssr.class = ?
        AND ssr.section = ?
        AND ssr.subdomain = ?
      ORDER BY ssr.percentage DESC
      `,
      [paperid, cls, section, subject]
    );

    return {
      labels: rows.map(r => r.studentname),
      datasets: [
        {
          label: `${subject} - Student Performance`,
          data: rows.map(r => Number(r.percentage))
        }
      ]
    };
  }

  // =========================
  // DEFAULT FALLBACK
  // =========================
  return {
    labels: [],
    datasets: []
  };
}
  */

async getPrincipalAnalytics(paperid: number, cls: string) {
  return this.dataSource.transaction(async (manager) => {

    // ================= SECTION SUMMARY =================
    const sectionRows = await manager
      .createQueryBuilder()
      .select("s.section", "section")
      .addSelect("s.avgPercentage", "avgPercentage")
      .addSelect("s.avgMarks", "avgMarks")
      .addSelect("s.studentCount", "studentCount")
      .from("studentsectionsummary", "s")
      .where("s.paperid = :paperid", { paperid })
      .andWhere("s.class = :cls", { cls })
      .orderBy("s.section", "ASC")
      .getRawMany();

    // ===== KPI =====
    const totalStudents = sectionRows.reduce(
      (sum, r) => sum + Number(r.studentCount), 0
    );

    const totalMarksWeighted = sectionRows.reduce(
      (sum, r) => sum + (Number(r.avgPercentage) * Number(r.studentCount)),
      0
    );

    const avgPercentage = totalStudents
      ? Number((totalMarksWeighted / totalStudents).toFixed(2))
      : 0;

    const sorted = [...sectionRows].sort(
      (a, b) => Number(b.avgPercentage) - Number(a.avgPercentage)
    );

    const topSection = sorted[0]?.section || null;
    const weakSection = sorted[sorted.length - 1]?.section || null;

    // ================= BLOOM SUMMARY =================
    const bloomRows = await manager
      .createQueryBuilder()
      .select("b.section", "section")
      .addSelect("b.bloomLevel", "bloomLevel")
      .addSelect("b.obtainedMarks", "obtained")
      .addSelect("b.maxMarks", "max")
      .from("bloomsummary", "b")
      .where("b.paperid = :paperid", { paperid })
      .andWhere("b.class = :cls", { cls })
      .getRawMany();

    const sections = [...new Set(bloomRows.map(r => r.section))];
    const blooms = [...new Set(bloomRows.map(r => r.bloomLevel))];

    // total per section for 100% stacked
    const sectionTotals: any = {};
    bloomRows.forEach(r => {
      sectionTotals[r.section] =
        (sectionTotals[r.section] || 0) + Number(r.obtained);
    });

    const bloomChart = {
      labels: sections,
      datasets: blooms.map(b => ({
        label: b,
        data: sections.map(sec => {
          const row = bloomRows.find(
            r => r.section === sec && r.bloomLevel === b
          );
          if (!row) return 0;

          return Number(
            ((Number(row.obtained) * 100) / sectionTotals[sec]).toFixed(2)
          );
        })
      }))
    };

    // ================= SUBDOMAIN SUMMARY =================
    const subRows = await manager
      .createQueryBuilder()
      .select("s.section", "section")
      .addSelect("s.subdomain", "subdomain")
      .addSelect("s.avgPercentage", "avgPercentage")
      .addSelect("s.avgMarks", "avgMarks")
      .from("studentsubjectsummary", "s")
      .where("s.paperid = :paperid", { paperid })
      .andWhere("s.class = :cls", { cls })
      .orderBy("s.section", "ASC")
      .getRawMany();

    // ================= RESPONSE =================
    return {

      // ===== KPI =====
      kpis: {
        totalStudents,
        avgPercentage,
        topSection,
        weakSection
      },

      // ===== SECTION CHART =====
      sectionChart: {
        labels: sectionRows.map(r => r.section),
        datasets: [
          {
            label: "Section Avg %",
            data: sectionRows.map(r => Number(r.avgPercentage))
          }
        ]
      },

      // ===== SECTION TABLE =====
      sectionTable: sectionRows.map(r => ({
        section: r.section,
        students: Number(r.studentCount),
        avgMarks: Number(r.avgMarks),
        percentage: Number(r.avgPercentage)
      })),

      // ===== BLOOM CHART (100% STACKED) =====
      bloomChart,

      // ===== BLOOM TABLE =====
      bloomTable: bloomRows.map(r => ({
        section: r.section,
        bloomLevel: r.bloomLevel,
        obtainedMarks: Number(r.obtained),
        maxMarks: Number(r.max),
        percentage: Number(
          ((Number(r.obtained) * 100) / Number(r.max)).toFixed(2)
        )
      })),

      // ===== SUBDOMAIN TABLE =====
      subdomainTable: subRows.map(r => ({
        section: r.section,
        subdomain: r.subdomain,
        avgMarks: Number(r.avgMarks),
        percentage: Number(r.avgPercentage)
      }))
    };
  });
}

}
