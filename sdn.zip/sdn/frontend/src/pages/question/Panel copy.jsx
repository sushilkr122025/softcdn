import { useEffect, useRef, useState } from "react";
import './Panel.css';
import socketClient from '../../api/socket';
import { BsFillChatSquareTextFill } from "react-icons/bs";
import { IoSend, IoReturnDownBack } from "react-icons/io5";
import { SlOptionsVertical } from "react-icons/sl";
import chatBg from "../../assets/images/chat-bg.jpg";

const Panel = ()=> {
  const mkMsg = (sender, text, date = new Date(), opts = {}) => ({
    id: `${date.getTime()}-${Math.floor(Math.random() * 10000)}`,
    sender,
    text,
    time: date.toISOString(),
    delivered: opts.delivered ?? true,
    readBy: opts.readBy ?? [],
    replyToId: opts.replyToId ?? null,
  });

  const [onlineUsers, setOnlineUsers] = useState(["himani"]);
  const [messages, setMessages] = useState([
    mkMsg("himani", "Hi everyone!", new Date(Date.now() - 1000 * 60 * 60 * 24 * 2)),
    mkMsg("Redbul", "Hey himani", new Date(Date.now() - 1000 * 60 * 60 * 24)),
    mkMsg("alex", "Let's meet at 6pm", new Date()),
    mkMsg("aayu", "Hey himani", new Date()),
  ]);

  const [selectedMessageId, setSelectedMessageId] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const [searchActive, setSearchActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showInfo, setShowInfo] = useState(false);
  const currentUser = "You";
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [pinnedMessage, setPinnedMessage] = useState(null);
  const [unseenCount, setUnseenCount] = useState(0);
  const messagesContainerRef = useRef(null);
  const lastMessageRef = useRef(null);

  // reply state & composer ref
  const [replyTo, setReplyTo] = useState(null);
  const composerInputRef = useRef(null);

  // format time
  const formatTime = (iso) => {
    try {
      const d = new Date(iso);
      return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(d);
    } catch (e) {
      return "";
    }
  };

  const sameDay = (isoA, isoB) => {
    if (!isoA || !isoB) return false;
    const a = new Date(isoA);
    const b = new Date(isoB);
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  };

  const dateHeaderLabel = (iso) => {
    const d = new Date(iso);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (sameDay(iso, today.toISOString())) return "Today";
    if (sameDay(iso, yesterday.toISOString())) return "Yesterday";

    return new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(d);
  };

  useEffect(() => {
    // normalize incoming messages
    setMessages((prev) =>
      prev.map((m) => ({
        id: m.id || `${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        sender: m.sender ?? "Unknown",
        text: m.text ?? "",
        time: m.time ?? new Date().toISOString(),
        delivered: typeof m.delivered === "boolean" ? m.delivered : true,
        readBy: Array.isArray(m.readBy) ? m.readBy : [],
        replyToId: m.replyToId ?? null,
      }))
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setUnseenCount((prev) => prev + 1);
    }, 2000);
    const timeout = setTimeout(() => clearInterval(interval), 4000);
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  // Auto-scroll
  useEffect(() => {
    if (!messagesContainerRef.current) return;
    const container = messagesContainerRef.current;
    requestAnimationFrame(() => {
      if (lastMessageRef.current) {
        lastMessageRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
      } else {
        container.scrollTop = container.scrollHeight;
      }
    });
  }, [messages, searchQuery]);

  const findMessageIndexById = (id) => messages.findIndex((m) => m.id === id);

  const handleSendMessage = () => {
    if (newMessage.trim() === "") return;
    const msg = {
      id: `${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      sender: currentUser,
      text: newMessage,
      time: new Date().toISOString(),
      delivered: false,
      readBy: [],
      replyToId: replyTo?.id ?? null,
    };

    setMessages((prev) => [...prev, msg]);
    setOnlineUsers((prev) => (prev.includes(currentUser) ? prev : [...prev, currentUser]));
    setNewMessage("");
    setSelectedMessageId(null);
    setOpen(false);
    setReplyTo(null);

    setTimeout(() => {
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? { ...m, delivered: true } : m)));
    }, 700);
    setTimeout(() => {
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? { ...m, readBy: ["himani"] } : m)));
    }, 1800);
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") handleSendMessage();
  };

  const handleDeleteMessage = () => {
    if (!selectedMessageId) {
      alert("Please select a message first.");
      setOpen(false);
      return;
    }
    const msg = messages.find((m) => m.id === selectedMessageId);
    if (!msg) {
      alert("Message not found.");
      setOpen(false);
      return;
    }
    // NEW: only allow deleting messages sent by the current user
    if (msg.sender !== currentUser) {
      alert("You can only delete your own messages.");
      setOpen(false);
      return;
    }
    // confirm before deleting
    if (!window.confirm("Delete this message?")) {
      setOpen(false);
      return;
    }
    setMessages((prev) => prev.filter((m) => m.id !== selectedMessageId));
    setSelectedMessageId(null);
    setShowInfo(false);
    setOpen(false);
  };

  const handleEditMessage = () => {
    if (!selectedMessageId) {
      alert("Please select a message first.");
      setOpen(false);
      return;
    }
    const idx = findMessageIndexById(selectedMessageId);
    if (idx === -1) {
      alert("Message not found.");
      setOpen(false);
      return;
    }
    const msg = messages[idx];
    if (msg.sender !== currentUser) {
      alert("You can only edit your own messages.");
      setOpen(false);
      return;
    }
    setEditingId(selectedMessageId);
    setEditText(msg.text);
    setOpen(false);
  };

  const handlePinMessage = () => {
    if (!selectedMessageId) {
      alert("Please select a message first.");
      setOpen(false);
      return;
    }
    const msg = messages.find((m) => m.id === selectedMessageId);
    setPinnedMessage(msg || null);
    setOpen(false);
  };

  const handleSaveEdit = () => {
    if (!editingId) return;
    setMessages((prev) =>
      prev.map((m) => (m.id === editingId ? { ...m, text: editText + (m.text.includes("(edited)") ? "" : " (edited)") } : m))
    );
    setEditingId(null);
    setEditText("");
  };

  const handleSearch = () => {
    setSearchActive((prev) => !prev);
    if (searchActive) setSearchQuery("");
    setOpen(false);
  };

  const handleInfo = () => {
    if (selectedMessageId !== null) {
      setShowInfo(true);
    } else {
      alert("Please select a message first.");
    }
    setOpen(false);
  };

  const handleCopy = async () => {
    if (!selectedMessageId) {
      setOpen(false);
      return;
    }
    const text = messages.find((m) => m.id === selectedMessageId)?.text ?? "";
    if (!text) {
      setOpen(false);
      return;
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "absolute";
        ta.style.left = "-9999px";
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
    } catch (err) {
      console.error("Copy failed", err);
    } finally {
      setOpen(false);
    }
  };

  const filteredMessages = messages.filter((msg) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return msg.text.toLowerCase().includes(q) || msg.sender.toLowerCase().includes(q);
  });

  const handleMessageClick = (id) => {
    setSelectedMessageId((prev) => (prev === id ? null : id));
  };

  const getTickState = (m) => {
    if (m.sender !== currentUser) return null;
    if (!m.delivered) return "sent";
    if (m.readBy?.length > 0) return "read";
    return "delivered";
  };

  // Reply handler
  const handleReply = (msg) => {
    setReplyTo(msg);
    setTimeout(() => composerInputRef.current?.focus?.(), 0);
  };

  return (
    <>
      <div
        style={{
          position: "fixed",
          right: 0,
          top: 102,
          bottom: 0,
          width: 300,
          maxWidth: "300px",
          display: "flex",
          flexDirection: "column",
          borderLeft: "1px solid #dee2e6",
          zIndex: 9999,
          backgroundImage: `url(${chatBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "repeat",
          backgroundColor: "rgba(255,255,255,0.8)",
          backgroundBlendMode: "overlay",
        }}
      >
        {/* Header */}
        <div className="d-flex justify-content-between align-items-center p-3 bg-primary text-white fw-bold">
          <div className="position-relative d-inline-flex align-items-center">
            <BsFillChatSquareTextFill size={20} />
            {unseenCount > 0 && (
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                {unseenCount}
              </span>
            )}
          </div>

          <div className="position-relative" ref={menuRef}>
            <span role="button" className="p-1" onClick={() => setOpen(!open)}>
              <SlOptionsVertical size={20} />
            </span>

            {open && (
              <div className="position-absolute end-0 mt-2 bg-white text-dark shadow rounded z-1">
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={selectedMessageId === null ? undefined : handleCopy}>
                  copy
                </div>
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={handleEditMessage}>edit</div>
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={handlePinMessage}>pin</div>
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={handleInfo}>info</div>
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={handleSearch}>search</div>
                <div className="px-3 py-1 border-bottom menu-item cursor-pointer" onClick={handleDeleteMessage}>delete</div>
              </div>
            )}
          </div>
        </div>

        {/* Pinned message */}
        {pinnedMessage && (
          <div className="bg-warning bg-opacity-25 border-bottom px-2 py-1 d-flex justify-content-between align-items-center">
            <div>
              <small className="fw-bold">{pinnedMessage.sender}:</small>{" "}
              <span>{pinnedMessage.text}</span>
            </div>
            <button className="btn-close ms-2" onClick={() => setPinnedMessage(null)} />
          </div>
        )}

        {/* Search */}
        {searchActive && (
          <div className="position-relative ">
            <input type="text" className="form-control rounded-0" placeholder="Search chats..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            <button type="button" className="btn-close position-absolute" aria-label="Close" onClick={() => { if (searchQuery) setSearchQuery(""); else setSearchActive(false); }} style={{ right: "0.75rem", top: "50%", transform: "translateY(-50%)", border: "none", fontSize: "13px" }} />
          </div>
        )}

        {/* Messages area */}
        <div ref={messagesContainerRef} style={{ flex: 1, overflowY: "auto", padding: "0 0.5rem 0 0.5rem" }}>
          {filteredMessages.map((msg, idx) => {
            const isSelected = msg.id === selectedMessageId;
            const showDateHeader = idx === 0 || !sameDay(msg.time, filteredMessages[idx - 1]?.time);
            const tickState = getTickState(msg);
            const isLast = idx === filteredMessages.length - 1;
            const original = msg.replyToId ? messages.find((m) => m.id === msg.replyToId) : null;
            const isMine = msg.sender === currentUser;

            return (
              <div key={msg.id}>
                {showDateHeader && (
                  <div className="text-center ">
                    <small className="p-1">{dateHeaderLabel(msg.time)}</small>
                  </div>
                )}

                {/* chat-row wraps the outside icon + bubble */}
                <div
                  className={`chat-row d-flex ${isMine ? "justify-content-end" : "justify-content-start"}`}
                  onClick={() => handleMessageClick(msg.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === "Enter") handleMessageClick(msg.id); }}
                >
                  {/* For sent (isMine): icon left, then bubble */}
                  {isMine && (
                    <button
                      className="reply-btn-outside left"
                      onClick={(e) => { e.stopPropagation(); handleReply(msg); }}
                      aria-label={`Reply to ${msg.sender}`}
                      title={`Reply to ${msg.sender}`}
                    >
                      <IoReturnDownBack size={16} />
                    </button>
                  )}

                  {/* bubble */}
                  <div ref={isLast ? lastMessageRef : null} className={`chat-bubble ${isMine ? "sent" : "received"} ${isSelected ? "selected" : ""}`} title={msg.sender}>
                    <div className="header">
                      <a className="phone" href={`tel:${msg.sender}`} onClick={(e) => e.stopPropagation()}>{msg.sender}</a>
                      {msg.alias && <span className="alias">—{msg.alias}</span>}
                    </div>

                    {msg.replyToId && original && (
                      <div className="small-reply-quote">
                        <strong style={{ fontSize: 12 }}>{original.sender}:</strong>{" "}
                        <span title={original.text}>{original.text}</span>
                      </div>
                    )}

                    {editingId === msg.id ? (
                      <div>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={editText}
                          onChange={(e) => setEditText(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") handleSaveEdit();
                            if (e.key === "Escape") {
                              setEditingId(null);
                              setEditText("");
                            }
                          }}
                          autoFocus
                        />
                        <div className="mt-2">
                          <button className="btn btn-sm btn-success me-1" onClick={handleSaveEdit}>Save</button>
                          <button className="btn btn-sm btn-secondary" onClick={() => { setEditingId(null); setEditText(""); }}>Cancel</button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="body">{msg.text}</div>

                        <div className="meta">
                          <small>{formatTime(msg.time)}</small>
                          {tickState && (
                            <span className={`tick ${tickState}`} aria-hidden style={{ marginLeft: 6 }}>
                              {tickState === "sent" && (
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M20 6L9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              )}

                              {tickState === "delivered" && (
                                <svg width="18" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M1 13l4 4L11 11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                  <path d="M9 13l4 4L23 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              )}

                              {tickState === "read" && (
                                <svg width="18" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <path d="M1 13l4 4L11 11" stroke="#0b93f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                  <path d="M9 13l4 4L23 7" stroke="#0b93f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                              )}
                            </span>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  {/* For received messages: icon right, after bubble */}
                  {!isMine && (
                    <button
                      className="reply-btn-outside right"
                      onClick={(e) => { e.stopPropagation(); handleReply(msg); }}
                      aria-label={`Reply to ${msg.sender}`}
                      title={`Reply to ${msg.sender}`}
                    >
                      <IoReturnDownBack size={16} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Info popup */}
        {showInfo && selectedMessageId && (
          <div className="border rounded bg-white shadow p-3 m-2 position-absolute top-0 end-0 " style={{ zIndex: 10000 }}>
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h6 className="mb-0">Message Info</h6>
              <button type="button" className="btn-close" onClick={() => setShowInfo(false)} />
            </div>
            <p><strong>Message:</strong> {messages.find((m) => m.id === selectedMessageId)?.text}</p>
            <p><strong>Sender:</strong> {messages.find((m) => m.id === selectedMessageId)?.sender}</p>
            <p><strong>Time & Date:</strong> {new Date(messages.find((m) => m.id === selectedMessageId)?.time ?? "").toLocaleString()}</p>
            <p><strong>Delivered:</strong> {messages.find((m) => m.id === selectedMessageId)?.delivered ? "Yes" : "No"}</p>
            <p><strong>Read By:</strong></p>
            <ul className="mb-0">
              {messages.find((m) => m.id === selectedMessageId)?.readBy?.length > 0 ? (
                messages.find((m) => m.id === selectedMessageId).readBy.map((u, i) => (
                  <li key={i}>{u}</li>
                ))
              ) : (
                <li>No one yet</li>
              )}
            </ul>
          </div>
        )}

        {/* Reply preview */}
        {replyTo && (
          <div className="reply-preview">
            <div>
              <small className="text-muted">Replying to <strong>{replyTo.sender}</strong></small>
              <div className="snippet" title={replyTo.text}>{replyTo.text}</div>
            </div>
            <div>
              <button className="btn-close" aria-label="Cancel reply" onClick={() => setReplyTo(null)} />
            </div>
          </div>
        )}

        {/* Composer */}
        <div className="p-2 d-flex" style={{ flex: "0 0 auto" }}>
          <input
            ref={composerInputRef}
            type="text"
            className="form-control me-2"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <button className="btn border btn-primary pt-1" onClick={handleSendMessage}>
            <IoSend size={20} />
          </button>
        </div>
      </div>
    </>
  );
}

export default Panel;
