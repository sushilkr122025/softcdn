import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import './SectionReport.css'
import MultiServices from '../../api/MultiServices'

const Reportcard = () => {
  const [sparams] = useSearchParams()
  const [repdata, setRepdata] = useState()
  const [paper, setPaper] = useState()
  const studentid = sparams.get('studentid')
  let clsection = sparams.get('section')
  const handlereport = async () => {
    const response = await MultiServices.StudentReport({
      params: {
        studentid: studentid,
        section: clsection,
        class: 7,
      },
    })
    console.log(response);
    
    setRepdata(response.data)
    setPaper(response.paper)
  }

  useEffect(() => {
    handlereport()
  }, [])

  return (
    <div className="container-fluid col-6 offset-3 bg-warning p-4">
      {repdata &&
        repdata.map((pitem, pindex) => {
          return (
            <div key={pindex} className="m-4 shadow mb-5 rounded">
              <div className="tabletitle d-flex p-2 bg-white">
                <span className="flex-fill">{pitem.studentname}</span>
                <span className="flex-fill text-end">Class:7 | Roll No.: {pitem.rollno}</span>
              </div>
              <table className="table table-bordered bg-white">
                <thead>
                  <tr>
                    <th>Subject</th>
                    <th>Question</th>
                    <th>Correct</th>
                    <th>Incorrect</th>
                    <th>Grade</th>
                    <th>%</th>
                  </tr>
                </thead>
                <tbody>
                  {pitem.data.map((item, index) => (
                    <tr key={index}>
                      <td>{paper[index].subject}</td>
                      <td>{item.correct + item.incorrect}</td>
                      <td>{item.correct}</td>
                      <td>{item.incorrect}</td>
                      <td>{item.subgrade}</td>
                      <td>{item.percorrect}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        })}
    </div>
  )
}

export default Reportcard
