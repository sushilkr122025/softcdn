import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import { FaLock, FaUser } from 'react-icons/fa'
import loginimage from '../assets/images/login-page.png'
// import { isMobile, isTablet, isBrowser, isAndroid, isIOS } from 'react-device-detect'
// import useAuth from '../context/AuthContext'
import useCompany from '../context/CompanyContext'
import { loginUser } from '../api/authService'

const Login = () => {
  // const { login } = useAuth()
  const { school } = useCompany();
  const navigator = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  let imgdbsrc = school?.schoollogo ? `http://localhost:8081/assets/${school.schoollogo}` : null; // Placeholder for image source coming form database`${config.imageurl}/assets/default/${school?.schoollogo}`; // Placeholder for image source coming form database
    const imgsrc = imgdbsrc ||'/sansol.jpg' ;
  const [errors, setErrors] = useState({})

  const validate = () => {
    const newErrors = {}

    if (!email.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Invalid email format'
    }

    if (!password) {
      newErrors.password = 'Password is required'
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters'
    }

    return newErrors
  }
  const handleSubmit = async (e) => {
    e.preventDefault()

    const validationErrors = validate()
    setErrors(validationErrors)

    if (Object.values(validationErrors).length === 0) {
      try {
        const response = await loginUser(email, password)
        if (response) {
          localStorage.setItem('logged', true)
          navigator('/dashboard')
        } else {
          console.log('login failed')
        }
      } catch (err) {
        console.error('Login error:', err)
      }
    }
  }
  return (
    <div className="container-fluid  login-page min-vh-100 bg-light d-flex align-items-center">
      <div className="row">
        <div className="col-12 col-sm-12 col-md-12 col-lg-5   d-none d-lg-block text-center">
          <img src={loginimage} alt="classroom" className="img-fluid" width={'500rem'} />
        </div>
        <div className="col-12 col-sm-12 col-md-12 col-lg-7 ">
          <form onSubmit={handleSubmit} className="shadow p-2 p-sm-5 pt-5 mx-md-5 bg-white">
            <div className="row p-4 pt-0">
              <div className="col-md-12">
                <h3>Welcome to <img src={imgsrc}  alt="Company Logo" className='float-end' style={{height: 'fit-content', maxWidth: '120px'}} /> </h3>
                <h1 className="second-heading">Login Page</h1>
              </div>
              <div className="col-md-12 mt-5 mb-3 input-group">
                <span className="input-group-text border-0 bg-transparent">
                  <FaUser />
                </span>
                <input
                  type="text"
                  autoComplete="username"
                  placeholder="Enter Email"
                  name="email"
                  className="form-control rounded-0 logininput"
                  onChange={(e) => setEmail(e.target.value)}
                />
                {errors.email && <span className="text-danger">{errors.email}</span>}
              </div>
              <div className="col-md-12 mb-4 input-group">
                <span className="input-group-text border-0 bg-transparent">
                  <FaLock />
                </span>
                <input
                  type="password"
                  placeholder="Password"
                  className="form-control rounded-0 logininput"
                  onChange={(e) => setPassword(e.target.value)}
                  name="password"
                />
                {errors.password && <span className="text-danger">{errors.password}</span>}
              </div>
              {/* <div className="col-6 text-end mb-4">
                <div className="form-check">
                  <input 
                  className="form-check-input" type="checkbox"/>
                  <label className="form-check-label">
                    Checked checkbox
                  </label>
                </div>
              </div> */}
              <div className="col-md-12 text-end mb-4">
                <button className="btn forgotpassword" type="button">
                  Forgot password?
                </button>
              </div>
              <div className="col-md-12">
                <button className="btn  login-btn" type="submit">
                  Login
                </button>
              </div>
              <div className="col-md-12 text-center mt-5">
                Don&#39;t have an account?
                <button className="btn register" type="button">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login
