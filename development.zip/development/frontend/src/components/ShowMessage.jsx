import { useEffect, useState } from 'react';
import { Toast, Alert, ToastContainer, Modal, Button } from 'react-bootstrap';

function ShowMessage({ type, show, title, message, variant, position = 'bottom-end', size, textClose, textConfirm, btnClose, btnConfirm, onAction, onClose, onConfirm,
  confirmText = textConfirm || "Confirm",
  closeText = textClose || "Close", linkUrl, linkTarget, linkText }) {
  const [visible, setVisible] = useState(show);
  useEffect(() => {
    setVisible(show);
  }, [show]);

  return (
    <>
      {type === 'toast' && (
        <ToastContainer position={position} className="p-3 position-fixed">
          <Toast
            onClose={() => {
              setVisible(false);
              onClose?.();
              onAction?.('close');
            }}
            show={visible}
            bg={variant}
          >
            <Toast.Header closeButton className='text-white'>
              <Toast.Body className="me-auto">{message}</Toast.Body>
            </Toast.Header>
          </Toast>
        </ToastContainer>
      )}
      {type === 'alert' && (
        <Alert
          variant={variant}
          onClose={() => {
            setVisible(false);
            onClose?.();
            onAction?.('close');
          }}
          dismissible
          show={visible}
          className="pe-1 py-2 d-flex align-items-center flex-row-reverse justify-content-between bottom-right-alert"
        >
          {message}
        </Alert>
      )}

      {type === 'modal' && (
        <Modal
          show={visible}
          onHide={() => {
            setVisible(false);
            onClose?.();
          }}
          keyboard={false}
          backdrop='static'
          size={size}
          centered
        >
          {title && (
            <Modal.Header closeButton>
              <Modal.Title>{title}</Modal.Title>
            </Modal.Header>
          )}

          <Modal.Body className="text-center">{message}</Modal.Body>

          <Modal.Footer className="justify-content-center">
            {btnClose && (
              <Button
                variant="export"
                onClick={() => {
                  setVisible(false);
                  onClose?.();
                  onAction?.('close');
                }}
              >
                {closeText}
              </Button>
            )}
            {btnConfirm && (
              <Button
                className='h45'
                variant="primary"
                onClick={() => {
                  setVisible(false);
                  onConfirm?.();
                  onAction?.('confirm');
                }}
              >
                {confirmText}
              </Button>
            )}
            {linkUrl && (
              <a
                href={linkUrl || '#'}
                target={linkTarget || '_self'}
                className='btn btn-primary h45'
              >
                {linkText || 'Go to link'}
              </a>
            )}
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default ShowMessage;
