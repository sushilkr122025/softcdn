import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import './Question.css';
// import Toolbar from 'src/components/toolbar/Toolbar'
import { Modal, Button } from 'react-bootstrap';
import queServices from '../../api/QuestionServices';
import useAuth from '../../context/AuthContext';
import { BiImageAdd } from 'react-icons/bi';
import { FaImage } from 'react-icons/fa6';
import MultiServices from '../../api/MultiServices';
import { useNavigate, useParams } from 'react-router-dom';
import JoditEditor from 'jodit-react';
import 'jodit/es2021/jodit.min.css';
import GlobalFilters from '../../components/GlobalFilters';
import ShowMessage from '../../components/ShowMessage'
import { useMemo } from 'react';

const greekLetters = {
  π: "π", α: "α", β: "β", γ: "γ", ε: "ε", θ: "θ", λ: "λ", μ: "μ", 
  σ: "σ", φ: "φ", ω: "ω",
  ϵ: "ϵ", η: "η", ψ: "ψ",
  hr1: "<hr>",
  Σ: "Σ", Φ: "Φ", Ω: "Ω", Υ: "Υ", Ψ: "Ψ",
};

const relations = {
  "=": "=", "≠": "≠", "<": "<", ">": ">", "≤": "≤", "≥": "≥", "≪": "≪",
  "≫": "≫", "≡": "≡", "≃": "≃", "∼": "∼", "≅": "≅", "≈": "≈", 
  hr1: "<hr>",
  "⊂": "⊂", "⊃": "⊃", "⊆": "⊆", "⊇": "⊇", "∈": "∈", "∉": "∉", "∋": "∋",
};

const operators = {
  "×": "×", "÷": "÷", "·": "·", "±": "±", "*": "*",
  hr1: "<hr>",
  "∘ ": "∘", "⊕": "⊕", "⊗": "⊗", 
  hr2: "<hr>",
  "∧": "∧", "∨": "∨", "∩": "∩", "∪": "∪",
  hr3: "<hr>",
  "ℕ": "ℕ", "ℝ": "ℝ",  "ℚ": "ℚ", "ℤ": "ℤ","∞": "∞",
  hr4: "<hr>",
  "∂": "∂", "∇": "∇", "△": "△", 
}

const arrows = {
  "←": "←", "→": "→", "↔": "↔", "⇐": "⇐", "⇒": "⇒", "⇔": "⇔", "↑": "↑",
  "↓": "↓", "↕": "↕", "⇑": "⇑", "⇓": "⇓", "⇕": "⇕",
};

const functions = [
    { name: 'cuberoot', preview: '<span class="root"> <span class="rad-exponent">&#8203;n</span><span class="radical">√</span><span class="radicand">&#8203;n</span></span>' },
    { name: 'fraction', preview: '<span class="frac" style="font-size: 0.8em" contenteditable="true"><span class="fracnum">​a</span><span class="fracden">​b</span></span>' },
    { name: 'summation', preview: '<span class="summation" style="font-size: 1em"><span class="sum-upper">&#8203;n</span><span class="sum-symbol" contenteditable="true">∑</span><span class="sum-lower">&#8203;i=1</span></span>' },
    { name: 'integral', preview: '<span class="integration" style="font-size: 0.7em"><span class="int-symbol">∫</span><span class="int-lower">&#8203;a</span><span class="int-upper">&#8203;b</span></span>' },
    // { name: 'subscript', preview: 'xₐ' },
    // { name: 'superscript', preview: 'xᵇ' },
    // { name: 'subsup', preview: 'xᵇₐ' },
    { name: 'intersection', preview: '<span class="intersection" style="font-size: 1em"><span class="intersection-upper">&#8203;b</span><span class="intersection-symbol">∩</span><span class="intersection-lower">&#8203;a</span></span>' },
    { name: 'union', preview: '<span class="union" style="font-size: 1em"><span class="union-upper">&#8203;b</span><span class="union-symbol">∪</span><span class="union-lower">&#8203;a</span></span>' },
    { name: 'product', preview: '<span class="product" style="font-size: 0.8em"><span class="product-upper">&#8203;b</span><span class="product-symbol">∏</span><span class="product-lower">&#8203;a</span></span>' },
    { name: 'contour', preview: '<span class="contour-integral" style="font-size: 0.8em"><span class="contour-upper">b</span><span class="contour-symbol">∮</span><span class="contour-lower">a</span></span>' },
    { name: 'limit', preview: '<span class="limit" style="font-size: 0.8em"><span class="limit-symbol">lim</span><span class="limit-lower">&#8203;x → 0</span></span>' },
    { name: 'xbar', preview: 'x̄' },
    { name: 'xhat', preview: 'x̂' },
];

// A helper function to create popup content to avoid repetition
const createPopup = (jodit, data, insertFunc, close, isGrid = false) => {
  const container = jodit.create.div(isGrid ? 'symbol-grid' : 'symbol-list');
  
  Object.entries(data).forEach(([key, value]) => {
    // Handle horizontal rulers in data
    if (key.startsWith('hr')) {
      container.insertAdjacentHTML('beforeend', value);
      return;
    }
    
    const btn = jodit.create.element('button', { className: 'dd-item' });
    btn.innerHTML = isGrid ? `<span class="prev">${value.preview}</span>` : value;

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      // For functions, the key is the name; for symbols, it's the symbol itself
      const insertValue = isGrid ? value.name : key;
      insertFunc(jodit, insertValue);
      close();
    });
    container.appendChild(btn);
  });
  return container;
};

function QuestionGeneration({placeholder}) {
  const editor = useRef(null);
  const [content, setContent] = useState("");

  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const apiUrl = import.meta.env.VITE_HOST;  

  const joeditor = useRef(null);
  const editorInstance = useRef(null);
  const savedSelection = useRef(null);
  const [srcGallery, setSrcGallery] = useState(false);
  const { qid } = useParams();
  const shortuuid = qid ? qid : null;
  const [isContext, setISContext] = useState();
  const [qContext, setQContext] = useState(false);
  const [contextId, setContextId] = useState(false);
  const [topicName, setTopicName] = useState(false);
  const [contextstatus, setContextstatus] = useState(false);
  const handleRef = (wrapper) => {
    joeditor.current = wrapper;

    const waitForEditor = () => {
      const instance = wrapper?.editor;
      if (instance) {
        editorInstance.current = instance;       
      } else {
        setTimeout(waitForEditor, 100);
      }
    };

    waitForEditor();
  };

  const joditconfig = useMemo(() => ({
    readonly: false, // all options from https://xdsoft.net/jodit/docs/
    toolbarSticky: false,
    toolbarAdaptive: false,
    height: 350,
    // placeholder: placeholder || "Start typing...",      
    
    extraButtons: [
        {
          name: "greek",
          icon: "<span>αβγ</span>",
          popup: (j, c, s, close) => createPopup(j, greekLetters, insertText, close)
        },
        {
          name: "relations",
          icon: "<span>= ≠ ≤</span>",
          popup: (j, c, s, close) => createPopup(j, relations, insertText, close)
        },
        {
          name: "operators",
          icon: "<span>Ops</span>",
          popup: (j, c, s, close) => createPopup(j, operators, insertText, close)
        },
        {
          name: "arrows",
          icon: "<span>→</span>",
          popup: (j, c, s, close) => createPopup(j, arrows, insertText, close)
        },
        {
          name: "functions",
          icon: "<span>ƒ(x)</span>",
          popup: (jodit, current, self, close) => {
            const container = jodit.create.div("symbol-grid");
            functions.forEach((func) => {
              const btn = jodit.create.element("button", { className: "dd-item" });
              btn.innerHTML = `<span class="prev">${func.preview}</span>`;
              btn.addEventListener("click", (e) => {
                e.preventDefault();
                insertEquation(jodit, func.name);
                close();
              });
              container.appendChild(btn);
            });
            return container;
          },
        },
      ],

    buttons: [
      'bold',
      'italic',
      'underline',
      'strikethrough',
      'subscript',
      'superscript',
      '|',
      'ul',
      'ol',
      '|',
      'outdent',
      'indent',
      'table',
      '|',
      'font',
      'fontsize',
      'brush',
      'paragraph',
      '|',
      'align',
      '|',
      'customImageUpload',
      '|',
      'undo',
      'redo',
      '|',
      'hr',
      'eraser',
      'copyformat',
      // '|', 'fullsize', 'preview'
    ],
    askBeforePasteFromWord: true,
    processPasteFromWord: true,
    defaultActionOnPaste: 'insert_clear_html',
    cleanHTML: {
      cleanOnPaste: true,
      removeEmptyElements: false,
      fillEmptyParagraph: false,
      removeEmptyTextNodes: false,
    },
    controls: {
      customImageUpload: {
        name: 'Insert Image',
        icon: 'image',
        exec: () => {
          setShow(true);
          setSrcGallery(true);
        },
      },
    },
  }),[placeholder]);

  const navigator = useNavigate();
  const { user } = useAuth();
  
  const [filter, setFilter] = useState({
    std: '',
    subject: '',
    subDomain: '',
    cg: '',
    competency: '',
    difficulty: '',
    quesType: '',
    cgtext: '',
    competencytext: '',
  });
  const { quesType, cgtext, competencytext } = filter;

  const [question, setQuestion] = useState('');
  const [Options, setOptions] = useState(['', '', '', '']);
  const [chapter, setChapter] = useState('');

  const [optionImages, setOptionImages] = useState({});
  const [activeOption, setActiveOption] = useState(null);

  const [show, setShow] = useState(false);
  const [preview, setPreview] = useState(false);
  const [images, setImages] = useState([]);
  const [errors, setErrors] = useState({});
  const alphabet = ['A', 'B', 'C', 'D'];

  const [editData, setEditData] = useState({});
  

  // const [formData, setFormData] = useState([]);

  useEffect(() => {
    async function fetchImages() {
      const response = await MultiServices.getImages();
      setImages(response);
    }
    fetchImages();
    const isNumericId = /^\d+$/.test(qid);
    if (isNumericId == true && typeof(qid) != 'undefined') {
      fetchQuestion();
    }

    if (isNumericId == false && typeof(qid) != 'undefined') {
      // console.log('short uuid7', shortuuid, isNumericId);
      fetchContext();      
    }

    // joeditor 
    const editorInstance = joeditor.current?.editor;
    if (!editorInstance) return;
    const bindPasteHandler = () => {
      const container = editorInstance?.container;

      if (!container) return;

      const handlePaste = (event) => {
        const clipboardData = event.clipboardData || window.clipboardData;
        const html = clipboardData.getData("text/html");
        const text = clipboardData.getData("text/plain");

        event.preventDefault();

        if (html) {
          editorInstance.selection.insertHTML(html);
        } else {
          editorInstance.selection.insertHTML(text.replace(/\n/g, "<br>"));
        }
      };

      container.addEventListener("paste", handlePaste);

      // Cleanup
      return () => container.removeEventListener("paste", handlePaste);
    };

    const jodit = editorInstance;
    const root = jodit && jodit.editor;
    if (!root) return;

    // Classes whose element nodes must be preserved until empty
    const protectedClasses = [
      "radicand","fracnum","fracden","sum-upper","sum-lower",
      "int-lower","int-upper","int-content","subsup-sub","subsup-sup",
      "subsup-both-sub","subsup-both-sup","intersection-upper","intersection-lower",
      "union-upper","union-lower","product-upper","product-lower",
      "limit-lower","rad-exponent"
    ];

    // ZWSP detection and "empty with <br>" handling
    const ZWSP_REGEX = /\u200B/g;

    
    const isEffectivelyEmpty = (el) => {
      if (!el) return true;
      // If the element only contains a single <br> or is empty text, treat as empty
      const onlyBr =
        el.childNodes.length === 1 &&
        el.firstChild &&
        el.firstChild.nodeType === Node.ELEMENT_NODE &&
        el.firstChild.nodeName === "BR";

      const txt = (el.textContent || "").replace(ZWSP_REGEX, "").trim();
      return onlyBr || txt.length === 0;
    };

    const getRangeSafe = () => {
      const domSel = document.getSelection && document.getSelection();
      return (
        (jodit && jodit.selection && jodit.selection.range) ||
        (domSel && domSel.rangeCount ? domSel.getRangeAt(0) : null)
      );
    };

    const findNearestProtected = (start) => {
      let el = start;
      while (el && el !== root) {
        if (el.classList) {
          for (const cls of protectedClasses) {
            if (el.classList.contains(cls)) return el;
          }
        }
        el = el.parentElement;
      }
      return null;
    };

    // Allow normal text deletion; only block removal of a protected element if it is empty
    const keydownHandler = (ev) => {
      if (ev.key !== "Backspace" && ev.key !== "Delete") return;

      const rng = getRangeSafe();
      if (!rng) return;

      let node = rng.startContainer || null;
      if (!node) return;

      let startEl =
        node.nodeType === Node.TEXT_NODE
          ? (node.parentElement || null)
          : (node instanceof Element ? node : null);

      const protectedEl = findNearestProtected(startEl);
      if (!protectedEl) return;

      // If inner text is NOT empty, allow deletion of characters
      if (!isEffectivelyEmpty(protectedEl)) {
        return; // do nothing: let the key event proceed
      }

      // Inner text is empty: prevent deleting the element node itself
      // But still keep caret behavior pleasant: ensure a ZWSP is present for caret
      ev.preventDefault();
      ev.stopPropagation();
      

      // Maintain a ZWSP so caret can stay inside the empty protected element
      if ((protectedEl.textContent || "").replace(ZWSP_REGEX, "").length === 0) {
        if (protectedEl.innerHTML === "" || protectedEl.innerHTML === "<br>") {
          protectedEl.innerHTML = "\u200B";
        }
      }
    };

    // Keep empty protected leaves caret-friendly
    const ensurePlaceholders = () => {
      protectedClasses.forEach((cls) => {
        root.querySelectorAll(`.${cls}`).forEach((el) => {
          const txt = (el.textContent || "").replace(ZWSP_REGEX, "");
          if (txt.length === 0) {
            // Replace stray <br> with ZWSP to avoid browser auto-removal/merge
            if (el.innerHTML === "" || el.innerHTML === "<br>") {
              el.innerHTML = "\u200B";
            }
          }
        });
      });
    };

    root.addEventListener("keydown", keydownHandler, true); // capture early to beat default deletion
    root.addEventListener("input", ensurePlaceholders);
    root.addEventListener("keyup", ensurePlaceholders);

    // Also guard programmatic delete route if present
    const offFns = [];
    const evApi = jodit && jodit.events;
    if (evApi && evApi.on) {
      const offBeforeCommand = evApi.on("beforeCommand", (command) => {
        if (command !== "delete") return;
        const rng = getRangeSafe();
        if (!rng) return;
        let node = rng.startContainer || null;
        if (!node) return;
        let el =
          node.nodeType === Node.TEXT_NODE
            ? (node.parentElement || null)
            : (node instanceof Element ? node : null);
        const protectedEl = findNearestProtected(el);
        if (protectedEl && isEffectivelyEmpty(protectedEl)) {
          return false; // cancel delete command when protected element is empty
        }
      });
      if (typeof offBeforeCommand === "function") offFns.push(() => offBeforeCommand());
    }

    // Wait until Jodit's DOM is ready
    const timeout = setTimeout(() => {
      bindPasteHandler();
    }, 100); // or use requestAnimationFrame

    // Initial pass to normalize placeholders
    ensurePlaceholders();
    updateHighlight();

    // const currentEditor = editor.current;
    // if (!currentEditor) return;
    // const editorRoot = currentEditor.editor;
    // const handleHighlight = () => updateHighlight();
    // editorRoot.addEventListener("click", handleHighlight);
    // editorRoot.addEventListener("keyup", handleHighlight);
    // document.addEventListener("selectionchange", handleHighlight);

    // // Initial pass to normalize placeholders
    // ensurePlaceholders();
    // // updateHighlight();

    return () => { 
      root.removeEventListener("keydown", keydownHandler, true);
      root.removeEventListener("input", ensurePlaceholders);
      root.removeEventListener("keyup", ensurePlaceholders);
      offFns.forEach((fn) => {
        try { fn(); } catch {}
      });
    };
  }, []);

  const insertImage = (url) => {
    const editor = editorInstance.current;
    console.log(editor?.selection?.restore , savedSelection.current)
    if (editor?.selection?.restore && savedSelection.current) {
      editor.selection.restore(savedSelection.current);
      editor.selection.insertHTML(`<img src="${url}" style="max-width: 100%;" />`);
      console.log("Image inserted");
      savedSelection.current = null;
    } else {
      alert("Editor not ready or selection missing");
    }
    setShow(false);
  };

  const fetchContext = async () => {   
      const response = await queServices.getContextByShortUuid({ params: { id: qid } });      
      if (response.status == 200) {
        const data = response.data;
        setFilter({
          std: data.class,
          subject: data.subject,          
        });
        const type = data.contextstatus == 'CONTEXT' ? true : data.contextstatus == 'NONECONTEXT' ? false: false;

        setISContext(type);
        setContextstatus(data.contextstatus);
        setTopicName(data.topicName);
        setQContext(data.context);
        setContextId(data.id);
      }
    if(response.status == 404 || response.status == 500) { 
      setMsgType('modal');
      setMsgVariant('danger')
      setRedirect('/question')
      setBtnConfirm(true)
      setMessage(response.message)
      setShowMsg(true);      
    }
  };

  const fetchQuestion = async () => {
    try {
      const response = await queServices.getQuestionById({ params: { id: qid } });      
      const data = response;
      setEditData(data)
      if (response) {
        setFilter({
          std: data.class,
          subject: data.subject,
          cg: data.cg,
          competency: data.competency,
          difficulty: data.difficulty,
          quesType: data.quesType,
          subDomain: data.subDomain,
          cgtext: data.cgtext,
          competencytext: data.competencytext,
        });
        setQuestion(data.question);
        setChapter(data.chapter);
        setContextId(data.contextid);
        setContextstatus(data.contextstatus);
        setOptions([
          data.optA || '',
          data.optB || '',
          data.optC || '',
          data.optD || ''
        ]);

        setOptionImages({
          quesImg: data.image ? JSON.parse(data.image) : null,
          optAimg: data.optAimg ? JSON.parse(data.optAimg) : null,
          optBimg: data.optBimg ? JSON.parse(data.optBimg) : null,
          optCimg: data.optCimg ? JSON.parse(data.optCimg) : null,
          optDimg: data.optDimg ? JSON.parse(data.optDimg) : null,
        });

      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleClose = () => {
    setShow(false);
    setPreview(false);
  };

  const onSubmitHandler = async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    const payload = {
      ...Object.fromEntries(formData),
      ...filter,
      tId: user.id,
      contextid: contextId,
      contextstatus: contextstatus,
      question: question,
      competencytext: competencytext,
      cgtext: cgtext,
      chapter: chapter,
      image: optionImages['quesImg'] ? JSON.stringify(optionImages['quesImg']) : '',
      optA: Options[0],
      optB: Options[1],
      optC: Options[2],
      optD: Options[3],
    };

  //  console.log(payload);

    const validateForm = (formData) => {
    
      const errors = {};

      if (!formData.subject) {
        errors.subject = 'Subject is required';
      }
      if (!formData.std) {
        errors.class = 'Class is required';
      }
      if (!formData.cg) {
        errors.cg = 'Curriculum Goal is required';
      }
      if (!formData.competency) {
        errors.competency = 'Competency is required';
      }
      if (!formData.difficulty) {
        errors.difficulty = 'Difficulty is required';
      }
      if (!formData.quesType) {
        errors.quesType = 'Type is required';
      }
      if (formData.questionType === 'oneWord' && formData.corrAns.trim().split(' ').length > 1) {
        errors.correctAnswer = 'Please enter only one word';
      }
      if (formData.questionType === 'oneWord' && !formData.corrAns) {
        errors.correctAnswer = 'Please enter one word';
      }
      if (formData.questionType === 'trueFalse' && !formData.corrAns) {
        errors.correctAnswer = 'Please select either true or false';
      }
      if (formData.questionType === 'multipleChoice' && !formData.corrAns) {
        errors.correctAnswer = 'Please select any one option';
      }
      // Add more validation rules for other fields
      return errors;
    };

    const validationErrors = validateForm(payload);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      // console.log(validationErrors);
      return;
    }
    console.log(payload);        

      const response = await queServices.createQuestion(payload);        
      if (response.status == 201 || response.status == 200) {      
       setMsgType('modal');
        setMsgVariant('danger')
        setRedirect('/question')
        setTextClose('Add More')
        setTextConfirm('Complete')
        setBtnClose(true)
        setBtnConfirm(true)
        setMessage("Question Created Successfully")
        setShowMsg(true); 
        setQuestion('');
        setOptions(['','', '', '']);
        document.getElementById('corrAns').value = '';
        setChapter('');
      }

      if (response.status == 500) {   
        setTextConfirm('Exit')
        setRedirect('/question')
        setBtnClose(false)
        setBtnConfirm(true)
        setMessage(response.message)
        setShowMsg(true);      
      }
  };

const handleFiltersChange = (newFilters) => {
  setFilter((prev) => {
    const merged = {
      ...prev,
      ...newFilters,
      subDomain: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.subDomain,
      cg: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.cg,
      competency: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.competency,
      difficulty: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.difficulty,
      quesType: prev.std !== newFilters.std || prev.subject !== newFilters.subject ? '' : newFilters.quesType,
    };
    return JSON.stringify(prev) === JSON.stringify(merged) ? prev : merged;
  });
};


  // Highlighting logic remains the same
  const updateHighlight = () => {
    if (!editor.current) return;
    const editorRoot = editor.current.editor;
    editorRoot.querySelectorAll(".formula-highlight").forEach(el => el.classList.remove("formula-highlight"));
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    let node = sel.anchorNode;
    if (!node) return;
    let current = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    while (current && current !== editorRoot) {
      if (isFormulaElement(current)) {
        current.classList.add("formula-highlight");
        return;
      }
      current = current.parentElement;
    }
  };

  const isFormulaElement = (el) => {
    if (el.nodeType !== Node.ELEMENT_NODE) return false;
    const formulaClasses = ["root", "radicand", "rad-exponent", "exponent", "frac", "fracnum", "fracden", "summation", "sum-upper", "sum-lower", "sum-symbol", "integration", "int-lower", "int-upper", "int-symbol", "int-content", "paren", "paren-left", "paren-right", "paren-content", "subsup", "subsup-sub", "subsup-sup", "subsup-both", "subsup-both-sub", "subsup-both-sup", "xbar", "xhat", "intersection", "union", "product", "limit"];
    return formulaClasses.some(cls => el.classList.contains(cls));
  };

    const insertText = (jodit, text) => {
    if (!jodit) return;
    jodit.selection.insertHTML(text);
  };

  const insertEquation = (jodit, val) => {
    if (!jodit) return;
    let eqHTML = "";
    // Switch cases are identical to your original code
    switch (val) {
  case "cuberoot":
    eqHTML = `
    &#8203;
      <span class="root">
        <span class="rad-exponent">&#8203;n</span>
        <span class="radical">√</span>
        <span class="radicand">&#8203;n</span>
      </span>
    &#8203;`;
    break;

  case "fraction":
    eqHTML = `
    &#8203;
      <span class="frac" contenteditable="true">
        <span class="fracnum">&#8203;a</span>
        <span class="fracden">&#8203;b</span>
      </span>
      &#8203;`;
    break;

  case "summation":
    eqHTML = `
    &#8203;
      <span class="summation">
        <span class="sum-upper">&#8203;n</span>
        <span class="sum-symbol" contenteditable="true">∑</span>
        <span class="sum-lower">&#8203;i=1</span>
      </span>
      &#8203;`;
    break;

  case "integral":
    eqHTML = `
    &#8203;
      <span class="integration">
        <span class="int-symbol">∫</span>
        <span class="int-lower">&#8203;a</span>
        <span class="int-upper">&#8203;b</span>
        <span class="int-content">&#8203;f(x)dx</span>
      </span>
      &#8203;`;
    break;
    
  case "xbar":
    eqHTML = `&#8203;<span class="xbar">x</span>&#8203;`;
    break;

  case "xhat":
    eqHTML = `&#8203;<span class="xhat">x</span>&#8203;`;
    break;

  case "intersection":
    eqHTML = `
    &#8203;
      <span class="intersection">
        <span class="intersection-upper">&#8203;b</span>
        <span class="intersection-symbol">∩</span>
        <span class="intersection-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "union":
    eqHTML = `
    &#8203;
      <span class="union">
        <span class="union-upper">&#8203;b</span>
        <span class="union-symbol">∪</span>
        <span class="union-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "product":
    eqHTML = `
    &#8203;
      <span class="product">
        <span class="product-upper">&#8203;b</span>
        <span class="product-symbol">∏</span>
        <span class="product-lower">&#8203;a</span>
      </span>
      &#8203;`;
    break;

  case "contour":
    eqHTML = `
    &#8203;
      <span class="contour-integral">
        <span class="contour-upper">b</span>
        <span class="contour-symbol">∮</span>
        <span class="contour-lower">a</span>
      </span>
      <span class="contour-body"> f(x)dx</span>
      &#8203;`;
    break;

  case "limit":
    eqHTML = `
    &#8203; 
      <span class="limit">
        <span class="limit-symbol">lim</span>
        <span class="limit-lower">&#8203;x → 0</span>
      </span>
      &#8203; `;
    break;

  default:
    return;
}

    jodit.selection.insertHTML(eqHTML + "&nbsp;");
  };

  return (
    <>
      <div className="container-fluid" id="question-section">
        <GlobalFilters onFiltersChange={handleFiltersChange} selectedValues={filter} show={['subject', 'class', 'subDomain', 'cg', 'competency', 'difficulty', 'quesType']} />
        <div className='row'>
          <div className='col-md-12 bg-white'>
            <label className='h4'>Topic Name</label>
            <h4 className='border'>{topicName}</h4>
          </div>
        </div>
        {isContext && (
          <>
          <div className="row bg-white">{isContext}
            <div className="col-md-12"
                  dangerouslySetInnerHTML={{ __html: qContext }}
                />            
          </div>
          </>
        )}
        <div className="row">
          <div className="col-md-12 py-4">
            <JoditEditor
                // ref={handleRef}
                ref={editor}
                config={joditconfig} 
                value={question} 
                // onBlur={(content) => setQuestion(content)} />
                onBlur={(content) => {setContent(content); setQuestion(content)}}
                onChange={() => {}}
                onInit={(j) => {
                  // Placeholder logic remains the same
                  const protectedClasses = ["radicand", "fracnum", "fracden", "sum-upper", "sum-lower", "int-lower", "int-upper", "int-content", "subsup-sub", "subsup-sup", "subsup-both-sub", "subsup-both-sup", "intersection-upper", "intersection-lower", "union-upper", "union-lower", "product-upper", "product-lower", "limit-lower", "rad-exponent"];
                  const ensurePlaceholders = () => {
                    protectedClasses.forEach(cls => {
                      j.editor.querySelectorAll(`.${cls}`).forEach(el => {
                        if (el && el.textContent === "") {
                          el.innerHTML = "\u200B"; // zero-width space
                        }
                      });
                    });
                  };
                  j.events.on("keyup", ensurePlaceholders);
                  j.events.on("change", ensurePlaceholders);
                  ensurePlaceholders();
                }}
                />
          </div>
          <div className="col-md-2 py-4 d-flex flex-column justify-content-between align-items-center d-none">
            <button
              className="btn w-100 h-100 p-0"
              style={{ border: '1px dashed #000' }}
              onClick={() => {
                setActiveOption(`quesImg`);
                setShow(true);
              }}
              type="button"
            >
              {!optionImages['quesImg'] && <BiImageAdd />}
              {optionImages['quesImg'] && <img src={`${apiUrl}/assets${optionImages['quesImg']['src']}`} alt={optionImages['quesImg']['label']} className="image-preview m-0 w-100 h-100" />}
            </button>
            {optionImages.quesImg && <div className="py-2">{optionImages.quesImg.label}</div>}
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 p-4 bg-white shadow-sm">
            <form className="form" onSubmit={onSubmitHandler} encType="multipart/form-data">
              <input type="hidden" name="editId" id="editId" defaultValue={editData?.id} />
              <div className="row mb-3">
                <div className="col-md-5 offset-md-3">
                  {filter.quesType === 'oneWord' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="textQuesAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <input
                            id="corrAns"
                            name="corrAns"
                            className="form-control"
                            type="text"
                            defaultValue={editData?.correctAns}
                            // onChange={(e) => setCorrectAnswer(e.target.value)}
                            placeholder="Enter the Correct Answer"
                          />
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {quesType === 'trueFalse' && (
                    <>
                      <div className="row">
                        <div className="col-md-12 mb-3">
                          <label htmlFor="trueFalseAns" className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select id="corrAns" name="corrAns" className="form-select" defaultValue={editData?.correctAns}>
                            <option value="">Select Correct Answer</option>
                            <option value="true">True</option>
                            <option value="false">false</option>
                          </select>
                          {errors.correctAnswer && <div className="error-message">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  {quesType === 'multipleChoice' && (
                    <>
                      <div className="row">
                       
                        {Options.map((opt, index) => {
                          const key = `opt${alphabet[index]}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <>
                            <div className="col-2" key={`opt${index}`}>
                                <label htmlFor={key} className="form-label">
                                Option {alphabet[index]}
                              </label> 

                            </div>
                            <div className="col-md-10 mb-3" key={index}>
                              <div className="d-flex">                                
                                <span className="form-control form-control-sm me-3 border-dashed" style={{height:'auto', minHeight:'2em'}} contentEditable={true} suppressContentEditableWarning={true}  name={key}
                                  id={key}      
                                  dangerouslySetInnerHTML={{ __html: opt }}                            
                                  onBlur={(e) => {
                                    const newOptions = [...Options];
                                    newOptions[index] = e.target.innerHTML;                                   
                                    setOptions(newOptions);
                                  }}></span>                                 
                                  
                                <input type="hidden" name={imgKey} id={imgKey} value={imgObj ? JSON.stringify(imgObj) : ''} />
                                <button
                                  className="btn d-none"
                                  style={{ border: '1px dashed #000' }}
                                  onClick={() => {
                                    setShow(true);
                                    setActiveOption(`opt${alphabet[index]}img`);
                                  }}
                                  type="button"
                                >
                                  <BiImageAdd />
                                </button>
                                {imgObj && (
                                  <>
                                    <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview ms-2" />
                                    <span className="ms-2">{imgObj.label}</span>
                                  </>
                                )}
                              </div>
                            </div>
                            </>
                          );
                        })}
                      </div>
                      <div className="row pt-2">
                        <div className="col-md-12 mb-3">
                          <label className="mb-2">
                            Correct Answer<span className="required text-danger"> *</span>
                          </label>
                          <select className="form-select form-rows" name="corrAns" id="corrAns" defaultValue={editData?.correctAns}>
                            <option value="">Select Correct Answer</option>
                            <option value="optA">Option A</option>
                            <option value="optB">Option B</option>
                            <option value="optC">Option C</option>
                            <option value="optD">Option D</option>
                          </select>
                          {errors.correctAnswer && <div className="error">{errors.correctAnswer}</div>}
                        </div>
                      </div>
                    </>
                  )}
                  <div className="row mb-3 d-none">
                    <div className="col-12">
                      <label htmlFor="chapter" className="mb-2">
                        Chapter
                      </label>
                      <input type="text" name="chapter" id="chapter" className="form-control" value={chapter} onInput={(e) => setChapter(e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>
              <Modal show={show} onHide={handleClose} backdrop="static" size="xl">
                <Modal.Header closeButton>
                  <Modal.Title>Gallery</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="row">
                    {images.map((e, i) => {
                      return (
                        <div key={i} className="col-4">
                          <div
                            className="image-container"
                            onClick={() => {
                              if(srcGallery == false) {
                                setOptionImages((prev) => ({ ...prev, [activeOption]: { src: e.imageURL, label: e.name } }));
                                setShow(false);
                              }
                              if(srcGallery == true) {    
                                const editor = editorInstance.current;                                  
                                // console.log("Selection saved");
                                if (editor?.selection?.save) {
                                  // console.log("Selection saved inner");
                                  savedSelection.current = editor.selection.save();
                                  insertImage(e.imageURL);
                                  // console.log("Selection saved");
                                }
                                setSrcGallery(false);
                              }                              
                            }}
                          >
                            <div className="d-flex justify-content-between w-100">
                              <div className="img-head px-3">
                                <div className=" d-flex align-items-center">
                                  <FaImage className="text-danger me-3" /> {e.name}
                                </div>
                              </div>
                              <div className="img-foot">
                                <div className="keyword">{e.keyword}</div>
                                <div className="keyword description" title="description">
                                  {e.description}
                                </div>
                              </div>
                            </div>
                            <div className="img">
                              <img src={`${apiUrl}/assets${e.imageURL}`} alt={e.name} className="img-fluid" />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                  <Button variant="primary">Save Changes</Button>
                </Modal.Footer>
              </Modal>

              <div className="text-center mt-3">
                <button className="btn btn-ghost me-3" type="button">
                  Review panel
                </button>
                <button className="btn btn-grey me-3" type="button" onClick={() => setPreview(true)}>
                  preview
                </button>
                <button className="btn btn-primary" type="submit">
                  save
                </button>
              </div>
            </form>
            <Modal show={preview} onHide={handleClose} backdrop="static" size="md">
              <Modal.Header closeButton>
                <Modal.Title>Preview Question</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <div dangerouslySetInnerHTML={{ __html: question }}></div>
                <div className="row mb-4">
                  <div className="col-8 offset-2">
                    <div className="row">
                      {quesType === 'multipleChoice' &&
                        Options.map((e, index) => {
                          const key = `opt${alphabet[index]}`;
                          const imgKey = `${key}img`;
                          const imgObj = optionImages[imgKey];
                          return (
                            <div className="col-md-6 my-3 text-center" key={index}>
                              <span>
                                {index + 1}. &nbsp;{e}
                              </span>
                              {imgObj && <img src={`${apiUrl}/assets${imgObj.src}`} alt={imgObj.label} className="image-preview me-2" />}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </Modal.Body>
            </Modal>
          </div>
        </div>
      </div>
      <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose} 
      textConfirm={textConfirm}
      textClose={textClose}
      onClose={() => setShowMsg(false)}
      onConfirm={() => {
        setShowMsg(false);
        navigator(redirect);
      }}
      />
    </>
  );
}
export default QuestionGeneration;
