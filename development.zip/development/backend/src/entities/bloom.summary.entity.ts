import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity({ name : 'bloomsummary' })
export class BloomSummary {

  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  paperid!: number;

  @Column()
  class!: string;

  @Column()
  section!: string;

  @Column()
  bloomLevel!: string;

  @Column()
  maxMarks!: string;

  @Column()
  obtainedMarks!: string;

  @Column('float')
  avgPercentage!: number;
}