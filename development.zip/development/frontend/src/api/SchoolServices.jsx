import apiClient from './apiService';

class SchoolServices {
    // uploadFile = async (formData) =>{
    //     try {
    //       const company = formData.get('name').toLowerCase().replace(/\s+/g, '');
    //       const response = await apiClient.post(`/school/register/${company}`, formData, {
    //         headers: {
    //           'Content-Type': 'multipart/form-data',
    //         },
    //       });
    //       return response.data;
    //     } catch (error) {
    //       console.error('Error uploading file:', error);
    //       throw error;
    //     }
    // }
    getLookup = async (slug) => {
        try {
        const response = await apiClient.get('/lookup/' + slug);
        return response.data;
        } catch (error) {
        console.error('Error lookup school data:', error);
        throw error;
        }
    };

    getLookupVerify = async () => {
      try {
      const response = await apiClient.get('/company/me');       
      return {
        status: response.status,
        data: response.data,
      };
      } catch (error) {
      console.log(error);
      throw error;
      }
    };

    userLogin = async (data) => {
      try {
      const response = await apiClient.post('/auth/login', data);   
      return {
        status: response.status,
        data: response.data,
      };
      } catch (error) {
      console.log(error);
      throw error;
      }
    };

    // Load CSRF token
  loadCsrfToken = async () => {
    const res = await apiClient.get('/csrf-token');
    const token = res.data.csrfToken;
    if (token) {
      apiClient.defaults.headers.common['X-CSRF-Token'] = token;
    }
    return token;
  };
}

export default new SchoolServices;
