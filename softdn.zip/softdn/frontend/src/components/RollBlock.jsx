import { useEffect, useState, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './RollBlock.css';
import MultiServices from '../api/MultiServices';
// import { isAndroid } from 'react-device-detect';
// import { RollbackContext } from 'src/contexts/RollBlockProvider';

const RollBlock = () => {

  const location = useLocation();
  const { examDetails } = location.state || {};

  const [examDetail, setexamDetail] = useState(examDetails || null);
  const navigate = useNavigate();
  // const { paperId } = useParams();

  const [allStudents, setAllStudents] = useState([]);
  const [selectedSection, setSelectedSection] = useState('');
  const [quesDetailData, setQuesDetailData] = useState([]);
  const [idArr, setIdArr] = useState([]);

  const [result, setResult] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await MultiServices.GetStudentByClass({ class: examDetail.class, section: examDetail.section, paperId: examDetail.paperId });
        console.log(res);

        setAllStudents(res.studentData);
        setQuesDetailData(res.questionData);
        const firstSec = [...new Set(res.studentData.map((s) => s.section))][0] || '';
        setSelectedSection(firstSec);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();

  }, [examDetail]);

  const sectionData = useMemo(() => [...new Set(allStudents.map((s) => s.section))], [allStudents]);
  const studentData = useMemo(() => allStudents.filter((s) => s.section === selectedSection), [allStudents, selectedSection]);

  useEffect(() => {
    const res = allStudents.every((student) => idArr.includes(student.Id));
    setResult(res);
  }, [idArr, allStudents]);

  // const alertdata = async () => {
  //   try {
  //     const response = await MultiServices.GetAlertData({
  //       params: {
  //         paperid: state.examDetail.paperId,
  //         class: state.examDetail.class,
  //         section: sec,
  //       },
  //     });
  //     console.log(response.alertdata);
  //     console.log(response.alertdata[0].alertdetails);
  //     setAlert(response.alertdata);
  //     setAlertDetail(response.alertdata[0].alertdetails);
  //   } catch (error) {}
  // };

  // const handleCreateResult = async () => {
  //   try {
  //     const response = await MultiServices.CreateResult({
  //       params: {
  //         paperid: state.examDetail.paperId,
  //         class: state.examDetail.class,
  //         section: sec,
  //       },
  //     });
  //     console.log(response);

  //     if (response.success == 'success') {
  //       alertdata();
  //     }
  //   } catch (error) {}
  // };

  const handleSection = (val) => {
    setSelectedSection(val);
  };

  const [selectedBox, setSelectedBox] = useState([]);

  const handleClick = (roll) => {
    const rollNumber = roll;
    try {
      window.ReactNativeWebView.postMessage(
        JSON.stringify({
          type: 'openCamera',
          rollNumber,
          quesDetailData,
          examDetail
        })
      );
    } catch {

      console.log(rollNumber, quesDetailData, examDetail);


      let androidData = [];
      let examHeader;

      const data = studentData.filter((r) => r.rollNo === roll);
      console.log(data);

      examHeader = { ...data[0], class: examDetail.class, subject: examDetail.subject, examCode: examDetail.examCode, examDate: examDetail.examDate.split('T')[0] };

      const template = { Id: 'Student ID:', Name: 'Student Name:', class: 'Class:', section: 'Section:', examCode: 'Exam Code:', examDate: 'Date of Exam:', rollNo: 'Roll No.:', subject: 'Subject:' };
      //  console.log(examHeader, template);
      for (const key in examHeader) {
        androidData.push({ fieldName: template[key], value: examHeader[key], valueType: 'string', qid: '', paperId: examDetail.paperId });
      }

      navigate(`/QuesTemplate`, { state: { header: androidData, body: quesDetailData } });
    };

    // UI selection logic
    if (selectedBox.includes(rollNumber)) {
      setSelectedBox(selectedBox.filter((item) => item !== rollNumber));
    } else {
      setSelectedBox([...selectedBox, rollNumber]);
    }
  };


  return (
    <div className="container p-3">
      <div className="d-flex justify-content-between align-items-baseline">
        <h4 className="mb-0">{examDetail.name}</h4>
        {/* <h5 id='condition'></h5> */}
        <h6 className="text-muted">{examDetail.examCode}</h6>
      </div>
      <div className="row align-items-center">
        <div className="col-6 mb-3">Class: {examDetail.class}</div>
        <div className="col-auto ms-auto d-flex align-items-center mb-3">
          <label htmlFor="filterSection" className="form-label mb-0 me-2">
            Section
          </label>
          <select name="filterSection" id="filterSection" className="form-select form-select-sm" disabled={sectionData.length === 1} value={selectedSection} onChange={(e) => handleSection(e.target.value)}>
            {sectionData.map((e, i) => (
              <option key={i} value={e}>
                {e}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="row">
        <div className="col-12">
          <div className="studentRollNotable">
            {studentData.map((e, i) => (
              <div key={i} className={`col-1 selectfield ${idArr.includes(e.Id) ? 'active' : ''}`} data-id={e.Id} onClick={() => handleClick(e.rollNo)}>
                <span className="studentRollNo">{e.rollNo}</span>
              </div>
            ))}
          </div>
        </div>
        {result && (
          <div className="col-12 text-center my-2">
            {/* <button type="button" className="btn btn-lg btn-primary shadow" onClick={handleCreateResult}>
              Generate Result
            </button> */}
          </div>
        )}
      </div>
    </div>
  );
};

export default RollBlock;
