import React, { useState } from 'react'
import { Form, Button, Alert } from 'react-bootstrap'

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [showMessage, setShowMessage] = useState(false)

  const handleEmailChange = (e) => {
    setEmail(e.target.value)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    // Here you would send an HTTP request to your backend to handle the email sending process
    // This part is missing as it requires backend implementation
    try {
      // Simulate sending email
      // Replace this with actual code to send email via backend
      await sendEmail()
      setMessage('Password reset link sent to your email.')
      setShowMessage(true)
    } catch (error) {
      setMessage('Failed to send password reset link.' + error)
      setShowMessage(true)
    }
  }

  const sendEmail = () => {
    // Simulated function to send email
    return new Promise((resolve) => {
      // Simulate sending email with a delay
      setTimeout(() => {
        // Simulate success
        resolve()
        // Simulate failure
        // reject(new Error('Failed to send email'));
      }, 2000)
    })
  }

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Forgot Password</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={handleEmailChange}
            required
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>
      {showMessage && (
        <Alert variant={message.includes('Failed') ? 'danger' : 'success'} className="mt-3">
          {message}
        </Alert>
      )}
    </div>
  )
}

export default ForgotPasswordPage
