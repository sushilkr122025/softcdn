// src/alerts/alert.entity.ts

import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('alerts')
export class Alert {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  alertpaperid: string | null;

  @Column({ type: 'varchar', length: 50, nullable: true })
  alertclass: string | null;

  @Column({ type: 'varchar', length: 10 })
  alertsection: string;

  @Column({ type: 'varchar', length: 200 })
  alertstype: string;

  @Column({ type: 'json' })
  alertdetails: object;

  @Column({ type: 'varchar', length: 50, default: 'INSERT' })
  alertstatus: string;

  @Column({ type: 'int', default: 1 })
  status: number;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  createdate: Date;
}
