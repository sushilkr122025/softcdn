import { IsOptional, IsString, IsInt, IsUrl, MaxLength } from 'class-validator';

export class SchoolDto {
  @IsOptional()
  @IsString()
  @MaxLength(150)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  board?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  logo?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  address?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  city?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  state?: string;

  @IsOptional()
  @IsString()
  @MaxLength(10)
  pincode?: string;

  @IsOptional()
  @IsString()
  @MaxLength(15)
  contact?: string;

  @IsOptional()
  @IsUrl()
  website?: string;

  @IsOptional()
  @IsInt()
  adminlic?: number;

  @IsOptional()
  @IsInt()
  teacherlic?: number;

  @IsOptional()
  @IsInt()
  studentlic?: number;

  @IsOptional()
  @IsString()
  subscription?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  descriptive?: string;

  @IsOptional()
  @IsString()
  @MaxLength(10)
  status?: string;

  @IsOptional()
  createdate?: string;

  @IsOptional()
  updatedate?: string;
}
