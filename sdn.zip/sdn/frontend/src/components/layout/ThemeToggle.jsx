// ThemeToggle.jsx
import React from "react";
import { useTheme } from "./ThemeContext"; // 👈 import the hook

const themes = [
  { name: "blue", label: " Light" },
  { name: "green", label: " Green" },
  { name: "purple", label: " Purple" },
  { name: "orange", label: " orange" },
  // { name: "white", label: "white" },
];

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();

  return (
    <div className="dropdown" style={{ position: 'fixed', top: '2rem', right: '1rem', zIndex: 999 }}>
      <button
        className="btn btn-outline-primary dropdown-toggle"
        type="button"
        data-bs-toggle="dropdown"
        aria-expanded="false"
      >
        {theme}
      </button>
      <ul className="dropdown-menu">
        {themes.map((t) => (
          <li key={t.name}>
            <button
              className={`dropdown-item ${theme === t.name ? "active" : ""}`}
              onClick={() => setTheme(t.name)}
            >
              {t.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ThemeToggle;
