import { FaCheckCircle } from "react-icons/fa";
import { BiSolidXCircle } from "react-icons/bi";
import UserServices from '../api/UserServices';
import { useEffect, useState } from 'react';
import useAuth from '../context/AuthContext';
import { useParams } from 'react-router-dom';

function UserProfile() {
  const { userid } = useParams();
  const { user } = useAuth();
  const uid = userid ? userid : user.id;
   const [data, setData] = useState(null);

   useEffect(() => {
    const fetchData = async () => {      
      try {
        const response = await UserServices.getUser({
          params: { id: uid },
        });
        console.log('User profile data:', response.userdata);
        setData(response.userdata);
      } catch (error) {
        console.error('Error fetching user profile:', error);
      }
    }
    fetchData();
  }, [uid]);

  if (!data) {
    return <div className="container p-4">Loading...</div>;
  } 


  // const data = {
  //   name: "Himani Chauhan",
  //   email: "himani@gmail.com",
  //   address: "Noida",
  //   mobile: "+91 0000000000",
  //   dob: "2004-02-05",
  //   gender: "Female",
  //   designation: "Teacher",
  //   userID: "san12345",
  //   role: "teacher",
  // };
  return (
    <div className="container p-4">
      <div className="card shadow-sm bg-white">
        <div className="card-body">
          <div className="row align-items-center mb-4">
            <div className="col-md-2 d-flex justify-content-center mb-3 mb-md-0">
              <img
                src=""                
                className="card-img-top"
                width="96"
                height="96"
              />
            </div>
            <div className="col-md-7">
              <div className="row mt-3">
                <div className="col-12 col-sm-6 mb-2">
                  <div className="fw-semibold text-uppercase fs-4">{data.name}</div>
                  <p className="fs-12">
                    {data.classTeacher ? `Class Teacher: ${data.classTeacher}, Section: ${data.section}` : ''}
                  </p>
                  <p className="fs-12">
                    {data.role}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <hr />

          <div className="mb-4">
            <div className=" fw-bold small fs-5 mb-3">Personal Details</div>
            <div className="row gy-3">
              <div className="col-6 col-md-4">
                <div className="text-muted small ps-3">USER ID</div>
                <div className="fw-semibold ps-3 ">{data.userid}</div>
              </div>
              <div className="col-6 col-md-4">
                <div className="text-muted small">EMAIL</div>
                <div className="fw-semibold">{data.email}</div>
              </div>
              <div className="col-6 col-md-4">
                <div className="text-muted small">CONTACT</div>
                <div className="fw-semibold">{data.mobileno}</div>
              </div>
              <div className="col-6 col-md-4">
                <div className="text-muted small ps-3">DESIGNATION</div>
                <div className="fw-semibold ps-3">{data.designation}</div>
              </div>
              <div className="col-6 col-md-4">
                <div className="text-muted small">GENDER</div>
                <div className="fw-semibold">{data.gender}</div>
              </div>
              <div className="col-6 col-md-4">
                <div className="text-muted small">ADDRESS</div>
                <div className="fw-semibold">{data.address}</div>
              </div>
            </div>
          </div>
          <hr />
          
          <div className="mb-3">
            <div className="mb-2  fw-bold fs-5">Teaching Plan Overview</div>
            <table className="table table-sm">
              <thead>
                <tr>
                  <th className="col w-50  ps-3">List of Subjects</th>
                  <th className="col w-50 ">List of Classes</th>
                </tr>
              </thead>
              <tbody>
              {data?.teacherSubject?.map((v, index) => (
                <tr key={index}>
                  <td className="ps-3">{v.subjectId}</td>
                  <td>
                    {v.classIds?.map((clsId, idx) => (
                      <span key={idx} className="badge bg-secondary me-2">
                        {clsId}
                      </span>
                    ))}
                  </td>
                </tr>
              ))}
                
              </tbody>
            </table>
          </div>

          <div className="mb-3">
            <div className="mb-2  p-1 fw-bold fs-5">Question Bank Development</div>
            <table className="table table-sm">
              <thead>
                <tr>
                  <th className="col-md-3  text-center">Assign Subjects</th>
                  <th className="col-md-3  text-center ">Assign Classes</th>
                  <th className="col-md-2  text-center">View Item</th>
                  <th className="col-md-2  text-center">Write & Edit Item </th>
                  <th className="col-md-2  text-center">Approve Item</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="text-center">Math</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">6</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-danger text-center"><BiSolidXCircle size={19} /></td>
                </tr>
                <tr>
                  <td className="text-center">Physics</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">8</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-danger text-center"><BiSolidXCircle size={19} /></td>
                </tr>
                <tr>
                  <td className="text-center">Math</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">7</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mb-3">
            <div className="mb-2  p-1 fw-bold fs-5">Exam & Report of Assign Classes</div>
            <table className="table table-sm">
              <thead>
                <tr>
                   <th className="col-md-3  text-center">Assign Subjects</th>
                  <th className="col-md-3  text-center">Assign Classes</th>
                 
                  <th className="col-md-3  text-center ">Report View & Approve</th>
                  <th className="col-md-3  text-center">Exam View & Approve</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="text-center">Math</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">7</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                </tr>
                <tr>
                  <td className="text-center">Math</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">6</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-danger text-center"><BiSolidXCircle size={19} /></td>
                </tr>
                <tr>
                  <td className="text-center">Physics</td>
                  <td className="text-center"><span className="badge bg-secondary me-2">8</span></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                  <td className="text-success text-center"><FaCheckCircle /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
export default UserProfile;