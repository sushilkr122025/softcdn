import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
    DndContext,
    closestCenter,
    PointerSensor,
    useSensor,
    useSensors,
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    useSortable,
    verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { FaArrowsAlt, FaGripHorizontal, FaPlus, FaMinus, FaList } from "react-icons/fa";
import { AiOutlineColumnWidth, AiOutlineColumnHeight } from "react-icons/ai";
import { useLocation, useNavigate } from 'react-router-dom';
import { FaPen } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import ShowMessage from '../../components/ShowMessage';

const normalizeQuestions = (raw = []) =>
    raw.map((r) => {
        const questionText = r.question ?? r.text ?? "";
        const optA = r.optA ?? (Array.isArray(r.options) ? r.options[0] ?? "" : "");
        const optB = r.optB ?? (Array.isArray(r.options) ? r.options[1] ?? "" : "");
        const optC = r.optC ?? (Array.isArray(r.options) ? r.options[2] ?? "" : "");
        const optD = r.optD ?? (Array.isArray(r.options) ? r.options[3] ?? "" : "");

        const base = { ...(r || {}) };
        delete base.text;
        delete base.options;

        return {
            ...base,
            question: questionText,
            optA: optA ?? "",
            optB: optB ?? "",
            optC: optC ?? "",
            optD: optD ?? "",
            marks: r.marks ?? null,
            image: r.image ?? null,
        };
    }
    );

const Toolbar = ({ onAction, optionLayout, fontSize, currentMarks, selectedImageSize, optionIdType, setOptionIdType, onDelete }) => (
    <div className="d-flex gap-3 mb-2 px-3 toolcontainer rounded bg-opacity-10">
        <div className='border-end pe-3'>
            <div className='my-2 btn-group justify-content-between' role="group">
                <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => onAction("increaseText")}>
                    <FaPlus />
                </button>
                <span type="button" className='btn btn-sm btn-outline-secondary p-0 m-0' >
                    <select
                        type="button"
                        value={fontSize}
                        onChange={(e) => onAction("setFontSize", parseInt(e.target.value))}
                        className="form-select toolbar-select "
                    >
                        {[12, 14, 16, 18, 20, 22, 24, 26, 28].map((size) => (
                            <option key={size} value={size}>
                                {size}
                            </option>
                        ))}
                    </select>
                </span>
                <button className='btn btn-sm btn-outline-secondary' onClick={() => onAction("decreaseText")}>
                    <FaMinus />
                </button>
            </div>
        </div>
        {selectedImageSize.width &&
            (<div className='border-end pe-3'>
                <div className='my-2 btn-group justify-content-between' role="group">
                    <input
                        type="number"
                        value={selectedImageSize?.width || ""}
                        onChange={(e) => onAction("setImageWidth", parseInt(e.target.value) || 0)}
                        className='btn btn-outline-secondary input-container'
                    />
                    <div type="button" className="btn pt-1 btn-outline-secondary" >
                        <AiOutlineColumnWidth size={22} />
                    </div>
                    <div type="button" className="btn pt-1 btn-outline-secondary" >
                        <AiOutlineColumnHeight size={22} />
                    </div>
                    <input
                        type="number"
                        value={selectedImageSize?.height || ""}
                        onChange={(e) => onAction("setImageHeight", parseInt(e.target.value) || 0)}
                        className='btn  btn-outline-secondary input-container'
                    />
                </div>
            </div>)
        }
        <div className='border-end pe-3'>
            <div className="my-2">
                <button
                    className="btn btn-outline-secondary dropdown-toggle"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    Marks: {currentMarks ?? ""}
                </button>
                <ul className="dropdown-menu text-center" style={{ maxHeight: "200PX", overflow: "auto" }}>
                    {["", 0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 6, 7, 8].map((m) => (
                        <li className={`dropdown-item border-bottom cursor ${currentMarks === m ? "active" : ""}`} key={m} onClick={() => onAction("setMarks", m)}>
                            {m}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
        <div className='border-end pe-3'>
            <div className="my-2">
                <button
                    className="btn dropdown-toggle d-flex align-items-center justify-content-center btn-outline-secondary"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    <FaList size={25} className='pe-2' /> {optionIdType || "  "}
                </button>

                <ul className="dropdown-menu text-center">
                    {["A", "a", "1", "i", "I"].map((opt) => (
                        <li key={opt}>
                            <button
                                type="button"
                                className={`dropdown-item border-bottom ${optionIdType === opt ? "active" : ""}`}
                                onPointerDown={(e) => {
                                    e.preventDefault();
                                    setOptionIdType(opt);
                                }}
                                onClick={() => setOptionIdType(opt)}
                                aria-pressed={optionIdType === opt}
                            >
                                {opt}
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
        <div className='border-end pe-3'>
            <div className="my-2">
                <button
                    type="button"
                    className="btn btn-sm btn-outline-secondary p-2 "
                    onClick={() => onAction("toggleLayout")}
                >
                    {optionLayout === "vertical" && <FaGripHorizontal />}
                    {optionLayout === "horizontal" && <FaGripHorizontal />}
                    {optionLayout === "two-column" && <FaGripHorizontal />}
                </button>
            </div>
        </div>
        <div className='border-end pe-3'>
            <div className="my-2">
                <button
                    className="btn dropdown-toggle d-flex align-items-center justify-content-center btn-outline-secondary"
                    type="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                >
                    Optional Q..
                </button>
                <ul className="dropdown-menu text-center pointer">
                    <li className='dropdown-item' onClick={() => onAction("addConnector", "OR")}>
                        OR
                    </li>
                    <li className='dropdown-item' onClick={() => onAction("addConnector", "AND")}>
                        AND
                    </li>
                </ul>
            </div>
        </div>
        <div className="border-end pe-3">
            <button
                className="btn btn-sm btn-outline-secondary p-2 my-2"
                type="button"
                onClick={() => {
                    if (typeof onDelete === "function") {
                        if (window.confirm("Remove this question?")) {
                            onDelete();
                        }
                    }
                }}>
                <MdDelete size={18} />
            </button>
        </div>
    </div>
);

export function SortableQuestion({
    question,
    index,
    displayIndex,
    handleChangeMarks,
    optionIdType,
    setOptionIdType,
    ui = {},
    updateUi = () => { },
    onDelete,
    onAddConnector
}) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
        id: question.id,
    });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        padding: "10px",
    };

    const [fontSize, setFontSize] = useState(ui.fontSize ?? 16);
    const [align, setAlign] = useState(ui.align ?? "left");
    const [imageSizes, setImageSizes] = useState(ui.imageSizes ?? {});
    const [selectedImageKeys, setSelectedImageKeys] = useState(new Set(ui.selectedImageKeys ?? []));
    const [optionLayout, setOptionLayout] = useState(ui.optionLayout ?? "vertical");

    useEffect(() => {
        if (!ui) return;
        if (ui.fontSize !== undefined) setFontSize(ui.fontSize);
        if (ui.align) setAlign(ui.align);
        if (ui.imageSizes) setImageSizes(ui.imageSizes);
        if (ui.selectedImageKeys !== undefined) setSelectedImageKeys(new Set(ui.selectedImageKeys));
        if (ui.optionLayout) setOptionLayout(ui.optionLayout);
    }, [ui]);

    const handleToolbarAction = (action, value) => {
        const firstSelected = [...selectedImageKeys][0];

        if (firstSelected) {
            if (action === "setImageWidth" || action === "setImageHeight") {
                setImageSizes((prev) => {
                    const current = prev[firstSelected] || { width: 120, height: 50 };
                    const next = {
                        ...prev,
                        [firstSelected]: {
                            ...current,
                            width: action === "setImageWidth" ? (value || 50) : current.width,
                            height: action === "setImageHeight" ? (value || 50) : current.height
                        }
                    };
                    updateUi({ imageSizes: next, selectedImageKeys: [firstSelected] });
                    return next;
                });
                return;
            }
        }
        switch (action) {
            case "increaseText":
                setFontSize((f) => {
                    const next = f + 2;
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "decreaseText":
                setFontSize((f) => {
                    const next = Math.max(10, f - 2);
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "setFontSize":
                setFontSize(value);
                updateUi({ fontSize: value });
                break;
            case "setMarks":
                if (handleChangeMarks) {
                    handleChangeMarks(question.id, value);
                }
                break;
            case "toggleLayout":
                setOptionLayout((prev) => {
                    const next =
                        prev === "vertical" ? "horizontal" :
                            prev === "horizontal" ? "two-column" :
                                "vertical";
                    updateUi({ optionLayout: next });
                    return next;
                });
                break;
            case "addConnector":
                if (typeof onAddConnector === "function") {
                    onAddConnector(question.id, value);
                }
                break;
            default:
                break;
        }
    };

    function removeInlineStyles(html) {
        if (!html) return "";
        html = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        return html;
    }

    function parseQuestionText(html, questionId) {
        if (!html) return null;
        const cleanHtml = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        const parts = [];
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(cleanHtml)) !== null) {
            if (match.index > lastIndex) {
                const chunk = cleanHtml.slice(lastIndex, match.index);
                parts.push(
                    <span
                        key={`chunk-${lastIndex}`}
                        dangerouslySetInnerHTML={{ __html: chunk }}
                    />
                );
            }

            const src = match[1];
            const imgKey = `q-${questionId}-text-img-${match.index}`;
            parts.push(
                <img
                    key={imgKey}
                    src={src}
                    alt=""
                    onClick={() => {
                        setSelectedImageKeys(new Set([imgKey]));
                        setImageSizes((prev) => {
                            if (prev[imgKey]) {
                                updateUi({ selectedImageKeys: [imgKey] });
                                return prev;
                            }
                            const next = {
                                ...prev,
                                [imgKey]: { width: 120, height: 50 }
                            };
                            updateUi({ imageSizes: next, selectedImageKeys: [imgKey] });
                            return next;
                        });
                    }}
                    onPointerDown={(e) => e.stopPropagation()}
                    style={{
                        width: imageSizes[imgKey]?.width || 120,
                        height: imageSizes[imgKey]?.height || 50,
                        border: selectedImageKeys.has(imgKey) ? "2px solid blue" : "none",
                        cursor: "pointer",
                        margin: "5px 0"
                    }}
                />
            );
            lastIndex = imgRegex.lastIndex;
        }
        if (lastIndex < cleanHtml.length) {
            const chunk = cleanHtml.slice(lastIndex);
            parts.push(
                <span
                    key={`chunk-${lastIndex}`}
                    dangerouslySetInnerHTML={{ __html: chunk }}
                />
            );
        }
        return parts;
    }

    const effectiveOptionIdType = ui?.optionIdType || optionIdType;
    const getOptionLabel = (i) => {
        switch (effectiveOptionIdType) {
            case "A":
                return String.fromCharCode(65 + i);
            case "a":
                return String.fromCharCode(97 + i);
            case "1":
                return i + 1;
            case "i":
                return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][i] || i + 1;
            case "I":
                return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][i] || i + 1;
            default:
                return String.fromCharCode(65 + i);
        }
    };

    useEffect(() => {
        function handleClickOutside(e) {
            if (
                selectedImageKeys.size > 0 &&
                !e.target.closest("img") &&
                !e.target.closest(".toolcontainer")
            ) {
                setSelectedImageKeys(new Set());
                updateUi({ selectedImageKeys: [] });
            }
        }
        document.addEventListener("click", handleClickOutside);
        return () => document.removeEventListener("click", handleClickOutside);
    }, [selectedImageKeys, updateUi]);

    const mainImgKey = `q-${question.id}-main`;

    const optionsContainerStyle = {
        fontSize: `${fontSize}px`,
        textAlign: align,
        display: "flex",
        flexDirection: optionLayout === "vertical" ? "column" : "row",
        flexWrap: optionLayout === "two-column" ? "wrap" : "nowrap",
        gap: optionLayout === "horizontal" ? "40px" : "10px",
        alignItems: optionLayout === "vertical" ? "flex-start" : "center",
    };

    const rawOptionsOrdered = [
        { key: "optA", value: question.optA ?? "" },
        { key: "optB", value: question.optB ?? "" },
        { key: "optC", value: question.optC ?? "" },
        { key: "optD", value: question.optD ?? "" },
    ].filter(o => o.value && String(o.value).trim() !== "");

    const questionHtmlForUI = question.question ?? "";

    return (
        <div ref={setNodeRef} style={style} className="mb-3 border p-2 rounded bg-white">
            <Toolbar
                onAction={handleToolbarAction}
                optionLayout={optionLayout}
                fontSize={fontSize}
                currentMarks={question.marks}
                optionIdType={effectiveOptionIdType}
                setOptionIdType={(val) => {
                    setOptionIdType(val);
                    updateUi({ optionIdType: val });
                }}
                selectedImageSize={
                    [...selectedImageKeys].length > 0
                        ? imageSizes[[...selectedImageKeys][0]]
                        : { width: "", height: "" }
                }
                onDelete={() => onDelete?.(index)}
            />
            <div style={{ fontSize: `${fontSize}px`, textAlign: align }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div className="question-html d-flex flex-grow-1">
                        {!question.isConnector && (<span
                            className="me-2"
                            style={{ cursor: "grab" }}
                            {...attributes}
                            {...listeners}
                        >
                            <FaArrowsAlt />
                        </span>)
                        }
                        {question.isConnector ? (
                            <div className="w-100">
                                <div className="fw-bold text-center connector-row" style={{ padding: "8px 0" }}>
                                    {question.connector || ""}
                                </div>
                            </div>
                        ) : (
                            <>
                                {question.isSub ? (
                                    <div className="d-flex flex-column">
                                        <div className="question-html d-flex flex-column align-items-start questionstylecustom">
                                            {parseQuestionText(removeInlineStyles(questionHtmlForUI), question.id)}
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <strong className="me-1">{`Ques.${displayIndex}`}</strong>{" "}
                                        <div className="question-html d-flex flex-column align-items-start questionstylecustom">
                                            {parseQuestionText(removeInlineStyles(questionHtmlForUI), question.id)}
                                        </div>
                                    </>
                                )}
                            </>
                        )}
                    </div>

                    {question.marks && !question.isConnector && (
                        <div style={{ marginLeft: "20px", whiteSpace: "nowrap" }}>({question.marks})</div>
                    )}
                </div>

                {!question.isConnector && question.image && (
                    <img
                        src={question.image}
                        alt="question"
                        onClick={() => {
                            const key = mainImgKey;
                            setSelectedImageKeys(new Set([key]));
                            setImageSizes(prev => {
                                if (prev[key]) {
                                    updateUi({ selectedImageKeys: [key] });
                                    return prev;
                                }
                                const next = { ...prev, [key]: { width: 120, height: 50 } };
                                updateUi({ imageSizes: next, selectedImageKeys: [key] });
                                return next;
                            });
                        }}
                        onPointerDown={(e) => e.stopPropagation()}
                        style={{
                            width: imageSizes[mainImgKey]?.width || 120,
                            height: imageSizes[mainImgKey]?.height || 50,
                            border: selectedImageKeys.has(mainImgKey) ? "2px solid blue" : "none",
                            cursor: "pointer",
                            margin: "5px 0"
                        }}
                    />
                )}
            </div>

            {!question.isConnector && (
                <div className="mt-2" style={optionsContainerStyle}>
                    {rawOptionsOrdered.map((optObj, i) => {
                        const opt = optObj.value;

                        const optionItemStyle = {
                            display: "flex",
                            alignItems: "center",
                            width: optionLayout === "two-column" ? "45%" : "auto",
                            minWidth: optionLayout === "two-column" ? "200px" : "auto",
                            marginBottom: optionLayout === "vertical" ? "8px" : "0",
                        };

                        return (
                            <div key={optObj.key} style={optionItemStyle}>
                                <span className="fw-bold me-2">{getOptionLabel(i)}.</span>

                                <div className="option-html d-flex align-items-center">
                                    <span dangerouslySetInnerHTML={{ __html: removeInlineStyles(opt) }} />
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

const QuestionPreview = () => {
    const [active, setActive] = useState(true);
    const location = useLocation();
    const navigate = useNavigate();
    const { selectedQuestion = [], filter = {}, paperinfo = {} } = location.state || {};
    const [questions, setQuestions] = useState(() => normalizeQuestions(selectedQuestion));
    const sensors = useSensors(useSensor(PointerSensor));
    const [showToast, setShowToast] = useState(false);
    const [totalMarks, setTotalMarks] = useState(0);

    const handleDelete = (idOrIndex) => {
        setQuestions((prev) => {
            let next = prev;
            let removedItem = null;
            let removedIndex = -1;
            if (typeof idOrIndex === "number") {
                if (idOrIndex >= prev.length) return prev;
                removedItem = prev[idOrIndex];
                removedIndex = idOrIndex;
                next = prev.filter((_, idx) => idx !== idOrIndex);

                if (removedItem?.id !== undefined) {
                    setUiSettings((prevUi) => {
                        const copy = { ...(prevUi || {}) };
                        if (Object.hasOwn(copy, removedItem.id)) delete copy[removedItem.id];
                        return copy;
                    });
                }
            } else {
                removedIndex = prev.findIndex(q => q.id === idOrIndex);
                removedItem = prev.find(q => q.id === idOrIndex);
                next = prev.filter((q) => q.id !== idOrIndex);
                setUiSettings((prevUi) => {
                    const copy = { ...(prevUi || {}) };
                    if (Object.hasOwn(copy, idOrIndex)) delete copy[idOrIndex];
                    return copy;
                });
            }
            if (removedItem?.isConnector) {
                const nextRow = next[removedIndex];
                if (nextRow && nextRow.isSub) {
                    next[removedIndex] = {
                        ...nextRow,
                        isSub: false,
                        connector: null,
                    };
                }
            }
            return [...next];
        });
    };

    const handleDragEnd = (event) => {
        const { active, over } = event;
        if (!over) return;
        if (active.id !== over?.id) {
            const oldIndex = questions.findIndex((q) => q.id === active.id);
            const newIndex = questions.findIndex((q) => q.id === over?.id);
            if (oldIndex !== -1 && newIndex !== -1) {
                setQuestions(arrayMove(questions, oldIndex, newIndex));
            }
        }
    };

    const [optionIdType, setOptionIdType] = useState("A");
    const previewRef = useRef(null);
    const LOCAL_STORAGE_KEY = 'qb_ui_settings';
    const [generalDetails, setGeneralDetails] = useState({
        paperName: paperinfo.paperName,
        duration: paperinfo.duration,
        session: paperinfo.session,
        className: filter.std,
        sections: paperinfo.sections,
        maxMarks: paperinfo.maxMarks,
        subjectName: filter.subject ? (filter.SubjectData.find((e) => e.id == filter.subject).subject) : "-",
        examdate: paperinfo.examdate,
        generalInstruction: paperinfo.generalInstruction
    });

    const handleAddMore = () => {
        navigate("/question", { state: { previouslySelected: questions, previousFilter: filter, generaldetail: generalDetails } });
    };

    const [uiSettings, setUiSettings] = useState(() => {
        try {
            const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed === 'object' && parsed.uiSettings) return parsed.uiSettings;
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
            return {};
        } catch (e) {
            console.error("Failed to parse local storage data", e);
            return {};
        }
    });

    const unwrapSavedWrapper = (html) => {
        if (!html || typeof html !== 'string') return html;
        const wrapperRegex = /^<div[^>]*style\s*=\s*(['"])(?:(?!\1)[\s\S])*?(?:font-size|text-align)[\s\S]*?\1[^>]*>([\s\S]*?)<\/div>$/i;
        const m = html.match(wrapperRegex);
        if (m && m[2] !== undefined) {
            return m[2];
        }
        return html;
    };

    useEffect(() => {
        const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (!raw) return;
        let parsed;
        try {
            parsed = JSON.parse(raw);
        } catch (e) {
            console.error("Failed to parse data", e);
            return;
        }
        if (parsed.questions) {
            const normalized = parsed.questions.map(q => {
                const questionText = unwrapSavedWrapper(q.question ?? q.text ?? "");
                const optA = q.optA ?? (Array.isArray(q.options) ? q.options[0] ?? "" : "");
                const optB = q.optB ?? (Array.isArray(q.options) ? q.options[1] ?? "" : "");
                const optC = q.optC ?? (Array.isArray(q.options) ? q.options[2] ?? "" : "");
                const optD = q.optD ?? (Array.isArray(q.options) ? q.options[3] ?? "" : "");

                return {
                    ...q,
                    question: questionText,
                    optA: optA ?? "",
                    optB: optB ?? "",
                    optC: optC ?? "",
                    optD: optD ?? "",
                    marks: q.marks ?? null,
                    image: q.image ?? null,
                };
            });

            setQuestions(normalized);
        }

        if (parsed.generalDetails) setGeneralDetails(parsed.generalDetails);

        const uiMap = {};
        parsed.questions?.forEach(q => {
            if (q.ui) uiMap[q.id] = q.ui;
        });
        setUiSettings(uiMap);
    }, []);

    useEffect(() => {
        const CalculatedMarks = questions.reduce((sum, q) => {
            // ignore connector rows when summing marks
            if (q.isConnector) return sum;
            return sum + (parseFloat(q.marks) || 0);
        }, 0);
        setTotalMarks(CalculatedMarks);
    }, [questions]);

    const uiPatchQueue = useRef([]);
    const uiFlushScheduled = useRef(false);

    const flushUiQueue = useCallback(() => {
        if (uiPatchQueue.current.length === 0) {
            uiFlushScheduled.current = false;
            return;
        }
        setUiSettings(prev => {
            const next = { ...(prev || {}) };
            for (const { questionId, patch } of uiPatchQueue.current) {
                next[questionId] = {
                    ...(next[questionId] || {}),
                    ...patch
                };
            }
            return next;
        });
        uiPatchQueue.current = [];
        uiFlushScheduled.current = false;
    }, []);

    const updateUiForQuestion = useCallback((questionId, patch) => {
        uiPatchQueue.current.push({ questionId, patch });
        if (!uiFlushScheduled.current) {
            uiFlushScheduled.current = true;
            setTimeout(() => {
                flushUiQueue();
            }, 0);
        }
    }, [flushUiQueue]);

    useEffect(() => {
        setUiSettings(prev => {
            const copy = { ...(prev || {}) };
            let changed = false;
            questions.forEach(q => {
                if (!copy[q.id]) {
                    copy[q.id] = {
                        fontSize: 16,
                        align: 'left',
                        optionLayout: 'vertical',
                        optionIdType: optionIdType || 'A',
                        imageSizes: {},
                        selectedImageKey: null,
                    };
                    changed = true;
                } else {
                    if (copy[q.id].marks === undefined) { copy[q.id].marks = q.marks || null; changed = true; }
                    if (!copy[q.id].optionIdType) { copy[q.id].optionIdType = optionIdType || 'A'; changed = true; }
                }
            });
            return changed ? copy : prev;
        });
    }, [questions, optionIdType]);

    const handleChangeMarks = (id, newMarks) => {
        setQuestions((prev) =>
            prev.map((q) =>
                q.id === id ? { ...q, marks: newMarks } : q
            )
        );
    };

    const handleSetOptionIdTypeGlobal = (questionId, val) => {
        setOptionIdType(val);
        updateUiForQuestion(questionId, { optionIdType: val });
    };

    const sanitizeHtml = (html) => {
        if (!html) return "";
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        // Remove inline font-size from any element
        html = html.replace(/font-size\s*:\s*[^;"]+;?/gi, "");
        return html;
    };

    const handleSaveChanges = () => {
        if (totalMarks == generalDetails.maxMarks) {
            try {
                const mergedQuestions = questions.map((q, idx) => {
                    const ui = uiSettings[q.id] || {};
                    const uiToSave = JSON.parse(JSON.stringify(ui || {}));
                    if (Object.hasOwn(uiToSave, 'marks')) delete uiToSave.marks;
                    return {
                        id: q.id !== undefined ? q.id : `temp-${idx}`,
                        sequence: idx + 1,
                        marks: q.marks ?? null,
                        isConnector: q.isConnector,
                        connector: q.connector ?? null,
                        ui: uiToSave
                    };
                });

                const payload = {
                    questions: mergedQuestions,
                    generalDetails
                };

                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(payload));
                setShowToast(true);
            } catch (e) {
                alert("Save failed — see console");
                console.error(e);
            }
        } else {
            setShowToast(true)
            setTimeout(() => {
                setShowToast(false)
            }, 5000);
        }
    };

    const handlePrint = () => {
        if (!previewRef.current) return;
        const printContents = previewRef.current.innerHTML;
        const originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
        window.location.reload();
    };

    const renderHtmlWithImages = (html, qId, kind, ui) => {
        if (!html) return null;
        html = sanitizeHtml(html);
        const parts = [];
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(html)) !== null) {
            if (match.index > lastIndex) {
                const chunk = html.slice(lastIndex, match.index);
                parts.push(
                    <span
                        key={`chunk-${qId}-${kind}-${lastIndex}`}
                        dangerouslySetInnerHTML={{ __html: chunk }}
                    />
                );
            }
            const src = match[1];
            const imgKey = kind === 'text'
                ? `q-${qId}-text-img-${match.index}`
                : `q-${qId}-${kind}-text-img-${match.index}`;
            const sizing = ui?.imageSizes?.[imgKey] || {};
            parts.push(
                <img
                    key={`img-${qId}-${kind}-${match.index}`}
                    src={src}
                    alt=""
                    style={{
                        width: sizing.width || 120,
                        height: sizing.height || 50,
                        margin: "5px 0",
                    }}
                />
            );
            lastIndex = imgRegex.lastIndex;
        }

        if (lastIndex < html.length) {
            const chunk = html.slice(lastIndex);
            parts.push(
                <div
                    key={`chunk-${qId}-${kind}-${lastIndex}`}
                    dangerouslySetInnerHTML={{ __html: chunk }}
                />
            );
        }

        return parts;
    };

    const handleAddConnector = (questionId, connector) => {
        setQuestions(prev => {
            const idx = prev.findIndex(q => q.id === questionId);
            if (idx === -1) return prev;

            const newConnector = {
                id: `connector-${questionId}`,
                isConnector: true,
                connector: connector,
            };

            const next = [...prev];

            if (idx + 1 <= next.length) {
                next.splice(idx + 1, 0, newConnector);
                const originalNextIdx = idx + 2;
                const originalNext = next[originalNextIdx];
                if (originalNext) {
                    next[originalNextIdx] = {
                        ...originalNext,
                        isSub: true,
                        connector: connector,
                    };
                }
                return next;
            }
        });
    };

    return (
        <div className="p-lg-4">
            <div className='container-fluid QuestionExport-container'>
                <div className="row h-85vh">
                    <div className="col-12 mx-auto content-bg rounded-lg p-lg-4 py-40">
                        <h5 className='headingmain mb-0'>Question Design & Preview</h5>
                        <div className="border-0 rounded-0">
                            <div className="d-flex flex-column">
                                <div className='d-flex border-bottom align-items-center my-2'>
                                    <div
                                        className={`ps-1 pe-2 py-2 cursor-pointer ${active ? 'underline' : 'text-muted'}`}
                                        onClick={() => setActive(true)}
                                    >
                                        Design
                                    </div>
                                    <div
                                        className={`ps-1 pe-2 py-2 cursor-pointer ${active ? 'text-muted' : 'underline'}`}
                                        onClick={() => setActive(false)}
                                    >
                                        Preview
                                    </div>
                                    {active && (<button
                                        className="btn btn-secondary btn-sm ms-auto no-print"
                                        type="button"
                                        onClick={handleSaveChanges}
                                    >
                                        Save Changes
                                    </button>)}
                                    {!active && (
                                        <button
                                            className="btn btn-secondary btn-sm px-3 ms-auto no-print"
                                            type="button"
                                            onClick={handlePrint}
                                        >
                                            Print
                                        </button>
                                    )}
                                </div>

                                {active ? (
                                    <>
                                        <div className='row  themeUnderline mx-1'>
                                            <div className="col-12 border-bottom pb-3 fs-14">
                                                <div className="row">
                                                    <div className="col-12 px-2 py-3">
                                                        <h6 className='Question-header-color mb-0 d-flex align-items-center'>General Details
                                                            <FaPen size={15} className='ms-1' />
                                                        </h6>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0">
                                                        <div className='fw-bold'>Paper Name</div>
                                                    </div>
                                                    <div className="col-4 text-start p-0 text-muted">
                                                        <input
                                                            type='text'
                                                            className='text-nowrap border-0 w-100'
                                                            value={generalDetails.paperName}
                                                            onChange={(e) => setGeneralDetails({ ...generalDetails, paperName: e.target.value })}
                                                        />
                                                    </div>
                                                    <div className="col-2 text-start p-0">
                                                        <div className='fw-bold'>Duration</div>
                                                    </div>
                                                    <div className="col-3 p-0 text-muted text-start">
                                                        <input
                                                            type='text'
                                                            className='text-nowrap border-0 w-100'
                                                            value={generalDetails.duration}
                                                            onChange={(e) => setGeneralDetails({ ...generalDetails, duration: e.target.value })}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0">
                                                        <div className='fw-bold'>Class</div>
                                                    </div>
                                                    <div className="col-4 text-start p-0">
                                                        <div className='text-nowrap border-0'>
                                                            {generalDetails.className}
                                                        </div>
                                                    </div>
                                                    <div className="col-2 p-0">
                                                        <div className='fw-bold'>Max marks</div>
                                                    </div>
                                                    <div className="col-3 p-0 text-muted text-start">
                                                        <input
                                                            type='text'
                                                            className='text-nowrap border-0 w-100'
                                                            value={generalDetails.maxMarks}
                                                            onChange={(e) => setGeneralDetails({ ...generalDetails, maxMarks: e.target.value })}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0">
                                                        <div className='fw-bold'>Subject Name</div>
                                                    </div>
                                                    <div className="col-4 text-start p-0">
                                                        <div>
                                                            {generalDetails.subjectName}
                                                        </div>
                                                    </div>
                                                    <div className="col-2 text-start p-0">
                                                        <div className='fw-bold'>Date</div>
                                                    </div>
                                                    <div className="col-3 p-0 text-muted text-start">
                                                        <input
                                                            type='date'
                                                            className='text-nowrap border-0 '
                                                            value={generalDetails.examdate}
                                                            onChange={(e) => setGeneralDetails({ ...generalDetails, examdate: e.target.value })}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-12 pb-3 fs-13">
                                                <div className="row">
                                                    <div className="col-12 p-0 p-2 py-3">
                                                        <h6 className='Question-header-color mb-0 d-flex align-items-center'>General Instruction <FaPen size={15} className='ms-1' />
                                                        </h6>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-12">
                                                        <pre className='fw-semibold ps-2 fs-6 mb-0'>{generalDetails.generalInstruction}</pre>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-12 px-4 my-3 d-flex justify-content-between align-items-center">
                                                <h6 className='Question-header-color mb-0 d-flex align-items-center'>
                                                    Questions<FaPen size={15} className='ms-1' />
                                                </h6>
                                                <div>
                                                    <div className={`position-fixed btn btn-sm ${totalMarks == generalDetails.maxMarks ? "btn-success" : totalMarks > generalDetails.maxMarks ? "btn-danger" : "btn-warning"} me-3`} style={{ bottom: "50px" }}>Total Marks {totalMarks} of {generalDetails.maxMarks}</div>
                                                    <button className="Question-header-color btn btn-sm btn-secondary me-3" onClick={handleAddMore}>
                                                        + Questions
                                                    </button>
                                                </div>
                                            </div>
                                            <div className="container px-5">
                                                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                                    <SortableContext items={questions.map((q) => q.id)} strategy={verticalListSortingStrategy}>
                                                        {questions.map((q, index) => {
                                                            const displayIndex = questions.slice(0, index + 1).filter(x => !x.isSub && !x.isConnector).length;
                                                            return (
                                                                <SortableQuestion
                                                                    key={q.id}
                                                                    question={q}
                                                                    index={index}
                                                                    displayIndex={displayIndex}
                                                                    handleChangeMarks={handleChangeMarks}
                                                                    optionIdType={optionIdType}
                                                                    setOptionIdType={(val) => handleSetOptionIdTypeGlobal(q.id, val)}
                                                                    ui={uiSettings[q.id] || {}}
                                                                    updateUi={(patch) => updateUiForQuestion(q.id, patch)}
                                                                    onDelete={handleDelete}
                                                                    onAddConnector={handleAddConnector}
                                                                />
                                                            );
                                                        })}
                                                    </SortableContext>
                                                </DndContext>
                                            </div>
                                        </div>
                                    </>
                                ) : (<>
                                    <div ref={previewRef} className="container border pt-4 pb-5 px-5 bg-white mt-2 mb-5">
                                        <div className="text-center mb-3">
                                            <h5 className="fw-semibold fs-5">{generalDetails.paperName}</h5>
                                            <div className="fw-semibold fs-6">{generalDetails.subjectName}</div>
                                            <div className="fw-semibold fs-6">{generalDetails.session}</div>
                                            <div className="fw-semibold fs-6">Class - {generalDetails.className}</div>
                                            <div className="fw-semibold fs-6">Date : {new Date(generalDetails.examdate).toLocaleDateString('en-GB').replaceAll('/', '-')}</div>
                                            <div className="d-flex justify-content-between mt-2 px-1 fs-6">
                                                <span>[<strong>Duration:</strong> {generalDetails.duration}]</span>
                                                <span>[<strong>Maximum Marks:</strong> {generalDetails.maxMarks}]</span>
                                            </div>
                                        </div>

                                        <div className="mb-3">
                                            <h6 className="fw-semibold px-1 fs-5 mb-3">General Instructions:-</h6>
                                            <div className="row">
                                                <div className="col-12">
                                                    <pre className='fw-semibold ps-3 fs-6 mb-0'>{generalDetails.generalInstruction}</pre>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="text-center mb-3">
                                            <svg width="90%" height="30" viewBox="0 0 500 30">
                                                <defs>
                                                    <marker id="diamond" viewBox="0 0 10 10" refX="5" refY="5"
                                                        markerWidth="10" markerHeight="10" orient="auto"
                                                        markerUnits="strokeWidth">
                                                        <polygon points="5,0 10,5 5,10 0,5" fill="black" />
                                                    </marker>
                                                </defs>
                                                <line x1="0" y1="15" x2="500" y2="15" stroke="black" strokeWidth="1.5"
                                                    markerStart="url(#diamond)" markerEnd="url(#diamond)" />
                                            </svg>
                                        </div>

                                        <ol className="ps-0 fs-6">
                                            {questions.map((q, i) => {
                                                const ui = uiSettings[q.id] || {};
                                                const effectiveOptionIdType = ui.optionIdType || optionIdType || 'A';
                                                const getOptionLabelForPreview = (idx) => {
                                                    switch (effectiveOptionIdType) {
                                                        case "A": return String.fromCharCode(65 + idx);
                                                        case "a": return String.fromCharCode(97 + idx);
                                                        case "1": return idx + 1;
                                                        case "i": return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][idx] || idx + 1;
                                                        case "I": return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][idx] || idx + 1;
                                                        default: return String.fromCharCode(65 + idx);
                                                    }
                                                };

                                                const displayNum = questions.slice(0, i + 1).filter(x => !x.isSub && !x.isConnector).length;

                                                const previewText = q.question ?? "";

                                                const previewOptions = [
                                                    q.optA ?? "",
                                                    q.optB ?? "",
                                                    q.optC ?? "",
                                                    q.optD ?? ""
                                                ].filter(opt => opt && String(opt).trim() !== "");

                                                if (q.isConnector) {
                                                    return (
                                                        <div key={q.id} className="my-1">
                                                            <div className="text-center fw-bold">{q.connector || ""}</div>
                                                        </div>
                                                    );
                                                }

                                                return (
                                                    <div key={i}>
                                                        <div className="d-flex justify-content-between my-1">
                                                            <div className="question-html ps-3 mt-2 d-flex"
                                                                style={{ fontSize: `${ui.fontSize || 16}px`, textAlign: ui.align || 'left' }}>
                                                                {!q.isSub ? (
                                                                    <>
                                                                        <strong className='me-2'>{`Q${displayNum}`}</strong>
                                                                        <div className='d-flex flex-column'>
                                                                            {previewText ? renderHtmlWithImages(previewText, q.id, 'text', ui) : null}
                                                                        </div>
                                                                    </>
                                                                ) : (
                                                                    <div className='d-flex flex-column ps-4'>
                                                                        <div className='d-flex flex-column'>
                                                                            {previewText ? renderHtmlWithImages(previewText, q.id, 'text', ui) : null}
                                                                        </div>
                                                                    </div>
                                                                )}
                                                            </div>
                                                            {q.marks && (
                                                                <div style={{ marginLeft: "20px", whiteSpace: "nowrap" }}>
                                                                    ({q.marks})
                                                                </div>
                                                            )}
                                                        </div>
                                                        {previewOptions?.length > 0 && (
                                                            <div
                                                                className="ps-5"
                                                                style={{
                                                                    fontSize: `${ui.fontSize || 16}px`,
                                                                    textAlign: ui.align || "left",
                                                                    display: "flex",
                                                                    flexDirection: ui.optionLayout === "vertical" ? "column" : "row",
                                                                    flexWrap: ui.optionLayout === "horizontal" || ui.optionLayout === "two-column" ? "wrap" : "nowrap",
                                                                    gap: ui.optionLayout === "horizontal" ? "40px" : "10px",
                                                                }}
                                                            >
                                                                {previewOptions.map((opt, idx) => {
                                                                    const optKind = `opt-${idx}`;
                                                                    return (
                                                                        <div
                                                                            key={idx}
                                                                            style={{
                                                                                display: "flex",
                                                                                alignItems: "center",
                                                                                width: ui.optionLayout === "two-column" ? "45%" : "auto",
                                                                                minWidth: ui.optionLayout === "two-column" ? "200px" : "auto",
                                                                            }}
                                                                        >
                                                                            <span className="fw-bold me-2">{getOptionLabelForPreview(idx)}.</span>
                                                                            <>{renderHtmlWithImages(opt, q.id, optKind, ui)}</>
                                                                        </div>
                                                                    );
                                                                })}
                                                            </div>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </ol>
                                    </div>
                                </>)}
                            </div>
                        </div>
                        <ShowMessage show={showToast} position="bottom-end" type="toast" message={`${totalMarks != generalDetails.maxMarks ? "Unsaved !! Match the total marks with maximum marks" : "Save Changes Successful!!"}`} variant={`${totalMarks != generalDetails.maxMarks ? "danger" : "success"}`}
                            btnConfirm={true} btnClose={false}
                            onClose={() => setShowToast(false)}
                            onConfirm={() => {
                                setShowToast(false);
                            }}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default QuestionPreview;
