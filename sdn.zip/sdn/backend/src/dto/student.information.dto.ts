import {
  IsString,
  IsInt,
  IsOptional,
  IsDateString,
  Length,
  MaxLength,
  IsEmail,
} from 'class-validator';

export class StudentInformationDto {
  @IsOptional()
  studentId?: string;

  @IsString()
  @IsString()
  name: string;

  @IsInt()
  rollNo: number;

  @IsOptional()
  @IsString()
  fatherName?: string;

  @IsOptional()
  @IsString()
  motherName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(15)
  gender?: string;

  @IsDateString()
  dateOfBirth: string;

  @IsInt()
  class: number;

  @IsOptional()
  @IsString()
  @Length(1, 2)
  section?: string;

  @IsOptional()
  @IsString()
  @Length(10, 10)
  contactNumber?: string;

  @IsOptional()
  @IsString()
  @Length(10, 10)
  alternativeContactNumber?: string;

  @IsOptional()
  @IsEmail()
  @MaxLength(100)
  emailId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  address?: string;

  @IsOptional()
  @IsInt()
  state?: number;

  @IsOptional()
  @IsInt()
  district?: number;

  @IsString()
  @MaxLength(50)
  tenantid: string;
}
