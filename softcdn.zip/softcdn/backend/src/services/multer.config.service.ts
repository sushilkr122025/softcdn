import { diskStorage } from 'multer';
import { join } from 'path';
import * as fs from 'fs';
import { Request } from 'express';

export const generateMulterConfig = (folderName: string) => {
  return {
    storage: diskStorage({
      destination: (req: Request, file: Express.Multer.File, cb) => {
        const setFolder = folderName.replace(/[\s\W_]+/g, '');
        const uploadPath = join(
          __dirname,
          '..',
          '..',
          '..',
          'uploads',
          setFolder
        );
        // const uploadPath = join(__dirname, '..', '..', 'uploads', setFolder);

        if (!fs.existsSync(uploadPath)) {
          fs.mkdirSync(uploadPath, { recursive: true });
        }

        cb(null, uploadPath);
      },
      filename: (req: Request, file: Express.Multer.File, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        const originalName = file.originalname.replace(/\s+/g, '-');
        const newFileName = `${uniqueSuffix}-${originalName}`;
        cb(null, newFileName);
      },
    }),
  };
};
