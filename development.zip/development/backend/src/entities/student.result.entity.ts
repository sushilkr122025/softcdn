import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('studentresult')
export class StudentResult {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: 50 })
  paperid!: string;

  @Column({ type: 'varchar', length: 50 })
  studentid!: string;

  @Column({ type: 'varchar', length: 50 })
  class!: string;

  @Column({ type: 'varchar', length: 50 })
  section!: string;

  @Column()
  totalScore!: number;

  @Column()
  maxScore!: number;

  @Column({ type: 'float' })
  percentage!: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  grade!: string;

  @Column({ type: 'float', nullable: true })
  percentile!: number;

  @Column({ type: 'varchar', length: 50, nullable: true })
  scope!: 'SECTION' | 'CLASS';

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  createdate!: Date;
}
