// import useAuth from '../context/AuthContext'
import { PiBellLight } from "react-icons/pi";
import { GoAlertFill } from "react-icons/go";
import bell from "../assets/images/bell.svg"
import { UserStar } from 'lucide-react';
// import { useState } from 'react';
import { useNotification } from '../context/NotificationContext';


export default function NotificationBell() {
  const { notifications, markAsRead } = useNotification();
  // const [isshow, setisShow] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleshow = (id) => {
    markAsRead(id)
    // setisShow(true)
  }

  return (
    <div className="dropdown">
      <button className="custombtn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        {/* <PiBellLight className='fs30' /> */}
        <img src={bell} alt="" />
        {unreadCount > 0 && (
          <span className="bg-danger px-1 rounded position-absolute text-white" style={{ fontSize: "10px", right: "6px",top:"6px" }}>
            {unreadCount}
          </span>
        )}
      </button>
      <ul className="dropdown-menu" style={{ width: '500px' }} onClick={(e) => e.stopPropagation()}>
        <h5 className='pt-3 ps-3 text-secondary'>Notification</h5>
        <hr style={{ color: 'var(--secondary-500)' }} />
        {notifications.length === 0 ? (
          <li className='d-flex p-2 ps-3'>You don't have any notification</li>
        ) : (
          notifications.map((n) => (
            <li
              key={n.id}
              className={`d-flex justify-content-between p-2 ps-3  ${n.read ? "bg-gray-100" : "bg-white"}`}
            >
              <div>
                {n.message}
              </div>
              <div className='text-danger cursor-pointer' onClick={() => handleshow(n.id)}>
                x
              </div>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}
