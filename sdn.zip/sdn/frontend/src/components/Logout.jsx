
import { useNavigate } from 'react-router-dom'
import AuthService from '../api/authService';
import { useEffect} from 'react'
const Logout = () => {
  const navigate = useNavigate()

  const handleLogout = async () => {
    try {
      await AuthService.logoutUser();
      localStorage.removeItem('logged');
      sessionStorage.clear();
      console.log('Logout successful');
      navigate('/login');
      } catch (error) {
        console.error(error);
        }
   }   
  useEffect(() => {
    handleLogout();
  }, []);
}

export default Logout
