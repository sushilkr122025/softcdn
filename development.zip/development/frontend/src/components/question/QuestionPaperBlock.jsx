import { FiDownload } from 'react-icons/fi';
import { CiViewTimeline } from "react-icons/ci";
import { useNavigate } from 'react-router-dom';

const QuestionPaperBlock = ({ info }) => {
  const navigate = useNavigate();
  console.log('info', info);
  

  const handleView = (id) => {
    navigate(`/PreviewContent/${id}`);
  };

  const handleDownload = () => {
    navigate(`/question/template/${info.paperId}`);
  };

  const openModal = () => {
    navigate(`/rollblock/${info.paperId}`, {state: {examDetails: info}});
  };

  function toRoman(num) {
    if (isNaN(num)) return '';
    const romanNumerals = [
      { value: 1000, numeral: 'M' },
      { value: 900, numeral: 'CM' },
      { value: 500, numeral: 'D' },
      { value: 400, numeral: 'CD' },
      { value: 100, numeral: 'C' },
      { value: 90, numeral: 'XC' },
      { value: 50, numeral: 'L' },
      { value: 40, numeral: 'XL' },
      { value: 10, numeral: 'X' },
      { value: 9, numeral: 'IX' },
      { value: 5, numeral: 'V' },
      { value: 4, numeral: 'IV' },
      { value: 1, numeral: 'I' },
    ];
    let romanNumeral = '';
    for (let i = 0; i < romanNumerals.length; i++) {
      while (num >= romanNumerals[i].value) {
        romanNumeral += romanNumerals[i].numeral;
        num -= romanNumerals[i].value;
      }
    }
    return romanNumeral;
  }

  return (
   <div className="w-100 mb-4">
        <div className="d-flex justify-content-end gap-3 px-2 mb-2">
          <button className="btn btn-link p-0 text-secondary border-0 bg-transparent hover-opacity" type="button" title="Download" onClick={() => handleDownload(info.totalQuestion)} style={{ color: '#6B7280', cursor: 'pointer' }}>
            <FiDownload size={20} />
          </button>
          <button className="btn btn-link p-0 border-0 bg-transparent hover-opacity" type="button" title="View Question Paper" onClick={() => handleView(info.id)} style={{ color: '#22c55e', cursor: 'pointer' }} >
            <CiViewTimeline size={18} />
          </button>
        </div>
        <div 
          className="card shadow-sm border rounded-3 h-100" 
          onClick={openModal}>
          <div className="card-body p-4">
            <div className="row mb-1">
              <div className="col-6 text-start">
                <span className="text-muted">Class - </span>
                <span className="fw-bold text-muted">{toRoman(info.class) || "VIII"}</span>
              </div>
              <div className="col-6 text-end">
                <span className="text-muted">Time allowed - </span>
                <span className="fw-bold text-muted">{info.totalTime}</span>
              </div>
            </div>
  
            <div className="row mb-3">
              <div className="col-6 text-start">
                <span className="text-muted">Subject - </span>
                <span className="fw-bold text-muted">{info.subjectName}</span>
              </div>
              <div className="col-6 text-end">
                <span className="text-muted">Max marks - </span>
                <span className="fw-bold text-muted">{info.maxMarks}</span>
              </div>
            </div>
  
            <hr className="my-3"  />
  
            <div className="text-start d-flex justify-content-between">
              <span className="text-muted">Total Questions - <span className="fw-bold text-muted">{info.totalQuestion}</span> </span>
              <span className="text-muted">click here to open</span>
            </div>
          </div>
        </div>
      </div>
  );
};

export default QuestionPaperBlock;
