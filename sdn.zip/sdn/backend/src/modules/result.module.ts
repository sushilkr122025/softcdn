import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ResultService } from '../services/result.service';
import { ResultController } from '../controllers/result.controller';
import { Result } from '../entities/result.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { Answer } from '../entities/answer.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { Questions } from '../entities/questions.entity';
import { Grade } from '../entities/grade.entity';
import { Alert } from '../entities/alerts.entity';
import { Subject } from '../entities/subject.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Result,
      StudentInformation,
      Answer,
      ExamQuestion,
      Questions,
      Grade,
      Alert,
      Subject,
      QuestionPaper,
    ]),
  ],
  controllers: [ResultController],
  providers: [ResultService],
  exports: [ResultService],
})
export class ResultModule {}
