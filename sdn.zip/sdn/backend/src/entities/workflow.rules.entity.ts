import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({ name: 'workflowrules' })
export class WorkflowRules {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ default: 1 })
  priorityId: number;

  @Column({ type: 'enum', enum: ['GLOBAL', 'INDIVIDUAL'] })
  ruleType: 'GLOBAL' | 'INDIVIDUAL';

  @Column({ nullable: true })
  userId: number;

  @Column('json')
  rule: string;

  @Column({ type: 'varchar', length: '10' })
  createdBy: string;

  @Column({ type: 'varchar', length: '5', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date;
}
