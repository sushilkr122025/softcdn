import '../assets/css/dashboard.css'
import Card from '../components/Dashboard/card'
import classroom1 from '../assets/images/people1.svg'
import alert from '../assets/images/alert.svg'
import React from 'react'
// import { isMobile, isTablet, isAndroid } from 'react-device-detect'
import { NavLink } from 'react-router-dom'
import { BsBank } from 'react-icons/bs'
import { MdDashboard } from 'react-icons/md'
import { MdEditSquare } from 'react-icons/md'
import { IoIosPaper, IoIosAlert } from 'react-icons/io'
import {
  FaCheckCircle,
  FaUserCog,
  FaUserPlus,
  FaCalendarAlt,
  FaUser,
  FaRegQuestionCircle,
  FaCog,
} from 'react-icons/fa'
// import DatePicker from 'react-datepicker';
import {} from 'react-icons/io'
import useAuth from '../context/AuthContext'
// import useLicense from '../context/LicenseContext'

// import { HasUser } from 'src/contexts/RoleContext'

function Hello() {
  // const { user, isAuth } = HasUser()

  // console.log(user, isAuth)

  // function getDeviceType() {
  //   if (isMobile) {
  //     return isAndroid ? 'android' : 'ios'
  //   } else if (isTablet) {
  //     return isAndroid ? 'android tablet' : 'ios tablet'
  //   } else {
  //     return 'Browser'
  //   }
  // }

  // useEffect(() => {
  //   const bool = localStorage.getItem('access')
  //   const status = Boolean(bool)
  //   const deviceType = getDeviceType()
  //   console.log(deviceType)
  //   if (deviceType === 'android') {
  //     window.Android.handleLoginStatus(status)
  //   } else if (deviceType === 'ios') {
  //     window.webkit.messageHandlers.handleLoginStatus.postMessage(status)
  //   }
  // }, [])

  // let userType = user?.role
  const { user } = useAuth()
  // const { licenseInfo } = useLicense()
  console.log(user?.role)

  let userType = user?.role
  const newcard = []
  let links = ''
  if (userType === 'Student') {
    links = [{ link: 'Question Bank', color: 'text-bg-dark', icon: <BsBank />, href: '/Question' }]
    links.map((e) => {
      newcard.push(e)
    })
  } else if (userType === 'ADMIN') {
    links = [
      // {link: 'Create Question', color: 'lq-blue-color',  icon: <TbPencilQuestion />, href: '/QuestionGeneration' },
      { link: 'Question Bank', color: 'lq-blue-color', icon: <BsBank />, href: '/Question' },
      { link: 'Approval', color: 'lq-green-color', icon: <FaCheckCircle />, href: '/Approval-A' },
      { link: 'Answer Sheet', color: 'lq-sky-color', icon: <IoIosPaper />, href: '/AnswerSheet' },
      { link: 'Questions', color: 'lq-yellow-color', icon: <MdEditSquare />, href: '/Manupilate' },
      { link: 'Registration', color: 'lq-red-color', icon: <FaUserPlus />, href: '/Registration' },
      {
        link: 'Question Paper',
        color: 'lq-orange-color',
        icon: <BsBank />,
        href: '/QuestionPaper',
      },
      // {link: 'Student Information', color: 'lq-purple-color', icon: <IoIosInformationCircle />, href: '/StudentInformation'},
      // {link: 'User Registration', color: 'lq-red-color', icon: <FaRegistered />, href: '/UserRegistration'},
      // {link: 'Subject', color: 'text-bg-warning', icon: <FaRegQuestionCircle />, href: '/Subject'},
      { link: 'admin', color: 'lq-purple-color', icon: <FaUserCog />, href: '/admin' },
    ]
    links.map((e) => {
      newcard.push(e)
    })
  } else if (userType === 'Teacher') {
    links = [
      {
        link: 'Create Question',
        color: 'text-bg-primary',
        icon: <FaUser />,
        href: '/QuestionGeneration',
      },
      { link: 'Question Bank', color: 'text-bg-light', icon: <BsBank />, href: '/Question' },
      {
        link: 'Approval',
        color: 'text-bg-secondary',
        icon: <FaRegQuestionCircle />,
        href: '/Approval-A',
      },
      { link: 'Make Paper', color: 'text-bg-dark', icon: <FaCog />, href: '/MakePaper-A' },
      { link: 'Questions', color: 'text-bg-danger', icon: <BsBank />, href: '/Manupilate' },
      {
        link: 'Question Paper',
        color: 'text-bg-primary',
        icon: <BsBank />,
        href: '/QuestionPaper',
      },
      {
        link: 'Student Information',
        color: 'text-bg-info',
        icon: <FaUser />,
        href: '/StudentInformation',
      },
    ]
    links.map((e) => {
      newcard.push(e)
    })
  }
  return (
    <section id="dashboard">
      <div className="container-fluid mb-5 pt-md-1">
        <div className="row align-items-center">
          <div className="col-10 col-sm-10">
            <div className="d-flex align-items-center px-3 pt-md-1">
              <MdDashboard style={{ fontSize: '20px' }} />
              <h6 className="pt-2 ps-2">Dashboard</h6>
            </div>
          </div>
          <div className="col-2 col-sm-2 text-end">
            <FaCalendarAlt fontSize={'20px'} />
            {/* <input
              type='date'
              className='form-control form-control-sm custom-calendar'
            /> */}
          </div>
          <div className="col-md-8 col-12 mb-4">
            <section className="dashboard-image ms-4 pt-md-1">
              <img src={classroom1} alt="classroom" className="img-fluid" width={'100%'} />
            </section>
          </div>
          <div className="col-md-4 col-12 mb-4 px-4">
            <div className="notifications mx-4">
              <div className="row">
                <div className="col-12 ">
                  <div className="row notifications-top">
                    <div className="col-12 px-5 mb-3 pt-4">
                      <h5 className="text-white">Notifications</h5>
                    </div>
                    <div className="col-12">
                      <nav>
                        <div className="nav nav-tabs m-0" id="nav-tab" role="tablist">
                          <button
                            className="nav-link custom-navlink active"
                            id="nav-alert-tab"
                            data-bs-toggle="tab"
                            data-bs-target="#nav-alert"
                            type="button"
                            role="tab"
                            aria-controls="nav-alert"
                            aria-selected="true"
                          >
                            Alerts
                          </button>
                          <button
                            className="nav-link custom-navlink"
                            id="nav-approval-tab"
                            data-bs-toggle="tab"
                            data-bs-target="#nav-approval"
                            type="button"
                            role="tab"
                            aria-controls="nav-approval"
                            aria-selected="false"
                          >
                            Approval
                          </button>
                          {/* <button
                            className="nav-link custom-navlink"
                            id="nav-contact-tab"
                            data-bs-toggle="tab"
                            data-bs-target="#nav-contact"
                            type="button"
                            role="tab"
                            aria-controls="nav-contact"
                            aria-selected="false"
                          >
                            Contact
                          </button> */}
                        </div>
                      </nav>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-12 px-4 pb-3 pt-4 bg-white notification-content">
                      <div className="tab-content" id="nav-tabContent">
                        <div
                          className="tab-pane fade show active"
                          id="nav-alert"
                          role="tabpanel"
                          aria-labelledby="nav-alert-tab"
                          tabIndex="0"
                        >
                          <div className="row">
                            {/* <div className="col-12 text-center">
                              <div className="col-12 text-center pt-2">
                                <img src={alert} alt="alert" className="me-2" width="70%" />
                                <h6 className="fw-bold m-0 p-0">Well Done !</h6>
                                <p className="m-0 p-0">
                                  Try adjusting your search <br></br>to find what you are looking
                                  for
                                </p>
                              </div>
                            </div> */}
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <FaCheckCircle className="alerticon positive" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">just Now</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">2 hrs ago</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">5 hrs ago</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <FaCheckCircle className="alerticon positive" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">just Now</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">2 hrs ago</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">5 hrs ago</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <FaCheckCircle className="alerticon positive" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">just Now</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">2 hrs ago</div>
                            </div>
                            <div className="col-12 d-flex justify-content-between align-items-center mb-4">
                              <div className="d-flex">
                                <div className="pe-3">
                                  <IoIosAlert className="alerticon negative" />
                                </div>
                                <h6 className=" m-0 p-0 alert-name">
                                  {' '}
                                  You don&#39;t have any approval task.<br></br> Your are doing good
                                  !
                                </h6>
                              </div>
                              <div className="alert-time">5 hrs ago</div>
                            </div>
                          </div>
                        </div>
                        <div
                          className="tab-pane fade"
                          id="nav-approval"
                          role="tabpanel"
                          aria-labelledby="nav-approval-tab"
                          tabIndex="0"
                        >
                          <div className="row">
                            <div className="col-12 text-center states-ui">
                              <div className="col-12 text-center pt-2">
                                <img src={alert} alt="alert" className="me-2" width="70%" />
                                <h6 className="fw-bold m-0 p-0 states-uihead">Well Done !</h6>
                                <p className="m-0 p-0">
                                  You don&#39;t have any approval task <br></br>Your are doing good
                                  !
                                </p>
                              </div>
                              {/* <img src={alert} alt="classroom" className="img-fluid" width={'80%'} /> */}
                            </div>
                          </div>
                        </div>
                        {/* <div
                          className="tab-pane fade"
                          id="nav-contact"
                          role="tabpanel"
                          aria-labelledby="nav-contact-tab"
                          tabIndex="0"
                        >
                          contact
                        </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row mt-3 mx-2">
          {newcard.map((e, i) => {
            return (
              <div className="col-lg-3 col-6 col-md-3" key={i}>
                <NavLink to={e.href} className="nav-link">
                  <Card link={e.link} icon={e.icon} color={e.color} />
                </NavLink>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default Hello
