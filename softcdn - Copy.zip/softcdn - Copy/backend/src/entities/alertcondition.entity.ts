import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'alertcondition' })
export class Alertcondition {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '100' })
  class: string;

  @Column({ type: 'varchar', length: '100' })
  section: string;

  @Column({ type: 'varchar', length: '100' })
  subject: string;

  @Column({ type: 'varchar', length: '100' })
  subdomain: string;

  @Column({ type: 'varchar', length: '100' })
  criteria: string;

  @Column({ type: 'varchar', length: '100' })
  typeof: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'int' })
  status: number;
}
