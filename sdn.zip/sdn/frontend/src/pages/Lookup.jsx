import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import SchoolServices from '../api/SchoolServices';
import { useNavigate } from 'react-router-dom';

const LookupPage = () => {
  const { schoolurl } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(true);
  const navigate = useNavigate();
  
   useEffect(() => {
    const lookupCompany = async () => {
      console.log('LookupPage', schoolurl);
      try {
        const res = await SchoolServices.getLookup(schoolurl);
        if(res){        
       // setLocalenv('LOCALENVIRONMENT');
       console.log('LookupPage', res);
        setError(false);
        navigate('/login');
        }
      } catch (err) {        
        console.log(err);
        setError('This is Invalid URL, please check and try again');
      } finally {
        setLoading(false);
      }
    };
    if (schoolurl) {
      lookupCompany();
    } else {
      setLoading(false);
      setError(false);
    }
  }, [schoolurl]);

  if (loading) return <p>Loading....</p>;
  return (
    <div className="container mt-4">
      {error ? (
        <div className="alert alert-danger">
          <h4>{error}</h4>
          <p><strong>Invalid URL:</strong> {schoolurl}</p>
        </div>
      ) : (        
          <div className="alert alert-success">
            <h4>URL is missing</h4>
            <p>You have not use any url, please add and try again</p>
          </div>
      )}
    </div>
  );
};

export default LookupPage;
