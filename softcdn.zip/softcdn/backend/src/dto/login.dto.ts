import { IsEmail, IsOptional, MinLength, IsNotEmpty, IsEmpty, IsNumberString } from 'class-validator';

export class LoginDto {
  @MinLength(3, { message: 'Name must be at least 3 characters long' })
  name: string;

  @IsNumberString()
  userid: string;

  @IsEmail({}, { message: 'Invalid email format' })
  email: string;

  @MinLength(6, { message: 'Password must be at least 6 characters long' })
  password: string;

  @IsOptional()
  role?: string;

  @IsNotEmpty()
  tenantid?: string;

  @IsOptional()
  gender?: string;

  @IsOptional()
  mobileno: string;

  @IsOptional()
  address?: string;
}
