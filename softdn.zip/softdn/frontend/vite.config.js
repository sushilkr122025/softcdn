import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd());

  return {
    server: {
      host: '0.0.0.0',
      // host: true,
      port: env.VITE_PORT ? parseInt(env.VITE_PORT, 10) : 3001,
      allowedHosts: ['fpserver'],
      proxy: {
        '/assets': env.VITE_HOST,
      },
    },
    plugins: [react()],
    resolve: {
      alias: {
        '@emotion/react': path.resolve(__dirname, 'node_modules/@emotion/react'),
        '@emotion/styled': path.resolve(__dirname, 'node_modules/@emotion/styled'),
      },
    },
  };
});
