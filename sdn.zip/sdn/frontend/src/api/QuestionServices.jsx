import apiClient from './apiService'
class QuestionServices {
  createContext = async (data) => {
    try {
     const response = await apiClient.post('/school/createcontext', data);  
     return {
        status: response.status,
        data: response.data
      } 
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message: error.response?.data?.message.message || "Something went wrong",
      }
    }    
  }

  createQuestion = async (data) =>{
    try {
      const response = await apiClient.post('/school/questions', data);
      return {
        status: response.status,
        data: response.data
      }
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message: error.response?.data?.message.message || "Something went wrong",
      }
    }
  }

  getContextByShortUuid = async (data) => {
    try {
      const response = await apiClient.get(`school/getcontext/`, data);
      return{
        status: response.status,
        data: response.data
      } 
    } catch (error) {
      return {
        status: error.response?.status || 500,
        message: error.response?.data?.message.message || "Something went wrong",
      }
    }
  }
//  apiClient.get(`/school/getquestions?id=${sparams.get('id')}`);
    getQuestionById = async (id) => {
        try {
        const response = await apiClient.get(`/school/getquestions/`, id)
        return response.data
        } catch (error) {
        console.log(error)
        }
}
    getAllQuestions = async (fdata) => {
        try {
        const response = await apiClient.post('api/question/all', fdata)
        return response.data
        } catch (error) {
        console.log(error)
        }
    }
    }
export default new QuestionServices()