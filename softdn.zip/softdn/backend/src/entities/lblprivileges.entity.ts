import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'lblprivileges' })
export class Lblprivileges {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 50 })
  label: string;

  @Column({ length: 50 })
  type: string;

  @Column({ length: 50, default: null })
  itstype: string;

  @Column({ type: 'varchar', length: '5', default: 'I' })
  dmlType: string;
}
