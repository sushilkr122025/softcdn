import React, { useEffect, useState, useCallback } from 'react';
import { MdRemoveCircleOutline, MdAddCircleOutline } from 'react-icons/md';
import apiClient from '../api/apiService';
import UserServices from '../api/UserServices';
import { useParams } from 'react-router-dom';

export default function SubjectClassAssignment({ initialData = null }) {
  const [subjectData, setSubjectData] = useState([]);
  const [classData, setClassData] = useState([]);
  const [sectionData, setSectionData] = useState([]);
  const [rows, setRows] = useState([]); 
  const { id } = useParams();

  const makeEmptyRow = useCallback(() => ({ subject: '', classIds: [] }), []);

  // fetch subjects & classes
  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const [subjectsRes, classesRes, sectionRes] = await Promise.all([apiClient.get('/store/subject'), apiClient.get('/store/classes'), apiClient.get('/store/section')]);

        const subjects = subjectsRes.data || [];
        const classes = (classesRes.data || []).filter((c) => c.status === 1).map((c) => String(c.class));
        const sections = sectionRes.data || [];

        if (!mounted) return;
        setSubjectData(subjects);
        setClassData(classes);
        setSectionData(sections);

        // initialize rows either from initialData (edit mode) or at least one empty row
        if (initialData && Array.isArray(initialData) && initialData.length) {
          // expected shape: [{ subjectId: '3', classIds: ['6','7'] }, ...]
          const mapped = initialData.map((r) => ({ subject: String(r.subjectId), classIds: (r.classIds || []).map(String) }));
          setRows(mapped.length ? mapped : [makeEmptyRow()]);
        } else {
          setRows((prev) => (prev.length ? prev : [makeEmptyRow()]));
        }
      } catch (err) {
        console.error('Error loading subjects/classes:', err);
      }
    };

    load();
    return () => {
      mounted = false;
    };
  }, [initialData, makeEmptyRow]);

  // keep rows consistent if class set changes (e.g. admin updated classes) — remove classes that no longer exist
  useEffect(() => {
    if (!classData.length) return;
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        classIds: r.classIds.filter((cid) => classData.includes(cid)),
      }))
    );
  }, [classData]);

  const addRow = () => setRows((prev) => [...prev, makeEmptyRow()]);
  const removeRow = () => setRows((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));

  const handleSubjectChange = (index, subjectId) => {
    setRows((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], subject: subjectId };
      return next;
    });
  };

  const toggleClassForRow = (rowIndex, classId) => {
    setRows((prev) => {
      const next = [...prev];
      const row = { ...(next[rowIndex] || makeEmptyRow()) };
      const setIds = new Set(row.classIds || []);
      if (setIds.has(classId)) setIds.delete(classId);
      else setIds.add(classId);
      row.classIds = Array.from(setIds);
      next[rowIndex] = row;
      return next;
    });
  };

  const handleSave = async () => {
    try {
      const payload = rows
        .map((r) => ({ subjectId: r.subject, classIds: r.classIds }))
        .filter((r) => r.subjectId && Array.isArray(r.classIds) && r.classIds.length > 0)
        .map((r) => ({ userId: id, subjectId: r.subjectId, classIds: r.classIds }));

      if (!payload.length) {
        // you can replace this with a nicer UI alert/toast
        console.warn('No rows with both subject and classes; nothing to save.');
        return;
      }

      console.log('Saving subject-class assignments:', payload);
      
      // const res = await UserServices.setUserSubjectClasses(payload);
      // console.log('Save response:', res);
    } catch (err) {
      console.error('Error saving subject-class assignments:', err);
    }
  };

  return (
    <div className="container-fluid py-4">
      <div className="row">
        <div className="col-12 col-lg-10 mx-auto bg-white shadow-sm rounded p-4">
          <div className="form-header mb-4 border-bottom pb-2 d-flex justify-content-between align-items-center">
            <h3 className="fw-bold text-primary">Assign Subjects to Classes</h3>
            <button className="btn btn-primary" onClick={handleSave}>
              Save Assignments
            </button>
          </div>

          <div className="table-responsive">
            <table className="table table-bordered align-middle">
              <thead className="table-light">
                <tr>
                  <th style={{ width: '30%' }}>Subject</th>
                  <th>Classes</th>
                </tr>
              </thead>

              <tbody>
                {rows.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    <td>
                      <select className="form-select form-select-sm" value={row.subject} onChange={(e) => handleSubjectChange(rowIndex, e.target.value)}>
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td>
                      <div className="d-flex flex-wrap gap-2" style={{ maxHeight: 120, overflowY: 'auto' }}>
                        {classData.map((cls) => (
                          <div key={cls} className="form-check me-3">
                            <input className="form-check-input" type="checkbox" id={`r${rowIndex}-c${cls}`} checked={row.classIds.includes(cls)} onChange={() => toggleClassForRow(rowIndex, cls)} />
                            <label className="form-check-label" htmlFor={`r${rowIndex}-c${cls}`}>
                              {cls}
                            </label>
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>

              <tfoot>
                <tr>
                  <td colSpan={2} className="text-center bg-light">
                    <span className="me-4 text-danger fs-5 cursor-pointer" onClick={removeRow}>
                      <MdRemoveCircleOutline />
                    </span>
                    <span className="text-success fs-5 cursor-pointer" onClick={addRow}>
                      <MdAddCircleOutline />
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
            <div className="d-flex">
              <div className="col-6 pe-2">
                <label htmlFor="classTeacher">Class Teacher of</label>
                <select name="classTeacher" id="classTeacher" className="form-select form-select-sm">
                  <option value="">Class Teacher</option>
                  {classData.map((cls) => (
                    <option key={cls} value={cls}>
                      {cls}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-6 ps-2">
                <label htmlFor="sectionTeacher">Section Teacher of</label>
                <select name="sectionTeacher" id="sectionTeacher" className="form-select form-select-sm">
                  <option value="">Section Teacher</option>
                  {sectionData.map((sec) => (
                    <option key={sec.id} value={sec.id}>
                      {sec.section}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
