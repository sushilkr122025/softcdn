import * as winston from 'winston';

const formatContext = (meta: any) => {
  const ctx = meta?.context || meta || {};
  const path = ctx.path ?? '';
  const method = ctx.method ?? '';
  const status = ctx.status ?? '';

  if (!path && !method && !status) return '';

  return ` | ${method} ${path} (${status})`;
};

export const winstonLoggerOptions: winston.LoggerOptions = {
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    winston.format.errors({ stack: true }),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      const ctx = formatContext(meta);
      const msg =
        typeof message === 'object' ? JSON.stringify(message) : message;

      return `[${timestamp}] ${level}: ${msg}${ctx}`;
    })
  ),

  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize({ all: true }),
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }), //
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          const ctx = formatContext(meta);
          const msg =
            typeof message === 'object' ? JSON.stringify(message) : message;

          return `[${timestamp}] ${level}: ${msg}${ctx}`;
        })
      ),
    }),

    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error',
    }),

    new winston.transports.File({
      filename: 'logs/warn.log',
      level: 'warn',
    }),

    new winston.transports.File({
      filename: 'logs/info.log',
      level: 'info',
    }),
  ],
};
