import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ResultService } from '../services/result.service';
import { ResultController } from '../controllers/result.controller';
import { Result } from '../entities/result.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { Answer } from '../entities/answer.entity';
import { ExamQuestion } from '../entities/examquestion.entity';
import { Questions } from '../entities/questions.entity';
import { Grade } from '../entities/grade.entity';
import { Alert } from '../entities/alerts.entity';
import { Subject } from '../entities/subject.entity';
import { QuestionPaper } from '../entities/questionpaper.entity';
import { OpenAIResult } from '../entities/openai.result.entity';
import { StudentQuestionResult } from '../entities/student.question.result.entity';
import { StudentResult } from '../entities/student.result.entity';
import { StudentSubdomainResult } from '../entities/student.subdomain.result.entity';
import { StudentSectionSummary } from '../entities/student.section.summary.entity';
import { StudentSubjectSummary } from '../entities/student.subject.summary.entity';
import { StudentBloomSummary } from '../entities/student.bloom.summary.entity';
import { BloomSummary } from '../entities/bloom.summary.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Result,
      StudentInformation,
      Answer,
      ExamQuestion,
      Questions,
      Grade,
      Alert,
      Subject,
      QuestionPaper,
      OpenAIResult,
      StudentQuestionResult,
      StudentResult,
      StudentSubdomainResult,
      StudentSectionSummary,
      StudentSubjectSummary,
      StudentBloomSummary,
      BloomSummary
    ]),
  ],
  controllers: [ResultController],
  providers: [ResultService],
  exports: [ResultService],
})
export class ResultModule {}
