import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('userdetail')
export class UserDetail {
  @PrimaryGeneratedColumn({ name: 'Id' })
  id: number;

  @Column()
  userId: number;

  @Column({ type: 'varchar', length: 20 })
  gender: string;

  @Column({ type: 'date' })
  dob: string;

  @Column({ type: 'date' })
  doj: string;

  @Column({ type: 'varchar', length: 80 })
  education: string;

  @Column({ type: 'varchar', length: 80 })
  experience: string;

  @Column({ type: 'varchar', length: 15 })
  contactNo: string;

  @Column({ type: 'varchar', length: 15, nullable: true })
  altContactNo: string;

  @Column({ type: 'varchar', length: 100 })
  emailId: string;

  @Column({ type: 'varchar', length: 200 })
  address: string;

  @Column({ type: 'varchar', length: 50 })
  state: string;

  @Column({ type: 'text' })
  district: string;

  @Column({ type: 'varchar', length: 100 })
  empType: string;

  @Column({ type: 'tinyint', width: 1, default: () => '1' })
  status: boolean;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'datetime' })
  dateTime: Date;
}
