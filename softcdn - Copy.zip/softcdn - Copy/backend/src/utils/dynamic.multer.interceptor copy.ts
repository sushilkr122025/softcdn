import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  mixin,
  Type,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { generateMulterConfig } from '../services/multer.config.service';

export function DynamicMulterInterceptor(
  folderPathCallback: (req: any) => string,
): Type<NestInterceptor> {
  @Injectable()
  class MixinInterceptor implements NestInterceptor {
    async intercept(context: ExecutionContext, next: CallHandler) {
      const ctx = context.switchToHttp();
      const request = ctx.getRequest();
      // console.log('Incoming request to Multer Interceptor:', {
      // body: request.body,
      // params: request.params,
      // query: request.query,
      // });

      const folderName = folderPathCallback(request);
      const multerOptions = generateMulterConfig(folderName);

      const InterceptorClass = FileInterceptor('file', multerOptions);
      const interceptorInstance = new InterceptorClass();

      return interceptorInstance.intercept(context, next);
    }
  }

  return mixin(MixinInterceptor);
}
