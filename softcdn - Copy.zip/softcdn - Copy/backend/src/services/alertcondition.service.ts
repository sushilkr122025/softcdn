import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Alertcondition } from '../entities/alertcondition.entity';

@Injectable()
export class AlertConditionService {
  constructor(
    @InjectRepository(Alertcondition)
    private alertConditionRepository: Repository<Alertcondition>
  ) {}

  async findById(id: number): Promise<Alertcondition | null> {
    const alerts = await this.alertConditionRepository.findOne({ where : { id } });
    if (!alerts) {
      throw new NotFoundException('User not found');
    }
    return alerts;
  }
}
