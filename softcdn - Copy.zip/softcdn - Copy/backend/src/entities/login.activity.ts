import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'loginactivity' })
export class LoginActivity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({
    type: 'varchar',
    length: '50',
    default: null,
    comment: 'id/emaild',
  })
  loginId: string;

  @Column({ type: 'varchar', length: '50' })
  tenantId: string;

  @Column({ type: 'varchar', length: '150', default: null })
  userAgent: string;

  @Column({ type: 'varchar', length: '10' })
  logType: string;

  @Column({ type: 'varchar', length: '20' })
  logDetail: string;

  @Column({ type: 'varchar', length: '2', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;
}
