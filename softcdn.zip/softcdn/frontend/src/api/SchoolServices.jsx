import apiClient from './apiService';

class SchoolServices {
    // uploadFile = async (formData) =>{
    //     try {
    //       const company = formData.get('name').toLowerCase().replace(/\s+/g, '');
    //       const response = await apiClient.post(`/school/register/${company}`, formData, {
    //         headers: {
    //           'Content-Type': 'multipart/form-data',
    //         },
    //       });
    //       return response.data;
    //     } catch (error) {
    //       console.error('Error uploading file:', error);
    //       throw error;
    //     }
    // }
    getLookup = async (slug) => {
        try {
        const response = await apiClient.get('/lookup/' + slug);
        return response.data;
        } catch (error) {
        console.error('Error lookup school data:', error);
        throw error;
        }
    };

    getLookupVerify = async () => {
      try {
      const response = await apiClient.get('/company/me'); 
      return response.data;
      } catch (error) {
      console.log(error);
      throw error;
      }
    };
}

export default new SchoolServices;
