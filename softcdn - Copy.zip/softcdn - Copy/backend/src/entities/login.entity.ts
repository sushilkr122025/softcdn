import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  BeforeInsert,
  BeforeUpdate,
  UpdateDateColumn,
} from 'typeorm';
import * as bcrypt from 'bcrypt';

@Entity({ name: 'login' })
export class Login {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50', default: null })
  userid: string;

  @Column({ type: 'varchar', length: '150' })
  name: string;

  @Column({ type: 'varchar', length: '15', default: null })
  gender: string;

  @Column({ type: 'varchar', length: '50', default: null })
  email: string;

  @Column({ type: 'varchar', length: '255', default: null })
  address: string;

  @Column({ type: 'varchar', length: '15', default: null })
  mobileno: string;

  @Column({ type: 'varchar', length: '20', default: 'none' })
  role: string;

  @Column({ type: 'varchar', length: '255' })
  password: string;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @BeforeInsert()
  @BeforeUpdate()
  async hashPassword() {
    if (this.password && !this.password.startsWith('$2b$')) {
      this.password = await bcrypt.hash(this.password, 10);
    }
  }

  async comparePassword(userpassword: string) {
    return await bcrypt.compare(userpassword, this.password);
  }

  @UpdateDateColumn({ type: 'timestamp', default: null })
  updatedDate: Date;
}
