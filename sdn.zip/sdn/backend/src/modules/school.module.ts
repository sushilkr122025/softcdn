import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SchoolController } from '../controllers/school.controller';
import { School } from '../entities/school.entity';
import { SchoolService } from '../services/school.service';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { Questions } from '../entities/questions.entity';
import { QuestionIdTracker } from '../entities/questionid.tracker.entity';
import { CanvasImage } from '../entities/canvasimage.entity';
import { Gallery } from '../entities/gallery.entity';
import { QuestionContext } from '../entities/question.context.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      School,
      Questions,
      QuestionIdTracker,
      Gallery,
      CanvasImage,
      QuestionContext,
    ]),
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', '..', '..', 'uploads'), // Path to your 'uploads' folder
      serveRoot: '/assets', // URL root path for serving static assets
    }),
  ],
  controllers: [SchoolController],
  providers: [SchoolService],
})
export class SchoolModule {}
