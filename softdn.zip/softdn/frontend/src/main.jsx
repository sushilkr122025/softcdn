import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { ThemeProvider } from './components/layout/ThemeContext.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
   <ThemeProvider>
    <App />
    </ThemeProvider>
  </StrictMode>
)
