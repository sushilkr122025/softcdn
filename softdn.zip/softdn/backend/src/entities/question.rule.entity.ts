import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'questionrule' })
export class QuestionRule {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int' })
  userId: number;

  @Column({ type: 'varchar', length: '100', nullable: true })
  subjectId: string;

  @Column({ type: 'varchar', length: '100', nullable: true })
  classId: string;

  @Column({ type: 'varchar', length: '50', nullable: true })
  teachersId: string;

  @Column({ type: 'int' })
  createdBy: number;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;
}
