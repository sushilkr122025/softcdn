import React from 'react'

const QuestionType = React.lazy(() => import('../pages/question/QuestionType'))
const QuestionGenration = React.lazy(() => import('../pages/question/QuestionGeneration'))
const StudentInformation = React.lazy(() => import('../pages/StudentInformation'))
const UserRegistration = React.lazy(() => import('../pages/UserRegistration'))
const MakePaper1 = React.lazy(() => import('../pages/question/MakePaper-A'))
const Question = React.lazy(() => import('../pages/question/Question'))
const QuestionPreview = React.lazy(() => import('../pages/question/QuestionPreview'))
const QuestionPaper = React.lazy(() => import('../pages/question/QuestionPaper'))
const Approval1 = React.lazy(() => import('../pages/question/Approval-A'))
const Manupliate = React.lazy(() => import('../pages/question/Manupliate'))
const Approval2 = React.lazy(() => import('../pages/question/Approval-B'))
const MakePaper2 = React.lazy(() => import('../pages/question/MakePaper-B'))
const admin = React.lazy(() => import('../pages/admin'))
const Answersheet = React.lazy(() => import('../pages/answer/AnswerSheet'))
const Grade = React.lazy(() => import('../pages/report/Grade'))
const AlertCriteria = React.lazy(() => import('../pages/report/Alertcreteria'))
const ReportAdmin = React.lazy(() => import('../pages/report/Reportadmin'))
const Registration = React.lazy(() => import('../pages/Registration'))
const ReportCard = React.lazy(() => import('../pages/report/Reportcard'))
const TeacherReport = React.lazy(() => import('../pages/report/TeacherReport'))
const Template = React.lazy(() => import('../components/question/Template'))
const Gallery = React.lazy(() => import('../pages/gallery/Gallery'))
const Canvas = React.lazy(() => import('../pages/gallery/Fabric'))
const StudentRegistration = React.lazy(() => import('../pages/StudentRegister'))
const Users = React.lazy(() => import('../pages/Users'))
const Student = React.lazy(() => import('../pages/Student'))
const SectionReport = React.lazy(() => import('../pages/report/SectionReport'))
const UserPermission = React.lazy(() => import('../pages/UserPermission'))
const Panel = React.lazy(() => import('../pages/question/Panel'))
const Panel2 = React.lazy(() => import('../pages/question/Panel copy'))
const RollBlock = React.lazy(() => import('../components/RollBlock'))
const Marksheet = React.lazy(()=> import('../components/marksheet'))
const SubjectClassAssign = React.lazy(()=> import('../pages/SubjectClassAssign'))
const UserApproval = React.lazy(()=> import('../pages/UserApproval'))
const PanelItem = React.lazy(()=> import('../pages/question/PanelItem'))


const routes = [
  { path: '/question/paneling', name: 'PanelItem', element: PanelItem },
  { path: '/question/panel/:pqid', name: 'Panel', element: Panel },
  { path: '/question/panel2', name: 'Panel', element: Panel2 },
  { path: '/question/type', name: 'Question Type', element: QuestionType },
  { path: '/questionGeneration', name: 'Question Generation-A', element: QuestionGenration },
  { path: '/questionPreview', name: 'Question Preview', element: QuestionPreview },
  { path: '/questionGeneration/:qid', name: 'Question Generation with context or update question', element: QuestionGenration },
  { path: '/StudentInformation', name: 'StudentInformation', element: StudentInformation },
  { path: '/StudentRegistration', name: 'StudentInformation', element: StudentRegistration },
  { path: '/users/add', name: 'UserRegistration', element: UserRegistration },
  { path: '/users/:userid', name: 'UserRegistration', element: UserRegistration },
  { path: '/users/roles/:userid', name: 'UserPermission', element: UserPermission },
  { path: '/users/assign/:userid', name: 'SubjectClassAssign', element: SubjectClassAssign },
  { path: '/users/setrule/:userid', name: 'UserApproval', element: UserApproval },

  { path: '/Question', name: 'Question', element: Question },
  { path: '/QuestionPaper', name: 'Question Paper', element: QuestionPaper },
  { path: '/Manupilate', name: 'Manupilate', element: Manupliate },
  { path: '/MakePaper-A', name: 'MakePaper-A', element: MakePaper1 },
  { path: '/MakePaper-B', name: 'MakePaper-B', element: MakePaper2 },
  { path: '/Approval-A', name: 'Approval-A', element: Approval1 },
  { path: '/Approval-B/:id', name: 'Approval-B', element: Approval2 },
  { path: '/admin', name: 'admin', element: admin },
  { path: '/AnswerSheet', name: 'Answer Sheet', element: Answersheet },
  { path: '/grade', name: 'Grade', element: Grade },
  { path: '/alertCriteria', name: 'Alert Criteria', element: AlertCriteria },
  { path: '/reportAdmin', name: 'Admin Report', element: ReportAdmin },
  // { path: '/sectionreport', name: 'Admin Report', element: SectionReport },
  { path: '/registration', name: 'Registration', element: Registration },
  { path: '/reportCard', name: 'Report Card', element: ReportCard },
  { path: '/teacherReport', name: 'Teacher Report', element: TeacherReport },
  { path: '/Template', name: 'Question Template', element: Template },
  { path: '/gallery', name: 'Gallery', element: Gallery },
  { path: '/canvas', name: 'Canvas', element: Canvas },
  { path: '/users', name: 'Teacher', element: Users },
  { path: '/student', name: 'Student', element: Student },
  { path: '/rollblock/:paperId', name: 'Roll Number', element: RollBlock },
  { path: '/marksheet', name: 'Marksheet', element: Marksheet },
]
export default routes
