import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import './AnswerSheet.css';
import apiClient from '../../api/apiService';
import useAuth from '../../context/AuthContext';
import CustomDropdown from '../../components/layout/CustomDropdown';

const QuestionPaper = () => {
  const [params] = useSearchParams()
  const id = params.get('updateid')
  const [edit, setEdit] = useState(id)
  const [editData, setEditData] = useState()
  const [classData, setClassData] = useState([])
  const [SubjectData, setSubjectData] = useState([])
  const [SubDomainData, setSubDomainData] = useState([])
  const [sectionNo, setSectionNo] = useState(0)
  const [data, setData] = useState()
  const [selectedClass, setSelectedClass] = useState()
  const [errors, setErrors] = useState({})
  const [openKey, setOpenKey] = useState("");
  useEffect(() => {
    if (edit !== null) {
      apiClient
        .post('/api/examDetails', { updateId: edit })
        .then((response) => {
          // console.log(response.data);
          setEditData(response.data)
        })
        .catch((error) => {
          console.error('Error fetching exam data:', error.response)
        })
    }

    apiClient
      .get('/store/subject')
      .then((response) => {
        // console.log(response.data);
        setSubjectData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })

    apiClient
      .get('/store/classes')
      .then((response) => {
        // console.log(response.data);
        setClassData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching class data:', error)
      })
  }, [])

  const handleSubject = (val) => {
    apiClient
      .get('/store/subDomain', { subject: val })
      .then((response) => {
        setSubDomainData(response.data)
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const formData = new FormData(e.target)
    const payload = Object.fromEntries(formData)

    const errors = validateForm(payload)
    if (Object.keys(errors).length > 0) {
      setErrors(errors)
      return
    }

    setData(payload)
  }

  const validateForm = (data) => {
    const errors = {}

    if (!data.examName) {
      errors.examName = 'Exam name is required'
    }

    if (!data.class) {
      errors.class = 'Class is required'
    }

    if (!data.subject) {
      errors.subject = 'Subject is required'
    }

    if (!data.examDate) {
      errors.examDate = 'Date is required'
    }

    if (!data.sectionNo || data.sectionNo < 1 || data.sectionNo > 8) {
      errors.sectionNo = 'Section no must be between 1 and 8'
    }

    // validate question sections
    for (let i = 1; i <= data.sectionNo; i++) {
      const quesType = data[`quesType${i}`]
      const questionSection = data[`questionSection${i}`]
      const marksSection = data[`marksSection${i}`]

      if (!quesType) {
        errors[`quesType${i}`] = 'Question type is required'
      }

      if (!questionSection || questionSection < 1 || questionSection > 50) {
        errors[`questionSection${i}`] = 'No. of questions must be between 1 and 10'
      }

      if (!marksSection || marksSection < 0 || marksSection > 10) {
        errors[`marksSection${i}`] = 'Marks for question must be between 1 and 10'
      }
    }

    console.log(errors)

    return errors
  }

  return (
    <>
      <div className='p-lg-2 mt-2 mb-5'>
        <div className="container-fluid px-3 px-lg-4 py-4">
          <div className="answer-shell">
            <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
              <h5 className='mb-0 fw-bold pagetitle'>Answer Sheet</h5>
            </div>

            {(data || editData) && (
              <AnsKeySet
                anskeyData={data}
                subjects={SubjectData}
                subdomains={SubDomainData}
                classes={classData}
                update={editData}
              />
            )}
            {!data && !editData && (
              <form action="" method="post" autoComplete="off" onSubmit={handleSubmit}>
                <div className="row g-3 mb-4 px-4">
                  <div className="col-12 col-md-6 col-lg-3">
                    <label htmlFor="examName" className="form-label field-label required">
                      Exam Name
                    </label>
                    <input type="text" className="form-control form-control-lg answer-input" placeholder="Exam name" name="examName" id="examName" />
                    {errors.examName && <div className="text-danger small mt-1">{errors.examName}</div>}
                  </div>
                  <div className="col-12 col-md-6 col-lg-3">
                    <label htmlFor="class" className="form-label required field-label">
                      Class
                    </label>
                    <CustomDropdown
                      dropdownKey="class"
                      placeholder="Select Class"
                      openKey={openKey}
                      setOpenKey={setOpenKey}
                      value={selectedClass}
                      error={!!errors.class}
                      options={classData.map((row) => ({
                        value: row.class,
                        label: row.class,
                      }))}
                      onChange={(val) => setSelectedClass(val)}
                    />
                    {errors.class && <div className="text-danger small mt-1">{errors.class}</div>}
                  </div>
                  <div className="col-12 col-md-6 col-lg-3">
                    <label htmlFor="subject" className="form-label required field-label">
                      Subject
                    </label>
                    <CustomDropdown
                      dropdownKey="subject"
                      openKey={openKey}
                      setOpenKey={setOpenKey}
                      placeholder="Select"
                      value="dfdf" // you can bind selected value here if you already have state
                      options={SubjectData.map((row) => ({
                        label: row.subject,
                        value: row.id,
                      }))}
                      onChange={(val) => handleSubject(val)}
                    />
                    {errors.subject && <div className="text-danger small mt-1">{errors.subject}</div>}
                  </div>
                  <div className="col-12 col-md-6 col-lg-3">
                    <label htmlFor="examDate" className="form-label field-label">
                      Date
                    </label>
                    <input type="date" className="form-control form-control-lg answer-input" name="examDate" id="examDate" placeholder="DD/MM/YYYY" />
                    {errors.examDate && <div className="text-danger small mt-1">{errors.examDate}</div>}
                  </div>
                </div>
                <div className="row align-items-end mb-4 px-4">
                  <div className="col-12 col-md-6 col-lg-3">
                    <label htmlFor="sectionNo" className="form-label field-label">
                      Section
                    </label>
                    <div className="stepper">
                      <button
                        type="button"
                        className="stepper-btn"
                        onClick={() => setSectionNo(Math.max(0, sectionNo - 1))}
                        aria-label="Decrease sections"
                      >
                        -
                      </button>
                      <input
                        type="text"
                        className="stepper-value"
                        name="sectionNo"
                        id="sectionNo"
                        value={sectionNo}
                        onChange={(e) => setSectionNo(e.target.value)}
                      />
                      <button
                        type="button"
                        className="stepper-btn"
                        onClick={() => setSectionNo(Math.min(8, sectionNo + 1))}
                        aria-label="Increase sections"
                      >
                        +
                      </button>
                    </div>
                    {errors.sectionNo && <div className="text-danger small mt-1">{errors.sectionNo}</div>}
                  </div>
                </div>

                <div className="row g-4">
                  {Array.from({ length: sectionNo }, (_, index) => (
                    <InputGroups subdomain={SubDomainData} key={index} i={index + 1} errors={errors} />
                  ))}
                </div>
                <div className="d-flex justify-content-start mt-4 px-4">
                  <button type="submit" className="btn btn-primary h45">
                    Submit
                  </button>
                </div>
              </form>
            )}

          </div>
        </div>
      </div>
    </>
  )
}
export default QuestionPaper

function InputGroups(data) {
  const [count, setCount] = useState(0)
  const [marks, setMarks] = useState(0)
  const [openKey, setOpenKey] = useState("");
  const sErrors = data.errors
  const marksError = sErrors[`marksSection${data.i}`]
  const quesError = sErrors[`questionSection${data.i}`]

  return (
    <div className="col-12 col-xl-6 px-4">
      <div className="section-card-title">Section {data.i}</div>
      <section className="section-card d-flex flex-column">
        <div className="mb-3">
          <label htmlFor={`quesType${data.i}`} className="form-label field-label">
            Question Type
          </label>
          <CustomDropdown
            dropdownKey={`quesType${data.i}`}
            placeholder="Select question type"
            openKey={openKey}
            setOpenKey={setOpenKey}
            defaultValue=""
            options={[
              { value: "", label: "Select question type" },
              { value: "multipleChoice", label: "MCQ" },
              { value: "trueFalse", label: "True / False" },
              { value: "CR", label: "Constructed Response" },
            ]}
          />
        </div>
        <div className="row g-3">
          <div className="col-12 col-md-6">
            <label htmlFor={`questionSection${data.i}`} className="form-label field-label">
              No. of questions
            </label>
            <div className="stepper">
              <button
                type="button"
                className="stepper-btn"
                onClick={() => setCount(Math.max(0, count - 1))}
              >
                -
              </button>
              <input
                type="text"
                className="stepper-value"
                name={`questionSection${data.i}`}
                id={`questionSection${data.i}`}
                value={count}
                onChange={(e) => setCount(e.target.value)}
              />
              <button
                type="button"
                className="stepper-btn"
                onClick={() => setCount(Math.min(50, count + 1))}
              >
                +
              </button>
            </div>
            {quesError && <div className="text-danger small mt-1">{quesError}</div>}
          </div>

          <div className="col-12 col-md-6">
            <label htmlFor={`marksSection${data.i}`} className="form-label field-label">
              Marks for question
            </label>
            <div className="stepper">
              <button
                type="button"
                className="stepper-btn"
                onClick={() => setMarks(Math.max(0, marks - 1))}
              >
                -
              </button>
              <input
                type="text"
                className="stepper-value"
                name={`marksSection${data.i}`}
                id={`marksSection${data.i}`}
                value={marks}
                onChange={(e) => setMarks(e.target.value)}
              />
              <button
                type="button"
                className="stepper-btn"
                onClick={() => setMarks(Math.min(20, marks + 1))}
              >
                +
              </button>
            </div>
            {marksError && <div className="text-danger small mt-1">{marksError}</div>}
          </div>
        </div>

        {data.subdomain.length > 0 && (
          <div className="mt-3">
            <label htmlFor={`subdomain${data.i}`} className="form-label field-label">
              Sub Domain
            </label>
            <CustomDropdown
              dropdownKey={`subdomain${data.i}`}
              placeholder="Select"
              openKey={openKey}
              setOpenKey={setOpenKey}
              options={[
                { value: "", label: "Select" },
                ...data.subdomain.map((e, i) => ({
                  value: e.id,
                  label: e.Subject,
                })),
              ]}
            />
          </div>
        )}
        <div className="section-card-footer mt-3 d-flex justify-content-end px-4">
          <button type="submit" className="btn btn-primary">
            Start
          </button>
        </div>
      </section>
    </div>
  )
}

function AnsKeySet(data) {
  const { user } = useAuth()
  const [subDomData, setSubDomData] = useState([])
  const [classData, setClassData] = useState(data.classes)
  const [SubjectData, setSubjectData] = useState(data.subjects)
  const [subdomain, setSubdomain] = useState(data.subdomains)
  const [openKey, setOpenKey] = useState("");
  // const {user} = useAuth()

  const key = data.update ? data.update : data.anskeyData
  console.log(key)

  const subject = data.update ? key.examDetail.subject : key.subject
  useEffect(() => {
    apiClient
      .get('/store/subDomain', { subject: subject })
      .then((response) => {
        setSubDomData(response.data)
        // console.log(response.data);
      })
      .catch((error) => {
        console.error('Error fetching Subject data:', error)
      })
  }, [subject])

  // const navigator = useNavigate()

  const section = data.update
    ? Math.max(...data.update.questionData.map((e, i) => e.sectionNo))
    : key.sectionNo

  let content = []
  if (!data.update) {
    for (let i = 1; i <= section; i++) {
      content.push(<h5 key={i} className="section-preview-title" >Section {i}</h5>)

      let qKey = `questionSection${i}`
      let tKey = `quesType${i}`
      let hasDomain = `subdomain${i}` in key
      let subdomainDefault = `subdomain${i}`
      let marksDefault = `marksSection${i}`

      let subDomainLoop

      for (let j = 1; j <= key[qKey]; j++) {
        if (hasDomain && subDomData.length > 0) {
          subDomainLoop = (
            <CustomDropdown
              dropdownKey={`subdomain${i}${j}`}
              placeholder="Select"
              openKey={openKey}
              setOpenKey={setOpenKey}
              defaultValue={key[subdomainDefault]}
              options={[
                { value: "", label: "Select" },
                ...subDomData.map((e, i) => ({
                  value: e.id,
                  label: e.Subject,
                })),
              ]}
            />
          )
        }
        if (key[tKey] === 'multipleChoice') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-2 mb-md-0">
                <span className="question-no me-3">Q{j}</span>
                <input type="radio" id={`optionA${i}${j}`} name={`optMCQ${i}${j}`} value={'optA'} />
                <label htmlFor={`optionA${i}${j}`}>
                  <span className="circle">A</span>
                </label>
                <input type="radio" id={`optionB${i}${j}`} name={`optMCQ${i}${j}`} value={'optB'} />
                <label htmlFor={`optionB${i}${j}`}>
                  <span className="circle">B</span>
                </label>
                <input type="radio" id={`optionC${i}${j}`} name={`optMCQ${i}${j}`} value={'optC'} />
                <label htmlFor={`optionC${i}${j}`}>
                  <span className="circle">C</span>
                </label>
                <input type="radio" id={`optionD${i}${j}`} name={`optMCQ${i}${j}`} value={'optD'} />
                <label htmlFor={`optionD${i}${j}`}>
                  <span className="circle">D</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else if (key[tKey] === 'trueFalse') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-3 mb-md-0">
                <span className="question-no me-2">Q{j}</span>
                <input type="radio" id={`optionT${i}${j}`} name={`optTF${i}${j}`} value={'true'} />
                <label htmlFor={`optionT${i}${j}`}>
                  <span className="circle">T</span>
                </label>
                <input type="radio" id={`optionF${i}${j}`} name={`optTF${i}${j}`} value={'false'} />
                <label htmlFor={`optionF${i}${j}`}>
                  <span className="circle">F</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <span className="question-no me-2 mb-2 mb-md-0">Q{j}</span>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        }
      }
    }
  } else {
    for (let i = 1; i <= section; i++) {
      content.push(<h5 key={i}>Section {i}</h5>)

      let qKey = `questionSection${i}`
      let tKey = `quesType${i}`
      let hasDomain = `subdomain${i}` in key
      let subdomainDefault = `subdomain${i}`
      let marksDefault = `marksSection${i}`

      let subDomainLoop

      for (let j = 1; j <= key[qKey]; j++) {
        if (hasDomain && subDomData.length > 0) {
          subDomainLoop = (
            <CustomDropdown
              dropdownKey={`subdomain${i}${j}`}
              placeholder="Select"
              openKey={openKey}
              setOpenKey={setOpenKey}
              defaultValue={key[subdomainDefault]}
              options={[
                { value: "", label: "Select" },
                ...subDomData.map((e, i) => ({
                  value: e.id,
                  label: e.Subject,
                })),
              ]}
            />
          )
        }
        if (key[tKey] === 'multipleChoice') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-2 mb-md-0">
                <span className="question-no me-2">Q{j}</span>
                <input type="radio" id={`optionA${i}${j}`} name={`optMCQ${i}${j}`} value={'optA'} />
                <label htmlFor={`optionA${i}${j}`}>
                  <span className="circle">A</span>
                </label>
                <input type="radio" id={`optionB${i}${j}`} name={`optMCQ${i}${j}`} value={'optB'} />
                <label htmlFor={`optionB${i}${j}`}>
                  <span className="circle">B</span>
                </label>
                <input type="radio" id={`optionC${i}${j}`} name={`optMCQ${i}${j}`} value={'optC'} />
                <label htmlFor={`optionC${i}${j}`}>
                  <span className="circle">C</span>
                </label>
                <input type="radio" id={`optionD${i}${j}`} name={`optMCQ${i}${j}`} value={'optD'} />
                <label htmlFor={`optionD${i}${j}`}>
                  <span className="circle">D</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else if (key[tKey] === 'trueFalse') {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <div className="radio-button-group mb-2 mb-md-0">
                <span className="question-no me-2 mb-2 mb-md-0">Q{j}</span>
                <input type="radio" id={`optionT${i}${j}`} name={`optTF${i}${j}`} value={'true'} />
                <label htmlFor={`optionT${i}${j}`}>
                  <span className="circle">T</span>
                </label>
                <input type="radio" id={`optionF${i}${j}`} name={`optTF${i}${j}`} value={'false'} />
                <label htmlFor={`optionF${i}${j}`}>
                  <span className="circle">F</span>
                </label>
              </div>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        } else {
          content.push(
            <div
              key={`${i}${j}`}
              className="d-flex align-items-center flex-wrap gap-2 questionItem"
              data-type={key[tKey]}
              data-section={i}
            >
              <span className="me-3 mb-3">Q{j}</span>
              <input
                type="number"
                className="form-control form-control-sm w-auto marks answer-input"
                min={0}
                name={`marks${i}${j}`}
                id={`marks${i}${j}`}
                defaultValue={key[marksDefault]}
              />
              {subDomainLoop}
            </div>
          )
        }
      }
    }
  }

  const handleAnsKey = (e) => {
    e.preventDefault()

    const queryData = {}

    const row = data.anskeyData

    const tId = user.id
    // const tId = undefined;
    console.log(tId)

    const questionData = []

    const questions = document.querySelectorAll('.questionItem')

    let maxMarks = 0

    questions.forEach((element) => {
      const quesDataObj = {}
      quesDataObj['tId'] = tId
      quesDataObj['subject'] = row.subject
      quesDataObj['class'] = row.class
      quesDataObj['subdomain'] = element.querySelector('select.subdomain')
        ? element.querySelector('select.subdomain').value
        : null
      quesDataObj['marks'] = element.querySelector('input.marks').value
      quesDataObj['quesType'] = element.getAttribute('data-type')
      quesDataObj['sectionNo'] = element.getAttribute('data-section')
      quesDataObj['correctAns'] = element.querySelector('input[type="radio"]:checked')
        ? element.querySelector('input[type="radio"]:checked').value
        : null
      questionData.push(quesDataObj)
      maxMarks += Number(quesDataObj['marks'])
    })

    row['marks'] = maxMarks

    const { examName, subject, class: className, marks, examDate } = row
    const selectedObject = { examName, subject, className, marks, examDate }
    queryData['questionpaper'] = selectedObject
    queryData['questions'] = questionData

    console.log(queryData)

    apiClient
      .post('/school/anskey', queryData)
      .then((response) => {
        console.log(response)
        if (response.status === 200) {
          // navigator('/dashboard')
        }
      })
      .catch((error) => {
        console.error('Error submitting answer key:', error)
      })
  }

  return (
    <div className="answer-sheet-page">
      <div className="container-fluid px-3 px-lg-4 py-4">
        <div className="answer-shell">
          <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">
            <h4 className="page-title mb-0">Answer Sheet</h4>
          </div>
          <form action="" method="post" autoComplete="off" onSubmit={handleAnsKey}>
            <div className="row g-3 mb-4">
              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="examName" className="form-label field-label required">
                  Exam Name
                </label>
                <input
                  type="text"
                  className="form-control form-control-lg answer-input"
                  name="examName"
                  id="examName"
                  defaultValue={key.examName}
                  disabled
                />
                {/* {errors.examName && <div className="text-danger">{errors.examName}</div>} */}
              </div>
              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="class" className="form-label field-label required">
                  Class
                </label>
                <CustomDropdown
                  dropdownKey="class"
                  openKey={openKey}
                  setOpenKey={setOpenKey}
                  placeholder="Select"
                  defaultValue={key.class}
                  disabled
                  options={[
                    { value: "", label: "Select" },
                    ...classData.map((row) => ({
                      value: row.class,
                      label: row.class,
                    })),
                  ]}
                />
                {/* {errors.class && <div className="text-danger">{errors.class}</div>} */}
              </div>
              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="subject" className="form-label field-label required">
                  Subject
                </label>
                <CustomDropdown
                  dropdownKey="subject"
                  placeholder="Select"
                  defaultValue={key.subject}
                  openKey={openKey}
                  setOpenKey={setOpenKey}
                  disabled
                  options={[
                    { value: "", label: "Select" },
                    ...SubjectData.map((row) => ({
                      value: row.id,
                      label: row.subject,
                    })),
                  ]}
                />
                {/* {errors.subject && <div className="text-danger">{errors.subject}</div>} */}
              </div>
              <div className="col-12 col-md-6 col-lg-3">
                <label htmlFor="examDate" className="form-label">
                  Date
                </label>
                <input
                  type="date"
                  className="form-select form-select-lg answer-input"
                  name="examDate"
                  id="examDate"
                  defaultValue={key.examDate}
                  disabled
                />
                {/* {errors.examDate && <div className="text-danger">{errors.examDate}</div>} */}
              </div>
            </div>
            <div className="row">
              <div className="col-12">{content}</div>
            </div>
            <div className="d-flex justify-content-start mt-4">
              <button type="submit" className="btn btn-primary h45">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
