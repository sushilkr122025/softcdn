import { Bar } from "react-chartjs-2";
import Color from '../gallery/Color'

const ChartRenderer = ({ type, data, options }) => {    
  if (!data) return null;

  if (type === "bar") {
    return <Bar 
    data={{
        labels: data.labels, 
        datasets: data.datasets.map((ds, i) => ({
        ...ds,
        backgroundColor: Color.bgColor[i],
        borderColor: Color.boColor[i],
        borderWidth: 1,
        }))
    }}
     />;
  }

  if (type === "stackedBar") {
    return (
      <Bar      
      data={data}
        options={{
          indexAxis: options?.indexAxis || "x",
          scales: {
            x: { stacked: true, max: 100 },
            y: { stacked: true }
          }
        }}
      />
    );
  }

  return null;
};

export default ChartRenderer;