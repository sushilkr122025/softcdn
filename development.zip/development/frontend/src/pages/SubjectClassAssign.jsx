import React, { useEffect, useState, useCallback } from 'react'
import { MdRemoveCircleOutline, MdAddCircleOutline, MdSave } from 'react-icons/md'
import apiClient from '../api/apiService'
import UserServices from '../api/UserServices'
import { useParams, useNavigate } from 'react-router-dom'
import ShowMessage from '../components/ShowMessage'
import CustomDropdown from '../components/layout/CustomDropdown'

export default function SubjectClassAssignment({ initialData = null }) {
  const [subjectData, setSubjectData] = useState([])
  const [classData, setClassData] = useState([])
  const [sectionData, setSectionData] = useState([])
  const [rows, setRows] = useState([])
  const [openKey, setOpenKey] = useState("");
  const [classTeacher, setClassTeacher] = useState({
    classTeacher: '',
    section: '',
  })
  const [showMsg, setShowMsg] = useState(false)
  const { userid } = useParams()
  const navigator = useNavigate()
  const updateId = userid ? userid : null
  const [userData, setUserData] = useState()
  const makeEmptyRow = useCallback(() => ({ subject: '', classIds: [] }), [])
  useEffect(() => {
    let mounted = true
    const load = async () => {
      try {
        const [subjectsRes, classesRes, sectionRes] = await Promise.all([
          apiClient.get('/store/subject'),
          apiClient.get('/store/classes'),
          apiClient.get('/store/section'),
        ])

        const subjects = subjectsRes.data || []
        const classes = (classesRes.data || [])
          .filter((c) => c.status === 1)
          .map((c) => String(c.class))
        const sections = sectionRes.data || []

        if (!mounted) return
        setSubjectData(subjects)
        setClassData(classes)
        setSectionData(sections)

        // initialize rows either from initialData (edit mode) or at least one empty row
        if (initialData && Array.isArray(initialData) && initialData.length) {
          // expected shape: [{ subjectId: '3', classIds: ['6','7'] }, ...]
          const mapped = initialData.map((r) => ({
            subject: String(r.subjectId),
            classIds: (r.classIds || []).map(String),
          }))
          setRows(mapped.length ? mapped : [makeEmptyRow()])
        } else {
          setRows((prev) => (prev.length ? prev : [makeEmptyRow()]))
        }
      } catch (err) {
        console.error('Error loading subjects/classes:', err)
      }
    }

    load()
    return () => {
      mounted = false
    }
  }, [initialData, makeEmptyRow])

  useEffect(() => {
    const fetchUserData = async () => {
      if (!updateId) return
      try {
        const response = await UserServices.getUser({ params: { id: updateId } })
        if (response?.userdata) {
          const user = response.userdata
          console.log(user)
          setUserData(user)
          const mappedRows =
            Array.isArray(user.teacherSubject) && user.teacherSubject.length > 0
              ? user.teacherSubject.map((item) => ({
                subject: String(item.subjectId),
                classIds: (item.classIds || []).map(String),
              }))
              : [makeEmptyRow()]

          setRows(mappedRows)

          setClassTeacher({
            classTeacher: user.classTeacher ? String(user.classTeacher) : '',
            section: user.section ? String(user.section) : '',
          })
        }
      } catch (error) {
        console.error('Error fetching user data:', error.message)
      }
    }

    fetchUserData()
  }, [updateId, makeEmptyRow])

  // keep rows consistent if class set changes (e.g. admin updated classes) — remove classes that no longer exist
  useEffect(() => {
    if (!classData.length) return
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        classIds: r.classIds.filter((cid) => classData.includes(cid)),
      }))
    )
  }, [classData])

  const addRow = () => setRows((prev) => [...prev, makeEmptyRow()])
  const removeRow = () => setRows((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev))

  const handleSubjectChange = (index, subjectId) => {
    setRows((prev) => {
      const next = [...prev]
      next[index] = { ...next[index], subject: subjectId }
      return next
    })
  }

  const toggleClassForRow = (rowIndex, classId) => {
    setRows((prev) => {
      const next = [...prev]
      const row = { ...(next[rowIndex] || makeEmptyRow()) }
      const setIds = new Set(row.classIds || [])
      if (setIds.has(classId)) setIds.delete(classId)
      else setIds.add(classId)
      row.classIds = Array.from(setIds)
      next[rowIndex] = row
      return next
    })
  }

  const handleSave = async () => {
    try {
      const payload = {}
      payload['teacherSubject'] = rows
        .map((r) => ({ subjectId: r.subject, classIds: r.classIds }))
        .filter((r) => r.subjectId && Array.isArray(r.classIds) && r.classIds.length > 0)

      payload['classTeacher'] = classTeacher.classTeacher
      payload['section'] = classTeacher.section
      payload['id'] = userid
      if (!payload.teacherSubject || payload.teacherSubject.length === 0) {
        console.warn('No rows with both subject and classes; nothing to save.')
        return
      }
      console.log({ payload })

      const response = await UserServices.updateUser(payload)
      if (response) {
        setShowMsg(true)
      }
    } catch (err) {
      console.error('Error saving subject-class assignments:', err)
    }
  }

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12 col-lg-10 mx-auto">
          <ShowMessage show={showMsg} type="modal" message="User Details Saved" variant="success" btnConfirm={true} btnClose={false} textConfirm="OK"
            onClose={() => setShowMsg(false)}
            onConfirm={() => {
              setShowMsg(false)
              navigator('/users')
            }}
          />
          <div className="card mt-5">
            <div className="card-body p-4">
              <div className="mb-4 border-bottom pb-2 d-flex justify-content-between align-items-center">
                <h5 className="fw-bold hdngcolor">{userData && userData.name}'s Assign Subjects to Classes</h5>
                <button className="btn btn-primary h45" onClick={handleSave}>
                  <MdSave className='me-2' size={20} />
                  Save Assignments
                </button>
              </div>
              <div className="row mb-3 gx-3">
                <div className="col-md-6 mb-2">
                  <label className="form-label small" htmlFor="classTeacher">Class Teacher of</label>
                  <CustomDropdown
                    dropdownKey="classTeacher"
                    placeholder="Class Teacher"
                    openKey={openKey}
                    setOpenKey={setOpenKey}
                    value={classTeacher.classTeacher}
                    error={false}
                    options={classData.map((cls) => ({
                      value: cls,
                      label: cls,
                    }))}
                    onChange={(val) =>
                      setClassTeacher({ ...classTeacher, classTeacher: val })
                    }
                  />
                </div>
                <div className="col-6 ps-2">
                  <label className="form-label small" htmlFor="sectionTeacher">Section Teacher of</label>
                  <CustomDropdown
                    dropdownKey="sectionTeacher"
                    placeholder="Section Teacher"
                    openKey={openKey}
                    setOpenKey={setOpenKey}
                    value={classTeacher.section}
                    error={false}
                    options={sectionData.map((sec) => ({
                      value: sec.id,
                      label: sec.section,
                    }))}
                    onChange={(val) =>
                      setClassTeacher({ ...classTeacher, section: val })
                    }
                  />
                </div>
              </div>
              <table className="table table-bordered align-middle mb-0">
                <thead>
                  <tr>
                    <th style={{ width: '30%' }}>Subject</th>
                    <th>Classes</th>
                  </tr>
                </thead>

                <tbody>
                  {rows.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      <td>
                        <CustomDropdown
                          dropdownKey={`subject-${rowIndex}`}
                          openKey={openKey}
                          setOpenKey={setOpenKey}
                          placeholder="Select Subject"
                          value={row.subject}
                          error={false}
                          options={subjectData.map((s) => ({
                            value: s.id,
                            label: s.subject,
                          }))}
                          onChange={(val) => handleSubjectChange(rowIndex, val)}
                        />
                      </td>

                      <td>
                        <div
                          className="classes-wrap"
                          style={{ maxHeight: 120, overflowY: 'auto' }}
                        >
                          {classData.map((cls) => {
                            const checked = row.classIds.includes(cls)
                            return (
                              <label key={cls} className={`class-checkbox ${checked ? 'checked' : ''}`}>
                                <input
                                  className="checkbox-input"
                                  type="checkbox"
                                  id={`r${rowIndex}-c${cls}`}
                                  checked={checked}
                                  aria-checked={checked}
                                  onChange={() => toggleClassForRow(rowIndex, cls)}
                                />
                                <span className="checkbox-box" aria-hidden="true" />
                                <span className="pill-label">{cls}</span>
                              </label>
                            )
                          })}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={2} className="text-center bg-light">
                      <span className="me-4 text-danger fs-5 cursor-pointer" onClick={removeRow}>
                        <MdRemoveCircleOutline />
                      </span>
                      <span className="text-success fs-5 cursor-pointer" onClick={addRow}>
                        <MdAddCircleOutline />
                      </span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
