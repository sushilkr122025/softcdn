import {
  Injectable,
  NotFoundException,
  HttpStatus,
  InternalServerErrorException,
  BadRequestException,
  LoggerService,
  Inject,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, In } from 'typeorm';
import { plainToInstance } from 'class-transformer';
import { Login } from '../entities/login.entity';
import { LoginDto, UpdateLoginDto } from '../dto/login.dto';
import { ConfigService } from '@nestjs/config';
import { UserDetail } from '../entities/userdetail.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { StudentInformationDto } from '../dto/student.information.dto';
import { UserPermission } from '../entities/user.permissions.entity';
import { QuestionRule } from '../entities/question.rule.entity';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

@Injectable()
export class UserService {
  private readonly keybrcyt: string;
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Login)
    private loginRepository: Repository<Login>,
    @InjectRepository(UserDetail)
    private detailRepository: Repository<UserDetail>,
    @InjectRepository(StudentInformation)
    private studentRepository: Repository<StudentInformation>,
    @InjectRepository(UserPermission)
    private userPermissionRepository: Repository<UserPermission>,
    @InjectRepository(QuestionRule)
    private questionRuleRepository: Repository<QuestionRule>,
    @Inject(WINSTON_MODULE_NEST_PROVIDER)
    private readonly logger: LoggerService,
    private readonly configuration: ConfigService
  ) {
    this.keybrcyt = this.configuration.get<string>('keybcrypt') || 'education';
  }

  async findAll(tenantid: string, notin: number): Promise<any[]> {
    try {
      //, id: Not(notin)
      const result = await this.loginRepository.find({
        where: { tenantid: tenantid, dmlType: 'I' },
        select: [
          'id',
          'userid',
          'name',
          'email',
          'gender',
          'designation',
          'classTeacher',
          'section',
          'mobileno',
          'role',
          'createdate',
        ],
      });
      return result;
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  async findUserDetails(data: { tenantid: string; id: number }): Promise<any> {
    const { tenantid, id } = data;
    try {
      const user = await this.loginRepository.findOne({
        where: { tenantid, id },
      });

      if (!user) {
        throw new Error('User not found');
      }
      this.logger.log(
        `UserService: Retrieved user details for ID ${id} | user.id: ${user.id}`
      );
      const userparmission = await this.userPermissionRepository.find({
        where: { userId: user.id },
      });

      // return plainToInstance(UpdateLoginDto, user, {
      //   excludeExtraneousValues: true,
      // });
      return {
        userdata: plainToInstance(UpdateLoginDto, user, {
          excludeExtraneousValues: true,
        }),
        permission: userparmission,
      };
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  async findUserRule(id: number): Promise<any> {
    try {
      const qb = this.questionRuleRepository
        .createQueryBuilder('q')
        .leftJoin('login', 'u', 'FIND_IN_SET(u.id, q.teachersId) > 0')
        .select([
          'q.id AS id',
          'q.teachersId AS teachersId',
          'q.subjectId AS subjectId',
          'q.classId AS classId',
          'u.id AS approverId',
          'u.name AS name',
        ])
        .where('q.userId = :id', { id });
      // const [query, parameters] = qb.getQueryAndParameters();
      // console.log('Executed SQL:', query);
      // console.log('Parameters:', parameters);

      // Now execute it
      const user = await qb.getRawMany();
      if (!user) {
        throw new Error('User not found');
      }
      // console.log('user', user);
      return user;
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  findByEmail(email: string): Promise<Login | null> {
    return this.loginRepository.findOne({ where: { email } });
  }

  async findById(id: number): Promise<Login | null> {
    const user = await this.loginRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  async createUser(loginDto: LoginDto): Promise<any> {
    const { id, password, tenantid } = loginDto;

    let user: Login | undefined;

    if (loginDto.id) {
      user = await this.loginRepository.preload(loginDto);
      if (!user) {
        throw new NotFoundException(`User with id ${id} not found`);
      }
    } else {
      user = this.loginRepository.create({
        ...loginDto,
        password: password + this.keybrcyt,
      });
      await user.hashPassword();
    }
    const create = await this.loginRepository.save(user);
    if (create) {
      return create.id;
    } else {
      throw new NotFoundException('Error from backend service');
    }
  }

  async updateUser(loginDto: LoginDto): Promise<any> {
    // console.log('loginDto', loginDto.id);
    const { id } = loginDto;
    if (!loginDto.id) {
      throw new NotFoundException(`User ID is required for update`);
    }

    const user = await this.loginRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    if (
      loginDto.teacherSubject !== undefined ||
      loginDto.teacherSubject !== ''
    ) {
      user.teacherSubject = loginDto.teacherSubject ?? null;
    }
    if (loginDto.classTeacher !== undefined || loginDto.classTeacher !== '') {
      user.classTeacher = loginDto.classTeacher ?? '';
    }
    if (loginDto.section !== undefined || loginDto.section !== '') {
      user.section = loginDto.section ?? '';
    }

    const update = await this.loginRepository.save(user);
    if (update) {
      return { message: 'User updated successfully', id: update.id };
    } else {
      throw new NotFoundException('Error from backend service');
    }
  }

  // async createUser(loginDto: LoginDto): Promise<any> {
  //   console.log('Creating user with DTO:', loginDto);
  //   const {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   } = loginDto;
  //   const user = new Login();
  //   Object.assign(user, {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   });
  //   user.password = user.password + this.keybrcyt;
  //   await user.hashPassword();
  //   const create = await this.loginRepository.save(user);
  //   if (create) {
  //     return create.id;
  //   } else {
  //     throw new NotFoundException('Error from backend service');
  //   }
  // }

  async createStudent(studentDto: StudentInformationDto): Promise<any> {
    const student = new StudentInformation();
    Object.assign(student, studentDto);
    const create = await this.studentRepository.save(student);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    const studentData = {
      id: create.Id,
      name: create.name,
      rollNo: create.rollNo,
      fatherName: create.fatherName,
      motherName: create.motherName,
    };
    return studentData;
  }

  async findAllStudent(tenantid: string, q): Promise<StudentInformation[]> {
    return this.studentRepository.find({
      where: { tenantid: tenantid, class: 7, section: 'A' },
    });
  }

  async addUserPermissions(
    createdBy: number,
    permissionBody: any[],
    tenantid: string
  ): Promise<any> {
    if (!Array.isArray(permissionBody) || permissionBody.length === 0) {
      // throw new BadRequestException('Invalid permissions payload');
      console.log('invalid permissions payload');
    }

    const userId = parseInt(permissionBody[0].userId);

    const data = permissionBody.map((e) => ({
      id: e.id ?? undefined,
      module: e.module,
      permissions: e.permissions,
      userId,
      createdBy,
      tenantid,
    }));

    // console.log('Prepared data:', data);

    const create = await this.userPermissionRepository.save(data);

    return {
      statusCode: HttpStatus.CREATED,
      message: 'Permissions inserted/updated successfully',
      insertedCount: Array.isArray(create) ? create.length : 1,
    };
  }

  async allUserPermissions(userid: number): Promise<UserPermission[]> {
    return this.userPermissionRepository.find({
      where: { userId: userid },
    });
  }

  async findTeacherByClassAndSubject(
    classId: string,
    subjectId: string
  ): Promise<any> {
    //   const query = `
    //   SELECT userId
    //   FROM userpermissions
    //   WHERE JSON_CONTAINS(
    //     JSON_EXTRACT(permissions, '$.APPROVE'),
    //     JSON_OBJECT('subjectId', ?),
    //     '$'
    //   )
    //   AND JSON_SEARCH(permissions, 'one', ?, NULL, '$.APPROVE[*].classIds[*]') IS NOT NULL
    // `;
    // console.log('🟢 Executing SQL:\n', query);
    //   const teachers = await this.userPermissionRepository.query(query, [
    //     subjectId,
    //     classId,
    //   ]);
    const qb = this.userPermissionRepository
      .createQueryBuilder('p')
      .select('p.userId')
      .where(
        `JSON_CONTAINS(JSON_EXTRACT(p.permissions, '$.REVIEW'), JSON_OBJECT('subjectId', :subjectId), '$')
        AND JSON_SEARCH(p.permissions, 'one', :classId, NULL, '$.REVIEW[*].classIds[*]') IS NOT NULL`,
        { subjectId, classId }
      );
    const [sql, parameters] = qb.getQueryAndParameters();
    console.log(' Executed SQL:', sql);
    console.log(' Parameters:', parameters);
    const teachers = await qb.getRawMany();
    if (!teachers) {
      throw new NotFoundException('No teachers found');
    }
    // console.log('teachers', teachers);
    const tid = [...new Set(teachers.map((t) => t.p_userId))];
    const user = await this.loginRepository.find({
      select: ['id', 'name'],
      where: {
        id: In(tid),
      },
    });

    return user;
  }

  async createQuestionRule(body: any[], createdBy: number): Promise<any> {
    if (!body || body.length === 0) {
      throw new BadRequestException('Request body is empty');
    }

    const userId = body[0].userId;

    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Check if user already has rules
      const existing = await queryRunner.manager.find(
        this.questionRuleRepository.target,
        {
          where: { userId },
        }
      );

      if (existing.length > 0) {
        // Delete existing rules for that user
        await queryRunner.manager.delete(this.questionRuleRepository.target, {
          userId,
        });
      }

      // Prepare new insert data
      const insertData = body.map((e) => ({
        userId: e.userId,
        subjectId: e.subjectId,
        classId: e.classId,
        teachersId: e.teachersId.toString(),
        createdBy,
      }));

      await queryRunner.manager.insert(
        this.questionRuleRepository.target,
        insertData
      );

      await queryRunner.commitTransaction();

      return `Rules for user ${userId} successfully ${existing.length > 0 ? 'replaced' : 'created'}`;
    } catch (error) {
      await queryRunner.rollbackTransaction();
      console.error('Error creating question rules:', error);
      throw new InternalServerErrorException('Error creating question rules');
    } finally {
      await queryRunner.release();
    }
  }
}
