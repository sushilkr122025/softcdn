import React, { useEffect, useRef, useState } from 'react'
import { Bar, getElementAtEvent } from 'react-chartjs-2'
import Modal from 'react-bootstrap/Modal'
import './Reportadmin.css'
import 'chart.js/auto'
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Color from '../gallery/Color'
import MultiServices from '../../api/MultiServices'


const Reportadmin = () => {
  const [selectedclass, setSelectedclass] = useState('')
  const [answer, setAnswer] = useState([])
  const [resdata, setResdata] = useState([])
  const [paper, setPaper] = useState()
  let [selectedPaperid, setSelectedPaperid] = useState('')
  let [selectedsubject, setSelectedsubject] = useState()
  let [selsection, setSelsection] = useState()
  let [datasets, setDatasets] = useState([])
  let [meandatasets, setMeandatasets] = useState([])
  let [meanlabel, setMeanlabel] = useState([])
  let [meandata, setMeandata] = useState([])
  let [meanbgcolor, setMeanbgcolor] = useState([])
  let [quesids, setQesids] = useState([])
  let [subDomainvalue, setSubDomainvalue] = useState('all')
  let romancount = [
    'I',
    'II',
    'III',
    'IV',
    'V',
    'VI',
    'VII',
    'VIII',
    'IX',
    'X',
    'XI',
    'XII',
    'XIII',
    'XIV',
    'XV',
    'XVI',
    'XVII',
    'XVIII',
    'XIX',
    'XX',
  ]

  const handleClassData = async (e) => {
    e.preventDefault()
    let classes = selectedclass
    const response = await MultiServices.ClassReport({
      params: {
        class: classes,
      },
    })    
    // console.log(response.quesid[response.answer[0].paperid])
    // console.log(response.answer[0].paperid)
    setQesids(response.quesid)
    setResdata(response.answer)
    setSelectedPaperid(response.answer[0].paperid)
    setPaper(response.paper)
    setSelectedsubject(response.paper[0].subject)
    setAnswer(response.answer.filter((item) => item.paperid == response.answer[0].paperid))
  }

  const handlesubject = (e) => {
    filterdata(e.target.value)
    setSelectedPaperid(e.target.value)
    setSelectedsubject(e.target[e.target.selectedIndex].textContent)
  }

  const filterdata = (pid) => {
    setSubDomainvalue('all')
    return setAnswer(resdata.filter((item) => item.paperid == pid))
  }
  const [question, setQuestion] = useState()
  const [subDomain, setSubDomain] = useState()
  useEffect(() => {
    {
      answer.length > 0 &&
        answer.map((item) => {
          let indata = []
          let inmeandata = []
          Object.keys(item.data).map((key, i) => {
            indata.push({
              label: 'Section ' + (i + 1),
              data: item.data[key].percent,
              backgroundColor: Color.bgColor[i],
            })
            inmeandata.push(item.data[key].meanpercent)
          })
          setDatasets(indata)
          setMeandatasets(inmeandata)
        })
    }

    if (selectedPaperid != '') {
      console.log(selectedPaperid)
      const quesData = async (e) => {
        // console.log(quesids[e])
        try {
          const response = await MultiServices.FindQuestionList({
            params: {
              qid: quesids[e].toString(),
            },
          })
          setQuestion(response)
          // const uniqueQuesTypes = [...new Set(response.map((question) => question.quesType))]
          const uniqueSubdomain = [...new Set(response.map((question) => question.subdomain))]
          setSubDomain(uniqueSubdomain)
        } catch (err) {
          console.log(err.message)
        }
      }
      quesData(selectedPaperid)
    }
  }, [answer, selectedPaperid])

  useEffect(() => {
    if (meandatasets.length > 0 && meandatasets) {
      let labels = ['Section 1', 'Section 2', 'Section 3', 'Section 4', 'Section 5']
      let data = meandatasets
      let backgroundColor = [
        Color.bgColor[0],
        Color.bgColor[1],
        Color.bgColor[2],
        Color.bgColor[3],
        Color.bgColor[4],
      ]

      let datamerged = data.map((color, i) => {
        return {
          data: data[i],
          label: labels[i],
          background: backgroundColor[i],
        }
      })

      let datasort = datamerged.sort((b, a) => {
        return a.data - b.data
      })

      let inmeandata = []
      let inmeanlabel = []
      let inmeanbgcolor = []

      datasort.map((d) => {
        inmeandata.push(d.data)
        inmeanlabel.push(d.label)
        inmeanbgcolor.push(d.background)
      })

      setMeanlabel(inmeanlabel)
      setMeandata(inmeandata)
      setMeanbgcolor(inmeanbgcolor)
    }
  }, [meandatasets])

  const [gradeList, setGradeList] = useState([])
  const handleGradeList = async () => {
    const res = await MultiServices.GradeList()    
    setGradeList(res)
  }

  useEffect(() => {
    handleGradeList()
  }, [])

  const numberToLetter = {
    1: 'a',
    2: 'b',
    3: 'c',
    4: 'd',
    5: 'e',
  }

  // Function to get corresponding letter
  const getLetter = (num) => {
    return numberToLetter[num] || ''
  }

  // first graph
  const chartRef = useRef()
  const [modalsrc, setModalsrc] = useState()
  const [show, setShow] = useState(false)
  const [matches, setMatches] = useState()

  const handleClose = () => setShow(false)
  // const handleShow = () => setShow(true);

  const graphclickfirst = (event) => {
    let datasetIndex = getElementAtEvent(chartRef.current, event)
    if (datasetIndex.length > 0) {
      let index = datasetIndex[0].datasetIndex
      // console.log(datasets[index].label)
      // console.log(datasetIndex[0].index)
      // console.log(selectedPaperid)
      const regex = /\d+/g
      setSelsection(datasets[index].label)
      console.log(datasets[index].label)
      const matche = getLetter(datasets[index].label.match(regex))
      setMatches(matche)
      setModalsrc(
        `/sectionreport?paperid=${selectedPaperid}&class=${selectedclass}&section=${matche}`,
        '_blank'
      )
      setShow(true)
    }
  }

  const choptionsfirst = {
    plugins: {
      title: {
        display: false,
        text: 'Comparison Chart By Section', // Chart title
        // color: '#343a40',
        font: {
          weight: 'bold',
          size: 24,
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          autoSkip: false,
          maxRotation: 0,
          minRotation: 0,
        },
      },
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: '%', // Name of y-axis
          font: {
            size: 24,
          },
        },
      },
    },
  }
  const choptions = {
    plugins: {
      title: {
        display: false,
        text: 'Chart by mean %', // Chart title
        // color: '#343a40',
        font: {
          weight: 'bold',
          size: 24,
        },
      },
      legend: {
        display: false,
      },
      tooltip: {
        enabled: true,
      },
      datalabels: {
        display: true,
        //color: "black",
        //formatter: Math.round,
        font: {
          weight: 'bold',
          family: 'arial',
          size: 13,
        },
        anchor: 'end',
        offset: -25,
        align: 'start',
      },
      afterUpdate: function (chart) {
        // Add padding to the top of the chart area
        chart.layout.padding.top = 20 // Adjust this value as needed
      },
    },
    scales: {
      x: {
        ticks: {
          autoSkip: false,
          maxRotation: 45,
          minRotation: 45,
        },
      },
      y: {
        title: {
          display: true,
          text: '% position',
          font: {
            size: 18,
          },
        },
        beginAtZero: true,
        grace: '15%',
        ticks: {
          //stepSize: 20,
          //min:10,
          //max: 100
        },
      },
    },
  }
  // const optiongraphfirst= {
  //   onclick: graphclickfirst
  // }

  const setSelectedType = async (e) => {
    console.log(e)
    setSubDomainvalue(e)
    if (e !== 'all') {
      try {
        let filterid = []
        question.filter((item) => {
          if (item.subdomain === e) {
            return filterid.push(item.id)
          }
        })
        // console.log(filterid)
        // const response = await MultiServices.ClassReportSubdomain({
        //   params: {
        //     qid: filterid.toString()
        //   }
        // });
        const response = await MultiServices.ClassReport({
          params: {
            class: selectedclass,
            subdomain: e,
            paperid: selectedPaperid,
          },
        })
        setAnswer(response.answer)
      } catch (err) {
        console.log(err.message)
      }
    } else {
      setAnswer(resdata.filter((item) => item.paperid == selectedPaperid))
      setSubDomainvalue('all')
    }
  }

  return (
    <div className="container-fluid">
      <div className="row justify-content-md-center">
        <div className="col-md-auto m-4 p-4">
          <div className="input-group mb-3">
            <span className="input-group-text">Class</span>
            <select
              className="form-select inputfield"
              name="seletclass"
              onChange={(e) => setSelectedclass(e.target.value)}
              value={selectedclass}
            >
              <option value="">Select</option>
              <option value="6">6 th</option>
              <option value="7">7 th</option>
              <option value="8">8 th</option>
              <option value="9">9 th</option>
              <option value="10">10 th</option>
            </select>
            <span className="input-group-text">
              <input
                type="button"
                value="Go"
                className="btn btn-primary btn-sm "
                onClick={handleClassData}
              />
            </span>
          </div>
        </div>
      </div>
      {answer.length > 0 && (
        <>
          <div className="row align-items-center">
            <div className="col-lg-7 col-12 ms-lg-4 me-lg-5 py-3 border bg-white rounded rounded-4">
              <div className="row pb-3 align-items-center">
                <div className="col-sm-3">
                  <div className="form-floating w-100">
                    <select
                      className="form-select inputfield "
                      id="floatingSelect"
                      onChange={handlesubject}
                    >
                      {paper.map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.subject}
                        </option>
                      ))}
                    </select>
                    <label htmlFor="floatingSelect">Select Subject</label>
                  </div>
                  {/* <select className='form-select inputfield' onChange={handlesubject}>
            {
              paper.map((item) =>(            
                <option key={item.id} value={item.id}>{item.subject}</option>                        
            ))
            }
          </select> */}
                </div>
                <div className="col-sm-3">
                  <div className="form-floating w-100">
                    {subDomain && subDomain.length > 1 && (
                      <>
                        <select
                          className="form-select d-inline inputfield"
                          id="floatingSelect"
                          value={subDomainvalue}
                          onChange={(e) => setSelectedType(e.target.value)}
                        >
                          <option value="all">All</option>
                          {subDomain.map((item, index) => {
                            return (
                              <option key={index} value={item}>
                                {item}
                              </option>
                            )
                          })}
                        </select>
                      </>
                    )}
                    <label htmlFor="floatingSelect">Select Sub domain</label>
                  </div>
                  {/* {subDomain && subDomain.length > 1 && (  
                  <>
                Sub Domain <select className='form-select w-auto d-inline inputfield' value={subDomainvalue} onChange={(e) => setSelectedType(e.target.value)}><option value="all">All</option>
                  {
                    subDomain.map((item, index) => {
                      return <option value={item}>{item}</option>
                      })
                  }
                  </select>
                  </>
                )
              }  */}
                </div>
                <div className="col-sm-6 h5 px-md-4 text-end">Comparison Chart By Section</div>
              </div>

              <Bar
                ref={chartRef}
                data={{
                  labels: [
                    'Grade A+',
                    'Grade A',
                    'Grade B+',
                    'Grade B',
                    'Grade C+',
                    'Grade C',
                    'Grade D',
                    'Grade E',
                  ],
                  datasets: datasets,
                }}
                options={choptionsfirst}
                onClick={graphclickfirst}
              />
            </div>

            <div className="col-md-4">
              <div className="row ">
                <div className="col-6 h5">Grade by Range</div>
                <div className="col-6 text-end">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-info-circle-fill"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2" />
                  </svg>
                </div>
              </div>
              <div>
                <table className="table-bordered table-hover text-center rangedta">
                  <thead>
                    <tr>
                      <th>Grades</th>
                      <th>Range</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gradeList.map((item, key) => {
                      if (gradeList.length >= key + 3) {
                        //console.log("g1="+gradeList.length +'---'+ key)
                        return (
                          <tr key={key}>
                            <td>{item.grade}</td>
                            <td>
                              {item.markstart > 0 ? item.markstart - 1 : item.markstart}+ to{' '}
                              {item.markend}
                            </td>
                          </tr>
                        )
                      } else if (gradeList.length != key + 1) {
                        //console.log("g2="+gradeList.length +'---'+ key)
                        return (
                          <tr key={key}>
                            <td>{item.grade}</td>
                            <td>
                              {item.markstart} to {item.markend}
                            </td>
                          </tr>
                        )
                      } else if (gradeList.length == key + 1) {
                        //console.log("g3="+gradeList.length +'---'+ key)
                        return (
                          <tr key={key}>
                            <td>{item.grade}</td>
                            <td>
                              {item.markstart} to {item.markend}
                            </td>
                          </tr>
                        )
                      }
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div className="row pt-4 mt-4 mx-2">
            <div className="col-md-12 border bg-white rounded rounded-4">
              <div className="row mt-4 px-1 ">
                <div className="col-6 h5">Section wise performance</div>
                <div className="col-6 text-end">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-info-circle-fill"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2" />
                  </svg>
                </div>
              </div>
              <table className="secwiper table-bordered table-hover text-center">
                <thead>
                  <tr>
                    <th>Section</th>
                    {gradeList.map((item) => {
                      //if((key+1) != gradeList.length){
                      return (
                        <>
                          <th>{item.grade}</th>
                          <th>%</th>
                        </>
                      ) //}
                    })}

                    <th>mean %</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.keys(answer[0].data).map((key, i) => (
                    <tr key={key}>
                      <td>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="25"
                          height="25"
                          fill="currentColor"
                          className="bi bi-stop-fill"
                          viewBox="0 0 16 16"
                        >
                          <path
                            d="M5 3.5h6A1.5 1.5 0 0 1 12.5 5v6a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 11V5A1.5 1.5 0 0 1 5 3.5"
                            fill={Color.bgColor[i]}
                          />
                        </svg>
                        section {i + 1}
                      </td>
                      {answer[0].data[key].count.map((item, i) => (
                        <>
                          <td>{item}</td>
                          <td>{answer[0].data[key].percent[i]}</td>
                        </>
                      ))}
                      <td>{answer[0].data[key].meanpercent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="row pt-4 mt-4 mx-2 align-items-center">
            <div className="col-md-4 py-3 border bg-white rounded rounded-4">
              <div className="row">
                <div className="col-6 offset-6 text-end h5">Chart By Mean %</div>
              </div>
              <Bar
                data={{
                  labels: meanlabel,
                  datasets: [
                    {
                      label: '',
                      barPercentage: 0.9,
                      categoryPercentage: 1,
                      data: meandata,
                      backgroundColor: meanbgcolor,
                    },
                  ],
                }}
                plugins={[ChartDataLabels]}
                options={choptions}
              />
            </div>
            <div className="col-md-3 ms-4">
              <div className="row mt-4 px-1 captions ">
                <div className="col-7 h5">Position by mean % </div>
                <div className="col-5 text-end">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-info-circle-fill"
                    viewBox="0 0 16 16"
                  >
                    <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16m.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2" />
                  </svg>
                </div>
              </div>
              <table className="rangedta text-center table-bordered table-hover ">
                <thead>
                  <tr>
                    <th>Section</th>
                    <th>Position</th>
                  </tr>
                </thead>
                <tbody>
                  {meanlabel.map((item, i) => (
                    <tr key={i}>
                      <td>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="25"
                          height="25"
                          fill="currentColor"
                          className="bi bi-stop-fill"
                          viewBox="0 0 16 16"
                        >
                          <path
                            d="M5 3.5h6A1.5 1.5 0 0 1 12.5 5v6a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 11V5A1.5 1.5 0 0 1 5 3.5"
                            fill={meanbgcolor[i]}
                          />
                        </svg>
                        {item}
                      </td>
                      <td>{romancount[i]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {modalsrc && (
        <Modal
          //  className="custom-xl-modal"
          size="fullscreen"
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title className="h5">
              {selectedsubject} : Class {selectedclass + matches}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <iframe
              src={modalsrc}
              title="Dynamic Iframe"
              width="100%"
              height="98%"
              allowFullScreen
            />
          </Modal.Body>
        </Modal>
      )}
    </div>
  )
}

export default Reportadmin
