import React, { useState, useEffect } from 'react'
import { FaEllipsisVertical } from "react-icons/fa6";
import './admin.css'
import apiClient from '../api/apiService';
import student from '../assets/images/student-grey.svg';
import { Link } from 'react-router-dom';

function Student() {
  const [userData, setUserData] = useState([])
  const [classes, setClasses] = useState('');
  const [classData, setClassData] = useState([]);
  const [section, setSection] = useState('');
  const [sectiondata, setSectiondata] = useState([]);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);

  const AllStudents = async () => {
    try {
      apiClient
        .get('/user/student', {
          params: {
            class: classes,
            section: section,
          }
        })
        .then((response) => {
          setUserData(response.data)
        })
        .catch((error) => {
          console.error(error)
        })
    } catch (error) {
      console.error('Error fetching sections:', error);
    }
  };
  const handleStudents = () => {
    AllStudents();
  }
  useEffect(() => {
    AllStudents();
    apiClient.get('/store/classes').then((res) => setClassData(res.data)).catch((err) => console.error('Class fetch error', err));
    apiClient
      .get('/store/section')
      .then((response) => {
        // console.log(response.data);
        setSectiondata(response.data)
      })
      .catch((error) => {
        console.error('Error fetching section data:', error)
      })
  }, [])
  const paginatedQuestions = () => {
    const startIndex = (currentPage - 1) * rowsPerPage;
    return userData.slice(startIndex, startIndex + rowsPerPage);
  };

  const totalPages = Math.ceil(userData.length / rowsPerPage);

  const handlePageChange = (n) => {
    if (n >= 1 && n <= totalPages) setCurrentPage(n);
  };
  return (
    <section id="admin">
      <div className="container-fluid">
        <div className="row align-items-center">
          <div className="col-6 py-3 d-flex align-items-end">
            <img
              src={student}
              alt="student"
              style={{ width: "25px" }} />
            <h5 className='text-grey-400 mb-0 ms-3'>Student</h5>
          </div>
          <div className="col-6 py-3 text-end">
            <Link to="/StudentRegistration">
              <button className='btn btn-sm btn-primary' >Add Student</button>
            </Link>
          </div>
        </div>
        <div className="row mb-4">
          <div className="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
            <select id="class" name="class" className="form-select" onChange={(e) => { setClasses(e.target.value); handleStudents() }}>
              <option value="">Class</option>
              {classData.map((classes) => (
                <option key={classes.id} value={classes.class}>
                  {classes.class}
                </option>
              ))}
            </select>
          </div>
          <div className="col-lg-2 col-md-3 col-sm-4 col-6 mb-3">
            <select id="subject" name="subject" className="form-select" onChange={(e) => { setSection(e.target.value); handleStudents() }}>
              <option value="">Section</option>
              {sectiondata.map((data) => (
                <option key={data.id} value={data.id}>
                  {data.section}
                </option>
              ))}
            </select>
          </div>
          <div className="col-12">
            <div className="table-responsive tbl-container">
              <table className="table border mb-0 table-hover" id="userTable">
                <thead className='position-sticky top-0'>
                  <tr>
                    <th>-</th>
                    <th>Name</th>
                    <th>Class</th>
                    <th>Section</th>
                    <th>Roll No</th>
                    <th>DOB</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Gender</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody className='tbody'>
                  {paginatedQuestions().map((row, index) => (
                    <tr key={row.id}>
                      <td>{index + 1}</td>
                      <td>{row.name}</td>
                      <td>{row.class}</td>
                      <td>{row.section}</td>
                      <td>{row.rollNo}</td>
                      <td>{row.dateOfBirth}</td>
                      <td>{row.emailId}</td>
                      <td>{row.contactNumber}</td>
                      <td>{row.gender}</td>
                      <td>
                        {row.dmlType === 'I' ? <span className="badge-active rounded-pill ">ACTIVE</span> : <span className="badge-inactive rounded-pill ">INACTIVE</span>}
                      </td>
                      <td>
                        <button type='button' className='btn btn-sm border-0' data-bs-toggle="dropdown" aria-expanded="false">
                          <FaEllipsisVertical className='text-primary' />
                        </button>
                        <ul className='dropdown-menu p-2'>
                          <li><a href={`/UserRegistration?id=${row.id}`} className='dropdown-item'>Edit Details</a></li>
                          <li><a href={`roles?id=${row.id}`} className='dropdown-item'>Set Roles</a></li>
                        </ul>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="d-flex justify-content-between align-items-center mt-3">
              <div className="d-flex align-items-center gap-2">
                <select
                  className="form-select form-select-sm"
                  style={{ width: '70px' }}
                  value={rowsPerPage}
                  onChange={(e) => {
                    setRowsPerPage(parseInt(e.target.value));
                    setCurrentPage(1);
                  }}
                >
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                </select>
                <span className="text-muted">
                  {(currentPage - 1) * rowsPerPage + 1}–{Math.min(currentPage * rowsPerPage, userData.length)} of {userData.length}
                </span>
              </div>
              <nav>
                <ul className="pagination pagination-sm mb-0">
                  <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                    <span className="page-link" onClick={() => handlePageChange(currentPage - 1)}>«</span>
                  </li>
                  {Array.from({ length: totalPages }).map((_, i) => (
                    <li key={i} className={`page-item ${currentPage === i + 1 ? 'active' : ''}`}>
                      <span className="page-link" onClick={() => handlePageChange(i + 1)}>{i + 1}</span>
                    </li>
                  ))}
                  <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                    <span className="page-link" onClick={() => handlePageChange(currentPage + 1)}>»</span>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Student
