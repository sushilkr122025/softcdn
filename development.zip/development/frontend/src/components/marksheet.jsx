import { useEffect, useState } from 'react'
import './Marksheet.css'
import QuestionServices from '../api/QuestionServices'
import ShowMessage from '../components/ShowMessage'
import { useNavigate, useLocation } from 'react-router-dom'

const Marksheet = () => {
  const [paperInfo, setPaperInfo] = useState(null)
  const [quesInfo, setQuesInfo] = useState([])
  const [answers, setAnswers] = useState({})
  const [unansweredKeys, setUnansweredKeys] = useState([])

  const [showMsg, setShowMsg] = useState(false)
  const [message, setMessage] = useState('')
  const [msgType, setMsgType] = useState('')
  const [btnConfirm, setBtnConfirm] = useState(false)
  const [textConfirm, setTextConfirm] = useState('')

  const navigator = useNavigate()
  const location = useLocation()

  /* ================= RECEIVE DATA (WEB + RN) ================= */

  useEffect(() => {
    if (location.state?.header && location.state?.body) {
      setPaperInfo(location.state.header)
      setQuesInfo(location.state.body)
    }
    console.log(location.state?.header)
    

    const handler = (event) => {
      try {
        const msg = JSON.parse(event.data)
        if (msg.type === 'INIT_DATA') {
          const { ocr, header, body } = msg.payload

          if (!header || !body) return

          setPaperInfo(header)
          setQuesInfo(body)

          const temp = {}
          ocr?.answers?.forEach((item) => {
            temp[`Q${item.question}`] = {
              value: item.prediction,
              review: item.Review || false,
            }
          })
          setAnswers(temp)
        }
      } catch (err) {
        console.error('Message parse error:', err)
      }
    }

    window.addEventListener('message', handler)
    return () => window.removeEventListener('message', handler)
  }, [location.state])

  /* ================= STUDENT CHECK ================= */

  useEffect(() => {
    if (!paperInfo) return

    const studentCheck = async () => {
      try {
        const res = await QuestionServices.studentAnswered({
          paperId: paperInfo.paperId,
          studentid: paperInfo.Id,
          section: paperInfo.section,
          class: paperInfo.class,
        })

        if (res.status === 200 && res.statusCode === 409) {
          setTextConfirm('Exit')
          setMsgType('modal')
          setBtnConfirm(true)
          setMessage('Already answered')
          setShowMsg(true)
        }
      } catch (err) {
        console.error('Answered check failed:', err)
      }
    }

    studentCheck()
  }, [paperInfo])

  /* ================= HANDLE CHANGE ================= */

  const handleChange = (e, key) => {
    const value = e.target.value

    setAnswers((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        value,
      },
    }))

    setUnansweredKeys((prev) => prev.filter((k) => k !== key))
  }

  /* ================= VALIDATION ================= */

  const validateAnswers = () => {
    const unanswered = []

    quesInfo.forEach((q) => {
      const key = `Q${q.sequence}`
      const value = answers[key]?.value
      if (!value || value.toString().trim() === '') {
        unanswered.push(key)
      }
    })

    setUnansweredKeys(unanswered)
    return unanswered
  }

  /* ================= PAYLOAD ================= */

  const generateMergedPayload = () => {
    if (!paperInfo) return null

    return {
      answers: quesInfo.map((q) => {
        const key = `Q${q.sequence}`
        const val = answers[key]?.value || ''

        return {
          sequence: q.sequence,
          paperid: paperInfo.paperId,
          class: paperInfo.class,
          section: paperInfo.section,
          studentid: paperInfo.Id,
          qid: q.id,
          questionKey: key,
          uanswer:
            q.quesType === 'multipleChoice'
              ? val
                ? `opt${val.toUpperCase()}`
                : null
              : q.quesType === 'trueFalse'
              ? val || null
              : null,
          canswer:
            q.quesType === 'multipleChoice' ||
            q.quesType === 'trueFalse'
              ? q.correctAns || null
              : null,
          marks: q.quesType === 'CR' ? val || null : null,
          quesType: q.quesType,
        }
      }),
    }
  }

  /* ================= SUBMIT ================= */

  const handleSubmit = async () => {
    const unanswered = validateAnswers()
    if (unanswered.length > 0) {
      const first = document.querySelector(
        `[data-question="${unanswered[0]}"]`
      )
      if (first) first.scrollIntoView({ behavior: 'smooth', block: 'center' })
      return
    }

    try {
      const payload = generateMergedPayload()
      if (!payload) return

      const response = await QuestionServices.SaveStudentAnswer(payload)

      if (response.status === 200 || response.statusCode === 201) {
        setTextConfirm('Exit')
        setMsgType('modal')
        setBtnConfirm(true)
        setMessage(response.message)
        setShowMsg(true)
      }
    } catch (err) {
      console.error('Save error:', err)
    }
  }

  /* ================= SAFE RENDER ================= */

  if (!paperInfo) {
    return <div style={{ padding: 20 }}>Loading marksheet...</div>
  }

  return (
    <div className="marksheet-container">
      <h2>ABCD SCHOOL MARKSHEET</h2>

      <div className="info-section">
        <div>Student Name: {paperInfo.name}</div>
        <div>Class: {paperInfo.class}</div>
        <div>Section: {paperInfo.section}</div>
        <div>Roll No: {paperInfo.rollNo}</div>
        <div>Subject: {paperInfo.subject}</div>
      </div>

      {/* ===== FLAT GRID LAYOUT ===== */}
      <div className="questions-grid">
        {quesInfo.map((q) => {
          const key = `Q${q.sequence}`
          const value = answers[key]?.value || ''
          const errorClass = unansweredKeys.includes(key) ? 'error' : ''
          const reviewClass = answers[key]?.review ? 'review-box' : ''

          return (
            <div className="question-box" key={q.sequence}>
              <span>{key}:</span>

              {q.quesType === 'multipleChoice' && (
                <select
                  data-question={key}
                  className={`form-select form-select-sm ${reviewClass} ${errorClass}`}
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                >
                  <option value="">--</option>
                  {['A', 'B', 'C', 'D', 'E'].map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              )}

              {q.quesType === 'trueFalse' && (
                <select
                  data-question={key}
                  className={`form-select form-select-sm ${reviewClass} ${errorClass}`}
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                >
                  <option value="">--</option>
                  <option value="T">T</option>
                  <option value="F">F</option>
                </select>
              )}

              {q.quesType === 'CR' && (
                <input
                  data-question={key}
                  type="text"
                  className={`form-control form-control-sm ${reviewClass} ${errorClass}`}
                  value={value}
                  onChange={(e) => handleChange(e, key)}
                />
              )}
            </div>
          )
        })}
      </div>

      <div className="text-center p-4">
        <button className="btn-primary" onClick={handleSubmit}>
          Save Marksheet
        </button>
      </div>

      <ShowMessage
        show={showMsg}
        type={msgType}
        message={message}
        btnConfirm={btnConfirm}
        textConfirm={textConfirm}
        onClose={() => setShowMsg(false)}
        onConfirm={() => {
          setShowMsg(false)

          if (!paperInfo?.paperId) {
            console.error('Missing paperId')
            return
          }

          navigator(`/rollblock/${paperInfo.paperId}/${paperInfo.Rollsection}`);
        }}
      />
    </div>
  )
}

export default Marksheet