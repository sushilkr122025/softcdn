import React, { useState, useEffect } from 'react'
import { Modal } from 'react-bootstrap'
import { CiSearch, CiGrid41, CiMenuBurger } from "react-icons/ci";
import { GoUpload } from "react-icons/go";
import { BiDotsVerticalRounded} from "react-icons/bi";
import { IoIosAdd } from "react-icons/io";
import {IoArrowUp } from "react-icons/io5";
import { FaRegEye  } from "react-icons/fa";
import { FaImage } from "react-icons/fa6";
import { FiEdit3 } from "react-icons/fi";
import { RiDeleteBin6Line } from "react-icons/ri";
import { VscGitPullRequestCreate } from "react-icons/vsc";
import { Link } from 'react-router-dom';
import './gallery.css';
import apiClient from '../../api/apiService';
import MultiServices from '../../api/MultiServices';
import useAuth from '../../context/AuthContext';
// import myImage from '../../assets/images/Question.png'

const Gallery = () => {

    const [show, setShow] = useState(false);
    const [errors, setErrors] = useState({})
    const [keyword, setKeyword] = useState([])

    const [source, setSource] = useState(null);

    const [images, setImages] = useState([]);

    const [uploadedImage, setUploadedImage] = useState(null);

    const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'

    const { user } = useAuth();
    
    const apiUrl = import.meta.env.VITE_HOST;

    const handleViewChange = (e) => {
        setViewMode(e.target.id === 'gridView' ? 'grid' : 'list');
    };

      useEffect(() => {
        async function fetchImages() {
            const response = await MultiServices.getImages()
            console.log(response);
            setImages(response)
        }    
        fetchImages();
      }, [])

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const handleImageUpload = (e) => {
        const imageFile = e.target.files[0];

        setErrors({})

        if (!imageFile) {
            setErrors((prev) => ({ ...prev, image: 'No file selected' }));
            handleShow();
            return;
        }

        if (!imageFile.type.startsWith('image/')) {
            setErrors((prev) => ({ ...prev, image: 'Please select a valid image file' }));
            handleShow();
            return;
        }

        if (imageFile.size > 10 * 1024 * 1024) { 
            setErrors((prev) => ({ ...prev, image: 'File size exceeds 10 MB' }));
            handleShow();
            return;
        }
        
        setUploadedImage({
            file: imageFile,
            preview: URL.createObjectURL(imageFile)
        });
        handleShow()
    }

    const handleKeyword = () => {
        const keywordObj = document.getElementById('keyword')
        const val = keywordObj.value
    
        if (val.trim().split(' ').length > 1) {
          setErrors((prev) => ({ ...prev, keyword: 'Please enter only one word' }))
          return
        } else if (!keyword.includes(val.toLowerCase()) && val !== '') {
          setKeyword((prev) => [...prev, val.toLowerCase()])
        }
    
        keywordObj.value = ''
      }

    const handleRemoveKeyword = (index) => {
        setKeyword((prev) => prev.filter((keyword, i) => i !== index))
    }

    const submitMetaData = async (e) => {
        e.preventDefault();
        
        const errors = {}
        let isValid = true

        const name = document.getElementById('name').value.trim();
        const description = document.getElementById('description').value.trim();
        const visibility = document.getElementById('visibility').value === 'on' ? 'private' : 'public';

        if (name === '') {
            errors.name = 'Name is required';
            isValid = false;
        }

        if (keyword.length === 0) {
            errors.keyword = 'At least one keyword is required';
            isValid = false;
        }

        setErrors(errors)        
 
        if (isValid) {
            try {
                const data = {
                  name: name,
                  description: description,
                  keyword: keyword,
                  visibility: visibility,
                  source: source,
                  image: uploadedImage?.file,
                  userId: user.id,
                };
                console.log(data);
                
                const response = await apiClient.post('/school/galleryImage', data, {
                  headers: {
                    'Content-Type': 'multipart/form-data',
                  },
                  withCredentials: true,
                });
                if (response.status === 200) {
                    handleClose();
                }
                console.log('Response from server:', response.data);
            } catch (error) {
                console.error('Error uploading image:', error);
            }
        } else {
            console.log(errors);
        }
    }

    return (
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3 col-lg-2">
            <div className="bg-light border-right" style={{ height: '100vh' }}>
              <h5 className="p-3">Sidebar</h5>
              <label htmlFor="imageupload" className="w-100" style={{ cursor: 'pointer' }} onClick={() => setSource('upload')}>
                <button type="button" className="btn btn-outline-secondary shadow-sm w-100 mb-3" style={{ pointerEvents: 'none' }}>
                  <GoUpload /> Upload Image
                </button>
              </label>
              <input className="d-none" type="file" id="imageupload" accept="image/*" name="imageupload" onChange={handleImageUpload} />
              <Link to="/canvas" className="btn btn-primary shadow w-100 mb-3">
                <VscGitPullRequestCreate /> Create Image
              </Link>
              {/* <button type='button' ><VscGitPullRequestCreate /> Create Image</button> */}
              <ul className="list-group">
                <li className="list-group-item">Link 1</li>
                <li className="list-group-item">Link 2</li>
                <li className="list-group-item">Link 3</li>
                <li className="list-group-item">Link 4</li>
              </ul>
            </div>
          </div>
          <div className="col-md-9 col-lg-10 bg-white">
            <div className="header my-4">
              {/* <h2 className='text-center fw-normal mb-4'>Welcome to Gallery</h2> */}
              <div className="row">
                <div className="col-10 mb-4">
                  <div className="position-relative">
                    <span className="position-absolute top-50 z-1" style={{ transform: 'translate(-50%, -50%)', left: '20px' }}>
                      <CiSearch />
                    </span>
                    <input type="search" className="form-control gallerysearch rounded-5" placeholder="Search" id="search" name="search" style={{ paddingLeft: '2.5rem', backgroundColor: '#f8f9fa', border: '1px solid #f8f9fa' }} />
                  </div>
                </div>
                <div className="col-2 text-center">
                  <div className="btn-group gridsystem" role="group">
                    <input type="radio" className="btn-check" name="view" id="listView" onChange={handleViewChange} checked={viewMode === 'list'} />
                    <label className="btn btn-sm " htmlFor="listView">
                      <CiMenuBurger />
                    </label>

                    <input type="radio" className="btn-check " name="view" id="gridView" onChange={handleViewChange} checked={viewMode === 'grid'} />
                    <label className="btn btn-sm " htmlFor="gridView">
                      <CiGrid41 />
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="main" id="gallery">
              <div className="filterArea">
                {/* <div className='col-6 mx-auto w-50 mb-4'>
                                <div className="position-relative">
                                    <span className="position-absolute top-50 z-1" style={{transform: 'translate(-50%, -50%)', left: '20px'}}><CiSearch /></span>
                                    <input type="text" className="form-control rounded-5" placeholder='Search' id="search" name='search' style={{paddingLeft: '2.5rem', backgroundColor: '#e9ebf8'}} />
                                </div>
                            </div> */}

                <div>
                  <select className="form-select filterbutton form-select-sm" aria-label="Small select example">
                    <option>---Select Class---</option>
                    <option value="1">6th</option>
                    <option value="2">7th</option>
                    <option value="3">8th</option>
                    <option value="3">9th</option>
                    <option value="3">10th</option>
                    <option value="3">11th</option>
                    <option value="3">12th</option>
                  </select>
                </div>
                <div>
                  <select className="form-select filterbutton form-select-sm" aria-label="Small select example">
                    <option>---Select Subject---</option>
                    <option value="1">Hindi</option>
                    <option value="2">English</option>
                    <option value="3">Mathematics</option>
                    <option value="3">Physics</option>
                    <option value="3">Biology</option>
                    <option value="3">Chemistry</option>
                    <option value="3">Social Science</option>
                  </select>
                </div>
                <div>
                  <select className="form-select filterbutton form-select-sm" aria-label="Small select example">
                    <option>---Select Section---</option>
                    <option value="1">A</option>
                    <option value="2">B</option>
                    <option value="3">C</option>
                    <option value="3">D</option>
                    <option value="3">E</option>
                    <option value="3">F</option>
                  </select>
                </div>
              </div>
              {viewMode === 'list' && (
                <div className="row">
                  <div className="listtopbar">
                    <div className={`image-container ${viewMode}`}>
                      <div className="d-flex justify-content-between w-100">
                        <div className="img-head px-3">
                          <div className=" d-flex align-items-center">
                            <h6>
                              Name <IoArrowUp />
                            </h6>
                          </div>
                        </div>
                        <div className="img-foot">
                          <div className="keyword">
                            <h6>Keywords</h6>
                          </div>
                          <div className="keyword description" title="description">
                            <h6>Description</h6>
                          </div>
                        </div>
                        <div className="moreoption">Action</div>
                      </div>
                      <div className="img">{/* <img src={} alt='Tree' className="img-fluid" /> */}</div>
                    </div>
                  </div>
                </div>
              )}
              <div className="row">
                {images.map((e, i) => {
                  const srcObject = Array.isArray(e.canvasImage?.objects) ? e.canvasImage.objects.find((obj) => obj.src) : null;
                  const imageSrc = srcObject?.src || null;
                  return (
                    <div key={i} className={`col ${viewMode === 'grid' ? 'col-md-3' : 'col-12'}`}>
                      <div className={`image-container ${viewMode}`}>
                        <div className="d-flex justify-content-between w-100">
                          <div className="img-head px-3">
                            <div className=" d-flex align-items-center">
                              <FaImage className="text-danger me-3" /> {e.name}
                            </div>
                          </div>
                          <div className="img-foot">
                            <div className="keyword">{e.keyword}</div>
                            <div className="keyword description" title="description">
                              {e.description}
                            </div>
                          </div>
                          <div className="moreoption">
                            <div className="btn-group">
                              <button type="button" className="btn btn-sm" title="more action" data-bs-toggle="dropdown" aria-expanded="false">
                                <BiDotsVerticalRounded />
                              </button>
                              <ul className="dropdown-menu">
                                <li>
                                  <Link className="dropdown-item">
                                    <FaRegEye className="me-2" />
                                    Preview
                                  </Link>
                                </li>
                                <li>
                                  <Link to={`/canvas?updateId=${e.id}`} className="dropdown-item">
                                    <FiEdit3 className="me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item">
                                    <RiDeleteBin6Line className="me-2" /> Move to Trash
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div className="img">
                          <img src={`${apiUrl}/assets${e.imageURL}`} alt="" className="img-fluid" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
        <Modal show={show} onHide={handleClose} onExited={() => setErrors({})}>
          <Modal.Header closeButton>
            <div className="modal-title h5">Image Details</div>
          </Modal.Header>
          <form action="" id="metaDataForm" method="post" autoComplete="off" onSubmit={submitMetaData}>
            <Modal.Body>
              {errors.image && <span className="error">{errors.image}</span>}
              {!errors.image && (
                <>
                  <div className="mb-3 text-center">{uploadedImage && <img src={uploadedImage?.preview} alt="Uploaded" className="img-fluid" />}</div>
                  <div className="mb-3">
                    <input type="text" className="form-control" id="name" name="name" placeholder="Name" />
                    {errors && <span className="error">{errors.name}</span>}
                  </div>
                  <div className="input-group mb-3">
                    <input type="text" className="form-control" id="keyword" name="keyword" />
                    <button type="button" className="btn btn-light border" onClick={handleKeyword}>
                      <IoIosAdd /> Keywords
                    </button>
                  </div>
                  {errors && <span className="error">{errors.keyword}</span>}
                  <div id="keyword-badges">
                    {keyword.map((keyword, index) => (
                      <div key={index} className="badge custom-purple-badge">
                        <span className="me-2"> {keyword}</span>
                        <span className="badge-remove pointer" onClick={() => handleRemoveKeyword(index)}>
                          &times;
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="mb-3">
                    <textarea className="form-control" id="description" name="description" placeholder="Description (If have any)"></textarea>
                  </div>
                  <div class="form-check form-switch">
                    <input className="form-check-input" type="checkbox" role="switch" id="visibility" name="visibility" />
                    <label className="form-check-label" htmlFor="visibility">
                      Private
                    </label>
                  </div>
                </>
              )}
            </Modal.Body>
            {!errors.image && (
              <Modal.Footer>
                <button type="button" className="btn btn-light border">
                  Edit & Upload
                </button>
                <button type="submit" className="btn btn-primary shadow">
                  Upload
                </button>
              </Modal.Footer>
            )}
          </form>
        </Modal>
      </div>
    );
}

export default Gallery
