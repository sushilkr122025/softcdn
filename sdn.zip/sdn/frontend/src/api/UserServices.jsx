
import apiClient from './apiService'

class UserServices {
  registerUser = async (data) => {
    try {
      const response = await apiClient.post('/user/adduser', data)
      return response.data
    } catch (error) {
      console.error('Error registering user:', error)
      throw error
    }
  }
  getSystemRoles = async () => {
    try {
      const response = await apiClient.get(`store/roles`)     
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getSystemPermissions = async () => {
    try {
      const response = await apiClient.get(`store/permissions`)     
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getUser = async (data) => {
    try {
      const response = await apiClient.get(`/user/details/`, data)
      return response.data
    } catch (error) {
      console.error('Error fetching user:', error)
      throw error
    }
  }
  
  allUser = async () => {
    try {
      const response = await apiClient.get(`/user/all`)
      return response.data
    } catch (error) {
      console.error('Error fetching user:', error)
      throw error
    }
  }

  setUserPermissions = async (permissions) => {
    try {
      const response = await apiClient.post(`/user/addPermissions/`, permissions);
      return response.data;
    } catch (error) {
      console.error('Error saving user permissions:', error);
      throw error;
    }
  }; 

  getUserPermissions = async (userId) => {
    try {
      const response = await apiClient.get(`/user/permissions/${userId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      throw error;
    }
  };
}

export default new UserServices()