import React, { useEffect, useState } from 'react'

import { useForm } from 'react-hook-form'
import { Row, Col, Form } from 'react-bootstrap'
import { useNavigate, useParams } from 'react-router-dom'
import UserServices from '../api/UserServices'

const UserRegistration = () => {  
  document.title = 'User Registration'
  const navigator = useNavigate()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm(
    {
      mode: 'onChange'
    }
  )

  const [userData, setUserData] = useState();
  const [roles, setRoles] = useState([]);
  const { userid } = useParams();
  const updateId = userid ? userid : null;

  const fetchUserData = async () => {
    if (updateId) {
      try {
        const response = await UserServices.getUser({ params: { id: updateId } });
        setUserData(response);       
        reset(response);
      } catch (error) {
        console.error(error.message)
      }
    }
  }

  useEffect(() => {
    fetchUserData()
  }, [updateId, reset])

  useEffect(() => {
    const allRoles = async () => {    
      try {
        const response = await UserServices.getSystemRoles()       
        setRoles(response);
      } catch (error) {
        console.error(error.message)
      }   
  }
    allRoles();
  }, [])  



  const onSubmit = async (data) => {
    console.log('data', data)
    try {
      const response = await UserServices.registerUser(data)
      if(response) {
        navigator('/users')
     }
    } catch (error) {
      console.log(error)
    }
  }

  if (updateId && !userData) {
    return <div>Loading...</div>
  }

  return (
    <div className="container-fluid">
      <div className="row mt-3">
        <div className="col-7 mx-auto bg-white">
          <Form className=" p-4 " onSubmit={handleSubmit(onSubmit)}>
            <div className="form-header mt-3 mb-4">
              <h2>User Registration</h2>
            </div>
            <Row className="form-grid g-4">
              <Col md={12}>
              <Form.Group controlId="role" className="form-label">
                <Form.Label>Registered As</Form.Label>

                {roles.map((role, i) => (
                  <Form.Check
                    key={i}
                    type="radio"
                    id={`role-${i}`}
                    label={role.rolename}
                    value={role.rolename}
                    {...register('role', { required: 'Register As is required' })}
                    className={errors.role ? 'is-invalid' : ''}
                    name="role" // ensures they are grouped together
                  />
                ))}

                {errors.role && (
                  <div className="invalid-feedback d-block">{errors.role.message}</div>
                )}
              </Form.Group>
              </Col>
            </Row>
            <Row className="form-grid g-4">
              <Col md={6}>
              {updateId && (
                <>
                <Form.Control
                  type="hidden"
                  defaultValue={userData?.id}
                  {...register('id')}
                />
                </>
              )}
                <Form.Group controlId="name" className="form-label">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"                   
                    {...register('name', {
                      required: 'Name is required',
                      pattern: {
                        value: /^[a-zA-Z\s]+$/,
                        message: 'Name should contain letters only',
                      },
                      minLength: {
                        value: 3,
                        message: 'Name should be at least 3 characters long',
                      },
                    })}
                    className={errors.name ? 'is-invalid' : ''}
                  />
                  {errors.name && (
                    <div className="invalid-feedback d-block">{errors.name.message}</div>
                  )}
                </Form.Group>
              </Col>
              <Col md={6}>

                <Form.Group controlId="email" className="form-label">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"                    
                    {...register('email', {
                      pattern: {
                        value: /^\S+@\S+\.\S+$/,
                        message: 'Invalid email address',
                      },
                    })}
                    className={errors.email ? 'is-invalid' : ''}
                  />
                  {errors.email && (
                    <div className="invalid-feedback d-block">
                      {errors.email.message}
                    </div>
                  )}
                </Form.Group>

              </Col>

              <Col md={6}>
                <Form.Group controlId="mobileno" className="form-label">
                  <Form.Label>Contact No</Form.Label>
                  <Form.Control
                    type="text"
                    maxLength="10"
                    {...register('mobileno', {
                      pattern: {
                        value: /^[6-9]\d{9}$/,
                        message: 'Enter a valid 10-digit phone number starting with 6-9',
                      },
                    })}
                    className={errors.mobileno ? 'is-invalid' : ''}                  
                  />
                  {errors.mobileno && (
                    <div className="invalid-feedback d-block">
                      {errors.mobileno.message}
                    </div>
                  )}
                </Form.Group>

              </Col>
                             
              <Col md={6}>
                <Form.Group controlId="userid" className="form-label">
                  <Form.Label>User ID</Form.Label>
                  {!updateId ? (
                    <>
                  <Form.Control
                    type="text"
                    maxLength="15"
                    {...register('userid', {
                      required: 'User ID is required',
                      pattern: {
                        value: /^[a-zA-Z0-9]{5,15}$/,
                        message: 'User ID must be 5–15 characters, letters and numbers only',
                      },
                    })}
                    className={errors.userid ? 'is-invalid' : ''}                  
                  />
                  {errors.userid && (
                    <div className="invalid-feedback d-block">{errors.userid.message}</div>
                  )}
                  </>
                  ) : (
                  <p className="form-control-plaintext mb-0">
                    {userData?.userid}
                  </p>
                  )}
                </Form.Group>
              </Col>              
            {!updateId && (
              <>
              <Col md={6}>
                <Form.Group controlId="password" className="form-label">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    {...register('password', {
                      required: 'Password is required',
                      minLength: {
                        value: 6,
                        message: 'Minimum 6 characters required',
                      },
                    })}
                    className={errors.password ? 'is-invalid' : ''}
                  />
                  {errors.password && (
                    <div className="invalid-feedback d-block">{errors.password.message}</div>
                  )}
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group controlId="confirmpassword" className="form-label">
                  <Form.Label>Confirm password</Form.Label>
                  <Form.Control
                    type="password"
                    {...register('confirmpassword', {
                      required: 'Confirm Password is required',
                      minLength: {
                        value: 6,
                        message: 'Minimum 6 characters required',
                      },
                    })}
                    className={errors.confirmpassword ? 'is-invalid' : ''}
                  />
                  {errors.confirmpassword && (
                    <div className="invalid-feedback d-block">{errors.confirmpassword.message}</div>
                  )}
                </Form.Group>
              </Col>
              </>
              )}
              <Col md={6}>
                <Form.Group controlId="gender" className="form-label">
                  <Form.Label>Gender</Form.Label>
                  <Form.Select
                    {...register('gender', { required: 'Gender is required' })}
                    className={errors.gender ? 'is-invalid' : ''}                                    
                  >
                    <option value="">---Select---</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </Form.Select>
                  {errors.gender && (
                    <div className="invalid-feedback d-block">{errors.gender.message}</div>
                  )}
                </Form.Group>
              </Col>

              {/* <Col md={6}>
                <Form.Group controlId="role" className="form-label">
                  <Form.Label>Registered As</Form.Label>
                  <Form.Select
                    {...register('role', { required: 'Register As is required' })}
                    className={errors.role ? 'is-invalid' : ''}
                  >
                    <option value="">---Select---</option>
                    {roles.map((role, i) => (
                      <option key={i} value={role.rolename}>
                        {role.rolename}
                      </option>
                    ))}
                  </Form.Select>
                  {errors.role && (
                    <div className="invalid-feedback d-block">{errors.role.message}</div>
                  )}
                </Form.Group>
              </Col> */}
            </Row>
            <div className="mt-4 text-center">
              <button
                className="btn btn-primary ms-3"
                disabled={isSubmitting}
                value={isSubmitting ? 'Submitting' : 'Submit'}
                type="submit"
              >
                Register
              </button>
            </div>
          </Form>
        </div>
      </div>
    </div >
  )
}


export default UserRegistration
