import {
  Controller,
  Post,
  Req,
  UploadedFile,
  UseInterceptors,
  BadRequestException,
  UploadedFiles,
  Body,
  Inject,
} from '@nestjs/common';
import { OcrService } from '../services/ocr.service';
import { DynamicMulterInterceptor } from 'src/utils/dynamic.multer.interceptor';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { LoggerService } from '@nestjs/common';

@Controller('ocr')
export class OcrController {
  constructor(
    private readonly ocrService: OcrService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: LoggerService
  ) {}

  @Post('upload')
  @UseInterceptors(
    DynamicMulterInterceptor(
      (req: Request & { schoolname?: string }) =>
        req.schoolname || 'default-folder',
      [{ name: 'image', maxCount: 1 }]
    )
  )
  async upload(
    @UploadedFiles() files: { image?: Express.Multer.File[] },
    @Req() req: Request,
    @Body() data: any
  ): Promise<any> {
    console.log(data);
    if (!data) {
      this.logger.log('ocr-controller: No data provided in the request body');
      throw new BadRequestException('No data provided');
    }
    const tenantId = req['company'] as string;
    const allFiles: Express.Multer.File[] = [...(files.image ?? [])];
    const folderName =
      (req['schoolname'] as string).toLowerCase().replace(/[\s\W_]+/g, '') ||
      'default-folder';
    if (!files) {
      this.logger.log('ocr-controller: No file');
      throw new BadRequestException('No file uploaded');
    }
    const ocrdata = {
      ...data,
      tenantId,
      folderName,
    };
    // file.buffer is the image data
    const result = await this.ocrService.predict(allFiles, ocrdata);
    if (!result) {
      this.logger.log('ocr-controller: OCR processing failed');
      throw new BadRequestException('OCR processing failed');
    }
    return result;
  }
}
