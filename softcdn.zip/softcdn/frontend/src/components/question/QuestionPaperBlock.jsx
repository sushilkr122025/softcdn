import React, { useState } from 'react'
import { FiEdit2, FiDownload } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
// import apiClient from '../../api/apiService'
import MultiServices from '../../api/MultiServices'

const QuestionPaperBlock = ({ info }) => {
  const navigator = useNavigate()
  const [studentData, setStudentData] = useState([])
  const [questionData, setQuestionData] = useState([])
  const [check, setCheck] = useState(false)

  let newData = []
  const openModal = async (e) => {
    const dataAttr = e.currentTarget.dataset
    const response = await MultiServices.GetStudentByClass(
       {
        class: dataAttr.class,
        section: dataAttr.section,
        paperId: info.paperId,
      })
      if(response){
        // console.log(response.questionData)
        setStudentData(response.studentData)

        response.questionData.map((e) =>
          newData.push({
            fieldName: `Q${e.sequence}:`,
            value: 0,
            valueType: `${e.quesType}`,
            qid: e.id,
            paperId: info.paperId,
          })
        )
        setQuestionData(newData)
        setCheck(true)
      }
  }

  const handleEdit = (id) => {
    navigator(`/AnswerSheet?updateid=${id}`)
  }

  const handleDownload = (tq) => {
    navigator(`/QuesTemplate?totalQuestions=${tq}`)
  }

  function toRoman(num) {
    if (isNaN(num)) {
      return ''
    }
    let romanNumeral = ''
    const romanNumerals = [
      { value: 1000, numeral: 'M' },
      { value: 900, numeral: 'CM' },
      { value: 500, numeral: 'D' },
      { value: 400, numeral: 'CD' },
      { value: 100, numeral: 'C' },
      { value: 90, numeral: 'XC' },
      { value: 50, numeral: 'L' },
      { value: 40, numeral: 'XL' },
      { value: 10, numeral: 'X' },
      { value: 9, numeral: 'IX' },
      { value: 5, numeral: 'V' },
      { value: 4, numeral: 'IV' },
      { value: 1, numeral: 'I' },
    ]

    for (let i = 0; i < romanNumerals.length; i++) {
      while (num >= romanNumerals[i].value) {
        romanNumeral += romanNumerals[i].numeral
        num -= romanNumerals[i].value
      }
    }

    return romanNumeral
  }

  if (check) {
    navigator(`/rollblock`, {
      state: {
        studentInfo: studentData,
        examDetail: info,
        questionDetail: questionData,
      },
    })
    return null
    // return <RollBlock studentData={studentData} examDetail={info} questionDetail={questionData} />
  } else {
    return (
      <>
        <div className="col-12 col-md-6 col-lg-4 mb-4 quesBlock">
          <div className="d-flex justify-content-end mb-1">
            <div className="icons" onClick={() => handleDownload(info.totalQuestion)}>
              <FiDownload />
            </div>
            <div className="icons" onClick={() => handleEdit(info.id)}>
              <FiEdit2 />
            </div>
          </div>
          <div
            className="p-3 bg-body shadow-sm fw-normal quesData"
            data-class={info.class}
            data-subject={info.subject}
            data-section={info.section}
            onClick={(e) => openModal(e)}
          >
            <div className="d-flex justify-content-between">
              <h5>{info.name}</h5>
              <p className="text-end text-muted">
                <strong>{info.examCode}</strong>
              </p>
            </div>
            <div className="d-flex justify-content-between">
              <div className="text-muted">Class - {toRoman(info.class)}</div>
              <div className="text-muted">Time allowed - {info.totalTime}</div>
            </div>
            <div className="d-flex justify-content-between">
              <div className="text-muted">Subject - {info.subject}</div>
              <div className="text-muted">Max marks - {info.maxMarks}</div>
            </div>
            <p className="mt-3">Total Questions - {info.totalQuestion}</p>
            <div className="quesType">
              <span className="me-2">Types</span>
              <span className="badge rounded-pill text-bg-primary me-2">MCQ</span>
              <span className="badge rounded-pill text-bg-success me-2">True False</span>
              <span className="badge rounded-pill text-bg-secondary">One Word</span>
            </div>
          </div>
        </div>
      </>
    )
  }
}

export default QuestionPaperBlock
