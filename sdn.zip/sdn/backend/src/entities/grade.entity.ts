import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'grade' })
export class Grade {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50' })
  grade: string;

  @Column({ type: 'int' })
  markstart: number;

  @Column({ type: 'int' })
  markend: number;

  @CreateDateColumn({ type: 'timestamp' })
  createdate: Date;

  @Column({ type: 'int', default: '1' })
  status: number;
}
