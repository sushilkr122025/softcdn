import { Module, MiddlewareConsumer, RequestMethod } from '@nestjs/common';
import configuration from './config/configuration';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './modules/auth.module';
import { SchoolModule } from './modules/school.module';
import { LookupMiddleware } from './middleware/lookup.middleware';
import { LookupModule } from './modules/lookup.module';
import { EncryptionModule } from './modules/encryption.module';
import { ResultModule } from './modules/result.module';
import { UserModule } from './modules/user.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configuration],
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        type: configService.get<'mysql' | 'mongodb'>('database.type', 'mysql'),
        host: configService.get<string>('database.host'),
        port: configService.get<number>('database.port'),
        username: configService.get<string>('database.user'),
        password: configService.get<string>('database.password'),
        database: configService.get<string>('database.database'),
        synchronize: true,
        autoLoadEntities: true,
        logging: false,
      }),
    }),
    EncryptionModule,
    LookupModule,
    AuthModule,
    SchoolModule,
    ResultModule,
    UserModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LookupMiddleware)
      .exclude({ path: 'lookup/:slug', method: RequestMethod.GET })
      .forRoutes({ path: '*path', method: RequestMethod.ALL });
  }
}
