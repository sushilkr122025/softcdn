import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('examquestion')
export class ExamQuestion {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int' })
  paperId: number;

  @Column({ type: 'int' })
  questionId: number;

  @Column({ type: 'int' })
  sequence: number;

  @Column({ type: 'int' })
  marks: number;

  @Column({ type: 'int', default: null })
  sectionId: number;

  @Column({ type: 'varchar', length: 50, default: null })
  sectionName: string;

  @Column({ type: 'varchar', length: 200, default: null })
  sectionDesc: string;

  @Column({ type: 'varchar', length: 10 })
  paperFrom: string;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;

  @Column({ type: 'datetime', default: () => 'CURRENT_TIMESTAMP' })
  dateTime: Date;
}
