import React, { useState, useEffect } from 'react'
import { FaEllipsisVertical } from "react-icons/fa6";
import './admin.css'
// import { useNavigate } from 'react-router-dom'
import apiClient from '../api/apiService';
import user from '../assets/images/user-grey.svg';
import { Link } from 'react-router-dom';

function Users() {
  const [userData, setUserData] = useState([])

  useEffect(() => {
    apiClient
      .get('/user/all')
      .then((response) => {
        console.log(response.data);

        setUserData(response.data)
      })
      .catch((error) => {
        console.error(error)
      })
  }, [])

  return (
    <section id="admin">
      <div className="container-fluid">
        <div className="row align-items-center">
          <div className="col-6 py-3 d-flex align-items-center">
            <img
              src={user}
              alt="student"
              style={{ width: "23px" }} />
            <h5 className='text-grey-400 mb-0 ms-3'>User</h5>
          </div>
          <div className="col-6 py-3 text-end">
            <Link to="/users/add">
              <button className='btn btn-sm btn-primary' >Add user</button>
            </Link>
          </div>
        </div>
        <div className="table-responsive tbl-container">
          <table className="table mb-0 border table-hover" id="userTable">
            <thead>
              <tr>
                <th>-</th>
                <th>Name</th>
                <th>DOJ</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Emp. Type</th>
                <th>Role</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody className='tbody'>
              {userData.map((row, index) => (
                <tr key={row.id}>
                  <td>{index + 1}</td>
                  <td>{row.name}</td>
                  <td>{row.DOJ.split('T')[0]}</td>
                  <td>{row.emailId}</td>
                  <td>{row.contactNo}</td>
                  <td>{row.empType}</td>
                  <td>{row.role}</td>
                  <td>
                    {row.status === 1 ? <span className="badge-active rounded-pill ">ACTIVE</span> : <span className="badge-inactive rounded-pill">INACTIVE</span>}
                  </td>
                  <td>
                    <button type='button' className='btn btn-sm border-0' data-bs-toggle="dropdown" aria-expanded="false">
                      <FaEllipsisVertical className='text-primary' />
                    </button>
                    <ul className='dropdown-menu p-2'>
                      <li><a href={`/users/${row.id}`} className='dropdown-item'>Edit Details</a></li>
                      <li><a href={`roles?id=${row.id}`} className='dropdown-item'>Set Roles</a></li>
                    </ul>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}

export default Users
