import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'questionpaper' })
export class QuestionPaper {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'varchar', length: '15', nullable: true })
  examCode!: string;

  @Column({ type: 'varchar', length: '80', nullable: true })
  name!: string;

  @Column({ type: 'int', nullable: true })
  class!: number;

  @Column({ type: 'varchar', length: '50', nullable: true })
  subject!: string;

  @Column({ type: 'varchar', length: '50', nullable: true })
  subjectName!: string;

  @Column({ type: 'varchar', length: '10', nullable: true })
  section!: string;

  @Column({ type: 'int', nullable: true })
  maxMarks!: number;

  @Column({ type: 'varchar', length: '15', nullable: true })
  totalTime!: string;

  @Column({ type: 'varchar', length: '10', nullable: true })
  createdFrom!: string;

  @Column({ type: 'text', nullable: true })
  generalInstruction!: string;

  @CreateDateColumn({ type: 'timestamp', nullable: true })
  examDate!: Date;

  @Column({ type: 'varchar', nullable: true })
  session!: string;

  @Column({ type: 'json', nullable: true })
  sectionsData!: object | null;

  @Column({ type: 'varchar', length: '50', nullable: true })
  tenantid!: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @CreateDateColumn({ type: 'timestamp' })
  dateTime!: Date;
}
