import React, { useState, useEffect } from 'react'
import { LuFileQuestion } from "react-icons/lu";
import blankDataImage from '../../assets/images/questionPaper.png'
import { FaPlus } from "react-icons/fa";
import GlobalFilter from '../../components/GlobalFilter';
import QuestionPaperBlock from '../../components/question/QuestionPaperBlock';

const QuestionPaper = () => {

  const [data, setData] = useState(null);
  const [filteredData, setFilteredData] = useState([])

  useEffect(() => {
    const storedData = sessionStorage.getItem('quesPaper');
    const storedFilter = sessionStorage.getItem('quesPaperFilter');
    if (storedData) {
      const qpData = JSON.parse(storedData) 
      const filtered = storedFilter !== 'all' ? qpData.filter((e) => e.createdFrom === storedFilter) : qpData
      setFilteredData(filtered)
      setData(JSON.parse(storedData))
    }
  }, []);
  
  const questionData = (childData) => {
    console.log(childData);

    if (JSON.stringify(childData) !== JSON.stringify(data)) {
      setFilteredData(childData);  
      setData(childData)
      sessionStorage.setItem('quesPaper', JSON.stringify(childData));
      sessionStorage.setItem('quesPaperFilter', 'all');
    }
  }

  const renderData = () => {
    if (filteredData.length === 0) {
      return <section className='text-center' style={{marginTop: '5rem'}}>
      <div className="row mx-0 justify-content-center">
        <div className="col-8 col-sm-7 col-md-5 col-lg-3">
          <img src={blankDataImage} alt="Question Bank" className='img-fluid mb-4' />
        </div>
      </div>
      <h4 className='fw-normal'>No data available</h4>
      <p className='text-muted'>Start Filtering data according to your need</p>
      <a href='/MakePaper-A' className='btn lq-orange-color'><FaPlus /> Create Exam</a>
    </section>
    }
  }

  const handleFilter = (flag) => {
    const filteredData = flag !== 'all' ? data.filter(e => e.createdFrom === flag) : data
    setFilteredData(filteredData)
    sessionStorage.setItem('quesPaperFilter', flag)
  }

  return (
    <div className="container-fluid mb-5">
      <GlobalFilter icon={<LuFileQuestion />} heading={'Question Paper'} headClass={'orange'} table='questionpaper' page={"questionPaper"} questionData={questionData} />
      <section className="paper-block">
        <div className="row">
        {data !== null && (
          <div className="col-12 mb-3">
            <div className="row align-items-center gx-3">
              <label htmlFor="filter" className='form-label mb-0 col-auto col-sm-auto ms-auto'>Filter</label>
              <div className="col col-sm-3 col-lg-2">
                <select name="filter" id="filter" className='form-select form-select-sm' onChange={(e) => handleFilter(e.target.value)} defaultValue={sessionStorage.getItem('quesPaperFilter')}>
                  <option value="all">All</option>
                  <option value="bank">Bank</option>
                  <option value="manual">Manual</option>
                </select>
              </div>
            </div>
          </div>
        )}
        {renderData()}
        {
          filteredData.length !== 0 && filteredData.map((e, i) => {
            return <QuestionPaperBlock key={i} info={e} />
        })
        }
        </div>
      </section>
    </div>
  )
}

export default QuestionPaper
