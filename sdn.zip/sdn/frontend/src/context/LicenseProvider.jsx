import React, { useState, useEffect } from 'react'
import { LicenseContext } from './LicenseContext'
import { validateLicense } from '../api/LicenseService'
import useAuth from './AuthContext'

const LicenseProvider = ({ children }) => {
  const [licenseInfo, setLicenseInfo] = useState(null)
  const [loading, setLoading] = useState(true)

  const { user } = useAuth()  

  const valid = async (tenantId, licenseKey) => {
    try {
      const data = await validateLicense(tenantId, licenseKey)
      setLicenseInfo(data)
      setLoading(false)
    } catch (error) {
      setLicenseInfo(null)
      return { success: false, reason: error.message }
    } finally {
      setLoading(false)
    }
  }

  const clearLicense = () => {
    setLicenseInfo(null)
  }

  useEffect(() => {
    const fetchLicense = async () => {
      if (user?.tenantId && user?.license_key) {
        setLoading(true)
        await valid(user.tenantId, user.license_key)
        setLoading(false)
      }
    }

    fetchLicense()
  }, [user])
  

  return (
    <LicenseContext.Provider
      value={{
        licenseInfo,
        loading,
        valid,
        clearLicense,
      }}
    >
      {children}
    </LicenseContext.Provider>
  )
}

export default LicenseProvider
