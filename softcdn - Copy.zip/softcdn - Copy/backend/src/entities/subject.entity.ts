import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('subject')
export class Subject {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true, type: 'varchar', length: 200 })
  subject: string;

  @Column({ type: 'varchar', length: 200, nullable: true })
  book: string;

  @Column({ type: 'int', default: 0 })
  parentId: number;

  @Column({ type: 'int', default: 1 })
  status: number;

  @Column({ type: 'int', default: 1 })
  visible: number;
}
