import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import { FaLock, FaUser } from 'react-icons/fa'
// import loginimage from '../assets/images/login-page.png'
// import { isMobile, isTablet, isBrowser, isAndroid, isIOS } from 'react-device-detect'
// import useAuth from '../context/AuthContext'
import useCompany from '../context/CompanyContext'
import AuthService from '../api/authService';
import logo from '../assets/images/logo.jpg'
import ShowMessage from '../components/ShowMessage'

const Login = () => {
  // const { login } = useAuth()
  const { school } = useCompany();
  const navigator = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  let imgdbsrc = school?.schoollogo ? `http://fpserver:8081/assets/${school.schoollogo}` : null; // Placeholder for image source coming form database`${config.imageurl}/assets/default/${school?.schoollogo}`; // Placeholder for image source coming form database
  const imgsrc = imgdbsrc || '/sansol.jpg';
  const [errors, setErrors] = useState({})
  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState(false);
  const [msgType, setMsgType] = useState(false);
  const [msgVariant, setMsgVariant] = useState(false);
  const [btnConfirm, setBtnConfirm] = useState(false);
  const [btnClose, setBtnClose] = useState(false);
  const [textClose, setTextClose] = useState(false);
  const [textConfirm, setTextConfirm] = useState(false);
  const [redirect, setRedirect] = useState(false);

  const validate = () => {
    const newErrors = {}

    if (!email.trim()) {
      newErrors.email = 'Email is required'
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Invalid email format'
    }

    if (!password) {
      newErrors.password = 'Password is required'
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters'
    }

    return newErrors
  }
  const handleSubmit = async (e) => {
    e.preventDefault()

    const validationErrors = validate()
    setErrors(validationErrors)

    if (Object.values(validationErrors).length === 0) {      
        const response = await AuthService.loginUser(email, password)
        if (response.status == 201 || response.status == 200) {        
          localStorage.setItem('logged', true)
          navigator('/dashboard')
        }
        else if (response.status == 401 || response.status == 500) {
          console.log('login failed')
          setMessage(response.message)
          setShowMsg(true);  
          setMsgType('alert');
          setMsgVariant('danger')
          setBtnClose(true);
          //setRedirect('/question')
          //setTextClose('Add More')
          //setTextConfirm('Complete')
        }
      
    }
  }
  return (
    <div className="container-fluid login-page bg-background">
      <div className="row min-vh-100 d-flex align-items-center justify-content-center ">
        <div className="col-12 col-sm-12 col-md-12 col-lg-5 text-center">
          <h2 className='text-grey-400 fw-semibold mb-5'>Welcome, Log into you account</h2>
          <form onSubmit={handleSubmit} className="p-2 p-sm-5 pt-5 mx-md-5 bg-white">
            <div className="row pt-0 justify-content-center">
              <div className="col-md-12 d-flex justify-content-between">
                <img src={logo} alt="logo" width={130} />
                <img src={imgsrc}  alt="Company Logo" className='float-end' style={{height: 'fit-content', maxWidth: '120px'}} /> 
                {/* School Logo */}
              </div>
              <div className="col-8 text-center mt-5 mb-4">
                <p className='text-grey-500'>It is our great pleasure to have you on board! </p>
              </div>
              <div className="col-10 mb-3">
                <input
                  type="text"
                  autoComplete="username"
                  placeholder="Enter Email"
                  name="email"
                  className="form-control logininput"
                  onChange={(e) => setEmail(e.target.value)}
                />
                {errors.email && <span className="text-danger">{errors.email}</span>}
              </div>
              <div className="col-10 mb-4">
                <input
                  type="password"
                  placeholder="Password"
                  className="form-control logininput"
                  onChange={(e) => setPassword(e.target.value)}
                  name="password"
                />
                {errors.password && <span className="text-danger">{errors.password}</span>}
              </div>
              <div className="col-10 mb-4">
                <button className="btn btn-primary w-100" type="submit">
                  Login
                </button>
                <ShowMessage show={showMsg} type={msgType} message={message} variant={msgVariant} btnConfirm={btnConfirm} btnClose={btnClose} 
                      textConfirm={textConfirm}
                      textClose={textClose}
                      onClose={() => setShowMsg(false)}
                      onConfirm={() => {
                        setShowMsg(false);
                        navigator(redirect);
                      }}
                      />       
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login
