import React from 'react'
import './Toolbar.css'
import { FaRegCircle, FaRegSquare  } from "react-icons/fa";
import { BsTriangle } from "react-icons/bs";
import { LuRectangleHorizontal } from "react-icons/lu";
import { MdEmojiSymbols } from "react-icons/md";
import { GoChevronDown } from "react-icons/go"; 
const Toolbar = ({symbols , shapes}) => {

  const handleSymbolClick = (symbolData) => {
    // const questionArea = document.querySelector('.question-area');
    symbols(symbolData)
  };

  const handleShapes = (shape) => {
    shapes(shape)
  }

  return (
    <div className="toolbar shadow-sm" id="toolbar-box">
      <div className="row mx-0">
        <div className="col-3 ps-0 pe-2 d-flex flex-column column-border">
            <div className="row mx-0 column-body">
                <div className="col-9 ps-0 pe-1">
                    <select className="form-select form-select-sm tool-select" name='font-family' id="font-family">
                        <option value="Arial">Arial</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Courier New">Courier New</option>
                        <option value="Comic Sans MS">Comic Sans MS</option>
                    </select>
                </div>
                <div className="col-3 px-0">
                    <select name="fontSize" id="fontSize" className='form-select form-select-sm tool-select'>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="12">12</option>
                        <option value="14">14</option>
                        <option value="16">16</option>
                        <option value="18">18</option>
                        <option value="20">20</option>
                        <option value="22">22</option>
                        <option value="24">24</option>
                        <option value="26">26</option>
                        <option value="28">28</option>
                        <option value="32">32</option>
                        <option value="48">48</option>
                        <option value="72">72</option>
                    </select>
                </div>
            </div>
            <div className="row mx-0 column-footer">
                <div className="col-12">
                    Font
                </div>
            </div>
        </div>
        <div className="col-3 px-0 d-flex flex-column column-border">
            <div className="row mx-0 column-body">
                <div className="col-12 px-2">
                    <div className="shapes-container">
                        <span className="shape" onClick={() => handleShapes('circle')}><FaRegCircle /></span>
                        <span className="shape" onClick={() => handleShapes('triangle')}><BsTriangle /></span>
                        <span className="shape" onClick={() => handleShapes('square')}><FaRegSquare /></span>
                        <span className="shape" onClick={() => handleShapes('rectangle')}><LuRectangleHorizontal /></span>
                    </div>
                </div>
            </div>
            <div className="row mx-0 column-footer">
                <div className="col-12">
                    Shapes
                </div>
            </div>
        </div>
        <div className="col-2 d-flex flex-column column-border">
          <div className="row column-body text-center">
            <div className="col-12">
              <div className="text-center">
                <div className="dropdown-center btn-group">
                  <button className='btn btn-light'><MdEmojiSymbols /></button>
                  <button className='btn btn-light' data-bs-toggle="dropdown" aria-expanded="false"><GoChevronDown /></button>
                  <ul className="dropdown-menu">
                    <li className='dropdown-submenu'>
                      <button className='dropdown-item'>Arithmatic & Algebra</button>
                      <ul className="dropdown-menu">
                        <li className='dropdown-item'>
                          <div className="symbols-container">
                          <span className="symbol" data-symbol="&#xd7;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#xd7;</span>
                          <span className="symbol" data-symbol="&#xf7;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#xf7;</span>
                          <span className="symbol" data-symbol="&#x2260;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#x2260;</span>
                          <span className="symbol" data-symbol="&#x2264;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#x2264;</span>
                          <span className="symbol" data-symbol="&#x2265;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#x2265;</span>
                          <span className="symbol" id="fractionButton" data-symbol="&#8213;">&#8213;</span>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li className='dropdown-submenu'>
                      <button className='dropdown-item'>
                        Geometry
                      </button>
                      <ul className="dropdown-menu">
                        <li className="dropdown-item">
                          <div className="symbols-container">
                          <span className="symbol" data-symbol="&#960;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#960;</span>
                          <span className="symbol" data-symbol="&#x2220;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#x2220;</span>
                          <span className="symbol" data-symbol="&#9651;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#9651;</span>
                          <span className="symbol" data-symbol="&#8741;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8741;</span>
                          <span className="symbol" data-symbol="&#10178;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#10178;</span>
                          <span className="symbol" data-symbol="&#9675;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#9675;</span>
                          <span className="symbol" data-symbol="&#x221F;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#x221F;</span>
                          <span className="symbol" data-symbol="&#8734;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8734;</span>
                          <span className="symbol" data-symbol="&#8733;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8733;</span>
                          <span className="symbol" data-symbol="&#8771;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8771;</span>
                          <span className="symbol" data-symbol="&#8773;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8773;</span>
                          <span className="symbol" data-symbol="&#8776;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8776;</span>
                          <span className="symbol" data-symbol="&#8774;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8774;</span>
                          <span className="symbol" data-symbol="&#8775;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8775;</span>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li className='dropdown-submenu'>
                      <button className='dropdown-item'>
                        Algebra & Functions
                      </button>
                      <ul className="dropdown-menu">
                        <li className="dropdown-item">
                          <div className="symbols-container">
                          <span className="symbol" data-symbol="&#931;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#931;</span>
                          <span className="symbol" data-symbol="&#8719;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#8719;</span>
                          <span className="symbol" id="applySuperscript">X<sup>2</sup></span>
                          <span className="symbol" id="applySubscript">X<sub>2</sub></span>
                          <span className="symbol" id="applySquareRoot">&#873;x</span>
                          <span className="symbol" data-symbol="&#402;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#402;</span>
                          </div>
                        </li>
                      </ul>
                    </li>
                    <li className='dropdown-submenu'>
                      <button className='dropdown-item'>
                        Trigonometry
                      </button>
                      <ul className="dropdown-menu">
                        <li className="dropdown-item">
                          <div className="symbols-container">
                          <span className="symbol" data-symbol="&#952;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#952;</span>
                          <span className="symbol" data-symbol="&#945;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#945;</span>
                          <span className="symbol" data-symbol="&#946;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#946;</span>
                          <span className="symbol" data-symbol="&#947;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#947;</span>
                          <span className="symbol" data-symbol="&#948;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&#948;</span>
                          <span className="symbol" data-symbol="&deg;" onClick={(e) => handleSymbolClick(e.target.getAttribute('data-symbol'))}>&deg;</span>
                          </div>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="row column-footer">
            <div className="col-12">
              Symbols
            </div>
          </div>
        </div>
        <div className="col-2">
        </div>
      </div>
    </div>
  );
};

export default Toolbar;