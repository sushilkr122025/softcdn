import { Injectable, NotFoundException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, Not, In } from 'typeorm';
import { plainToInstance } from 'class-transformer';
import { Login } from '../entities/login.entity';
import { LoginDto, UpdateLoginDto } from '../dto/login.dto';
import { ConfigService } from '@nestjs/config';
import { UserDetail } from '../entities/userdetail.entity';
import { StudentInformation } from '../entities/studentinformation.entity';
import { StudentInformationDto } from '../dto/student.information.dto';
import { UserPermission } from '../entities/user.permissions.entity';
import { QuestionRule } from 'src/entities/question.rule.entity';

@Injectable()
export class UserService {
  private readonly keybrcyt: string;
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Login)
    private loginRepository: Repository<Login>,
    @InjectRepository(UserDetail)
    private detailRepository: Repository<UserDetail>,
    @InjectRepository(StudentInformation)
    private studentRepository: Repository<StudentInformation>,
    @InjectRepository(UserPermission)
    private userPermissionRepository: Repository<UserPermission>,
    @InjectRepository(QuestionRule)
    private questionRuleRepository: Repository<QuestionRule>,
    private readonly configuration: ConfigService
  ) {
    this.keybrcyt = this.configuration.get<string>('keybcrypt') || 'education';
  }

  async findAll(tenantid: string, notin: number): Promise<any[]> {
    try {
      const result = await this.loginRepository.find({
        where: { tenantid: tenantid, dmlType: 'I', id: Not(notin) },
        select: [
          'id',
          'name',
          'email',
          'gender',
          'designation',
          'classTeacher',
          'section',
          'mobileno',
          'role',
          'createdate',
        ],
      });
      return result;
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  // async findAll(tenantid: string): Promise<any[]> {
  //   try {
  //     const result = await this.dataSource.transaction(async (manager) => {
  //       const data = await manager
  //         .createQueryBuilder()
  //         .select([
  //           'l.id AS id',
  //           'l.name AS name',
  //           'u.DOJ AS DOJ',
  //           'u.contactNo AS contactNo',
  //           'u.emailId AS emailId',
  //           'u.empType AS empType',
  //           'u.status AS status',
  //           'l.role AS role',
  //         ])
  //         .from('userdetail', 'u')
  //         .innerJoin('login', 'l', 'u.userId = l.id')
  //         .where('l.tenantId = :tenantid', { tenantid })
  //         .getRawMany();
  //       return data;
  //     });

  //     return result;
  //   } catch (error) {
  //     console.error('Transaction failed. Rolled back.', error);
  //     throw error;
  //   }
  // }
  async findUserDetails(data: {
    tenantid: string;
    id: number;
  }): Promise<any> {
    const { tenantid, id } = data;
    try {
      const user = await this.loginRepository.findOne({
        where: { tenantid, id },
      });

      if (!user) {
        throw new Error('User not found');
      }

      const userparmission = await this.userPermissionRepository.find({
        where: { userId: id },
      });

      return {
        userdata: plainToInstance(UpdateLoginDto, user, {
          excludeExtraneousValues: true,
        }),
        permission: userparmission,
      };
    } catch (error) {
      console.error('Transaction failed. Rolled back.', error);
      throw error;
    }
  }

  findByEmail(email: string): Promise<Login | null> {
    return this.loginRepository.findOne({ where: { email } });
  }

  async findById(id: number): Promise<Login | null> {
    const user = await this.loginRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  async createUser(loginDto: LoginDto): Promise<any> {
    const { id, password, tenantid } = loginDto;

    let user: Login | undefined;

    if (loginDto.id) {
      user = await this.loginRepository.preload(loginDto);
      if (!user) {
        throw new NotFoundException(`User with id ${id} not found`);
      }
    } else {
      user = this.loginRepository.create({
        ...loginDto,
        password: password + this.keybrcyt,
      });
      await user.hashPassword();
    }
    const create = await this.loginRepository.save(user);
    if (create) {
      return create.id;
    } else {
      throw new NotFoundException('Error from backend service');
    }
  }

  async updateUser(loginDto: LoginDto): Promise<any> {
    console.log('loginDto', loginDto.id);
    const { id } = loginDto;
    if (!loginDto.id) {
      throw new NotFoundException(`User ID is required for update`);
    }

    const user = await this.loginRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException(`User with id ${id} not found`);
    }

    if (
      loginDto.teacherSubject !== undefined ||
      loginDto.teacherSubject !== ''
    ) {
      user.teacherSubject = loginDto.teacherSubject ?? null;
    }
    if (loginDto.classTeacher !== undefined || loginDto.classTeacher !== '') {
      user.classTeacher = loginDto.classTeacher ?? '';
    }
    if (loginDto.section !== undefined || loginDto.section !== '') {
      user.section = loginDto.section ?? '';
    }

    const update = await this.loginRepository.save(user);
    if (update) {
      return { message: 'User updated successfully', id: update.id };
    } else {
      throw new NotFoundException('Error from backend service');
    }
  }

  // async createUser(loginDto: LoginDto): Promise<any> {
  //   console.log('Creating user with DTO:', loginDto);
  //   const {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   } = loginDto;
  //   const user = new Login();
  //   Object.assign(user, {
  //     name,
  //     email,
  //     password,
  //     role,
  //     tenantid,
  //     gender,
  //     mobileno,
  //     address,
  //     userid,
  //   });
  //   user.password = user.password + this.keybrcyt;
  //   await user.hashPassword();
  //   const create = await this.loginRepository.save(user);
  //   if (create) {
  //     return create.id;
  //   } else {
  //     throw new NotFoundException('Error from backend service');
  //   }
  // }

  async createStudent(studentDto: StudentInformationDto): Promise<any> {
    const student = new StudentInformation();
    Object.assign(student, studentDto);
    const create = await this.studentRepository.save(student);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    const studentData = {
      id: create.Id,
      name: create.name,
      rollNo: create.rollNo,
      fatherName: create.fatherName,
      motherName: create.motherName,
    };
    return studentData;
  }

  async findAllStudent(tenantid: string, q): Promise<StudentInformation[]> {
    return this.studentRepository.find({
      where: { tenantid: tenantid, class: 7, section: 'A' },
    });
  }

  async addUserPermissions(
    createdBy: number,
    permissionBody: any,
    tenantid: string
  ): Promise<any> {
    const { userId, permission } = permissionBody;
    const data = permission.map((e) => ({
      module: e.module,
      permissions: e.permissions,
      userId: parseInt(userId),
      createdBy,
      tenantid,
    }));
    const create = await this.userPermissionRepository.insert(data);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Permissions inserted successfully',
      insertedCount: create.identifiers.length,
    };
  }

  async allUserPermissions(userid: number): Promise<UserPermission[]> {
    return this.userPermissionRepository.find({
      where: { userId: userid },
    });
  }

  async findTeacherByClassAndSubject(
    classId: string,
    subjectId: string
  ): Promise<any> {
    //   const query = `
    //   SELECT userId
    //   FROM userpermissions
    //   WHERE JSON_CONTAINS(
    //     JSON_EXTRACT(permissions, '$.APPROVE'),
    //     JSON_OBJECT('subjectId', ?),
    //     '$'
    //   )
    //   AND JSON_SEARCH(permissions, 'one', ?, NULL, '$.APPROVE[*].classIds[*]') IS NOT NULL
    // `;
    // console.log('🟢 Executing SQL:\n', query);
    //   const teachers = await this.userPermissionRepository.query(query, [
    //     subjectId,
    //     classId,
    //   ]);
    const qb = this.userPermissionRepository
      .createQueryBuilder('p')
      .select('p.userId')
      .where(
        `JSON_CONTAINS(JSON_EXTRACT(p.permissions, '$.APPROVE'), JSON_OBJECT('subjectId', :subjectId), '$')
        AND JSON_SEARCH(p.permissions, 'one', :classId, NULL, '$.APPROVE[*].classIds[*]') IS NOT NULL`,
        { subjectId, classId }
      );
    // const [sql, parameters] = qb.getQueryAndParameters();
    // console.log('🟢 Executed SQL:', sql);
    // console.log('🟡 Parameters:', parameters);
    const teachers = await qb.getRawMany();
    if (!teachers) {
      throw new NotFoundException('No teachers found');
    }
    const tid = [...new Set(teachers.map((t) => t.p_userId))];
    const user = await this.loginRepository.find({
      select: ['id', 'name'],
      where: {
        id: In(tid),
      },
    });

    return user;
  }

  async createQuestionRule(body: any, createdBy: number): Promise<any> {
    const data = body.map((e) => ({
      userId: e.userId,
      subjectId: e.subjectId,
      classId: e.classId,
      teachersId: e.teachersId.toString(),
      createdBy: createdBy,
    }));
    const create = await this.questionRuleRepository.insert(data);
    if (!create) {
      throw new NotFoundException('Error from backend service');
    }
    return `Rule created successfully`;
  }
}
