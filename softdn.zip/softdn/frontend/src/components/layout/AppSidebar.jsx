import React, { useState, useEffect, useMemo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Sidebar.css';

// import teacherIcon from '../../assets/images/teacher-grey.svg';
import student from '../../assets/images/student-grey.svg';
// import report from '../../assets/images/report-grey.svg';
import bank from '../../assets/images/bank-grey.svg';
import profile from '../../assets/images/admin-grey.svg';
import dashboard from '../../assets/images/dashboard-grey.svg';
import user from '../../assets/images/user-grey.svg';
import question from '../../assets/images/question.svg';

const SIDEBAR_MENU = [
  { id: 'dashboard', label: 'Dashboard', to: '/dashboard', icon: dashboard },
  { id: 'Alluser', label: 'All User', to: '/users', icon: user },
  { id: 'AllStudent', label: 'All Student', to: '/student', icon: student },
  { id: 'qbank', label: 'Question Bank', to: '/question', icon: bank },
  {
    id: 'question',
    label: 'Question',
    icon: question,
    children: [
      { id: 'q-create', label: 'Create a question', to: '/question/type' },
      { id: 'q-approval', label: 'Paneling', to: '/question/paneling' },
      { id: 'q-exam', label: 'Create exam', to: '/QuestionPaper' },
      { id: 'q-ans', label: 'Answer sheet', to: '/AnswerSheet' },
    ],
  },

  { id: 'managementReport', label: 'Management Report', to: '/reportadmin', icon: profile, },
];

const Sidebar = ({ propVisible, setPropVisible }) => {
  const location = useLocation();

  const setVisible = setPropVisible;
  const sidebarVisible = propVisible;

  const { pathToId, parentOf } = useMemo(() => {
    const pathToId = {};
    const parentOf = {};
    SIDEBAR_MENU.forEach(item => {
      if (item.children) {
        parentOf[item.id] = null;
        item.children.forEach(child => {
          pathToId[child.to] = child.id;
          parentOf[child.id] = item.id;
        });
      } else if (item.to) {
        pathToId[item.to] = item.id;
        parentOf[item.id] = null;
      }
    });
    return { pathToId, parentOf };
  }, []);

  const [activeId, setActiveId] = useState(() => {
    const p = location.pathname;
    if (pathToId[p]) return pathToId[p];
    for (const [path, id] of Object.entries(pathToId)) if (p.startsWith(path)) return id;
    return null;
  });

  const [openParents, setOpenParents] = useState(() => {
    const m = {};
    SIDEBAR_MENU.forEach(item => { if (item.children) m[item.id] = false; });
    if (activeId && parentOf[activeId]) m[parentOf[activeId]] = true;
    return m;
  });


  useEffect(() => {
    const onResize = () => setVisible(window.innerWidth >= 800);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [setVisible]);

  const setSingleOpenParent = (parentId) => {
    setOpenParents(prev => {
      const next = Object.keys(prev).reduce((o, k) => ({ ...o, [k]: false }), {});
      if (parentId) next[parentId] = true;
      return next;
    });
  };

  const handleParentToggle = (parentId) => {
    setOpenParents(prev => {
      const isOpen = !!prev[parentId];
      const next = Object.keys(prev).reduce((o, k) => ({ ...o, [k]: false }), {});
      next[parentId] = !isOpen;
      return next;
    });
    setActiveId(parentId);
  };

  const handleLinkClick = (id) => {
    setActiveId(id);
    const parent = parentOf[id] || null;
    setSingleOpenParent(parent);
    if (window.innerWidth < 800) setVisible(false);
  };

  const isItemActive = (item) => {
    if (item.children) {
      if (activeId === item.id) return true;
      return item.children.some(c => c.id === activeId);
    }
    return activeId === item.id;
  };

  return (
    <nav className={`sidebar ${sidebarVisible ? 'show' : 'hide'}`} aria-label="Main navigation">
      <ul className="sidebar-list">
        {SIDEBAR_MENU.map(item => (
          <li key={item.id} className={`sidebar-item ${item.children ? 'has-sub' : ''} ${isItemActive(item) ? 'active-item' : ''}`}>
            {!item.children ? (
              <NavLink to={item.to} className={() => `sidebar-link ${isItemActive(item) ? 'active' : ''}`} onClick={() => handleLinkClick(item.id, item.to)}>
                {item.icon && <img src={item.icon} alt="" className="sidebar-icon" />}
                <span className="sidebar-label">{item.label}</span>
              </NavLink>
            ) : (
              <div className="sidebar-parent">
                <button
                  type="button"
                  className={`sidebar-link sidebar-parent-btn ${isItemActive(item) ? 'active' : ''}`}
                  aria-expanded={!!openParents[item.id]}
                  onClick={() => handleParentToggle(item.id)}
                >
                  {item.icon && <img src={item.icon} alt="" className="sidebar-icon" />}
                  <span className="sidebar-label">{item.label}</span>
                  <span className={`chev ${openParents[item.id] ? 'open' : ''}`} aria-hidden>▸</span>
                </button>

                <ul className={`submenu ${openParents[item.id] ? 'open' : ''}`}>
                  {item.children.map(child => (
                    <li key={child.id}>
                      <NavLink
                        to={child.to}
                        className={() => `sidebar-sublink ${activeId === child.id ? 'active' : ''}`}
                        onClick={() => handleLinkClick(child.id, child.to)}
                      >
                        <span>{child.label}</span>
                      </NavLink>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Sidebar;
