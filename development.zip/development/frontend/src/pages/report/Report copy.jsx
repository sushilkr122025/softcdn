import React, { useEffect, useState } from "react";
import { Bar, Line } from "react-chartjs-2";
import ReportServices from "../../api/ReportServices";
import ChartDataLabels from "chartjs-plugin-datalabels";

import Color from '../gallery/Color'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend
);

export default function AnalyticsDashboard() {
  const [data, setData] = useState(null);
  const [filters, setFilters] = useState({
    class: "10",
    section: "ALL",
    paperId: "4",
  });

  useEffect(() => {
    fetchAnalytics();
  }, [filters]);

  const fetchAnalytics = async () => {
    const res = await ReportServices.getAnalyticsReport({
            params: { 
                paperid: filters.paperId,
                class: filters.class,
                section: filters.section
            }}      
        );
    const json = await res;
    setData(json);
  };

  if (!data) return <div>Loading...</div>;

  // 🎨 Apply colors to datasets dynamically
  const applyColors = (chartData) => {
    return {
      ...chartData,
      datasets: chartData.datasets.map((ds, index) => ({
        ...ds,
        backgroundColor: Color.bgColor[index],
        borderColor: Color.boColor[index],
        borderWidth: 1,
      })),
    };
  };

  // Section Performance (single bar)
  const sectionChart = applyColors({
    labels: data.sectionPerformance.map((d) => d.section),
    datasets: [
      {
        label: "Avg %",
        data: data.sectionPerformance.map((d) => d.avg),
        backgroundColor: data.sectionPerformance.map((d,index) => Color.bgColor[index]),
        borderColor: data.sectionPerformance.map((d,index) => Color.bgColor[index]),
      },
    ],
  });

  const subjectChart = applyColors(data.subjectChart);
  const questionTypeChart = applyColors(data.questionTypeChart);
  const difficultyChart = applyColors(data.difficultyChart);
  const scoreDistribution = applyColors(data.scoreDistribution);


  const performanceBandChart = {
  ...data.performanceBandChart,
  datasets: data.performanceBandChart.datasets.map((ds, i) => ({
    ...ds,
    backgroundColor: Color.bandColor[i],
    borderColor: Color.bandColor[i],
    borderWidth: 1,
  })),
};
const bandOptions = {
  indexAxis: "y",
  responsive: true,
  plugins: {
    legend: {
      position: "bottom",
    },
    tooltip: {
      callbacks: {
        label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}%`,
      },
    },

    // ⭐ ADD THIS
    datalabels: {
      color: "#fff",
      anchor: "center",
      align: "center",
      formatter: (value) => {
        if (value === 0) return "";
        return value.toFixed(2) + "%";
      },
      font: {
        weight: "bold",
        size: 12,
      },
    },
  },
  scales: {
    x: {
      stacked: true,
      max: 100,
      ticks: {
        callback: (val) => val + "%",
      },
    },
    y: {
      stacked: true,
    },
  },
};
const bandOptionsX = {  
  responsive: true,
  plugins: {
    legend: {
      position: "bottom",
    },
    datalabels: {
      display: true,
      color: "#fff",
      anchor: "center",
      align: "center",
      formatter: (value) => {
        if (!value || value === 0) return "";
        return value.toFixed(2);
      },
      font: {
        weight: "bold",
      },
    },
  },
  scales: {
    x: {
      stacked: true, // 👈 IMPORTANT
    },
    y: {
      stacked: true,
      max: 100,
      ticks: {
        callback: (val) => val + "%",
      },
    },
  },
};
  return (
    <div style={{ padding: 20 }}>
      <h2>Analytics Dashboard</h2>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <select
          value={filters.class}
          onChange={(e) => setFilters({ ...filters, class: e.target.value })}
        >
          <option value="7">Class 7</option>
          <option value="8">Class 8</option>
        </select>

        <select
          value={filters.section}
          onChange={(e) => setFilters({ ...filters, section: e.target.value })}
        >
          <option value="ALL">All Sections</option>
          <option value="A">A</option>
          <option value="B">B</option>
          <option value="C">C</option>
          <option value="D">D</option>
        </select>

        <select
          value={filters.paperId}
          onChange={(e) => setFilters({ ...filters, paperId: e.target.value })}
        >
          <option value="1">Paper 1</option>
          <option value="2">Paper 2</option>
        </select>
      </div>

      {/* Charts Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 20,
        }}
      >
        <div>
          <h4>Section Performance</h4>
          <Bar data={sectionChart} />
        </div>

        <div>
          <h4>Subject Comparison</h4>
          <Bar data={subjectChart} />
        </div>

        <div>
          <h4>Question Type Analysis</h4>
          <Bar data={questionTypeChart} />
        </div>

        <div>
          <h4>Question Difficulty</h4>
          <Line data={difficultyChart} />
        </div>

        <div>
          <h4>Score Distribution</h4>
          <Bar data={scoreDistribution} />
        </div>
        <div>
          <h4>Student Performance Bands</h4>
          <Bar data={performanceBandChart} options={bandOptions} plugins={[ChartDataLabels]} />
      </div>
        <div>
          <h4>Student Performance Bands</h4>
          <Bar data={performanceBandChart} options={bandOptionsX} plugins={[ChartDataLabels]} />
      </div>
      </div>

      {/* Top Students Table */}
      <div style={{ marginTop: 30 }}>
        <h3>Top Students</h3>
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Section</th>
              <th>Name</th>
              <th>Roll No</th>
              <th>Percentage</th>
              <th>Grade</th>
            </tr>
          </thead>
          <tbody>
            {data.topStudents.map((s, i) => (
              <tr key={i}>
                <td>{s.section}</td>
                <td>{s.name}</td>
                <td>{s.rollno}</td>
                <td>{s.percentage}</td>
                <td>{s.grade}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
