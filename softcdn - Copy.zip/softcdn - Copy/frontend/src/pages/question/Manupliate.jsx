import React, { useState } from 'react'
import blankDataImage from '../../assets/images/questions.png'
import { GoFile, GoChevronDown } from 'react-icons/go'
import { FaPlus } from 'react-icons/fa'
import { IoFilterOutline } from 'react-icons/io5'
import apiClient from '../../api/apiService'
import GlobalFilter from '../../components/GlobalFilter'
import { Link } from 'react-router-dom'

const Manupilate = () => {
  const [data, setData] = useState([])
  const [filters, setFilters] = useState({
    quesType: '',
    subject: '',
    class: '',
    difficulty: '',
  })

  const questionData = (childData) => {
    const ogData = childData.filter((key) => key.tId === 1)
    setData(ogData)
  }

  // const toggleAccordion = (accordionId) => {
  //   setExpandedAccordions((prevAccordions) => (prevAccordions.includes(accordionId)
  //     ? prevAccordions.filter((id) => id !== accordionId)
  //     : [...prevAccordions, accordionId]));
  // };

  // const toggleNavbar = () => {
  //   setNavbarCollapsed((prevCollapsed) => !prevCollapsed);
  // };

  const handleFilterChange = (filterType, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [filterType]: value,
    }))
  }

  const handleToggle = (e) => {
    const element = e.currentTarget
    const subData = element.nextElementSibling
    if (subData && subData.classList.contains('d-none')) {
      subData.classList.remove('d-none')
      element.querySelector('.pointer > svg').classList.add('rotate')
    } else {
      subData.classList.add('d-none')
      element.querySelector('.pointer > svg').classList.remove('rotate')
    }
    // element.previousElementSibling.querySelector('.pointer > svg').classList.toggle('rotate')
  }
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [itemToDelete, setItemToDelete] = useState(null)

  // const handleDeleteItem = (itemId) => {
  //   // Show the delete confirmation modal and store the item to delete
  //   setShowDeleteModal(true);
  //   setItemToDelete(itemId);
  // };
  const confirmDelete = () => {
    if (itemToDelete) {
      // Send a DELETE request to your server
      apiClient
        .delete(`/questions/${itemToDelete}`)
        .then(() => {
          // console.log("Item deleted successfully");
          apiClient.get('/questions').then((response) => {
            setData(response.data)
          })
        })
        .catch((error) => {
          // Handle the error (e.g., show an error message)
          console.error('Error deleting item:', error)
        })
        .finally(() => {
          // Close the delete confirmation modal and clear the itemToDelete
          setShowDeleteModal(false)
          setItemToDelete(null)
        })
    }
  }

  const cancelDelete = () => {
    // Close the delete confirmation modal and clear the itemToDelete
    setShowDeleteModal(false)
    setItemToDelete(null)
  }
  const filteredData = data.filter(
    (item) =>
      (!filters.quesType || item.quesType === filters.quesType) &&
      (!filters.subject || item.subject === filters.subject) &&
      (!filters.class || item.class === filters.class) &&
      (!filters.difficulty || item.difficulty === filters.difficulty)
  )

  const renderTable = () => {
    if (filteredData.length === 0) {
      return (
        <section className="text-center my-4">
          <div className="row justify-content-center">
            <div className="col-8 col-sm-7 col-md-5 col-lg-3">
              <img src={blankDataImage} alt="Question Bank" className="img-fluid mb-4" />
            </div>
          </div>
          <h4 className="fw-normal">No data available</h4>
          <p className="text-muted">Start Filtering data according to your need</p>
          <Link to="/questionGeneration" className="btn lq-yellow-color">
            <FaPlus /> Create Question
          </Link>          
        </section>
      )
    } else {
      document.getElementById('filter').classList.remove('d-none')
      return (
        <>
          <div className="table-responsive">
            <table className="table table-lg" id="questionTable" width={100}>
              <thead>
                <tr>
                  <th colSpan={3} className="border-start border-end">
                    Questions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((item, index) => (
                  <>
                    <tr className="quesRow" key={index} onClick={(e) => handleToggle(e, index)}>
                      <td className="border-start">{item.question}</td>
                      <td className="border-end">
                        <span className="pointer">
                          <GoChevronDown size={20} />
                        </span>
                      </td>
                    </tr>
                    <tr className="subData d-none">
                      <td colSpan={3} className="border-start border-end">
                        <div className="d-flex justify-content-between">
                          <p className="me-2">
                            <span className="fw-bold">1. </span>
                            {item.opt1}
                          </p>
                          <p className="me-2">
                            <span className="fw-bold">2. </span>
                            {item.opt2}
                          </p>
                          <p className="me-2">
                            <span className="fw-bold">3. </span>
                            {item.opt3}
                          </p>
                          <p className="me-2">
                            <span className="fw-bold">4. </span>
                            {item.opt4}
                          </p>
                        </div>
                      </td>
                    </tr>
                  </>
                ))}
              </tbody>
            </table>
          </div>
          <Link to="/questionGeneration" className="btn lq-yellow-color">
            <FaPlus /> Create Question
          </Link>
        </>
      )
    }
  }

  return (
    <div className="container-fluid">
      <GlobalFilter
        icon={<GoFile />}
        heading={'Questions'}
        headClass={'yellow'}
        questionData={questionData}
      />
      <section>
        <div className="row mb-3 d-none filter-header yellow" id="filter">
          <div className="col-lg-4 col-md-3 d-flex align-items-center mb-2">
            <IoFilterOutline /> Filters
          </div>
          <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
            <select
              className="form-select form-select-sm"
              id="type"
              value={filters.quesType}
              onChange={(e) => handleFilterChange('quesType', e.target.value)}
            >
              <option value="">Select Type</option>
              <option value="multipleChoice">Multiple Choice</option>
              <option value="trueFalse">True/False</option>
              <option value="oneword">one word</option>
              <option value="CR">Constructed response</option>
            </select>
          </div>
          <div className="col-sm-6 col-lg-2 col-md-2 mb-2">
            <select
              className="form-select form-select-sm"
              value={filters.difficulty}
              onChange={(e) => handleFilterChange('difficulty', e.target.value)}
            >
              <option value="">Select Difficulty Level</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </div>
        </div>
      </section>
      <main className="col ps-md-2 pt-2">{renderTable()}</main>
      <div
        className="modal fade"
        id="deleteConfirmationModal"
        tabIndex="-1"
        aria-labelledby="deleteConfirmationModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="deleteConfirmationModalLabel">
                Confirm Delete
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              />
            </div>
            <div className="modal-body">Are you sure you want to delete this item?</div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
                onClick={cancelDelete}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={confirmDelete}
                data-bs-dismiss="modal"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default Manupilate
