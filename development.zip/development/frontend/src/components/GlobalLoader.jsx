import { useEffect, useState } from "react"
import { loaderStore } from "../LoaderStore"

export default function GlobalLoader() {
  const [loading, setLoading] = useState(loaderStore.get())

  useEffect(() => loaderStore.subscribe(setLoading), [])

  if (!loading) return null

  return (
    <div style={overlay}>
      <div style={box}>Loading...</div>
    </div>
  )
}

const overlay = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100vw",
  height: "100vh",
  background: "rgba(0,0,0,0.25)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  zIndex: 9999
}

const box = {
  background: "#fff",
  padding: "20px 40px",
  borderRadius: 8
}
