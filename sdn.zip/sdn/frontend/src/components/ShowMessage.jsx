import { useEffect, useState } from 'react';
import { Toast, Alert, ToastContainer, Modal, Button } from 'react-bootstrap';

function ShowMessage({type , show,title, message, variant, autohide = true, delay = 3000, position = 'top-center',size, textClose, textConfirm, btnClose, btnConfirm, onClose,onConfirm,
  confirmText = textConfirm || "Confirm",
  closeText = textClose || "Close" }) {
  const [visible, setVisible] = useState(show);

  useEffect(() => {
    setVisible(show);
  }, [show]);

  return (
    <>
      {type === 'toast' && (
        <ToastContainer position={position} className="p-3">
          <Toast
            onClose={() => {
              setVisible(false);
              onClose?.();
            }}
            show={visible}
            delay={delay}
            autohide={autohide}
            bg={variant}
          >
            <Toast.Body className="text-white">{message}</Toast.Body>
          </Toast>
        </ToastContainer>
      )}
      {type === 'alert' && (
        <Alert 
          variant={variant} 
          onClose={() => {
              setVisible(false);
              onClose?.();
            }} 
          dismissible
        >          
          {message}
        </Alert>
      )}
      {type === 'modal' && (
        <Modal
          show={visible}
          onHide={() => {
            setVisible(false);
            onClose?.();
          }}
          keyboard={false}
          backdrop='static'
          size={size}
          centered
        >
          {title && (
            <Modal.Header closeButton>
              <Modal.Title>{title}</Modal.Title>
            </Modal.Header>
          )}

          <Modal.Body className="text-center">{message}</Modal.Body>

          <Modal.Footer className="justify-content-center">
            {btnClose && (
              <Button
                variant="secondary"
                onClick={() => {
                  setVisible(false);
                  onClose?.();
                }}
              >
                {closeText}
              </Button>
            )}
            {btnConfirm && (
              <Button
                variant="primary"
                onClick={() => {
                  setVisible(false);
                  onConfirm?.();
                }}
              >
                {confirmText}
              </Button>
            )}
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default ShowMessage;
