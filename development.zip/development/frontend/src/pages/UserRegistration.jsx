import React, { useEffect, useState } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { Row, Col, Form, Container, Card, Button, Spinner } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom'
import UserServices from '../api/UserServices'
import ShowMessage from '../components/ShowMessage'
import CustomDropdown from '../components/layout/CustomDropdown'
const UserRegistration = () => {
  const navigator = useNavigate()
  const { register, handleSubmit, reset, control, setValue, formState: { errors, isSubmitting } } = useForm(
    { mode: 'onChange' }
  )

  const [userData, setUserData] = useState();
  const [roles, setRoles] = useState([]);
  const { userid } = useParams();
  const updateId = userid ? userid : null;
  const [showToast, setShowToast] = useState(false);
  const [designation, setDesignation] = useState();
  const [openKey, setOpenKey] = useState("");
  useEffect(() => {
    const getRoles = async (type) => {
      try {
        const response = await UserServices.getSystemRoles({ params: { type: type } })
        setRoles(response);
      } catch (error) {
        console.error(error.message)
      }
    }
    getRoles('SYSTEMROLE');
  }, [])

  useEffect(() => {
    const fetchUserData = async () => {
      if (updateId) {
        try {
          const response = await UserServices.getUser({ params: { id: updateId } });
          console.log(response.userdata);
          setUserData(response.userdata);
          reset(response.userdata);
        } catch (error) {
          console.error(error.message)
        }
      }
    }

    fetchUserData()
  }, [updateId, reset])

  useEffect(() => {
    if (userData && roles.length > 0) {
      const selectedRole = roles.find(r => r.label === userData.role);
      if (selectedRole?.itstype) {
        getDesignation(selectedRole.itstype);
      }
    }
  }, [userData, roles]);

  useEffect(() => {
    if (designation?.length > 0 && userData?.designation) {
      setValue('designation', userData.designation);
    }
  }, [designation, userData, setValue]);

  const getDesignation = async (type) => {
    try {
      const response = await UserServices.getSystemRoles({ params: { type: type } })
      setDesignation(response);
    } catch (error) {
      console.error(error.message)
    }
  }

  const onSubmit = async (data) => {
    try {
      const response = await UserServices.registerUser(data)
      if (response) {
        // navigator('/users')
        setShowToast(true);
      }
    } catch (error) {
      console.log(error)
    }
  }

  if (updateId && !userData) {
    return <div>Loading...</div>
  }

  return (
    <div className="position-relative h-85vh d-flex flex-column">
      <div className="useraddbanner"></div>
      <div className="d-flex  flex-grow-1">
        <Container className="my-5">
          <Row className="justify-content-center mt-5 pt-xxl-5">
            <Col lg={10} xl={9}>
              <Card className="border-0 custom-shadow">
                <Card.Body className="p-4 p-md-5">
                  <Form onSubmit={handleSubmit(onSubmit)} autoComplete="off">
                    <div className="mb-4 row">
                      <div className="col-9">
                        <h4 className="fw-bold usertext  mb-1">User Registration</h4>
                        <hr className="border border-primary border-2 rounded opacity-100 mt-0 w-25" />
                      </div>
                    </div>
                    <Row className="form-grid">
                      <Col md={12}>
                        <ShowMessage show={showToast} type="modal" message="User Details Saved" variant="success"
                          btnConfirm={true} btnClose={false} textConfirm="OK"
                          onClose={() => setShowToast(false)}
                          onConfirm={() => {
                            setShowToast(false);
                            navigator('/users');
                          }}
                        />
                      </Col>
                      <Col md={12}>
                        <Form.Group controlId="role" className="mb-4">
                          <Form.Label className="text-muted small fw-bold">Registered As</Form.Label>
                          <div className="d-flex flex-wrap gap-4 mt-1">
                            {roles.map((role, i) => (
                              <Form.Check
                                key={i}
                                type="radio"
                                id={`role-${i}`}
                                label={<span className="small text-secondary fw-semibold">{role.label}</span>}
                                value={role.label}
                                {...register('role', { required: 'Register As is required' })}
                                name="role"
                                onChange={(e) => {
                                  register('role').onChange(e);
                                  getDesignation(role.itstype);
                                }}
                              />
                            ))}
                          </div>
                          {errors.role && <small className="text-danger d-block mt-1">{errors.role.message}</small>}
                        </Form.Group>
                      </Col>
                    </Row>
                    <Row className="g-3">
                      <Col md={6} lg={4}>
                        {updateId && (
                          <>
                            <Form.Control
                              type="hidden"
                              defaultValue={userData?.id}
                              {...register('id')}
                            />
                          </>
                        )}
                        <Form.Group controlId="name">
                          <Form.Label className="text-muted small fw-bold">First Name</Form.Label>
                          <Form.Control
                            autoComplete="new-password"
                            type="text"
                            placeholder="First Name.."
                            {...register('name', {
                              required: 'First Name is required',
                              pattern: {
                                value: /^[a-zA-Z\s]+$/,
                                message: 'Name should contain letters only',
                              },
                              minLength: {
                                value: 3,
                                message: 'Name should be at least 3 characters long',
                              },
                            })}
                            className={`py-2 ${errors.name ? 'is-invalid' : ''}`}
                          />
                          {errors.name && <div className="invalid-feedback small">{errors.name.message}</div>}
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="lastname">
                          <Form.Label className="text-muted small fw-bold">Last Name</Form.Label>
                          <Form.Control
                            type="text"
                            autoComplete="new-password"
                            placeholder="Last Name.."
                            {...register('lastname', {
                              pattern: {
                                value: /^[a-zA-Z\s]+$/,
                                message: 'Last Name should contain letters only',
                              },
                            })}
                            className={`py-2 ${errors.lastname ? 'is-invalid' : ''}`}
                          />
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="designation">
                          <Form.Label className="text-muted small fw-bold">Designation</Form.Label>
                          <Controller
                            name="designation"
                            control={control}
                            defaultValue={userData?.designation || ""}
                            rules={{ required: "Designation is required" }}
                            render={({ field }) => (
                              <CustomDropdown
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                dropdownKey="designation"
                                placeholder="Choose..."
                                value={field.value}
                                error={!!errors.designation}
                                options={(designation || []).map((desig) => ({
                                  value: desig.label,
                                  label: desig.label,
                                }))}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.designation && <div className="invalid-feedback small">{errors.designation.message}</div>}
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="gender">
                          <Form.Label className="text-muted small fw-bold">Gender</Form.Label>
                          <Controller
                            name="gender"
                            control={control}
                            rules={{ required: "Gender is required" }}
                            render={({ field }) => (
                              <CustomDropdown
                                openKey={openKey}
                                setOpenKey={setOpenKey}
                                dropdownKey="gender"
                                placeholder="Please Select"
                                value={field.value}
                                error={!!errors.gender}
                                options={[
                                  { value: "male", label: "Male" },
                                  { value: "female", label: "Female" },
                                ]}
                                onChange={(val) => field.onChange(val)}
                              />
                            )}
                          />
                          {errors.gender && (
                            <div className="invalid-feedback d-block">{errors.gender.message}</div>
                          )}
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="email">
                          <Form.Label className="text-muted small fw-bold">Email ID</Form.Label>
                          <Form.Control
                            type="email"
                            autoComplete="new-password"
                            placeholder="name@gmail.com"
                            {...register('email', {
                              pattern: {
                                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                message: 'Invalid email address',
                              },
                            })}
                            className={`py-2 ${errors.email ? 'is-invalid' : ''}`}
                          />
                          {errors.email && <div className="invalid-feedback small">{errors.email.message}</div>}
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="mobileno">
                          <Form.Label className="text-muted small fw-bold">Contact No</Form.Label>
                          <Form.Control
                            type="text"
                            maxLength="10"
                            placeholder="10-digit mobile"
                            {...register('mobileno', {
                              pattern: {
                                value: /^[6-9]\d{9}$/,
                                message: 'Enter a valid 10-digit phone number starting with 6-9',
                              },
                            })}
                            className={`py-2 ${errors.mobileno ? 'is-invalid' : ''}`}
                          />
                          {errors.mobileno && <div className="invalid-feedback small">{errors.mobileno.message}</div>}
                        </Form.Group>
                      </Col>
                      <Col md={6} lg={4}>
                        <Form.Group controlId="userid">
                          <Form.Label className="text-muted small fw-bold">User ID</Form.Label>
                          {userData?.userid ? (
                            <p className="form-control mb-0">{userData.userid}</p>
                          ) : (
                            <>
                              <Form.Control
                                type="text"
                                maxLength="15"
                                placeholder='User ID..'
                                {...register('userid', {
                                  required: 'User ID is required',
                                  pattern: {
                                    value: /^[a-zA-Z0-9]{5,15}$/,
                                    message:
                                      'User ID must be 5–15 characters, letters and numbers only',
                                  },
                                })}
                                className={`py-2 ${errors.userid ? 'is-invalid' : ''}`}
                              />
                              {errors.userid && <div className="invalid-feedback small">{errors.userid.message}</div>}
                            </>
                          )}
                        </Form.Group>
                      </Col>
                      {!updateId && (
                        <>
                          <Col md={6} lg={4}>
                            <Form.Group controlId="password">
                              <Form.Label className="text-muted small fw-bold">Password</Form.Label>
                              <Form.Control
                                type="password"
                                placeholder="••••••••"
                                {...register('password', {
                                  required: 'Password is required',
                                  minLength: {
                                    value: 6,
                                    message: 'Minimum 6 characters required',
                                  },
                                })}
                                className={`py-2 ${errors.password ? 'is-invalid' : ''}`}
                              />
                              {errors.password && <div className="invalid-feedback small">{errors.password.message}</div>}
                            </Form.Group>
                          </Col>
                        </>
                      )}
                    </Row>
                    <div className="d-flex justify-content-end gap-3 mt-4">
                      <button type="button" className="px-5 fw-bold btn btn-export h45 shadow-sm" onClick={() => navigator('/users')}> Back</button>
                      <button type="submit" disabled={isSubmitting} className="px-5 btn btn-primary h45">
                        {isSubmitting ? (
                          <>
                            <Spinner size="sm" className="me-2" />
                            Saving...
                          </>
                        ) : updateId ? ('Update User') : ('Register User')}
                      </button>
                    </div>
                  </Form>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  )
}


export default UserRegistration
