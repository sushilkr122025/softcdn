import { Injectable, Inject, LoggerService } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { firstValueFrom } from 'rxjs';
import * as fs from 'fs';
import * as path from 'path';

import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';

@Injectable()
export class OcrService {
  private readonly flaskUrl: string;

  constructor(
    private readonly http: HttpService,
    private readonly configService: ConfigService,
    @Inject(WINSTON_MODULE_NEST_PROVIDER) private readonly logger: LoggerService
  ) {
    this.flaskUrl =
      this.configService.get<string>('app.ocrUrl') ||
      'http://192.168.0.180:5000/uploads';
  }

  async predict(files: Express.Multer.File[], ocrdata: any): Promise<any> {
    const ocrSubDir = 'ocr';
    this.logger.log(`ocr-service: Starting OCR prediction: ${this.flaskUrl}`);
    const fileDetails = files?.length
      ? await Promise.all(
          files.map(async (file) => {
            const dirPath = path.join(file.destination, ocrSubDir);

            if (!fs.existsSync(dirPath)) {
              fs.mkdirSync(dirPath, { recursive: true });
            }

            const newFilePath = path.join(dirPath, file.filename);
            await fs.promises.rename(file.path, newFilePath);
            this.logger.log(
              `ocr-service: Starting OCR prediction: ${newFilePath} : ${ocrdata?.folderName ?? ''}/${ocrSubDir}/${file.filename}`
            );
            console.log(
              `/${ocrdata?.folderName ?? ''}/${ocrSubDir}/${file.filename}`
            );

            return {
              fileName: file.filename,
              filePath: `/${ocrdata?.folderName ?? ''}/${ocrSubDir}/${file.filename}`,
            };
          })
        )
      : [];

    const payload = {
      ...ocrdata,
      fileDetails,
    };

    console.log('File Details Payload:', typeof payload);

    const response = await firstValueFrom(
      this.http.post(this.flaskUrl, payload)
    );
    if (!response) {
      this.logger.log(
        `ocr-service: OCR service responded with status ${response}`
      );
    }
    console.log('response.data');
    console.log(response.data);

    return response.data;
  }
}
