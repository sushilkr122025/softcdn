function formatDate(date) {
  const dateObject = new Date(date)
  const day = dateObject.getDate().toString().padStart(2, '0')
  const month = (dateObject.getMonth() + 1).toString().padStart(2, '0')
  const year = dateObject.getFullYear()

  return `${day}-${month}-${year}`
}

const stages = ['Foundation', 'Preparatory', 'Middle', 'Secondary']

const classToStage = {
  '1' : 'Foundation',
  '2' : 'Foundation',
  '3' : 'Preparatory',
  '4' : 'Preparatory',
  '5' : 'Preparatory',
  '6' : 'Middle',
  '7' : 'Middle',
  '8' : 'Middle',
  '9' : 'Secondary',
  '10' : 'Secondary',
  '11' : 'Secondary',
  '12' : 'Secondary',
};

export { formatDate, stages, classToStage }
