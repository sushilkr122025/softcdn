import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { LookupSchool } from '../entities/lookup.school.entity';
import { School } from '../entities/school.entity';

@Injectable()
export class LookupService {
  constructor(
    @InjectRepository(LookupSchool)
    private readonly lookupSchoolRepository: Repository<LookupSchool>,
    @InjectRepository(School)
    private schoolRepository: Repository<School>
  ) {}

  async findBySlug(getlocation: string) {
    const company = await this.lookupSchoolRepository.findOne({
      where: { getlocation },
    });
    // console.log('Company services:', company, 'getlocation:', getlocation);
    if (company) {
      const schools = await this.schoolRepository.findOne({
        where: { tenantid: company.returnlocation },
      });
      // console.log(
      //   'School services:',
      //   schools,
      //   'tenantid:',
      //   company.returnlocation
      // );
      if (!schools) {
        return null;
      }
      const school = {
        tenantid: schools.tenantid,
        board: schools.board,
        schoolname: schools.name,
        schoollogo: schools.logo,
      };
      return { company, school };
    }
    return null;
  }
}
