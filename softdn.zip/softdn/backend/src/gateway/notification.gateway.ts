/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
  ConnectedSocket,
  MessageBody,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Injectable } from '@nestjs/common';
import * as cookie from 'cookie';
import { EncryptionService } from '../services/encryption.service';
import { LookupService } from '../services/lookup.service';
import { AuthService } from '../services/auth.service';
import { MessageService } from '../services/message.services';

@Injectable()
@WebSocketGateway({
  namespace: '/api',
  cors: { origin: true, credentials: true },
})
export class NotificationGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer() server: Server;
  private userSockets = new Map<string, string>(); // tenantId|userId -> socketId

  constructor(
    private readonly encryptionService: EncryptionService,
    private readonly lookupService: LookupService,
    private readonly authService: AuthService,
    private readonly messageService: MessageService,
  ) {}

  async handleConnection(client: Socket) {
    // const rawCookie = client.handshake.auth.userId || '';
    // console.log('Raw Cookie:', rawCookie);
    // const cookies = cookie.parse(rawCookie);
    // const authToken = String(cookies['token']);
    // console.log('Client connected:', client.id, 'Auth Token:', authToken);
    // if (!authToken) throw new Error('Missing auth token');
    // const payload = this.jwtService.verify(authToken, {
    //   secret: this.configService.get<string>('jwt.secret') || 'secret.secret',
    // });

    // // 👇 call JwtStrategy.validate manually
    // const user = await this.jwtService.verify(payload);
    // if (!user) throw new Error('Invalid token');
    // const userId = user.id;
    // console.log('Authenticated user:', userId);
    try {
      // Parse cookies from handshake
      // console.log('Connected client:', client.id, 'namespace:', client.nsp.name);
      const rawCookie = client.handshake.headers.cookie || '';
      const cookies = cookie.parse(rawCookie);

      const companyToken = cookies['companyToken'];
      if (!companyToken) throw new Error('Missing company token');
      const tenantSlug = this.encryptionService.decrypt(companyToken);

      const company = await this.lookupService.findBySlug(tenantSlug);
      if (!company) throw new Error('Invalid tenant');
      const tenantId = company.school.tenantid;

      // 2. Verify auth token
      const authToken = client.handshake.auth.userId;
      // console.log('Auth Token:', client.handshake.auth.userId);
      if (!authToken) throw new Error('Missing auth token');
      const uid: string = authToken; //this.encryptionService.decrypt(authToken);
      const payload = await this.authService.findById(Number(uid), tenantId);
      if (!payload) throw new Error('User not found');
      const userId = payload.id;
      // console.log('Authenticated user:', userId);
      // 3. Store socket
      const key = `${tenantId}|${userId}`;
      this.userSockets.set(key, client.id);

      client.data.tenantId = tenantId;
      client.data.userId = userId;

      // console.log(`WS Connected: User ${userId} Tenant ${tenantId}`);
    } catch (err) {
      console.error(' WS Connection failed:', err.message);
      client.disconnect();
    }
  }

  async handleDisconnect(client: Socket) {
    for (const [key, socketId] of this.userSockets.entries()) {
      if (socketId === client.id) {
        this.userSockets.delete(key);
        console.log(`Disconnected: ${key}`);
        break;
      }
    }
  }

  //  Send notification to a specific user
  async sendToUser(tenantId: string, userId: number, message: string) {
    const key = `${tenantId}|${userId}`;
    const socketId = this.userSockets.get(key);
    if (socketId) {
      this.server.to(socketId).emit('notification', { message });
    }
  }

  //  Broadcast notification to all users in tenant
  async sendToTenant(tenantId: string, message: string) {
    for (const [key, socketId] of this.userSockets.entries()) {
      if (key.startsWith(`${tenantId}|`)) {
        this.server.to(socketId).emit('notification', { message });
      }
    }
  }

  @SubscribeMessage('join_room')
  async handleJoinRoom(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { qId: string }
  ) {
    const tenantId = client.data.tenantId;
    const room = String(data.qId); //`${tenantId}|${data.qId}` keep it simple for now
    await client.join(room);
    console.log(`User ${client.id} joined room ${room}`);
  }

  @SubscribeMessage('load_messages')
  async handleLoadMessages(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { qId: string }
  ) {
    const tenantId = client.data.tenantId;
    const qId = data.qId;
    // console.log(`Load messages for tenant ${tenantId} and qId ${qId}`);
    const messages = await this.messageService.getMessages(tenantId, qId);
    client.emit('messages_history', messages);
  }

  @SubscribeMessage('send_message')
  async handleSendMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody() msg: { qId: number; message: string }
  ) {
    const data = {
      tenantid: client.data.tenantId,
      userId: client.data.userId,
      qId: msg.qId,
      message: msg.message,
    };
    // Save message
    const message = await this.messageService.createMessage(data);
    // console.log('New message:', message);
    // console.log(`${data.tenantid}|${data.qId}`);
    // Emit to all users in task room  .to(`${data.tenantid}|${message.userId}`)
    // void client.join(String(data.qId));
    const room = String(data.qId); //`${data.tenantid}|${data.qId}`;
    // await client.join(room);
    this.server.to(room).emit('receive_message', message);
    // client.emit('receive_message', message);
  }
}
