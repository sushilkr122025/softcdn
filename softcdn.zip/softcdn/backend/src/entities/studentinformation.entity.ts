import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('studentinformation')
export class StudentInformation {
  @PrimaryGeneratedColumn()
  Id: number;

  @Column({ type: 'varchar', length: 25, default: null })
  studentId: string;

  @Column({ type: 'varchar', length: 80, default: null })
  name: string;

  @Column({ type: 'int' })
  rollNo: number;

  @Column({ type: 'varchar', length: 80, default: null })
  fatherName: string;

  @Column({ type: 'varchar', length: 80, default: null })
  motherName: string;

  @Column({ type: 'varchar', length: 15, default: null })
  gender: string;

  @Column({ type: 'date' })
  dateOfBirth: string;

  @Column({ type: 'int' })
  class: number;

  @Column({ type: 'varchar', length: 2, default: null })
  section: string;

  @Column({ type: 'varchar', length: 10, default: null })
  contactNumber: string;

  @Column({ type: 'varchar', length: 10, default: null })
  alternativeContactNumber: string;

  @Column({ type: 'varchar', length: 100, default: null })
  emailId: string;

  @Column({ type: 'varchar', length: 200, default: null })
  address: string;

  @Column({ type: 'int', default: null })
  state: number;

  @Column({ type: 'int', default: null })
  district: number;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;
}
