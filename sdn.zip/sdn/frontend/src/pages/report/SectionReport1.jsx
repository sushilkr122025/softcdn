import React,{useEffect,useRef,useState} from 'react'
import { useSearchParams } from 'react-router-dom';
import config from '../config';
import axios from 'axios';
import {Bar, getDatasetAtEvent, getElementAtEvent, getElementsAtEvent} from "react-chartjs-2";
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Color from './Color';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import 'chart.js/auto'
import './style.css'


function SectionReport() {
  const [sparams] = useSearchParams();
    const [section, setSection] = useState([])
    const [fdata, setFdata] = useState([])
    const [qid, setQid] = useState([])
    const [paper, setPaper] = useState()
    const [gradeList, setGradeList] = useState([])
    const [stulength, setStulength] = useState()
    const allavg = []
    const qarr = []
    const chartdata = []
    let paperid= sparams.get('paperid');
    let clsection=sparams.get('section');    
    const fetchData = async () => {
        try {
          //let paperid=1;
          const response = await axios.get(config.apiurl+'/api/ndata',{
            params: {
              paperid: paperid,
              section: clsection
            }
          }); 
        
          setQid(response.data.qid);
          setFdata(response.data.fdata);
          setSection(response.data.section);
          //setSection(['A']);
          setGradeList(response.data.grade)          
          setPaper(response.data.paper)    
          setStulength(response.data.fdata[clsection.toUpperCase()].students.length)
        } catch (err) {
          console.log(err.message);
        }
      };
      useEffect(() => {
        fetchData();
        },[]);
                
        const letterToNumber = {
          a: 0,
          b: 1,
          c: 2,
          d: 3,
          e: 4
        }

        const getNumber = (letter) => {
          return letterToNumber[letter];
        };

        const choptions = {          
          plugins: {            
            legend: {
              display: false,
              onClick: function(event, legendItem) {
              // Chart.defaults.global.legend.onClick.call(this, event, legendItem);
              let index = legendItem.datasetIndex
              let meta; //= this.datasetIndex(index);
              legendItem.hidden=true
              console.log(legendItem);
              console.log(this);
            },                            
              labels: {
                padding: 10,                
              }  
            },
            title: {
              display: true,
              text: 'Comparison Chart By Question', // Chart title
             // color: '#343a40',
              font: {
                  weight: 'bold',
                  size: 24
              }
          },
            tooltip: {
              enabled: true,
            },
            datalabels: {
              display: true,
              //color: "black",
              //formatter: Math.round,
              anchor: "end",
              offset: -20,
              align: "start"
            },
            afterUpdate: function(chart) {
              // Add padding to the top of the chart area
              chart.layout.padding.top = 20; // Adjust this value as needed
            }
          },
          scales: { 
            x: {
              title: {
                  display: true,
                  text: "Question Number's", // Name of x-axis
                  font: {                    
                    size: 24
                  },                  
              },
              beginAtZero: true
          },
          xTopPadding: {
            // Fake x-axis for padding
            position: 'top',
            labels: [''],
            grid: {
              drawOnChartArea: false,
              drawTicks: true,
              ticksWidth: 0,
              ticksLength: 0, // Increase ticksLength to increase the "padding"
            },
          },              
            y: {
              title: {
                display: true,
                text: '% Correct', // Name of y-axis
                font: {                 
                  size: 24
                }
            },
              beginAtZero: true,              
              grace: '5%',
              // ticks: {
              //   stepSize: 10,
              //   //min:10,
              //   //max: 100
              // }
            }
          }          
          
        };
        const choptionsinner = {
          layout: {
            padding: {
              top: 0  // Adjust the top padding here
            }
          },
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              enabled: true,
            },
            datalabels: {
              display: true,
              color: "black",
              //formatter: Math.round,
              anchor: "end",
              offset: -20,
              align: "start"
            },
            afterUpdate: function(chart) {              
              chart.layout.padding.top = 40; // Adjust this value as needed
            }
          },
          legend: {
            display: false
          },
          scales: {
            x: {
                title: {
                display: true,
                text: 'Options', // Name of y-axis
                font: {                 
                  size: 16
                }
              }
            },
            y: {
                  title: {
                  display: true,
                  text: 'Percentage', // Name of y-axis
                  font: {                 
                    size: 16
                  }
                },
                beginAtZero: true,
                grace: '5%',
            }
        }
        };

        let dlable = []
        let dcount  = []
        let davg = []
        let [qdata , setQdata] = useState()
        let [question , setQuestion] = useState()
        const [showInnerModal, setShowInnerModal] = useState(false);

        const handleCloseInnerModal = () => setShowInnerModal(false); 
        
        const handlequestionClick = async (e)=>{ 
          console.log(e);
          try {    
            const response = await axios.get(config.apiurl+'/getavg',{
                params: {
                   paperid:paperid,
                   qid:e,
                   students:stulength,
                   section: clsection
                }
            }); 
            dlable = []
            dcount  = []       
            // console.log(response.data.question)
            if(response.data.status){
              setQdata(response.data.data) 
              setShowInnerModal(true); 
              setQuestion(response.data.question)     
            } 
          } catch (err) {
            console.log(err.message);
          }
        
        } 
        
        {question &&
          qdata.map((item)=> {
            dlable.push(item.uanswer) 
            davg.push(item.tval)
          })                  
          console.log(qdata);
         // console.log(Object.keys(question[0]));
        }
        
        const chartRef = useRef()
        const graphclickinner = (event) => {
          let datasetIndex = getElementAtEvent(chartRef.current, event)
          if(datasetIndex.length > 0){        
            let index = datasetIndex[0].index    
            handlequestionClick(qid[0].split(',')[index])
            
          }
        }
        
  return (
    <div className='container-fluid'>       
          {chartdata &&           
      <div className='row'>        
        <div className='col-md-12 pb-4'>
        <Bar
        datasetIdKey='id'
        data={{
          labels: qarr,
          datasets: chartdata          
        }}
        plugins={[ChartDataLabels]}
        options={choptions}
        ref={chartRef}
        onClick={graphclickinner}
      />

        </div>
        </div>
      }
        <div className='row'>                       
        <div className='col-md-12'>
          <div className='table-responsive'>
        <table className='table table-sm table-bordered table-hover table-striped'>
    <thead>
        <tr>                  
          <th>No</th>          
          <th>Student</th>                  
          {qid &&
              qid.map((item, index) => {
                let q = item.split(",");
                return q.map((citem, i) => {  
                  qarr.push(citem)                
                 return <th key={citem}>
                    <span onClick={(e) => handlequestionClick(e.currentTarget.textContent)} className='cursor'>
                      {citem}                      
                    </span>
                  </th>
              });
              })}
              <th>%</th>          
              <th>Grade</th>          
        </tr>
      </thead>
    <tbody>
    {section && section.map((item, index) => {
    let rdata = fdata[item].students;    
    let colindex = getNumber(clsection)    
    let avgdata = fdata[item].average;
    let inchartdata = {
      id:index,
      label: item,
      data: avgdata,
      backgroundColor: Color.bgColor[colindex]      
    }
    chartdata.push(inchartdata)
    // console.log(avgdata)
    allavg.push(avgdata)
    return ( rdata.map((citem, index) => (
        
      <tr key={"tr"+index}>        
        <td className='text-primary-emphasis'>{citem.rollno}</td>
        <td className='text-primary-emphasis'>{citem.name}</td>        
        {          
          citem.data.map((citem, index) => (            
            <td
            className={`text-${citem == 1? 'success fw-bolder text-center' : 'danger fw-bolder text-center'} `}
            key={'td' + index}
          >
            {citem == 1? <>&#x2713;</>  : <>&#x292B;</>}            
          </td>
          ))          
        }        
        <td>{citem.par}</td>                
        <td>{citem.grade}</td>                
      </tr>
    ))

    
      
  );
    
  })
}

        </tbody>
        </table>
        </div>
        </div>
        </div>
        
        <Modal size="lg" show={showInnerModal} onHide={handleCloseInnerModal}>
          <Modal.Header>
            <Modal.Title className='h5'>Question No: {qdata && qdata[0].qid}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          {qdata && 
    <div className='row'>
      <div className='col-md-6'>          
          <Bar          
        datasetIdKey='id'
        data={{
          labels: dlable,
          datasets: [
            {
              id: 1,
              label: '',
              backgroundColor: Color.bgColor, 
              borderColor: Color.boColor,
              data: davg
            }
          ]
        }}       
        plugins={[ChartDataLabels]}
        options={choptionsinner}        
      />      
      </div>
      <div className='col-md-6'>      
        <table className='table table-sm table-bordered table-hover table-striped mt-0'>
          <thead>
            <tr>
              <th>Option</th>
              <th>Count</th>
              <th>Avg %</th>
            </tr>
          </thead>
          <tbody>
          {qdata.map((item, index) => (
            <tr className={item.canswer == item.uanswer? 'table-success' : ''}>                                      
            <td>{item.uanswer}</td>
            <td>{item.count}</td>        
            <td>{item.tval}</td>        
            </tr>
          ))
            }
          </tbody>
        </table> 
        </div>        
        </div>     
      }
          </Modal.Body>          
        </Modal>
       
    </div>
  )
}

export default SectionReport