import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('section') // Enforces UNIQUE constraint on 'section'
export class Section {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true, type: 'varchar', length: 20 })
  section: string;

  @Column({ default: 1 })
  status: number;

  @Column({ default: 1 })
  visible: number;

  @CreateDateColumn({ type: 'datetime' })
  date: Date;
}
