import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('licenses')
export class License {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 100 })
  tenantid: string;

  @Column({ unique: true, type: 'varchar', length: 100 })
  license_Key: string;

  @Column({
    type: 'enum',
    enum: ['standard', 'professional', 'enterprise'],
  })
  license_type: 'standard' | 'professional' | 'enterprise';

  @Column({ type: 'date', nullable: true })
  valid_from: string;

  @Column({ type: 'date', nullable: true })
  valid_until: string;

  @Column({ type: 'tinyint', width: 1, default: () => '1' })
  is_active: boolean;

  @CreateDateColumn({ type: 'timestamp', nullable: true })
  created_at: Date;
}
