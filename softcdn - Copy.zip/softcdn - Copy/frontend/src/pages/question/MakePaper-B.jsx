import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import './MakePaper-B.css'
import apiClient from '../../api/apiService'

const QuestionPaperForm = () => {
  const [questions, setQuestions] = useState([])
  const [draggedIndex, setDraggedIndex] = useState(null)
  const [draggedmarks, setDraggedmarks] = useState(0)
  // const [insertId, setInsertId] = useState()
  // const [marksError, setMarksError] = useState('')

  const [classs, setClasss] = useState()
  const [subject, setSubject] = useState()

  const location = useLocation()
  const { state } = location;

  const navigator = useNavigate()

  useEffect(() => {
    if (!state) {
      navigator(-1)
    } else {
      const {selectedQuestion, class: paperClass, subject, questions} = state
      const questionIds =  selectedQuestion.split(',')
      setClasss(paperClass)
      setSubject(subject)
      setQuestions(questions.filter(e => questionIds.includes(e.id.toString())))
      }
  },[state])


  const handleDragStart = (e, index, marks) => {
    setDraggedIndex(index)
    e.dataTransfer.setData('index', index)
    e.dataTransfer.setData('marks', marks)
    e.dataTransfer.effectAllowed = 'move';
  }

  const [sections, setSections] = useState([
    {
      title: 'Section 1',
      questions: [],
    },
  ])

  // Function to add a new section
  // const addSection = () => {
  //   setSections([
  //     ...sections,
  //     {
  //       title: `Section ${sections.length + 1}`,
  //       questions: [],
  //     },
  //   ])
  // }

  const handleDragOver = (e, index) => {
    e.preventDefault()
    // Provide visual feedback by swapping positions during drag
    if (draggedIndex !== null && draggedIndex !== index) {
      const updatedQuestions = [...questions]
      const [draggedQuestion] = updatedQuestions.splice(draggedIndex, 1)
      updatedQuestions.splice(index, 0, draggedQuestion)
      setQuestions(updatedQuestions)
      setDraggedIndex(index)
    }
  }

  const handleDragEnd = () => {
    setDraggedIndex(null)
  }
  const Print = () => {
    //console.log('print');
    let printContents = document.getElementById('printablediv').innerHTML
    let originalContents = document.body.innerHTML
    document.body.innerHTML = printContents
    window.print()
    document.body.innerHTML = originalContents
  }

  const handlemarks = (e) => {
    const inputVal = e.target.value;
    setDraggedmarks(e.target.value);
    const ele = e.target;
    const dataId = ele.parentElement.parentElement.getAttribute('data-id');
    const printableDiv = document.getElementById('printablediv');
    printableDiv.querySelector('[data-id="'+dataId+'"]').querySelector('.questionMarks').textContent = inputVal;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = {};
    const examQuestion = [];
    const questionIds = [];
    let maxMarks = 0

    questions.map((e) => questionIds.push(e.id));
    
    const quesList = document.querySelectorAll('.question-list');
    quesList.forEach((e) => {
      const marks = e.querySelector('input').value;
      maxMarks += parseFloat(marks) 
    })
    
    data['name'] = `class-${classs} ${subject}`
    data['class'] = classs;
    data['subject'] = subject;
    data['maxMarks'] = maxMarks;
    data['examTime'] = '';
    console.log(data);
    
    await apiClient
      .post(`/questionPaper`, data)
      .then((res) => {
        // setInsertId(res.data.data)

        const quesList = document.querySelectorAll('.question-list')
        quesList.forEach((e, i) => {
          const quesData = {}
          quesData['paperId'] = res.data.data
          quesData['questionId'] = quesList[i].getAttribute('data-id')
          quesData['marks'] = quesList[i].querySelector('input').value
          quesData['sequence'] = i + 1
          quesData['paperFrom'] = 'bank'
          quesData['sectionName'] = 'Part A'
          quesData['sectionDesc'] = 'This section contain 4 questions 1 marks each'
          examQuestion.push(quesData)
        })
      })
      .catch((error) => {
        console.error(error)
      })

      console.log(examQuestion);

      await apiClient
        .post(`/examQuestions`, examQuestion)
        .then((res) => {
          console.log(res)
        })
        .catch((error) => {
          console.error(error)
        })

  }


  return (
    <div className="container-fluid mb-5">
      <h4 className="text-center pt-4">Question Paper Preview</h4>
      <div className="row">
        <div className="col-lg-6 col-md-12">
          <div className="p-3">
          <div className="d-flex justify-content-between mb-3">
            <h5 className='text-center'>Selected Questions</h5>
            <button type="button" className='btn btn-sm btn-primary'
             onClick={() => {
              navigator('/MakePaper-A' ,{state: {questions: state.questions, selectedQuestions : state.selectedQuestion}})
             }}>
              Add Questions</button>
          </div>
            {sections.map((section, sectionIndex) => (
              <div key={sectionIndex}>
                {/* <h4>{section.title}</h4> */}

                <ol className="list-group mb-3">
                  {questions.map((question, index) => (
                    <li
                      data-id={question.id}
                      className="question-list list-group-item d-flex justify-content-between align-items-center grab rounded-0 pt-3 pb-3"
                      key={question.id}
                      onDragStart={(e) => handleDragStart(e, index, draggedmarks)}
                      onDragOver={(e) => handleDragOver(e, index, draggedmarks)}
                      onDragEnd={handleDragEnd}
                      draggable
                    >
                      <div className="ms-2 w-100">
                        {index + 1}. {question.question}
                      </div>
                      <div className="align-self-center mx-3">
                        {/* {marksError && <div className="text-danger">{marksError}</div>} */}
                        <input
                          type="text"
                          className="form-control rounded-0 form-control-sm w-50 ms-auto text-center"
                          placeholder="Marks"
                          onChange={handlemarks}
                          required
                        />
                      </div>
                    </li>
                  ))}
                </ol>
                <button type='button' className='btn lq-sky-color btn-sm' onClick={handleSubmit}>Submit Questions</button>
              </div>
            ))}
            {/* {marksError && <div className="text-danger">{marksError}</div>} */}
          </div>
        </div>
        <div className="col-lg-6 col-md-12 p-5">
          <div className="border rounded-0 bg-white p-5" id="printablediv">
            <div className='row mb-3'>
              <div className='col-md-12 col-sm-12 text-center'>
                <h6 className='fw-bold'>Sample Question Paper (2024-25)</h6>
                <h6 className='fw-bold'>Class - X</h6>
                <h6 className='fw-bold'>Mathematics(201)</h6>
              </div>
            </div>
            <div className='row mb-3'>
              <div className='col-md-6 col-sm-12 text-start'>
                <h6 className='fw-bold'>
                  Duration:  70
                </h6>
              </div>
              <div className='col-md-6 col-sm-12 text-end'>
                <h6 className='fw-bold'>
                  Maximum Marks:  60
                </h6>
              </div>
            </div>
            <div className='row px-3'>
              <div className='col-md-12 col-sm-12 text-start'>
                <h6 className='fw-bold'>
                  General Instructions
                </h6>
                <ol className='fw-bold'>
                  <li>Write your Name on the top of the question paper cum answer sheet.</li>
                  <li>All questions are compulsory.</li>
                  <li>All questions are MCQ.</li>
                </ol>
              </div>
            </div>
           <div className='row m-3 mt-5'>
            <div className='col-sm-12'>
              <h4 className='fw-bold text-center'>
                    Section
              </h4>
            </div>
           </div>
            {questions.map((question, index) => (
              <div key={index} className="questionContainer" data-id={question.id}>
                <div className="d-flex">
                  <p className='question'>
                    {index + 1}. {question.question}
                  </p>
                  <span className='questionMarks ms-auto'></span>
                </div>
              </div>
            ))}
          </div>
          <button className="btn lq-sky-color btn-sm m-3" type="button" onClick={Print}>
            Print
          </button>
        </div>
      </div>
    </div>
  )
}

export default QuestionPaperForm
