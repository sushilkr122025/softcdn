import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';
@Entity({ name: 'questionmarkscheme' }) // Question Marking Scheme History Entity
export class QuestionsMarkingScheme {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: 'int', nullable: true })
  qId!: number;

  @Column({ type: 'longtext', nullable: true })
  expectedFromat!: string;

  @Column({ type: 'json', nullable: true })
  markingScheme!: object | null;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType!: string;

  @CreateDateColumn({ type: 'timestamp' })
  createdate!: Date;
}
