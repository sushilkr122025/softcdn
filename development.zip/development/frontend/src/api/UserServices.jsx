
import apiClient from './apiService'

class UserServices {
  registerUser = async (data) => {
    try {
      const response = await apiClient.post('/user/adduser', data)
      return response.data
    } catch (error) {
      console.error('Error registering user:', error)
      throw error
    }
  }

  updateUser = async (data) => {
    try {
      const response = await apiClient.post('/user/updateuser', data)
      return response.data
    } catch (error) {
      console.error('Error registering user:', error)
      throw error
    }
  }
  getSystemRoles = async (data) => {
    try {      
      const response = await apiClient.get('store/labels', data)     
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getSystemPermissions = async (data) => {
    try {
      const response = await apiClient.get('store/labels', data)
      return response.data
    } catch (error) {
      console.log(error)
    }
  }

  getUser = async (data) => {
    try {
      const response = await apiClient.get(`/user/details/`,  data )            
      return response.data
    } catch (error) {
      console.error('Error fetching user:', error)
      throw error
    }
  }

  getUserRule = async (data) => {
    try {
      const response = await apiClient.get(`/user/rule/`, data)            
      return response.data
    } catch (error) {
      console.error('Error fetching user:', error)
      throw error
    }
  }
  
  allUser = async () => {
    try {
      const response = await apiClient.get(`/user/all`)
      return response.data
    } catch (error) {
      console.error('Error fetching user:', error)
      throw error
    }
  }

  setUserPermissions = async (permissions) => {
    try {
      const response = await apiClient.post(`/user/addPermissions/`, permissions);
      return response.data;
    } catch (error) {
      console.error('Error saving user permissions:', error);
      throw error;
    }
  }; 

  getUserPermissions = async (userId) => {
    try {
      const response = await apiClient.get(`/user/userPermissions/${userId}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      throw error;
    }
  };

  getTeacherBySubjectClass = async (data) => {
    try {
      const response = await apiClient.get('/user/findTeacher/', data);
      return response.data;
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      throw error;
    }
  };

  setRule = async (data) => {
    try {
      const response = await apiClient.post('/user/createRule/', data);
      return {
        status: response.status,
        data: response.data
      }
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      throw error;
    }
  };
}

export default new UserServices()