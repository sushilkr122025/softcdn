import * as winston from 'winston';
import configuration from './configuration';

const config = configuration();
const customFormat = winston.format.printf(({ level, message, timestamp }) => {
  if (message === 'Starting Nest application...') {
    return `[${timestamp}] ${level}: ${config.message.startapp}`;
  }
  if (message === 'Nest application successfully started') {
    return `[${timestamp}] ${level}: ${config.message.appstarted(
      config.app.port.toString()
    )}`;
  }
  return `[${timestamp}] ${level}: ${message}`;
});

export const winstonLoggerOptions: winston.LoggerOptions = {
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.colorize({ all: true }),
        winston.format.errors({ stack: true }),
        winston.format.simple(),
        customFormat
      ),
    }),
    new winston.transports.File({
      filename: 'logs/info.log',
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format((info) => {
          const msg = typeof info.message === 'string' ? info.message : '';
          if (msg.startsWith('Mapped {')) return false; // skip this log
          if (
            msg.includes('dependencies initialized') || // Modules
            /^\w+Controller\s+{/.test(msg) // skip this log
          ) {
            return false;
          }

          return info;
        })(),
        customFormat
      ),
    }),
    new winston.transports.File({
      filename: 'logs/warn.log',
      level: 'warn',
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        customFormat
      ),
    }),
    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error',
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        customFormat
      ),
    }),
  ],
};