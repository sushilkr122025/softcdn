import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    const activate = super.canActivate(context);
    if (activate instanceof Observable) {
      return activate.pipe(
        tap((result) => {
          // console.log('JwtAuthGuard passed via Observable:', result);
        })
      );
    }

    if (activate instanceof Promise) {
      return activate.then((result) => {
        // console.log('wtAuthGuard passed via Promise:', result);
        return result;
      });
    }

    // console.log('✅ JwtAuthGuard passed directly:', activate);
    return activate;
  }

  handleRequest(err, user, info) {
    // console.log('JwtAuthGuard > err:', err);
    // console.log('JwtAuthGuard > user:', user);
    // console.log('JwtAuthGuard > info:', info);
    if (err || !user) {
      throw err || new UnauthorizedException('User not authenticated');
    }
    return user;
  }
}
