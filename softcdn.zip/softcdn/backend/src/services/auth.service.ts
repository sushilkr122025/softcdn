import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Login } from '../entities/login.entity';
import { LoginDto } from 'src/dto/login.dto';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { LoginActivity } from 'src/entities/login.activity';
import { UserAgentService } from './user-agent.service';
interface Log {
  loginId: string;
  tenantId: string;
  userAgent: string;
  logType: string;
  logDetail: string;
}
@Injectable()
export class AuthService {
  private readonly keybrcyt: string;
  constructor(
    @InjectRepository(Login)
    private loginRepository: Repository<Login>,
    @InjectRepository(LoginActivity)
    private logsRepository: Repository<LoginActivity>,
    private readonly userAgentService: UserAgentService,
    private readonly configuration: ConfigService,
    private jwtService: JwtService
  ) {
    this.keybrcyt = this.configuration.get<string>('keybcrypt') || 'education';
  }

  async findAll(): Promise<Login[]> {
    return this.loginRepository.find();
  }

  findByEmail(email: string): Promise<Login | null> {
    return this.loginRepository.findOne({ where: { email } });
  }

  async findById(id: number, tenantid: string): Promise<Login | null> {
    const user = await this.loginRepository.findOne({
      where: { id, tenantid },
    });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }
  //partial also use for create by like create(user: Partial<User>): Promise<User>

  async createUser(loginDto: LoginDto): Promise<Login> {
    const user = new Login();
    Object.assign(user, loginDto);
    user.password = user.password + this.keybrcyt;
    await user.hashPassword();
    return this.loginRepository.save(user);
  }

  async update(id: number, login: Login): Promise<Login | null> {
    await this.loginRepository.update(id, login);
    return this.loginRepository.findOne({ where: { id } });
  }

  async validateUser(
    email: string,
    plainPassword: string,
    tenantid: string,
    userAgent: string
  ): Promise<{
    access_token: string;
    user: { id: number; name: string; role: string };
  }> {
    const userAgentInfo = this.userAgentService.parse(userAgent);
    const user = await this.loginRepository.findOne({
      where: { email, tenantid },
    });
    if (!user) {
      const lookupData: Log = {
        loginId: email,
        tenantId: tenantid,
        userAgent: JSON.stringify(userAgentInfo),
        logType: 'Failed',
        logDetail: 'Invalid credentials',
      };
      const log = this.logsRepository.create(lookupData);
      await this.logsRepository.save(log);
      throw new NotFoundException('Invalid credentials');
    }

    const isMatch = await user.comparePassword(plainPassword + this.keybrcyt);
    if (!isMatch) {
      const lookupData: Log = {
        loginId: email,
        tenantId: tenantid,
        userAgent: JSON.stringify(userAgentInfo),
        logType: 'Failed',
        logDetail: 'Invalid credentials',
      };
      const log = this.logsRepository.create(lookupData);
      await this.logsRepository.save(log);
      throw new UnauthorizedException('Invalid credentials');
    }
    const lookupData: Log = {
      loginId: user.id.toString(),
      tenantId: tenantid,
      userAgent: JSON.stringify(userAgentInfo),
      logType: 'Success',
      logDetail: 'Login',
    };
    const log = this.logsRepository.create(lookupData);
    await this.logsRepository.save(log);
    user.updatedDate = new Date();
    await this.loginRepository.save(user);
    const payload = { id: user.id, name: user.name, role: user.role };
    const access_token = this.jwtService.sign(payload);
    return {
      access_token,
      user: { id: user.id, name: user.name, role: user.role },
    };
  }
}
