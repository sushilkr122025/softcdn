import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity({ name: 'questions' })
export class Questions {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: '50', default: null })
  customId: string;

  @Column({ type: 'int' })
  tId: number; // Teacher ID

  @Column({ type: 'int' })
  subject: number;

  @Column({ type: 'int' })
  class: number;

  @Column({ type: 'int', default: null })
  subDomain: number;

  @Column({ type: 'text' })
  difficulty: string;

  @Column({ type: 'int', default: null })
  cg: number;

  @Column({ type: 'text' })
  competency: string;

  @Column({ type: 'varchar', length: '100' })
  quesType: string;

  @Column({ type: 'varchar', length: '500' })
  question: string;

  @Column({ type: 'varchar', length: '500' })
  correctAns: string;

  @Column({ type: 'varchar', length: '100' })
  opt1: string;

  @Column({ type: 'varchar', length: '100' })
  opt2: string;

  @Column({ type: 'varchar', length: '100' })
  opt3: string;

  @Column({ type: 'varchar', length: '100' })
  opt4: string;

  @Column({ type: 'varchar', length: '100', default: null })
  opt1img: string;

  @Column({ type: 'varchar', length: '100', default: null })
  opt2img: string;

  @Column({ type: 'varchar', length: '100', default: null })
  opt3img: string;

  @Column({ type: 'varchar', length: '100', default: null })
  opt4img: string;

  @Column({ type: 'json', default: null })
  canvas: string;

  @Column({ type: 'json', default: null })
  image: string;

  @Column({ type: 'varchar', length: '20', default: 'UNAPPROVED' })
  status: string;

  @Column({ type: 'varchar', length: '50' })
  approverId: string;

  @Column({ type: 'varchar', length: '10' })
  createdBy: string;

  @CreateDateColumn({ type: 'timestamp' })
  time: Date;

  @Column({ type: 'varchar', length: '50' })
  tenantid: string;

  @Column({ type: 'char', length: '5', default: 'I' })
  dmlType: string;
}
