import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, } from '@dnd-kit/core';
import { SortableContext, useSortable, verticalListSortingStrategy, } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { FaArrowsAlt, FaGripHorizontal, FaGripVertical, FaPlus, FaMinus, FaList, FaPen } from "react-icons/fa";
import { AiOutlineColumnWidth, AiOutlineColumnHeight } from "react-icons/ai";
import { useLocation, useNavigate } from 'react-router-dom';
import { MdDelete } from "react-icons/md";
import ShowMessage from '../../components/ShowMessage';
import { TfiLayoutColumn2Alt } from "react-icons/tfi";
import QuestionServices from "../../api/QuestionServices";
import PreviewContent from './PreviewContent';
import CustomDropdown from '../../components/layout/CustomDropdown';

function numberToRoman(num) {
    if (num <= 0) return "";
    const romans = [["M", 1000], ["CM", 900], ["D", 500], ["CD", 400], ["C", 100], ["XC", 90], ["L", 50], ["XL", 40], ["X", 10], ["IX", 9], ["V", 5], ["IV", 4], ["I", 1]];
    let res = "";
    for (const [r, v] of romans) {
        while (num >= v) { res += r; num -= v; }
    }
    return res;
}

const LETTERS = Array.from({ length: 5 }, (_, i) => String.fromCharCode(65 + i));
const ROMANS = Array.from({ length: 5 }, (_, i) => numberToRoman(i + 1));

const Toolbar = ({ onAction, optionLayout, questionopt, fontSize, selectedImageSize, optionIdType, setOptionIdType, onDelete, sectionsCount, currentSection, currentConnector, questiontype, labelType: propLabelType, labelValue: propLabelValue }) => {
    const QuestionTypeText = [{ multipleChoice: "Multiple Choice" }, { trueFalse: "True/False" }, { oneWord: "One Word" }, { CR: "Written Response" }, { fillups: "Fill in the Blanks" }, { match: "Match the Following" }]
    const renderSectionLabel = (sec) => {
        if (!sec && sec !== 0) return 'Section';
        if (typeof sec === 'object') {
            const labelSuffix = String(sec.id).includes('-') ? String(sec.id).split('-').pop() : sec.section ?? '';
            return `Section - ${labelSuffix}`;
        }
        try {
            const s = String(sec);
            if (s) return `Section - ${s.split('-').pop()}`;
            return `Section - ${s}`;
        } catch {
            return 'Section';
        }
    };

    const connectorLabel = (val) => {
        if (!val) return 'Connector';
        return val;
    };
    const [labelType, setLabelType] = useState(propLabelType ?? "none");
    const [labelValue, setLabelValue] = useState(propLabelValue ?? "");

    const handleApply = () => {
        let normalized = labelValue;
        if (labelType === "alphaLower" || labelType === "romanLower") {
            normalized = String(labelValue || "").toLowerCase();
        } else if (labelType === "number") {
            normalized = String(labelValue || "");
        } else {
            normalized = String(labelValue || "");
        }
        const meta = { type: labelType, value: normalized };
        onAction && onAction("applyLabel", meta);
    };

    return (
        <div className='position-relative toolcontainer'>
            <div className="d-flex justify-content-between align-items-center mb-3 border-bottom border-primary bg-opacity-10">
                <div className="d-flex gap-2">
                    <div className="btn-group my-2" role="group">
                        <button type="button" className="btn btn-sm btn-light border border-secondary" onClick={() => onAction("increaseText")}><FaPlus /></button>
                        <div className="btn-group" role="group">
                            <select value={fontSize} onChange={(e) => onAction("setFontSize", parseInt(e.target.value))} className="form-select brder border-dark rounded-0">
                                {[10, 12, 14, 16, 18, 20, 22].map((size) => (
                                    <option key={size} value={size}> {size}</option>
                                ))}
                            </select>
                        </div>
                        <button className="btn btn-sm btn-light border border-secondary" onClick={() => onAction("decreaseText")}><FaMinus /></button>
                    </div>
                    {selectedImageSize.width > 0 &&
                        <div className="btn-group my-2 " role="group">
                            <input type="number" value={selectedImageSize?.width || ""} onChange={(e) => onAction("setImageWidth", parseInt(e.target.value) || 0)} className="btn btn-outline-secondary input-container" />
                            <button type="button" className="btn btn-light border border-secondary pt-1"> <AiOutlineColumnWidth size={22} /></button>
                            <button type="button" className="btn btn-light border border-secondary pt-1"><AiOutlineColumnHeight size={22} /></button>
                            <input type="number" value={selectedImageSize?.height || ""} onChange={(e) => onAction("setImageHeight", parseInt(e.target.value) || 0)} className="btn btn-outline-secondary input-container" />
                        </div>}
                    {questionopt && (<>
                        <div className="btn-group my-2">
                            <button className="btn btn-light border border-secondary btn-sm dropdown-toggle d-flex align-items-center" type="button" data-bs-toggle="dropdown"> <FaList size={25} className="pe-2" /> {optionIdType || " "}</button>
                            <ul className="dropdown-menu text-center">
                                {["A", "a", "1", "i", "I"].map((opt) => (
                                    <li key={opt}>  <button type="button" className={`dropdown-item border-bottom ${optionIdType === opt ? "active" : ""}`} onClick={() => setOptionIdType(opt)}
                                    >{opt}</button></li>
                                ))}
                            </ul>
                        </div>
                        <div className="btn-group my-2">
                            <button className="btn btn-light border border-secondary btn-sm p-2" onClick={() => onAction("toggleLayout")}>
                                {optionLayout === "vertical" && <FaGripVertical />}
                                {optionLayout === "horizontal" && <FaGripHorizontal />}
                                {optionLayout === "two-column" && <TfiLayoutColumn2Alt />}
                            </button>
                        </div>
                    </>)}
                    {sectionsCount.length > 0 &&
                        <div className="btn-group my-2">
                            <button className={`${renderSectionLabel(currentSection) !== "Section" ? "btn-outline-success" : "btn-light"} btn border border-secondary btn-sm dropdown-toggle`} type="button" data-bs-toggle="dropdown">
                                {renderSectionLabel(currentSection)}
                            </button>
                            <ul className="dropdown-menu text-center pointer">
                                {Array.isArray(sectionsCount) ? (
                                    sectionsCount.map((sec) => {
                                        const label = `Section - ${sec.id}`;
                                        return (
                                            <li key={sec.id} className="dropdown-item" onClick={() => onAction("addSection", sec)}>{label}</li>
                                        );
                                    })
                                ) : (
                                    <li className="dropdown-item">No sections</li>
                                )}
                            </ul>
                        </div>}
                    <div className="btn-group my-2">
                        <button className="btn btn-light border border-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">{connectorLabel(currentConnector)}</button>
                        <ul className="dropdown-menu text-center pointer">
                            <li className="dropdown-item" onClick={() => onAction("setConnector", null)}>None</li>
                            <li className="dropdown-item" onClick={() => onAction("setConnector", "OR")}>OR</li>
                            <li className="dropdown-item" onClick={() => onAction("setConnector", "AND")}>AND</li>
                        </ul>
                    </div>
                    <div className="btn-group my-2" role="group">
                        <div className="btn-group" role="group">
                            <button className="btn btn-light border border-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                {labelType === "none" && "Default (Ques.)"}
                                {labelType === "alphaLower" && "Lower Alpha (a)"}
                                {labelType === "romanLower" && "Roman (i)"}
                                {labelType === "number" && "Numeric (1)"}
                            </button>
                            <ul className="dropdown-menu text-center pointer">
                                <li className="dropdown-item" onClick={() => {
                                    setLabelType("none");
                                    setLabelValue("");
                                }}>
                                    None
                                </li>
                                <li className="dropdown-item" onClick={() => {
                                    setLabelType("alphaLower");
                                    setLabelValue("a");
                                }}>
                                    Lower Alpha (a)
                                </li>
                                <li className="dropdown-item"
                                    onClick={() => {
                                        setLabelType("romanLower");
                                        setLabelValue((ROMANS[0] || "I").toLowerCase());
                                    }}>
                                    Roman (i)
                                </li>
                                <li className="dropdown-item"
                                    onClick={() => {
                                        setLabelType("number");
                                        setLabelValue("1");
                                    }}>
                                    Numeric (1)
                                </li>
                            </ul>
                        </div>
                        {labelType === "alphaLower" && (
                            <div className='btn-group' role="group">
                                <button className="btn btn-light border border-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown">{labelValue}</button>
                                <ul className="dropdown-menu">
                                    {LETTERS.map((l) => (
                                        <li key={l} className="dropdown-item" onClick={() => setLabelValue(l.toLowerCase())}>{l.toLowerCase()}</li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        {labelType === "number" && (
                            <div className='btn-group' role="group">
                                <input type="number" className="form-control form-control-sm me-2" style={{ width: 110 }} value={labelValue} onChange={(e) => setLabelValue(e.target.value)} />
                            </div>
                        )}
                        {labelType === "romanLower" && (
                            <div className="btn-group" role="group">
                                <button className="btn btn-light border border-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown">{labelValue || "Select"}</button>
                                <ul className="dropdown-menu">
                                    {ROMANS.map((r) => {
                                        const val = r.toLowerCase();
                                        return (
                                            <li key={r} className="dropdown-item" onClick={() => setLabelValue(val)}>{val}</li>
                                        );
                                    })}
                                </ul>
                            </div>
                        )}
                        <button className="btn btn-sm btn-primary" type="button" onClick={handleApply}>Apply</button>
                    </div>
                    <div className="btn-group my-2">
                        <button type="button" className="btn btn-sm btn-light border border-secondary"
                            onClick={() => {
                                if (typeof onDelete === "function") {
                                    if (window.confirm("Remove this question?")) {
                                        onDelete();
                                    }
                                }
                            }}>
                            <MdDelete size={18} />
                        </button>
                    </div>
                </div>
                <div className='text-end fw-semibold text-muted'>Question Type - {QuestionTypeText.map((e) => e[questiontype])}</div>
            </div>
        </div>
    );
};

export function SortableQuestion({ question, index, displayIndex, optionIdType, setOptionIdType, ui = {}, updateUi = () => { }, updateQuestion = () => { }, onDelete, onAddConnector, onAddSection, sectionsCount, selectedQuestionIds = [], toggleSelect = () => { }, showContext = true }) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: question.id });
    const baseStyle = { transform: CSS.Transform.toString(transform), transition, padding: "10px", };
    const selected = selectedQuestionIds.includes(question.id);
    const style = {
        ...baseStyle,
        border: selected ? "2px solid #0d6efd" : baseStyle.border,
        background: selected ? "#e9f2ff" : undefined,
    };
    const [fontSize, setFontSize] = useState(ui.fontSize ?? 16);
    const [align] = useState(ui.align ?? "left");
    const [imageSizes, setImageSizes] = useState(ui.imageSizes ?? {});
    const [selectedImageKeys, setSelectedImageKeys] = useState(new Set(ui.selectedImageKeys ?? []));
    const [optionLayout, setOptionLayout] = useState(ui.optionLayout ?? "vertical");

    const handleToolbarAction = (action, value) => {
        const firstSelected = [...selectedImageKeys][0];
        if (firstSelected) {
            if (action === "setImageWidth" || action === "setImageHeight") {
                setImageSizes((prev) => {
                    const current = prev[firstSelected] || { width: 120, height: 50 };
                    const next = {
                        ...prev,
                        [firstSelected]: {
                            ...current,
                            width: action === "setImageWidth" ? (value || 50) : current.width,
                            height: action === "setImageHeight" ? (value || 50) : current.height
                        }
                    };
                    updateUi({ imageSizes: next, selectedImageKeys: [firstSelected] });
                    return next;
                });
                return;
            }
        }
        switch (action) {
            case "increaseText":
                setFontSize((f) => {
                    const next = Math.min(22, f + 2);
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "decreaseText":
                setFontSize((f) => {
                    const next = Math.max(10, f - 2);
                    updateUi({ fontSize: next });
                    return next;
                });
                break;
            case "setFontSize":
                setFontSize(value);
                updateUi({ fontSize: value });
                break;
            case "toggleLayout":
                setOptionLayout((prev) => {
                    const next = prev === "vertical" ? "horizontal" : prev === "horizontal" ? "two-column" : "vertical";
                    updateUi({ optionLayout: next });
                    return next;
                });
                break;
            case "applyLabel": {
                const meta = value || { type: "none", value: "" };
                const patch = { quesLabelMeta: meta, __skipContextLabel: true };
                if (meta.value !== undefined && meta.value !== null && String(meta.value).trim() !== "") {
                    patch.queslabel = String(meta.value).trim();
                }
                updateQuestion && updateQuestion(question.id, patch);
                break;
            }
            case "setConnector":
                if (typeof onAddConnector === "function") {
                    onAddConnector(question.id, value);
                }
                break;
            case "addSection":
                if (typeof onAddSection === "function") {
                    onAddSection(question.id, value);
                }
                break;
            default:
                break;
        }
    };

    function removeInlineStyles(html) {
        if (!html) return "";
        html = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        html = html.replace(/<p[^>]*>(?:\s|&nbsp;|(?:<br\s*\/?>\s*))*<\/p>/gi, "");
        return html;
    }

    function parseHtmlWithImages(html, keyPrefix) {
        if (!html) return null;
        const cleanHtml = html.replace(/\s*style\s*=\s*(['"])[\s\S]*?\1/gi, "");
        const parts = [];
        const imgRegex = /<img[^>]+src=['"]([^'"]+)['"][^>]*>/gi;
        let lastIndex = 0;
        let match;
        while ((match = imgRegex.exec(cleanHtml)) !== null) {
            if (match.index > lastIndex) {
                const chunk = cleanHtml.slice(lastIndex, match.index);
                parts.push(
                    <span key={`${keyPrefix}-chunk-${lastIndex}`} dangerouslySetInnerHTML={{ __html: chunk }} />
                );
            }
            const src = match[1];
            const imgKey = `${keyPrefix}-img-${match.index}`;
            parts.push(
                <img key={imgKey} src={src} alt=""
                    onClick={(e) => {
                        e.stopPropagation();
                        setSelectedImageKeys(new Set([imgKey]));
                        setImageSizes((prev) => {
                            if (prev[imgKey]) {
                                updateUi({ selectedImageKeys: [imgKey] });
                                return prev;
                            }
                            const next = {
                                ...prev,
                                [imgKey]: { width: 120, height: 50 }
                            };
                            updateUi({ imageSizes: next, selectedImageKeys: [imgKey] });
                            return next;
                        });
                    }}
                    onPointerDown={(e) => e.stopPropagation()}
                    style={{ width: imageSizes[imgKey]?.width || 120, height: imageSizes[imgKey]?.height || 50, border: selectedImageKeys.has(imgKey) ? "2px solid blue" : "none", cursor: "pointer", margin: "5px 0" }}
                />
            );
            lastIndex = imgRegex.lastIndex;
        }
        if (lastIndex < cleanHtml.length) {
            const chunk = cleanHtml.slice(lastIndex);
            parts.push(
                <span key={`${keyPrefix}-chunk-${lastIndex}`} dangerouslySetInnerHTML={{ __html: chunk }} />
            );
        }
        return parts;
    }

    const effectiveOptionIdType = ui?.optionIdType || optionIdType;

    const getOptionLabel = (i) => {
        switch (effectiveOptionIdType) {
            case "A":
                return String.fromCharCode(65 + i);
            case "a":
                return String.fromCharCode(97 + i);
            case "1":
                return i + 1;
            case "i":
                return ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"][i] || i + 1;
            case "I":
                return ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"][i] || i + 1;
            default:
                return String.fromCharCode(65 + i);
        }
    };

    useEffect(() => {
        function handleClickOutside(e) {
            if (selectedImageKeys.size > 0 && !e.target.closest("img") && !e.target.closest(".toolcontainer")) {
                setSelectedImageKeys(new Set());
                updateUi({ selectedImageKeys: [] });
            }
        }
        document.addEventListener("click", handleClickOutside);
        return () => document.removeEventListener("click", handleClickOutside);
    }, [selectedImageKeys, updateUi]);

    const mainImgKey = `q-${question.id}-main`;

    const optionsContainerStyle = {
        fontSize: `${fontSize}px`, textAlign: align, display: "flex", flexDirection: optionLayout === "vertical" ? "column" : "row", flexWrap: optionLayout === "two-column" ? "wrap" : "nowrap", gap: optionLayout === "horizontal" ? "40px" : "10px", alignItems: optionLayout === "vertical" ? "flex-start" : "center",
    };

    const rawOptionsOrdered = [{ key: "optA", value: question.optA ?? "" }, { key: "optB", value: question.optB ?? "" }, { key: "optC", value: question.optC ?? "" }, { key: "optD", value: question.optD ?? "" },
    ].filter(o => o.value && String(o.value).trim() !== "");

    const questionHtmlForUI = question.question ?? "";
    const labelMeta = (question && question.quesLabelMeta) || (ui && ui.quesLabelMeta) || { type: "none", value: "" };

    const computePreviewLabel = (meta, seq) => {
        if (!meta || meta.type === "none") {
            return `${seq}`;
        }
        switch (meta.type) {
            case "alphaLower":
                return meta.value ?? "a";
            case "number":
                return meta.value ?? `${seq}`;
            case "romanLower":
                return (meta.value ?? numberToRoman(seq)).toLowerCase();
            default:
                return `${seq}`;
        }
    };
    const labelPreview = (question && question.queslabel) ? question.queslabel : computePreviewLabel(labelMeta, displayIndex);

    return (
        <div ref={setNodeRef} style={style} className="mb-3 border border-primary px-2 rounded">
            <Toolbar
                onAction={handleToolbarAction}
                optionLayout={optionLayout}
                fontSize={fontSize}
                currentMarks={question.marks}
                optionIdType={effectiveOptionIdType}
                setOptionIdType={(val) => {
                    setOptionIdType(val);
                    updateUi({ optionIdType: val });
                }}
                selectedImageSize={
                    [...selectedImageKeys].length > 0 ? imageSizes[[...selectedImageKeys][0]] : { width: "", height: "" }
                }
                onDelete={() => onDelete?.(index)}
                sectionsCount={sectionsCount}
                currentSection={question.section}
                currentConnector={question.connector ?? null}
                questiontype={question.quesType}
                questionopt={question.optA}
                labelType={labelMeta.type}
                labelValue={labelMeta.value}
            />
            <div style={{ fontSize: `${fontSize}px`, textAlign: align }}>
                <div className='d-flex justify-content-between'>
                    <div className="question-html pointer d-flex flex-grow-1"
                        onClick={(e) => {
                            toggleSelect(question.id);
                            e.stopPropagation();
                        }}>
                        <span className="me-2" style={{ cursor: "grab" }} {...attributes} {...listeners}><FaArrowsAlt /></span>
                        {question.isSub ? (
                            <div className="question-html d-flex flex-column  questionstylecustom ps-4">
                                {parseHtmlWithImages(removeInlineStyles(questionHtmlForUI), `q-${question.id}-text`)}
                            </div>
                        ) : (
                            <div className="flex-grow-1">
                                {showContext && question.context && !question.isSub && (
                                    <div className="question-html d-flex flex-column questionstylecustom mb-2">
                                        <strong className="me-2 text-nowrap">{`Q${question.contextLabel ?? question.queslabel ?? ""}`}</strong>
                                        <div>{parseHtmlWithImages(removeInlineStyles(question.context || ""))}</div>
                                    </div>
                                )}
                                <div className="question-html questionstylecustom">
                                    <div className='d-flex align-items-baseline'>
                                        <strong className="me-1 text-nowrap">
                                            {question.context && !question.isSub ? labelPreview : !isNaN(labelPreview) ? `Q${labelPreview}` : labelPreview}
                                        </strong>
                                        <div className='d-flex justify-content-between flex-grow-1'>
                                            <div>{parseHtmlWithImages(removeInlineStyles(questionHtmlForUI), `q-${question.id}-text`)}</div>
                                            {question.marks && (
                                                <div className='ms-3'>({question.marks})</div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                    {/* {question.marks && (
                        <div className='ms-3'>({question.marks})</div>
                    )} */}
                </div>

                {question.image && (
                    <img src={question.image} alt="question"
                        onClick={(e) => {
                            e.stopPropagation();
                            const key = mainImgKey;
                            setSelectedImageKeys(new Set([key]));
                            setImageSizes(prev => {
                                if (prev[key]) {
                                    updateUi({ selectedImageKeys: [key] });
                                    return prev;
                                }
                                const next = { ...prev, [key]: { width: 120, height: 50 } };
                                updateUi({ imageSizes: next, selectedImageKeys: [key] });
                                return next;
                            });
                        }}
                        onPointerDown={(e) => e.stopPropagation()}
                        style={{ width: imageSizes[mainImgKey]?.width || 120, height: imageSizes[mainImgKey]?.height || 50, border: selectedImageKeys.has(mainImgKey) ? "2px solid blue" : "none", cursor: "pointer", margin: "5px 0" }}
                    />
                )}
            </div>

            <div className="mt-2" style={optionsContainerStyle}>
                {rawOptionsOrdered.map((optObj, i) => {
                    const opt = optObj.value;
                    const optionItemStyle = { display: "flex", alignItems: "center", width: optionLayout === "two-column" ? "45%" : "auto", minWidth: optionLayout === "two-column" ? "200px" : "auto", marginBottom: optionLayout === "vertical" ? "8px" : "0", };
                    return (
                        <div key={optObj.key} style={optionItemStyle}>
                            <span className="fw-bold me-2">{getOptionLabel(i)}.</span>
                            <div>{parseHtmlWithImages(removeInlineStyles(opt), `q-${question.id}-${optObj.key}`)}</div>
                        </div>
                    );
                })}
            </div>
            {question.connector && (
                <div className="text-center fw-bold connector-row py-2 my-2">{question.connector}</div>
            )}
        </div>
    );
}

const QuestionPreview = () => {
    const [active, setActive] = useState(true);
    const location = useLocation();
    const navigate = useNavigate();
    const { selectedQuestion = [], filter = {}, paperinfo = {} } = location.state || {};
    const [questions, setQuestions] = useState(selectedQuestion || []);
    const sensors = useSensors(useSensor(PointerSensor));
    const [showToast, setShowToast] = useState(false);
    const [showSaveModal, setShowSaveModal] = useState(false);
    const [saveModalConfig, setSaveModalConfig] = useState({ title: "", message: "", btnClose: false, btnConfirm: false, confirmText: "OK", closeText: "Close", onConfirm: null, onClose: null });
    const [totalMarks, setTotalMarks] = useState(0);
    const [selectedQuestionIds, setSelectedQuestionIds] = useState([]);
    const [connectorError, setConnectorError] = useState(null);

    const normalizeSequence = (list) =>
        list.map((q, index) => ({
            ...q, sequence: index + 1,
        }));

    const computeLabels = (list) => {
        if (!Array.isArray(list)) return list;
        const isNumeric = (s) => /^\d+$/.test(String(s || "").trim());
        const isAlpha = (s) => /^[a-z]+$/i.test(String(s || "").trim());
        const isRomanLike = (s) => /^[ivxlcdm]+$/i.test(String(s || "").trim());
        const alphaFor = (n) => {
            if (!Number.isFinite(n) || n <= 0) return "a";
            let out = "";
            let i = n - 1;
            do {
                out = String.fromCharCode(97 + (i % 26)) + out;
                i = Math.floor(i / 26) - 1;
            } while (i >= 0);
            return out;
        };
        const alphaToNumber = (s) => {
            if (!s) return 0;
            s = String(s).toLowerCase().trim();
            if (!/^[a-z]+$/.test(s)) return 0;
            let n = 0;
            for (let i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 96);
            return n;
        };
        let mainNumeric = 0;
        let alphaSeq = 0;
        let lastAssignedLabel = "";
        let currentContextId = null;
        let romanLocal = 0;

        return list.map((q) => {
            const copy = { ...q, ui: { ...(q.ui || {}) } };
            const skipContextLabel = !!q.__skipContextLabel;
            if (typeof copy.__skipContextLabel !== "undefined") delete copy.__skipContextLabel;
            const meta = copy.quesLabelMeta || (copy.ui && copy.ui.quesLabelMeta) || null;
            const isSub = !!copy.isSub;
            const explicit = (copy.queslabel !== undefined && copy.queslabel !== null && String(copy.queslabel).trim() !== "") ? String(copy.queslabel).trim() : null;
            const assignLabel = (label, { numericHint } = {}) => {
                copy.queslabel = label;
                lastAssignedLabel = label;
                if (numericHint && Number.isFinite(numericHint)) {
                    mainNumeric = Math.max(mainNumeric, Number(numericHint));
                }
            };
            if (explicit) {
                if (isNumeric(explicit) && !isSub) {
                    mainNumeric = Math.max(mainNumeric, Number(explicit));
                } else if (isAlpha(explicit)) {
                    alphaSeq = Math.max(alphaSeq, alphaToNumber(explicit.toLowerCase()));
                } else if (isRomanLike(explicit)) {
                    // don't change romanLocal/global here — explicit roman likely intentional
                }
                if (copy.context && !isSub && isNumeric(explicit)) {
                    currentContextId = copy.contextId;
                    romanLocal = 0;
                    if (!skipContextLabel) {
                        copy.contextLabel = explicit;
                    }
                }
                assignLabel(explicit);
                return copy;
            }

            if (meta && meta.type) {
                if (meta.type === "number") {
                    if (meta.value !== undefined && meta.value !== null && String(meta.value).trim() !== "") {
                        const v = String(meta.value).trim();
                        if (isNumeric(v) && !isSub) mainNumeric = Math.max(mainNumeric, Number(v));
                        assignLabel(v, { numericHint: isNumeric(v) ? Number(v) : undefined });
                    } else {
                        if (!isSub) mainNumeric++;
                        assignLabel(String(mainNumeric), { numericHint: mainNumeric });
                    }
                    currentContextId = copy.context && !isSub ? copy.contextId : currentContextId;
                    if (!copy.context || isSub) {
                        currentContextId = null;
                        romanLocal = 0;
                    }
                    return copy;
                }

                if (meta.type === "alphaLower") {
                    if (meta.value && String(meta.value).trim() !== "") {
                        const v = String(meta.value).trim().toLowerCase();
                        alphaSeq = Math.max(alphaSeq, alphaToNumber(v));
                        assignLabel(v);
                    } else {
                        alphaSeq++;
                        assignLabel(alphaFor(alphaSeq));
                    }
                    return copy;
                }

                if (meta.type === "romanLower") {
                    if (meta.value && String(meta.value).trim() !== "") {
                        assignLabel(String(meta.value).trim().toLowerCase());
                    } else {
                        if (copy.context && !isSub && copy.contextId === currentContextId) {
                            romanLocal++;
                            assignLabel(numberToRoman(romanLocal).toLowerCase());
                        } else {
                            // not inside a context group, create roman numbering from 1 for standalone roman meta
                            romanLocal = 1;
                            assignLabel(numberToRoman(romanLocal).toLowerCase());
                        }
                    }
                    return copy;
                }
            }
            if (copy.context && !isSub && copy.contextId !== currentContextId) {
                mainNumeric++;
                currentContextId = copy.contextId;
                copy.contextLabel = String(mainNumeric);
                romanLocal = 1;
                assignLabel(numberToRoman(romanLocal).toLowerCase(), { numericHint: mainNumeric });
                return copy;
            }
            if (copy.context && !isSub && copy.contextId === currentContextId) {
                romanLocal++;
                assignLabel(numberToRoman(romanLocal).toLowerCase());
                return copy;
            }
            if (!isSub) {
                mainNumeric++;
                currentContextId = null;
                romanLocal = 0;
                assignLabel(String(mainNumeric), { numericHint: mainNumeric });
                return copy;
            } else {
                const fallback = lastAssignedLabel || String(mainNumeric);
                assignLabel(fallback);
                return copy;
            }
        });
    };

    useEffect(() => {
        if (!selectedQuestion || selectedQuestion.length === 0) {
            setQuestions([]);
            return;
        }
        const incomingMap = new Map(selectedQuestion.map(q => [q.id, q]));
        const getPaper = async () => {
            try {
                const currentIds = selectedQuestion.map(q => q.id);
                const payload = { paperId: currentIds, reqType: "questions" };
                const response = await QuestionServices.GetQuestionPaper(payload);
                const merged = response.questions.map(fetched => {
                    const inc = incomingMap.get(fetched.id) || {};
                    const { ui: incomingUi = {}, ...incomingRest } = inc;
                    const defaultUi = { fontSize: 16, align: 'left', optionLayout: 'vertical', optionIdType: optionIdType ?? 'A', imageSizes: {}, selectedImageKeys: [], };
                    const mergedUi = { ...defaultUi, ...(incomingUi || {}) };
                    return { ...fetched, ...incomingRest, ui: mergedUi };
                });
                const hasSequence = merged.some(q => q.sequence !== undefined && q.sequence !== null);
                const sectionsArr = Array.isArray(generalDetails.sectionsData) ? generalDetails.sectionsData : [];
                const finalQuestions = hasSequence ? [...merged].sort((a, b) => Number(a.sequence || 0) - Number(b.sequence || 0)) : merged;
                const ordered = reorderBySections(finalQuestions, sectionsArr);
                const cleared = ordered.map(q => ({ ...q, queslabel: undefined }));
                setQuestions(computeLabels(normalizeSequence(cleared)));
            } catch (err) {
                console.error("Failed to fetch questions", err);
            }
        };
        getPaper();
    }, [selectedQuestion]);

    const getSectionNumberFromObj = (sec) => {
        if (!sec) return null;
        if (typeof sec === 'number') return sec;
        if (typeof sec === 'string') {
            const parts = String(sec).split('-');
            const last = parts[parts.length - 1];
            const num = Number(last);
            return Number.isFinite(num) ? num : null;
        }
        if (typeof sec === 'object') {
            const possible = sec.id ?? sec.section;
            if (typeof possible === 'number') return possible;
            if (typeof possible === 'string') {
                const parts = String(possible).split('-');
                const last = parts[parts.length - 1];
                const num = Number(last);
                return Number.isFinite(num) ? num : (sec.section ?? null);
            }
            return sec.section ?? null;
        }
        return null;
    };

    function findConnectorBlockRange(list, idx) {
        const n = list.length;
        if (idx < 0 || idx >= n) return [idx, idx];
        const isConnectorItem = (item) => !!(item && (item.connector));
        const item = list[idx];
        if (item.isSub) {
            let parentIdx = idx - 1;
            while (parentIdx >= 0 && list[parentIdx].isSub) parentIdx--;
            if (parentIdx >= 0) return [parentIdx, idx];
            return [idx, idx];
        }
        if (isConnectorItem(item)) {
            if (idx + 1 < n && list[idx + 1].isSub) return [idx, idx + 1];
            return [idx, idx];
        }
        return [idx, idx];
    }

    const toggleSelect = (id) => {
        setSelectedQuestionIds(prev => {
            if (prev.includes(id)) return prev.filter(x => x !== id);
            return [...prev, id];
        });
    };

    const handleDelete = (idOrIndex) => {
        setQuestions((prev) => {
            let next = prev;
            let removedItem = null;
            let removedIndex = -1;
            if (typeof idOrIndex === "number") {
                if (idOrIndex >= prev.length) return prev;
                removedItem = prev[idOrIndex];
                removedIndex = idOrIndex;
                next = prev.filter((_, idx) => idx !== idOrIndex);
            } else {
                removedIndex = prev.findIndex(q => q.id === idOrIndex);
                removedItem = prev.find(q => q.id === idOrIndex);
                next = prev.filter((q) => q.id !== idOrIndex);
            }

            if (removedItem?.isSub) {
                const possibleParentIdx = removedIndex - 1;
                if (possibleParentIdx >= 0) {
                    const possibleParent = next[possibleParentIdx];
                    if (possibleParent && (possibleParent.connector)) {
                        next[possibleParentIdx] = { ...possibleParent, connector: null };
                    }
                }
            }

            if (removedItem && (removedItem.connector)) {
                const nextRow = next[removedIndex];
                if (nextRow && nextRow.isSub) {
                    next[removedIndex] = { ...nextRow, isSub: false, subOf: null };
                }
            }
            const normalized = next;
            setSelectedQuestionIds(prevSel => prevSel.filter(sid => normalized.some(q => q.id === sid)));
            const cleared = normalized.map(q => ({ ...q, queslabel: undefined }));
            return computeLabels(normalizeSequence([...cleared]));
        });
    };

    const handleDragEnd = (event) => {
        const { active, over } = event;
        if (!over) return;
        if (active.id === over?.id) return;

        setQuestions((prev) => {
            const oldIndex = prev.findIndex((q) => q.id === active.id);
            const overIndex = prev.findIndex((q) => q.id === over?.id);
            if (oldIndex === -1 || overIndex === -1) return prev;

            const blocksToMove = [];
            const removeIndexSet = new Set();

            const addBlockRange = (s, e) => {
                s = Math.max(0, s);
                e = Math.min(prev.length - 1, e);
                for (let i = s; i <= e; i++) {
                    if (removeIndexSet.has(i)) return;
                }
                blocksToMove.push({ start: s, end: e, block: prev.slice(s, e + 1) });
                for (let i = s; i <= e; i++) removeIndexSet.add(i);
            };

            const computeMoveRangeForIndex = (idx) => {
                let [blockStart, blockEnd] = findConnectorBlockRange(prev, idx);
                if (blockStart > blockEnd) {
                    const t = blockStart; blockStart = blockEnd; blockEnd = t;
                }
                if (blockEnd > blockStart) {
                    return [blockStart, blockEnd];
                }
                return [idx, idx];
            };

            if (
                Array.isArray(selectedQuestionIds) &&
                selectedQuestionIds.length > 0 &&
                selectedQuestionIds.includes(active.id)
            ) {
                const selectedOrdered = selectedQuestionIds
                    .map((id) => ({ id, idx: prev.findIndex((q) => q.id === id) }))
                    .filter((x) => x.idx !== -1)
                    .sort((a, b) => a.idx - b.idx);

                for (const s of selectedOrdered) {
                    const [sStart, sEnd] = computeMoveRangeForIndex(s.idx);
                    addBlockRange(sStart, sEnd);
                }
            } else {
                const [moveStart, moveEnd] = computeMoveRangeForIndex(oldIndex);
                if (overIndex >= moveStart && overIndex <= moveEnd) return prev;
                addBlockRange(moveStart, moveEnd);
            }
            const getGroupKeyFor = (q) => {
                const ctx = (q && typeof q.context === "string") ? q.context.trim() : "";
                if (!ctx) return null; // empty context -> unconstrained
                return q.contextId !== undefined && q.contextId !== null ? `id:${q.contextId}` : `ctx:${ctx}`;
            };
            const movingNonEmptyKeys = new Set();
            for (const idx of Array.from(removeIndexSet)) {
                const key = getGroupKeyFor(prev[idx]);
                if (key !== null) movingNonEmptyKeys.add(key);
            }
            if (movingNonEmptyKeys.size > 1) {
                setConnectorError("Cannot move questions from multiple context groups together.");
                setShowToast(true);
                setTimeout(() => setShowToast(false), 4000);
                return prev;
            }
            const movingKey = movingNonEmptyKeys.size === 1 ? [...movingNonEmptyKeys][0] : null;
            const targetKey = getGroupKeyFor(prev[overIndex]); // may be null

            if (movingKey !== null) {
                if (targetKey !== movingKey) {
                    setConnectorError("Cannot move question to a different context group.");
                    setShowToast(true);
                    setTimeout(() => setShowToast(false), 4000);
                    return prev;
                }
            } else {
                // movers all have empty context -> allowed to move anywhere (no constraint)
                // no-op
            }

            if (removeIndexSet.has(overIndex)) return prev;

            const remaining = prev.filter((_, idx) => !removeIndexSet.has(idx));
            const remainingOriginalIndices = [];
            for (let i = 0; i < prev.length; i++) {
                if (!removeIndexSet.has(i)) remainingOriginalIndices.push(i);
            }

            const protectedBlocks = [];
            for (let i = 0; i < prev.length; i++) {
                const [s, e] = findConnectorBlockRange(prev, i);
                if (s === undefined || e === undefined) continue;
                const start = Math.min(s, e);
                const end = Math.max(s, e);
                if (end > start) {
                    if (!protectedBlocks.some(b => b.start === start && b.end === end)) {
                        protectedBlocks.push({ start, end });
                    }
                }
                i = end;
            }

            const overIndexInRemaining = remaining.findIndex((q) => q.id === over.id);
            let insertAt;
            const firstRemovedIdx =
                removeIndexSet.size > 0 ? Math.min(...Array.from(removeIndexSet)) : oldIndex;
            const isMovingUp = firstRemovedIdx > overIndex;

            if (overIndexInRemaining === -1) {
                insertAt = remaining.length;
            } else {
                insertAt = isMovingUp ? overIndexInRemaining : overIndexInRemaining + 1;
            }

            const isSplitProtectedBlock = (() => {
                if (remainingOriginalIndices.length === 0) return false;
                if (insertAt <= 0 || insertAt >= remainingOriginalIndices.length) return false;

                const leftOrig = remainingOriginalIndices[insertAt - 1];
                const rightOrig = remainingOriginalIndices[insertAt];

                for (const b of protectedBlocks) {
                    if (leftOrig >= b.start && leftOrig <= b.end && rightOrig >= b.start && rightOrig <= b.end) {
                        return true;
                    }
                }
                return false;
            })();

            if (isSplitProtectedBlock) {
                return prev;
            }

            const final = [...remaining];
            for (let i = 0; i < blocksToMove.length; i++) {
                final.splice(insertAt + i, 0, ...blocksToMove[i].block);
            }
            // const normalized = final.map((q, index) => ({
            //     ...q,
            //     sequence: index + 1
            // }));
            const cleared = final.map(q => ({ ...q, queslabel: undefined }));
            setSelectedQuestionIds([]);
            return computeLabels(normalizeSequence(cleared));
        });
    };

    const [optionIdType, setOptionIdType] = useState("A");

    const generalDetails = useMemo(() => ({
        name: paperinfo?.name,
        totalTime: paperinfo?.totalTime,
        session: paperinfo?.session,
        year: paperinfo.year,
        class: filter?.std,
        maxMarks: paperinfo?.maxMarks,
        subject: filter?.subject,
        // subjectName: filter?.subject ? filter?.SubjectData?.find(e => e.id == filter.subject)?.subjectName : paperinfo?.subjectName,
        subjectName: paperinfo?.subjectName,
        generalInstruction: paperinfo?.generalInstruction,
        sectionsData: paperinfo?.sectionsData
    }), [paperinfo, filter]);

    const handleAddMore = () => {
        navigate("/question", { state: { previouslySelected: questions, previousFilter: filter, generaldetail: generalDetails } });
    };

    const handleAddToSection = (sectionObj, sectionIndex) => {
        const sectionQuestionType = generalDetails.sectionsData?.[sectionIndex]?.questionType || filter?.questionType || "";
        const previousFilterForQuestion = { ...filter, quesType: sectionQuestionType, };
        navigate("/question", {
            state: {
                previouslySelected: questions,
                previousFilter: previousFilterForQuestion,
                generaldetail: generalDetails,
                activeSectionIndex: typeof sectionIndex === 'number' ? Number(sectionIndex) : null,
                lastSectionReceived: typeof sectionIndex === 'number' ? String(Number(sectionIndex) + 1) : (getSectionNumberFromObj(sectionObj) ?? null)
            }
        });
    };

    const handlegeneraldetailchange = () => {
        navigate("/QuestionPaper/MakePaper-A", { state: { previouslySelected: questions, previousFilter: filter, generaldetail: generalDetails } });
    }

    const reorderBySections = (list, sectionsArr = []) => {
        if (!Array.isArray(list)) return list;
        if (!Array.isArray(sectionsArr) || sectionsArr.length === 0) return [...list];

        const sectionOrder = new Map(
            sectionsArr.map((sec, idx) => {
                const key = String(getSectionNumberFromObj(sec) ?? sec.section ?? sec.id ?? (idx + 1));
                return [key, idx];
            })
        );
        const getQSectionKey = (q) => String(getSectionNumberFromObj(q.section) ?? q.section ?? "");
        return [...list].sort((a, b) => {
            const aKey = getQSectionKey(a);
            const bKey = getQSectionKey(b);

            const aOrder = sectionOrder.has(aKey) ? sectionOrder.get(aKey) : Number.MAX_SAFE_INTEGER;
            const bOrder = sectionOrder.has(bKey) ? sectionOrder.get(bKey) : Number.MAX_SAFE_INTEGER;

            if (aOrder !== bOrder) return aOrder - bOrder;

            const aSeq = Number(a.sequence ?? a.id ?? 0);
            const bSeq = Number(b.sequence ?? b.id ?? 0);
            return aSeq - bSeq;
        });
    };

    useEffect(() => {
        const sectionsArr = Array.isArray(generalDetails.sectionsData) ? generalDetails.sectionsData : [];
        if (!sectionsArr || sectionsArr.length === 0) return;
        setQuestions(prev => {
            const reordered = reorderBySections(prev, sectionsArr);
            return computeLabels(normalizeSequence(reordered));
        });
    }, [generalDetails.sectionsData]);

    useEffect(() => {
        const CalculatedMarks = questions.reduce((sum, q) => {
            if (q.isSub) return sum;
            return sum + (parseFloat(q.marks) || 0);
        }, 0);

        setTotalMarks(CalculatedMarks);
    }, [questions]);

    const sectionSummaries = useMemo(() => {
        const sections = Array.isArray(generalDetails.sectionsData) ? generalDetails.sectionsData : [];
        if (sections.length === 0) return [];

        const summaries = sections.map((sec) => {
            const secId = sec.id;
            const secNum = getSectionNumberFromObj(sec) ?? sec.section;
            let assigned = 0;
            questions.forEach(q => {
                if (String(q.section) === String(secId) || Number(q.section) === Number(secNum)) {
                    if (!q.isSub) assigned += parseFloat(q.marks) || 0;
                }
            });
            const marksPerSection = sec.marksPerSection ?? null;
            return {
                id: secId,
                section: secNum,
                assignedMarks: assigned,
                marksPerSection: (marksPerSection === null || marksPerSection === undefined) ? null : Number(marksPerSection)
            };
        });
        return summaries;
    }, [questions, generalDetails]);

    const updateUiForQuestion = useCallback((questionId, patch) => {
        setQuestions(prev => {
            const next = prev.map(q => {
                if (q.id !== questionId) return q;
                const mergedUi = { ...(q.ui || {}), ...patch };
                return { ...q, ui: mergedUi };
            });
            return computeLabels(normalizeSequence(next));
        });
    }, []);

    const updateQuestionField = useCallback((questionId, patch) => {
        setQuestions(prev => {
            const idx = prev.findIndex(q => q.id === questionId);
            if (idx === -1) return prev;
            const next = prev.map((q) => q.id === questionId ? ({ ...q, ...patch }) : q);
            const isNumeric = (s) => /^\d+$/.test(String(s || "").trim());
            const isAlpha = (s) => /^[a-z]+$/i.test(String(s || "").trim());
            const isRomanLike = (s) => /^[ivxlcdm]+$/i.test(String(s || "").trim());
            let numericSeq = 0;
            for (let i = 0; i <= idx; i++) {
                const lbl = String(next[i].queslabel ?? "").trim();
                if (isNumeric(lbl) && !next[i].isSub) {
                    numericSeq = Number(lbl);
                }
            }
            for (let i = idx + 1; i < next.length; i++) {
                const item = next[i];
                if (item.isSub) continue;
                const lbl = String(item.queslabel ?? "").trim();
                if (isAlpha(lbl) || isRomanLike(lbl)) {
                    continue;
                }
                numericSeq++;
                next[i] = { ...item, queslabel: String(numericSeq) };
            }
            return computeLabels(next);
        });
    }, []);

    useEffect(() => {
        setQuestions(prev => {
            const next = prev.map((q) => {
                const base = q.ui || {};
                const defaults = {
                    fontSize: base.fontSize ?? 16,
                    align: base.align ?? 'left',
                    optionLayout: base.optionLayout ?? 'vertical',
                    optionIdType: base.optionIdType ?? optionIdType ?? 'A',
                    imageSizes: base.imageSizes ?? {},
                    selectedImageKeys: base.selectedImageKeys ?? [],
                };
                return { ...q, ui: { ...defaults, ...base } };
            });
            return computeLabels(normalizeSequence(next));
        });
    }, []);

    const handleSetOptionIdTypeGlobal = (questionId, val) => {
        setOptionIdType(val);
        updateUiForQuestion(questionId, { optionIdType: val });
    };

    const handleAddConnector = (questionId, connector) => {
        const idsToUpdate = selectedQuestionIds.length > 0 ? [...selectedQuestionIds] : [questionId];
        setQuestions(prev => {
            if (!Array.isArray(prev)) return prev;
            if (connector) {
                for (const id of idsToUpdate) {
                    const idx = prev.findIndex(x => x.id === id);
                    if (idx === -1) continue;
                    const nextItem = prev[idx + 1];
                    if (!nextItem) {
                        setConnectorError("Connector cannot be added. No next question found.");
                        setShowToast(true);
                        setTimeout(() => setShowToast(false), 5000);
                        return prev;
                    }

                    const parentMarks = parseFloat(prev[idx].marks);
                    const childMarks = parseFloat(nextItem.marks);
                    if (parentMarks !== childMarks) {
                        setConnectorError("Connector cannot be added as below question marks are not matched.");
                        setShowToast(true);
                        setTimeout(() => setShowToast(false), 5000);
                        return prev;
                    }
                }
            }
            const newList = prev.map(q => ({ ...q }));
            idsToUpdate.forEach(id => {
                const idx = newList.findIndex(x => x.id === id);
                if (idx === -1) return;
                const q = newList[idx];
                const newParent = { ...q, connector: connector ?? null };
                newList[idx] = newParent;
                const next = newList[idx + 1];
                if (next) {
                    newList[idx + 1] = { ...next, isSub: !!connector, subOf: connector ? q.id : null };
                    setShowToast(false);
                }
            });
            const normalized = newList;
            setSelectedQuestionIds([]);
            const cleared = normalized.map(q => ({ ...q, queslabel: undefined }));
            return computeLabels(cleared);
        });
    };

    const handleAddSection = (questionId, sectionObj) => {
        const sectionId = sectionObj && typeof sectionObj === 'object' ? sectionObj.id : sectionObj;
        const sectionNumber = getSectionNumberFromObj(sectionObj);
        const idsToMove = selectedQuestionIds.length > 0 ? [...selectedQuestionIds] : [questionId];
        setTimeout(() => {
            setQuestions(prev => {
                if (!Array.isArray(prev)) return prev;
                const toRemoveIndexSet = new Set();
                const blocks = [];
                for (let i = 0; i < prev.length; i++) {
                    const q = prev[i];
                    if (!idsToMove.includes(q.id)) continue;
                    const [start, end] = findConnectorBlockRange(prev, i);
                    let already = false;
                    for (let j = start; j <= end; j++) {
                        if (toRemoveIndexSet.has(j)) {
                            already = true;
                            break;
                        }
                    }
                    if (already) continue;
                    const block = prev.slice(start, end + 1);
                    blocks.push({ start, end, block });
                    for (let j = start; j <= end; j++) toRemoveIndexSet.add(j);
                }
                if (blocks.length === 0) return prev;
                const updatedCopy = prev.map((q, idx) => {
                    if (toRemoveIndexSet.has(idx)) {
                        return { ...q, section: sectionNumber ?? sectionId ?? sectionObj };
                    }
                    return q;
                });
                const sectionsArr = Array.isArray(generalDetails.sectionsData) ? generalDetails.sectionsData : [];
                const reordered = reorderBySections(updatedCopy, sectionsArr);
                const cleared = reordered.map(q => ({ ...q, queslabel: undefined }));
                setSelectedQuestionIds([]);
                return computeLabels(normalizeSequence(cleared));
            });
        }, 400);
    };

    const handleSaveChanges = async () => {
        setShowSaveModal(false);
        const sumAssignedMarks = sectionSummaries.reduce(
            (total, section) => total + Number(section.assignedMarks || 0),
            0
        );
        const isValid = sectionSummaries.length > 0 ? sumAssignedMarks === generalDetails.maxMarks : totalMarks === generalDetails.maxMarks;
        if (!isValid) {
            setShowToast(true);
            setTimeout(() => setShowToast(false), 10000);
            return;
        }
        try {
            const labelled = computeLabels(questions);
            const mergedQuestions = labelled.map((q, idx) => {
                const ui = q.ui || {};
                const uiToSave = JSON.parse(JSON.stringify(ui || {}));
                let sectionVal = null;
                if (q.section !== undefined && q.section !== null) {
                    const secNum = getSectionNumberFromObj(q.section);
                    sectionVal = secNum ?? q.section;
                }
                const connectorVal = q.connector ?? null;
                let computedQueslabel = null;
                computedQueslabel = q.queslabel ?? null;
                return {
                    questionId: q.id !== undefined ? q.id : idx,
                    sequence: idx + 1,
                    marks: q.marks ?? null,
                    connector: connectorVal,
                    isSub: q.isSub,
                    subOf: q.subOf,
                    section: sectionVal,
                    contextLabel: q.contextLabel ?? null,
                    queslabel: computedQueslabel,
                    ui: uiToSave
                };
            });

            const payload = {
                questions: mergedQuestions,
                generalDetails
            };
            const response = await QuestionServices.saveQuestionPaper(payload);
            console.log('Save response', response);
            setSaveModalConfig({
                title: "Success", message: "Saved successfully!", btnClose: false, btnConfirm: true, confirmText: "OK",
                onConfirm: () => {
                    navigate("/QuestionPaper");
                }
            });
            setShowSaveModal(true);
        } catch (e) {
            alert("Save failed — see console");
            console.error(e);
        }
    };

    const getToastConfig = (e) => {
        if (e) {
            return {
                message: e,
                variant: "danger",
            };
        }
        if (sectionSummaries.length > 0) {
            const invalidSection = sectionSummaries.find((e) => e.marksPerSection !== e.assignedMarks);
            if (invalidSection) {
                return {
                    message: `${invalidSection.id} assigned marks not matched`,
                    variant: "danger",
                };
            }
        }
        if (totalMarks !== generalDetails.maxMarks) {
            return {
                message: "Unsaved !! Match the total marks with maximum marks",
                variant: "danger",
            };
        }

        return {
            message: "Save Changes Successful!!",
            variant: "success",
        };
    };

    const toastConfig = getToastConfig(connectorError);

    return (
        <div className="p-lg-4">
            <div className='container-fluid QuestionExport-container'>
                <div className="row h-85vh">
                    <div className="col-12 mx-auto content-bg rounded-lg p-lg-4 py-40">
                        <div className="row align-items-center mb-4">
                            <div className="col-4">
                                <h4 className='mb-0 fw-bold pagetitle'>Question Design & Preview</h4>
                            </div>
                            <div className="col-8 d-flex justify-content-end align-items-center gap-3">
                                {active && (
                                    <div className='ms-auto'>
                                        <button className="no-print px-3 btn btn-primary h45" type="button" onClick={() => {
                                            setSaveModalConfig({ title: "Confirm Save", message: "Do you want to save?", btnClose: true, btnConfirm: true, closeText: "Cancel", confirmText: "Save", onConfirm: handleSaveChanges });
                                            setShowSaveModal(true);
                                        }}>Save Question Paper</button>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="border-0 rounded-0">
                            <div className="d-flex flex-column">
                                <div className='d-flex border-bottom align-items-center my-2'>
                                    <div className={`ps-1 pe-2 py-2 cursor-pointer ${active ? 'underline' : 'text-muted'}`} onClick={() => setActive(true)}>Design</div>
                                    <div className={`ps-1 pe-2 py-2 cursor-pointer ${active ? 'text-muted' : 'underline'}`} onClick={() => { setActive(false) }} >Preview</div>

                                </div>
                                {active ? (
                                    <>
                                        <div className='row  themeUnderline mx-1'>
                                            <div className="col-12 border-bottom pb-3 fs-14">
                                                <div className="row">
                                                    <div className="col-12 px-2 py-3">
                                                        <h6 className='Question-header-color mb-0 d-flex align-items-center'>General Details <FaPen size={13} className='ms-2 pointer' onClick={handlegeneraldetailchange} title='Edit General Details' /> </h6>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0 fw-bold">Paper Name</div>
                                                    <div className="col-4 text-start p-0">{generalDetails.name}</div>
                                                    <div className="col-2 text-start p-0 fw-bold">Time Durations:</div>
                                                    <div className="col-3 p-0 text-start">{generalDetails.totalTime} hrs.</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0 fw-bold">Class</div>
                                                    <div className="col-4 text-start p-0 text-nowrap">{generalDetails.class}</div>
                                                    <div className="col-2 p-0 fw-bold">Max marks</div>
                                                    <div className="col-3 p-0 text-start">{generalDetails.maxMarks}</div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-3 ps-3 p-0 fw-bold">Subject Name</div>
                                                    <div className="col-4 text-start p-0"> {generalDetails.subjectName}</div>
                                                    <div className="col-2 text-start p-0 fw-bold">Year</div>
                                                    <div className="col-3 p-0 text-start">{generalDetails.year}</div>
                                                </div>
                                            </div>
                                            <div className="col-12 pb-3 fs-13">
                                                <div className="row">
                                                    <div className="col-12 p-0 p-2 py-3"><h6 className='Question-header-color mb-0 d-flex align-items-center'>General Instruction</h6></div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-12"><pre className='fw-semibold ps-2 fs-6 mb-0'>{generalDetails.generalInstruction}</pre></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-12 px-4 my-3 d-flex justify-content-between align-items-center">
                                                {generalDetails.sectionsData && !generalDetails.sectionsData.length > 0 && (
                                                    <h6 className='Question-header-color mb-0 d-flex align-items-center'>
                                                        Questions<FaPen size={13} className='ms-2 pointer' onClick={handleAddMore} title='Edit Questions' />
                                                    </h6>
                                                )}
                                                <div className="btn-group" role="group" aria-label="Add question to section">
                                                    {Array.isArray(generalDetails.sectionsData) && generalDetails.sectionsData.length > 0 && (
                                                        <div className="btn-group" role="group">
                                                            {generalDetails.sectionsData.map((sec, idx) => {
                                                                const secNum = getSectionNumberFromObj(sec) ?? (idx + 1);
                                                                const label = `Sec-${secNum}`;
                                                                return (
                                                                    <button key={sec.id ?? idx} className="btn btn-outline-success btn-sm" type="button" onClick={() => handleAddToSection(sec, idx)} title={`Add question to section ${secNum}`}>
                                                                        {label} <FaPen size={13} className='ms-1 pointer' />
                                                                    </button>
                                                                );
                                                            })}
                                                        </div>
                                                    )}
                                                </div>
                                                <div>
                                                    <div className={`position-fixed z-3`} style={{ top: "12rem", right: "40px" }}>
                                                        {(!Array.isArray(generalDetails.sectionsData) || generalDetails.sectionsData.length === 0) ? (
                                                            <div className={`px-2 ${totalMarks == generalDetails.maxMarks ? "bg-success text-white" : totalMarks > generalDetails.maxMarks ? "bg-danger" : "bg-warning"}`}>Total Marks {totalMarks} of {generalDetails.maxMarks}</div>
                                                        ) : (
                                                            <div>
                                                                {sectionSummaries.map(s => (
                                                                    <div key={s.id} className={`px-2 border-bottom d-flex justify-content-between ${s.marksPerSection === s.assignedMarks ? "bg-success text-white" : s.marksPerSection < s.assignedMarks ? "bg-danger" : "bg-warning"}`}>
                                                                        <div> Sec-{s.section} Marks:</div> {s.assignedMarks} of {s.marksPerSection}
                                                                    </div>
                                                                ))}
                                                                <div className={`px-2 ${totalMarks == generalDetails.maxMarks ? "bg-success text-white" : totalMarks > generalDetails.maxMarks ? "bg-danger" : "bg-warning"}`}>Total Marks:  {totalMarks} of {generalDetails.maxMarks}</div>
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-12">
                                                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                                    <SortableContext items={questions.map(q => q.id)} strategy={verticalListSortingStrategy}>
                                                        {questions.map((q, index) => {
                                                            const displayIndex = questions.slice(0, index + 1).filter(x => !x.isSub).length;
                                                            const showContext = !!(q.context) && !q.isSub && (index === 0 || (questions[index - 1] && questions[index - 1].contextId !== q.contextId));
                                                            return (
                                                                <SortableQuestion
                                                                    key={q.id}
                                                                    question={q}
                                                                    index={index}
                                                                    displayIndex={displayIndex}
                                                                    // handleChangeMarks={handleChangeMarks}
                                                                    optionIdType={optionIdType}
                                                                    setOptionIdType={(val) => handleSetOptionIdTypeGlobal(q.id, val)}
                                                                    ui={q.ui || {}}
                                                                    updateUi={(patch) => updateUiForQuestion(q.id, patch)}
                                                                    updateQuestion={(id, patch) => updateQuestionField(id, patch)}
                                                                    onDelete={handleDelete}
                                                                    onAddConnector={handleAddConnector}
                                                                    onAddSection={handleAddSection}
                                                                    sectionsCount={generalDetails.sectionsData}
                                                                    selectedQuestionIds={selectedQuestionIds}
                                                                    toggleSelect={toggleSelect}
                                                                    showContext={showContext}
                                                                />
                                                            );
                                                        })}
                                                    </SortableContext>
                                                </DndContext>
                                            </div>
                                        </div>
                                    </>
                                ) : (<>
                                    <PreviewContent questions={questions} generalDetails={generalDetails} />
                                </>)}
                            </div>
                        </div>
                        <ShowMessage show={showToast} position="bottom-end" type="toast" message={toastConfig.message} variant={toastConfig.variant}
                            btnConfirm={true} btnClose={false}
                            onClose={() => { setShowToast(false); setConnectorError(null) }}
                        />
                        <ShowMessage type="modal" show={showSaveModal} title={saveModalConfig.title} message={saveModalConfig.message} btnClose={saveModalConfig.btnClose} btnConfirm={saveModalConfig.btnConfirm} closeText={saveModalConfig.closeText} confirmText={saveModalConfig.confirmText} onClose={() => setShowSaveModal(false)} onConfirm={saveModalConfig.onConfirm} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default QuestionPreview;
