import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('class')
export class Class {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  class: number;

  @Column({ default: 1 })
  status: number;

  @Column({ default: 1 })
  visible: number;

  @CreateDateColumn({ type: 'datetime' })
  date: Date;
}
