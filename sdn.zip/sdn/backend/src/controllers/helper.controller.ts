import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ClassDto } from '../dto/class.dto';
import { SectionDto } from '../dto/section.dto';
import { SubjectDto } from '../dto/subject.dto';
import { HelperService } from '../services/helper.service';

@Controller('store')
export class HelperController {
  constructor(private readonly helperService: HelperService) {}

  @Get('roles')
  async getRoles(): Promise<any> {
    return this.helperService.getRoles();
  }

  @Get('permissions')
  async getPermissions(): Promise<any> {
    return this.helperService.getPermissions();
  }

  @Post('class')
  async createClass(@Body() classDto: ClassDto) {
    const cls = await this.helperService.createUpdateClass(classDto);
    if (!cls) {
      throw new Error('Class creation failed ');
    }
    return { message: 'Class created successfully', data: cls };
  }

  @Get('classes')
  async getClass() {
    const cls = await this.helperService.getClass();
    if (!cls) {
      throw new Error('Class not found');
    }
    return cls;
  }

  @Post('Section')
  async createSection(@Body() sectionDto: SectionDto) {
    const section = await this.helperService.createUpdateSection(sectionDto);
    if (!section) {
      throw new Error('Section creation failed');
    }
    return section;
  }

  @Get('section')
  async getSection() {
    const section = await this.helperService.getSection();
    if (!section) {
      throw new Error('Section creation failed');
    }
    return section;
  }

  @Post('Subject')
  async createSubject(@Body() subjectDto: SubjectDto) {
    const subject = await this.helperService.createUpdateSubject(subjectDto);
    if (!subject) {
      throw new Error('subject creation failed');
    }
    return subject;
  }

  @Get('Subject')
  async getSubject(@Param('subdomain') parentId: number = 0) {
    const subject = await this.helperService.getSubject(parentId);
    if (!subject) {
      throw new Error('Section creation failed');
    }
    return subject;
  }

  @Get('subDomainData')
  async getSubDomainData() {
    return this.helperService.getAllSubdomain();
  }

  @Get('subDomain')
  async getSubDomain(@Query('subject') parentId: number) {
    return this.helperService.getSubdomain(parentId);
  }

  @Get('statesndistrict')
  async getDistrict(@Query('stateId') stateid: string): Promise<any> {
    const stateId: string = stateid ? stateid : '0';
    return await this.helperService.getStateNConstituency(stateId);
  }

  @Get('cg')
  async getCG(
    @Query('stage') stage: string,
    @Query('subject') domain: string
  ): Promise<any> {
    console.log('stage', stage, 'domain', domain);
    return await this.helperService.getCG(stage, domain);
  }

  @Get('competency')
  async getCompetency(@Query('id') parentId: number): Promise<any> {
    console.log('parentId', parentId);
    return await this.helperService.getCompetency(parentId);
  }
}
