import { Module, MiddlewareConsumer, RequestMethod } from '@nestjs/common';
import configuration from './config/configuration';
import { APP_FILTER } from '@nestjs/core';
import { WinstonModule } from 'nest-winston';
import { winstonLoggerOptions } from './config/winston.logger';
import { AllExceptionsFilter } from './auth/http-exception.filter';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './modules/auth.module';
import { SchoolModule } from './modules/school.module';
import { LookupMiddleware } from './middleware/lookup.middleware';
import { LookupModule } from './modules/lookup.module';
import { EncryptionModule } from './modules/encryption.module';
import { ResultModule } from './modules/result.module';
import { UserModule } from './modules/user.module';
import { NotificationModule } from './modules/notification.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      load: [configuration],
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        type: configService.get<'mysql' | 'mongodb'>('database.type', 'mysql'),
        host: configService.get<string>('database.host'),
        port: configService.get<number>('database.port'),
        username: configService.get<string>('database.user'),
        password: configService.get<string>('database.password'),
        database: configService.get<string>('database.database'),
        synchronize: true,
        autoLoadEntities: true,
        logging: false,
      }),
    }),
    WinstonModule.forRoot(winstonLoggerOptions),
    EncryptionModule,
    LookupModule,
    AuthModule,
    SchoolModule,
    ResultModule,
    UserModule,
    NotificationModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_FILTER,
      useClass: AllExceptionsFilter,
    },
  ],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LookupMiddleware)
      .exclude({ path: 'lookup/:slug', method: RequestMethod.GET })
      .forRoutes({ path: '*path', method: RequestMethod.ALL });
  }
}
