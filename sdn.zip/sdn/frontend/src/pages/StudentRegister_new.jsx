import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Row, Col, Button, Form } from 'react-bootstrap';
import { formatDate } from '../utils/util';
import apiClient from '../api/apiService';
import { useNavigate } from 'react-router-dom';

const StudentRegister = () => {
  const [sectionData, setSectionData] = useState([]);
  const [classOptions, setClassOptions] = useState([]);
  const [stateOptions, setStateOptions] = useState([]);
  const [districtOptions, setDistrictOptions] = useState([]);

  const navigator = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({ mode: 'onChange' });

  const [userData] = useState();
  const parameters = new URLSearchParams(window.location.search);
  const updateId = parameters.get('id');

  const fetchUserData = async () => {
    if (updateId) {
      try {
        // Fetch data logic goes here
      } catch (error) {
        console.error(error.message);
      }
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [updateId]);

  useEffect(() => {
    apiClient.get('/store/section')
      .then((response) => setSectionData(response.data))
      .catch((error) => console.error('Error fetching section data:', error));

    apiClient.get('/store/classes')
      .then((response) => setClassOptions(response.data))
      .catch((error) => console.error('Error fetching classes:', error));

    apiClient.get('/store/statesndistrict', { params: { stateId: '0' } })
      .then((response) => setStateOptions(response.data))
      .catch((error) => console.error('Error fetching state:', error));
  }, []);

  const handleState = (e) => {
    apiClient.get('/store/statesndistrict', { params: { stateId: e.target.value } })
      .then((response) => setDistrictOptions(response.data))
      .catch((error) => console.error('Error fetching district:', error));
  };

  const onSubmit = async (data) => {
    console.log('Form Data:', data);
    try {
      if (data.id) {
        const response = apiClient.put(`/user/student/${data.id}`, data);
        if (response.status === 200) navigator('/dashboard');
        else console.error('Failed to update data.');
      } else {
        const response = await apiClient.post(`/user/student`, data);
        if (response.status === 200) {
          console.log('Data inserted successfully!');
          navigator('/dashboard');
        } else console.error('Failed to insert data.');
      }
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  if (updateId && !userData) return <div>Loading...</div>;

  const handleselect = (e) => {
    const selectEl = e.target;
    const formFloatingEl = selectEl.closest('.form-floating');
    if (selectEl && formFloatingEl) {
      formFloatingEl.querySelector('label').style.transform = 'scale(0.85) translateY(-3.1rem)';
    }
  };

  return (
    <div className="min-h-screen bg-light py-5">
      <div className="container bg-white p-4 shadow rounded">
        <h3 className="text-center mb-4">Student Registration</h3>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Row className="g-3">
            <Col md={6}>
              <Form.Group controlId="name">
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" placeholder="User Name" isInvalid={!!errors.name} {...register('name', { required: 'Name is required', pattern: { value: /^[A-Za-z\s]+$/, message: 'Only alphabetic characters are allowed' } })} />
                <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="RollNo">
                <Form.Label>Roll No</Form.Label>
                <Form.Control type="text" placeholder="Enter Roll Number" isInvalid={!!errors.rollNo} {...register('rollNo', { required: 'Roll Number is required' })} />
                <Form.Control.Feedback type="invalid">{errors.rollNo?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="className">
                <Form.Label>Class</Form.Label>
                <Form.Select isInvalid={!!errors.class} {...register('class', { required: 'Class is required', onChange: (e) => handleselect(e) })}>
                  <option value="">Select Class</option>
                  {classOptions.map((e, i) => (<option key={i} value={e.class}>{e.class}</option>))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.class?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="section">
                <Form.Label>Section</Form.Label>
                <Form.Select isInvalid={!!errors.section} {...register('section', { required: 'Section is required' })}>
                  <option value="">Select Section</option>
                  {sectionData.map((e, i) => (<option key={i} value={e.section}>{e.section}</option>))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.section?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="gender">
                <Form.Label>Gender</Form.Label>
                <Form.Select isInvalid={!!errors.gender} {...register('gender', { required: 'Gender is required' })}>
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="May not prefer">May Not Prefer</option>
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.gender?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="dob">
                <Form.Label>Date of Birth</Form.Label>
                <Form.Control type="date" defaultValue={userData?.dob && formatDate(userData.dob)} isInvalid={!!errors.dateOfBirth} {...register('dateOfBirth', { required: 'Date of Birth is required' })} />
                <Form.Control.Feedback type="invalid">{errors.dateOfBirth?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="EmailID">
                <Form.Label>Email ID</Form.Label>
                <Form.Control type="email" defaultValue={userData?.emailId} isInvalid={!!errors.emailId} {...register('emailId', { required: 'Email ID is required' })} />
                <Form.Control.Feedback type="invalid">{errors.emailId?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="FatherName">
                <Form.Label>Father Name</Form.Label>
                <Form.Control type="text" placeholder="Enter Father's Name" isInvalid={!!errors.fatherName} {...register('fatherName', { required: 'Father Name is required', pattern: { value: /^[A-Za-z\s]+$/, message: 'Only alphabetic characters are allowed' } })} />
                <Form.Control.Feedback type="invalid">{errors.fatherName?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="MotherName">
                <Form.Label>Mother Name</Form.Label>
                <Form.Control type="text" placeholder="Enter Mother's Name" isInvalid={!!errors.motherName} {...register('motherName', { required: 'Mother Name is required', pattern: { value: /^[A-Za-z\s]+$/, message: 'Only alphabetic characters are allowed' } })} />
                <Form.Control.Feedback type="invalid">{errors.motherName?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="ContactNumber">
                <Form.Label>Contact Number</Form.Label>
                <Form.Control type="text" maxLength={10} placeholder="Enter Contact Number" isInvalid={!!errors.contactNumber} {...register('contactNumber', { required: 'Contact Number is required', pattern: { value: /^[0-9]{10}$/, message: 'Number must be 10 digits and numerical' } })} />
                <Form.Control.Feedback type="invalid">{errors.contactNumber?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="AlternativeContactNumber">
                <Form.Label>Alternative Contact Number</Form.Label>
                <Form.Control type="text" maxLength={10} placeholder="Enter Alternative Number" isInvalid={!!errors.alternativeContactNumber} {...register('alternativeContactNumber', { pattern: { value: /^[0-9]{10}$/, message: 'Number must be 10 digits and numerical' } })} />
                <Form.Control.Feedback type="invalid">{errors.alternativeContactNumber?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="Address">
                <Form.Label>Address</Form.Label>
                <Form.Control type="text" placeholder="Enter Address" isInvalid={!!errors.address} {...register('address', { required: 'Address is required' })} />
                <Form.Control.Feedback type="invalid">{errors.address?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="State">
                <Form.Label>State</Form.Label>
                <Form.Select isInvalid={!!errors.state} {...register('state', { required: 'State is required', onChange: (e) => handleState(e) })}>
                  <option value="">Select State</option>
                  {stateOptions.map((e, i) => (<option key={i} value={e.id}>{e.stateNConsti}</option>))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.state?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group controlId="District">
                <Form.Label>District</Form.Label>
                <Form.Select isInvalid={!!errors.district} {...register('district', { required: 'District is required' })}>
                  <option value="">Select District</option>
                  {districtOptions.map((e, i) => (<option key={i} value={e.id}>{e.stateNConsti}</option>))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.district?.message}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col xs={12} className="text-center mt-4">
              <Button variant="primary" size="lg" disabled={isSubmitting} type="submit">
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </Button>
            </Col>
          </Row>
        </Form>
      </div>
    </div>
  );
};

export default StudentRegister;