import React, { useEffect, useState, useCallback } from 'react';
import { MdRemoveCircleOutline, MdAddCircleOutline } from 'react-icons/md';
import apiClient from '../api/apiService';
import UserServices from '../api/UserServices';
import { useNavigate, useParams } from 'react-router-dom';
import ShowMessage from '../components/ShowMessage'

const UserPermission = () => {
  const { userid } = useParams();
  const updateId = userid ? userid : null;
  const navigator = useNavigate()
  const [userData, setUserData] = useState();
  const [subjectData, setSubjectData] = useState([]);
  const [classData, setClassData] = useState([]); 
  const [modules, setModules] = useState([]); 
  const [actions, setActions] = useState([]); 
  const [moduleRows, setModuleRows] = useState({}); 
  const [showMsg, setShowMsg] = useState(false); 

  const makeEmptyRow = useCallback(
    (classList = classData, actionList = actions) => {
      const permMap = {};
      classList.forEach((cls) => {
        permMap[cls] = {};
        actionList.forEach((a) => {
          permMap[cls][a] = false;
        });
      });
      return { subject: '', permissions: permMap };
    },
    [classData, actions]
  );
  useEffect(() => {
  const fetchUserData = async () => {
    if (updateId) {
      try {
        const response = await UserServices.getUser({ params: { id: updateId } });        
        setUserData(response);          
      } catch (error) {
        console.error(error.message)
      }
    }
  }
  
      fetchUserData()
    }, [updateId])

  useEffect(() => {
    const loadAll = async () => {
      try {
        // fetch subjects and classes in parallel
        const [subjectsRes, classesRes] = await Promise.all([apiClient.get('/store/subject'), apiClient.get('/store/classes')]);
        
        const subjects = subjectsRes.data || [];
        const classes = (classesRes.data || []).filter((c) => c.status === 1).map((c) => String(c.class)); // keep as string for keys

        setSubjectData(subjects);
        setClassData(classes);

        // fetch permission definitions (MODULE & ACTION)
        const permissions = await UserServices.getSystemPermissions({ params: { type: 'MODULE,ACTION' } });
        
        const modulesFromApi = permissions.filter((p) => p.type === 'MODULE').map((p) => p.label);
        const actionsFromApi = permissions.filter((p) => p.type === 'ACTION').map((p) => p.label);
        
        setModules(modulesFromApi);
        setActions(actionsFromApi);

        // initialize moduleRows with one empty row per module
        const initialRows = {};
        modulesFromApi.forEach((m) => {
          initialRows[m] = [makeEmptyRow(classes, actionsFromApi)];
        });
        setModuleRows(initialRows);
      } catch (err) {
        console.error('Error loading permission UI data:', err);
      }
    };

    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  // When classData or actions change after initial fetch, ensure existing rows have those keys.
  // This only adds missing keys — it does not overwrite existing user selections.
  useEffect(() => {
    if (!classData.length || !actions.length || !Object.keys(moduleRows).length) return;

    setModuleRows((prev) => {
      const next = {};
      Object.entries(prev).forEach(([moduleName, rows]) => {
        next[moduleName] = rows.map((row) => {
          const permissions = { ...(row.permissions || {}) };

          // ensure every class exists
          classData.forEach((cls) => {
            if (!permissions[cls]) {
              permissions[cls] = {};
              actions.forEach((a) => (permissions[cls][a] = false));
            } else {
              // ensure every action exists for that class
              actions.forEach((a) => {
                if (permissions[cls][a] === undefined) permissions[cls][a] = false;
              });
            }
          });

          return { ...row, permissions };
        });
      });
      return next;
    });
    // only when classData or actions change
  }, [classData, actions]); // eslint-disable-line

  const getAllowedActionsForModule = (moduleName) => {
    switch (moduleName.toLowerCase()) {
      case 'exam':
        return actions.filter((a) => a !== 'APPROVE');
      case 'bank':
      case 'report':
        return actions.filter((a) => a === 'READ');
      default:
        return actions;
    }
  };


  // Update rows for a module
  const handleUpdateRows = (moduleName, newRows) => {
    setModuleRows((prev) => ({ ...prev, [moduleName]: newRows }));
  };

  // Save: transform into module -> subjects -> [ { class, actions } ]
const handleSubmitAll = async () => {
  try {
    const finalPayload = {};

    Object.entries(moduleRows).forEach(([moduleName, rows]) => {
      const modulePermissions = {};
      actions.forEach((action) => {
        modulePermissions[action] = {};
      });

      rows.forEach((row) => {
        if (!row.subject) return;

        Object.entries(row.permissions).forEach(([classId, perms]) => {
          Object.entries(perms).forEach(([action, isAllowed]) => {
            if (isAllowed) {
              if (!modulePermissions[action][row.subject]) {
                modulePermissions[action][row.subject] = new Set();
              }
              modulePermissions[action][row.subject].add(classId);
            }
          });
        });
      });

      const cleanedActions = {};
      Object.entries(modulePermissions).forEach(([action, subjects]) => {
        const subjectArray = Object.entries(subjects).map(([subjectId, classSet]) => ({
          subjectId,
          classIds: Array.from(classSet),
        }));
        if (subjectArray.length > 0) {
          cleanedActions[action] = subjectArray;
        }
      });

      if (Object.keys(cleanedActions).length > 0) {
        finalPayload[moduleName] = cleanedActions;
      }
    });
    const moduleRowsArray = {};
    moduleRowsArray["permission"] = Object.entries(finalPayload).map(([module, permissions]) => ({
      module,
      permissions,
    }));

    // moduleRowsArray.forEach((item) => {
    //   item.userId = id;
    // });

    moduleRowsArray["userId"] = userid;

    console.log('Final payload to save:', moduleRowsArray);
   

    const response = await UserServices.setUserPermissions(moduleRowsArray)
    if (response) {
      setShowMsg(true);
    }

  } catch (error) {
    console.error('Error in handleSubmitAll:', error);
  }
};

  return (
    <div className="container-fluid py-4">
      <div className="row">
        <div className="col-12 col-lg-10 mx-auto bg-white shadow-sm rounded p-4">
          <ShowMessage show={showMsg} type="modal" message="User Permission Saved" variant="success" 
              btnConfirm={true} btnClose={false} textConfirm="OK"
                  onClose={() => setShowMsg(false)}
                  onConfirm={() => {
                    setShowMsg(false);
                    navigator('/users');
                  }}
                />
          <div className="form-header mb-4 border-bottom pb-2 d-flex justify-content-between align-items-center">
                        
            <h3 className="fw-bold text-primary">
              {userData && userData.name}'s Permissions</h3>
            <button className="btn btn-primary" onClick={handleSubmitAll}>
              Save All Permissions
            </button>
          </div>

          <nav>
            <div className="nav nav-tabs" role="tablist">
              {modules.map((moduleName, idx) => (
                <button key={moduleName} className={`nav-link ${idx === 0 ? 'active' : ''}`} data-bs-toggle="tab" data-bs-target={`#tab-${moduleName.toLowerCase()}`}>
                  {moduleName.charAt(0) + moduleName.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </nav>

          <div className="tab-content p-3 border border-top-0 rounded-bottom">
            {modules.map((moduleName, idx) => (
              <div key={moduleName} className={`tab-pane fade ${idx === 0 ? 'show active' : ''}`} id={`tab-${moduleName.toLowerCase()}`}>
                <PermissionTable
                 moduleName={moduleName}
                 classData={classData}
                 subjectData={subjectData}
                 actions={getAllowedActionsForModule(moduleName)}
                 rows={moduleRows[moduleName] || [makeEmptyRow(classData, getAllowedActionsForModule(moduleName))]}
                 onRowsChange={(newRows) => handleUpdateRows(moduleName, newRows)}
                 makeEmptyRow={() => makeEmptyRow(classData, getAllowedActionsForModule(moduleName))}
                 />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// PermissionTable: child component — expects rows shaped as:
// { subject: '', permissions: { '6': { read: false, write: false, ... }, ... } }
const PermissionTable = ({classData, subjectData, actions, rows, onRowsChange, makeEmptyRow}) => {
  const addRow = () => {
    onRowsChange([...rows, makeEmptyRow()]);
  };

  const removeRow = () => {
    if (rows.length > 1) onRowsChange(rows.slice(0, -1));
  };

  const handleSubjectChange = (rowIndex, value) => {
    const updated = [...rows];
    updated[rowIndex] = { ...updated[rowIndex], subject: value };
    onRowsChange(updated);
  };

  const handleCheckboxChange = (rowIndex, className, permission) => {
    const updated = [...rows];
    const row = { ...updated[rowIndex] };
    const classPerms = { ...(row.permissions[className] || {}) };
    const newValue = !classPerms[permission];

    // toggle
    classPerms[permission] = newValue;

    // business rule: if write checked, ensure read is checked
    if (permission === 'WRITE' && newValue) {
      classPerms['READ'] = true;
    }

    row.permissions = { ...row.permissions, [className]: classPerms };
    updated[rowIndex] = row;
    onRowsChange(updated);
  };

  return (
    <div>
      <div className="table-responsive prmsionTable text-center">
        <table className="table table-bordered align-middle table-hover">
          <thead className="table-light">
            <tr>
              <th>Subject</th>
              <th>Class</th>
              {actions.map((perm) => (
                <th key={perm} className="text-center">
                  {perm.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {rows.map((row, rowIndex) =>
              classData.map((cls, classIndex) => (
                <tr key={`${rowIndex}-${cls}`} className={classIndex === 0 ? 'table-primary' : ''}>
                  {classIndex === 0 && (
                    <td rowSpan={classData.length}>
                      <select className="form-select form-select-sm" value={row.subject} onChange={(e) => handleSubjectChange(rowIndex, e.target.value)}>
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>
                  )}

                  <td className="fw-semibold">{cls}</td>

                  {actions.map((perm) => (
                    <td key={perm} className="text-center">
                      <input type="checkbox" className="form-check-input" checked={!!row.permissions?.[cls]?.[perm]} onChange={() => handleCheckboxChange(rowIndex, cls, perm)} />
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>

          <tfoot>
            <tr>
              <td colSpan={actions.length + 2} className="text-center bg-light">
                <span className="me-4 text-danger fs-5 cursor-pointer" onClick={removeRow}>
                  <MdRemoveCircleOutline />
                </span>
                <span className="text-success fs-5 cursor-pointer" onClick={addRow}>
                  <MdAddCircleOutline />
                </span>
              </td>
            </tr>
          </tfoot>
        </table>

        {/* {errorMessage && <div className="alert alert-danger py-2">{errorMessage}</div>} */}
      </div>
    </div>
  );
};

export default UserPermission;
