import {
  Controller,
  Get,
  Post,
  Query,
  Res,
  InternalServerErrorException,
  NotFoundException,
  UseGuards,
} from '@nestjs/common';
import { Response } from 'express';
import { ResultService } from '../services/result.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('report')
export class ResultController {
  constructor(private readonly resultService: ResultService) {}

  @Get('grade')
  async getGradeAll(): Promise<any> {
    const grade = await this.resultService.getGradeAll();
    if (!grade) {
      throw new NotFoundException('Grade not found');
    }
    return grade;
  }

  @Get('createresult')
  async createResult(
    @Query('paperid') paperid: string,
    @Query('section') section: string,
    @Query('class') cls: string
  ): Promise<any> {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const result = await this.resultService.createResult(paperid, section, cls);
    if (!result) {
      throw new NotFoundException('Failed to create result');
    }
    return { message: 'Result created successfully', result };
  }

  @Get('reportadminnew')
  async getReportAdminNew(
    @Query('class') studentClass: string,
    @Query('paperid') paperId?: string,
    @Query('subdomain') subdomain?: string
  ) {
    const result = await this.resultService.getReportData(
      studentClass,
      paperId,
      subdomain
    );
    if (!result) {
      throw new NotFoundException('No result found');
    }
    return result;
  }
  @Get('studentByClass')
  async getStudentByClass(
    @Query('class') studentClass: string,
    @Query('paperId') paperId?: string,
    @Query('section') section?: string
  ) {
    const result = await this.resultService.getStudentByClass(
      studentClass,
      paperId,
      section
    );
    if (!result) {
      throw new NotFoundException('No result found');
    }
    return result;
  }

  @Get('getresultlist')
  async getResultList(@Query() data: any): Promise<any> {
    const result = await this.resultService.getResultList(data);
    if (!result) {
      throw new NotFoundException('No results found');
    }
    return result;
  }

  @Get('getavg')
  async getAvgList(@Query() data: any): Promise<any> {
    const result = await this.resultService.getAvg(data);
    if (!result) {
      throw new NotFoundException('No results found');
    }
    return result;
  }

  @Get('findquestions')
  async findQuestions(@Query('qid') qids: string): Promise<any[]> {
    if (!qids) {
      throw new NotFoundException('ID is required');
    }
    const questions: any[] = await this.resultService.findQuestions(qids);
    if (!questions || questions.length === 0) {
      throw new NotFoundException('No questions found for this paper');
    }
    return questions;
  }
}
//api/result/reportadminnew?class=7&paperid=15
