import React, { useEffect, useState, useCallback } from "react";
import { MdRemoveCircleOutline, MdAddCircleOutline } from "react-icons/md";
import { AiOutlineCloseCircle } from "react-icons/ai";
import UserServices from "../api/UserServices";
import apiClient from "../api/apiService";
import { useParams } from "react-router-dom";

const UserApproval = () => {
  const [subjectData, setSubjectData] = useState([]);
  const [rowData, setRowData] = useState({});
  const [rows, setRows] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [activeRow, setActiveRow] = useState(null);
  const [selectedTeachers, setSelectedTeachers] = useState([]);
  const [availableTeacher, setAvailableTeacher] = useState([]);

  const { userid } = useParams();
  const updateId = userid || null;

  // --- helper: empty row ---
  const makeEmptyRow = useCallback(
    () => ({
      classId: "",
      subjectId: "",
      teacherIds: []
    }),
    []
  );

  // --- load initial data ---
  useEffect(() => {
    const loadAll = async () => {
      const [userRes, subjectRes] = await Promise.all([
        UserServices.getUser({ params: { id: updateId } }),
        apiClient.get("/store/subject"),
      ]);

      const teacherSubjects = userRes.teacherSubject || [];

      // Shape subject-class mapping
      const shaped = {};
      teacherSubjects.forEach((s) => {
        shaped[s.subjectId] = s.classIds.map((cid) => ({
          classId: Number(cid),
          selectedteachers: [],
          availableTeacher: [],
        }));
      });

      setRowData(shaped);
      console.log("Initial RowData:", shaped);

      // Filter subjects user is assigned to
      const filteredSubjects = subjectRes.data.filter((s) =>
        teacherSubjects.some((t) => parseFloat(t.subjectId) === s.id)
      );
      setSubjectData(filteredSubjects);

      // Start with one empty row
      setRows([makeEmptyRow()]);
    };

    loadAll();
  }, [makeEmptyRow, updateId]);

  // --- subject change handler ---
  const handleSubjectChange = (rowIndex, subjectId) => {
    setRows((prev) =>
      prev.map((row, i) =>
        i === rowIndex ? { ...row, subjectId, classId: "", teacherIds: [] } : row
      )
    );
  };

  // --- class change handler ---
  const handleClassSelect = async (rowIndex, classId) => {
      const subjectId = rows[rowIndex].subjectId;

  if (!subjectId) {
    alert("⚠️ Please select a subject first!");
    return;
  }

  // Prevent duplicate subject-class combo
  const isDuplicate = rows.some(
    (r, i) => i !== rowIndex && r.subjectId === subjectId && r.classId === classId
  );

  if (isDuplicate) {
    alert("This subject and class combination already exists!");
    // Reset class selection
    setRows((prev) =>
      prev.map((row, i) => (i === rowIndex ? { ...row, classId: "" } : row))
    );
    return;
  }
    const updated = rows.map((row, i) =>
      i === rowIndex ? { ...row, classId } : row
    );
    setRows(updated);

    if (!subjectId || !classId) return;

    try {
      // Fetch available teachers from backend
      const response = await UserServices.getTeacherBySubjectClass({
        params: { classIds: classId, subjectId },
      });

      console.log("Fetched Teachers:", response);
      

      const available = response || [];

      // Update rowData structure
      setRowData((prev) => {
        const newRowData = { ...prev };
        if (!newRowData[subjectId]) newRowData[subjectId] = [];

        const existingIndex = newRowData[subjectId].findIndex(
          (c) => c.classId === Number(classId)
        );

        if (existingIndex !== -1) {
          newRowData[subjectId][existingIndex] = {
            ...newRowData[subjectId][existingIndex],
            availableTeacher: available,
          };
        } else {
          newRowData[subjectId].push({
            classId: Number(classId),
            selectedteachers: [],
            availableTeacher: available,
          });
        }
        return newRowData;
      });

      // open modal
      setActiveRow(rowIndex);
      setAvailableTeacher(available);
      setSelectedTeachers(updated[rowIndex].teacherIds || []);
      setShowModal(true);
    } catch (error) {
      console.error("Error fetching teachers:", error);
    }
  };

  // --- save selected teachers ---
  const handleSaveTeachers = () => {
    if (activeRow === null) return;

    const { subjectId, classId } = rows[activeRow];

    // update row-level
    setRows((prev) =>
      prev.map((row, i) =>
        i === activeRow ? { ...row, teacherIds: selectedTeachers } : row
      )
    );

    // update nested rowData
    setRowData((prev) => {
      const newRowData = { ...prev };
      if (!newRowData[subjectId]) return newRowData;

      newRowData[subjectId] = newRowData[subjectId].map((c) =>
        c.classId === Number(classId)
          ? { ...c, selectedteachers: selectedTeachers }
          : c
      );

      return newRowData;
    });

    setShowModal(false);
    setActiveRow(null);
  };

  // --- remove selected teacher ---
  const handleRemoveTeacher = (rowIndex, teacherId) => {
    const { subjectId, classId } = rows[rowIndex];

    // update table row
    setRows((prev) =>
      prev.map((row, i) =>
        i === rowIndex
          ? { ...row, teacherIds: row.teacherIds.filter((t) => t !== teacherId) }
          : row
      )
    );

    // update rowData
    setRowData((prev) => {
      const newRowData = { ...prev };
      if (!newRowData[subjectId]) return newRowData;

      newRowData[subjectId] = newRowData[subjectId].map((c) =>
        c.classId === Number(classId)
          ? {
              ...c,
              selectedteachers: c.selectedteachers.filter((t) => t !== teacherId),
            }
          : c
      );
      return newRowData;
    });
  };

  const handleSaveForm = async () => {
  try {
    // Filter out incomplete rows
    const validRows = rows.filter(
      (r) => r.subjectId && r.classId && r.teacherIds.length > 0
    );

    if (validRows.length === 0) {
      alert("Please select at least one subject, class, and teacher.");
      return;
    }

    // Convert to structured format (grouped by subjectId)
    const payload = {};

    // validRows.forEach((row) => {
    //   if (!payload[row.subjectId]) payload[row.subjectId] = [];
    //   payload[row.subjectId].push({
    //     classId: Number(row.classId),
    //     selectedteachers: row.teacherIds.map((id) => ({ id })),
    //   });
    // });

    validRows.forEach((row) => {
    if (!payload[row.subjectId]) payload[row.subjectId] = [];
    payload[row.subjectId].push({
      classId: row.classId,
      selectedteachers: row.teacherIds // **array of IDs**
    });
  });

    // Add userId = 18
    const body = {
      userId: 18,
      permissions: payload,
    };

    console.log("Final payload:", body);

    // Make API request
    const response = await UserServices.saveUserApproval(body);

    if (response.status === 200) {
      alert("✅ User approval data saved successfully!");
    } else {
      alert("Failed to save user approval data.");
    }
  } catch (error) {
    console.error("Error saving form:", error);
    alert("Error while saving user approval data.");
  }
};


  // --- debug watch ---
  useEffect(() => {
    console.log("Updated RowData:", JSON.stringify(rowData, null, 2));
  }, [rowData]);

  return (
    <div className="container-fluid py-4">
      <div className="row ms-5">
        <div className="col-12 col-lg-11 ms-5 bg-white shadow-sm rounded p-4">
          <div className="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
            <h3 className="fw-bold text-primary">User Approval</h3>
          </div>

          <table className="table table-bordered align-middle text-center">
            <thead className="table-light">
              <tr>
                <th style={{ width: "30%" }}>Subject</th>
                <th style={{ width: "30%" }}>Class</th>
                <th style={{ width: "40%" }}>Teacher</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => {
                const subjectClasses =
                  rowData[row.subjectId]?.map((c) => c.classId) || [];

                const selectedTeacherObjects =
                  row.teacherIds
                    .map((id) =>
                      rowData[row.subjectId]
                        ?.flatMap((c) => c.availableTeacher)
                        ?.find((t) => t.id === id)
                    )
                    .filter(Boolean) || [];

                return (
                  <tr key={i}>
                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.subjectId}
                        onChange={(e) =>
                          handleSubjectChange(i, e.target.value)
                        }
                      >
                        <option value="">Select Subject</option>
                        {subjectData.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.subject}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td>
                      <select
                        className="form-select form-select-sm"
                        value={row.classId}
                        onChange={(e) => handleClassSelect(i, e.target.value)}
                      >
                        <option value="">Select Class</option>
                        {subjectClasses.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="text-start">
                      {selectedTeacherObjects.length > 0 ? (
                        selectedTeacherObjects.map((t) => (
                          <span
                            key={t.id}
                            className="badge bg-primary me-2 p-2 d-inline-flex align-items-center"
                          >
                            {t.name}
                            <AiOutlineCloseCircle
                              className="ms-1"
                              style={{ cursor: "pointer" }}
                              onClick={() => handleRemoveTeacher(i, t.id)}
                            />
                          </span>
                        ))
                      ) : (
                        <span className="text-muted">No teacher selected</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>

            <tfoot>
              <tr>
                <td colSpan={3}>
                  <span
                    className="me-4 text-danger fs-5"
                    onClick={() => rows.length > 1 && setRows(rows.slice(0, -1))}
                    style={{ cursor: "pointer" }}
                  >
                    <MdRemoveCircleOutline />
                  </span>
                  <span
                    className="text-success fs-5"
                    onClick={() => setRows([...rows, makeEmptyRow()])}
                    style={{ cursor: "pointer" }}
                  >
                    <MdAddCircleOutline />
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
          <div className="d-flex justify-content-end mt-3">
            <button className="btn btn-primary" onClick={handleSaveForm}>
              💾 Save Approval Data
            </button>
          </div>

        </div>
      </div>

      {/* Teacher selection modal */}
      {showModal && (
        <div
          className="modal fade show"
          style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Select Teachers</h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                {availableTeacher.map((teacher) => (
                  <div key={teacher.id} className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={teacher.id}
                      checked={selectedTeachers.includes(teacher.id)}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setSelectedTeachers((prev) =>
                          checked
                            ? [...prev, teacher.id]
                            : prev.filter((t) => t !== teacher.id)
                        );
                      }}
                    />
                    <label className="form-check-label" htmlFor={teacher.id}>
                      {teacher.name}
                    </label>
                  </div>
                ))}
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
                <button className="btn btn-primary" onClick={handleSaveTeachers}>
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserApproval;
