import React from 'react'
import { PiStudentBold } from 'react-icons/pi'
import { FaChalkboardTeacher } from 'react-icons/fa'

const Registration = () => {
  return (
    <div className="container" id="registration">
      <div className="row px-5 mx-5 my-5">
        <div className="col-md-4 offset-2 my-5">
          <a href="/UserRegistration">
            <div className="card p-3 lq-red-color border-0 box-shadow align-items-center">
              <FaChalkboardTeacher className="icon" />
              {/* <img src={teacher} alt="classroom" className="img-fluid" width={'50%'} /> */}
              <h5>Teacher Registration</h5>
            </div>
          </a>
        </div>
        <div className="col-md-4 my-5">
          <a href="/StudentRegistration">
            <div className="card p-3 lq-red-color border-0 box-shadow align-items-center">
              <PiStudentBold className="icon" />
              {/* <img src={student} alt="classroom" className="img-fluid" width={'50%'} /> */}
              <h5>Student Registration</h5>
            </div>
          </a>
        </div>
      </div>
    </div>
  )
}
export default Registration
